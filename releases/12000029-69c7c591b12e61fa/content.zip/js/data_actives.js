// ============ 数据：主动技能与互斥进化，效果和描述共用定义 ============
(function(RG){
  const percent=v=>Math.round(v*100),base=id=>RG.ACTIVES[id];
  RG.ACTIVES={
    collapse:{name:'引力坍缩',glyph:'坍',color:'#c084fc',maxLv:3,curve:{damageBase:50,damagePerLevel:16,radiusBase:200,radiusPerLevel:30,cooldownBase:18,cooldownPerLevel:1.5},
      rules:{
  "useActive": {
    "dmg_factor": 0.22,
    "pull": 34,
    "pull_cap": 125,
    "pull_offset": 55,
    "pull_factor": 0.35,
    "length_threshold": 2
  }
},
      damage:lv=>base('collapse').curve.damageBase+lv*base('collapse').curve.damagePerLevel,
      radius:lv=>base('collapse').curve.radiusBase+lv*base('collapse').curve.radiusPerLevel,
      cooldown:lv=>base('collapse').curve.cooldownBase-lv*base('collapse').curve.cooldownPerLevel,
      desc:lv=>'吸拢大范围敌人并造成 '+base('collapse').damage(lv)+' 点基础伤害'},
    overdrive:{name:'超频核心',glyph:'频',color:'#fbbf24',maxLv:3,damageMul:1.4,cooldownMul:.78,curve:{durationBase:5,durationPerLevel:1,cooldownBase:26,cooldownPerLevel:2},
      duration:lv=>base('overdrive').curve.durationBase+lv*base('overdrive').curve.durationPerLevel,
      cooldown:lv=>base('overdrive').curve.cooldownBase-lv*base('overdrive').curve.cooldownPerLevel,
      desc:lv=>{const c=base('overdrive');return '进入超频 '+c.duration(lv)+' 秒：伤害提高'+percent(c.damageMul-1)+'%，攻击间隔缩短'+percent(1-c.cooldownMul)+'%';}},
    aegis:{name:'相位壁垒',glyph:'壁',color:'#38bdf8',maxLv:3,curve:{guardsBase:1,guardsPerLevel:1,invulBase:.65,invulPerLevel:.12,cooldownBase:24,cooldownPerLevel:1.5},
      guards:lv=>base('aegis').curve.guardsBase+lv*base('aegis').curve.guardsPerLevel,
      invul:lv=>base('aegis').curve.invulBase+lv*base('aegis').curve.invulPerLevel,
      cooldown:lv=>base('aegis').curve.cooldownBase-lv*base('aegis').curve.cooldownPerLevel,
      desc:lv=>'获得 '+base('aegis').guards(lv)+' 层临时格挡并短暂无敌'},
    thunder:{name:'召雷',glyph:'雷',color:'#fde047',maxLv:3,range:740,curve:{strikesBase:4,strikesPerLevel:4,damageBase:26,damagePerLevel:10,cooldownBase:24,cooldownPerLevel:2},
      rules:{
  "useActive": {
    "damage_cap": 1800,
    "damage_factor": 0.22,
    "useActive_applyElemArg3": 2
  }
},
      strikes:lv=>base('thunder').curve.strikesBase+lv*base('thunder').curve.strikesPerLevel,
      damage:lv=>base('thunder').curve.damageBase+lv*base('thunder').curve.damagePerLevel,
      cooldown:lv=>base('thunder').curve.cooldownBase-lv*base('thunder').curve.cooldownPerLevel,
      desc:lv=>{const c=base('thunder');return c.range+'范围随机落雷'+c.strikes(lv)+'道，每道基础雷伤'+c.damage(lv)+'\n随时间成长，可触发元素反应；冷却'+c.cooldown(lv)+'秒';}},
    chrono:{name:'时间静止',glyph:'停',color:'#67e8f9',maxLv:3,range:740,curve:{durationBase:1,durationPerLevel:1,bossDuration:[0,.5,.8,1],cooldownBase:32,cooldownPerLevel:2},effect:{vulnerableMul:1.2},
      duration:lv=>base('chrono').curve.durationBase+lv*base('chrono').curve.durationPerLevel,
      bossDuration:lv=>base('chrono').curve.bossDuration[lv],
      cooldown:lv=>base('chrono').curve.cooldownBase-lv*base('chrono').curve.cooldownPerLevel,
      desc:lv=>{const c=base('chrono');return c.range+'范围敌人停行停攻'+c.duration(lv)+'秒，首领'+c.bossDuration(lv)+'秒\n受控易伤'+percent(c.effect.vulnerableMul-1)+'%；敌弹、领域和刷怪继续\n冷却'+c.cooldown(lv)+'秒';}},
  };
  RG.ACTIVE_EVOLVE={collapse:{req:'magnet',branches:[
    {id:'horizon',name:'事件视界',duration:3,period:.5,pulse:.25,mobPull:60,bossPull:8,get desc(){return '吸拢并命中后，原地留下'+this.duration+'秒黑洞\n每'+this.period+'秒造成本次基础伤害'+percent(this.pulse)+'%，持续吸附';}},
    {id:'starburst',name:'星核爆裂',duration:.5,multiplier:3,get desc(){return '吸拢后延迟'+this.duration+'秒在原地引爆\n本次基础伤害×'+this.multiplier+'，取代原即时伤害';}}
  ]},overdrive:{req:'frenzy',branches:[
    {id:'overload',name:'过载熔炉',get desc(){return '超频'+this.duration+'秒，常规攻击伤+'+percent(this.damageMul-1)+'%，间隔-'+percent(1-base('overdrive').cooldownMul)+'%\n结束后虚弱'+this.weakness+'秒，攻击频率-'+percent(1-this.weaknessFrequency)+'%\n超频及虚弱期间不能重放';},duration:12,damageMul:1.55,weakness:2,weaknessFrequency:.7},
    {id:'perpetual',name:'永动机',get damageMul(){return base('overdrive').damageMul;},get desc(){return '超频'+this.duration+'秒，常规攻击伤+'+percent(this.damageMul-1)+'%，间隔-'+percent(1-base('overdrive').cooldownMul)+'%\n有效击杀续'+this.extension+'秒，总时长最多'+this.total+'秒\n超频期间不能重放';},duration:8,extension:.5,total:15}
  ]},aegis:{req:'shieldcore',branches:[
    {id:'void',name:'虚空领域',duration:5,radius:140,get desc(){return '保留'+base('aegis').guards(base('aegis').maxLv)+'层相位格挡，身周'+this.radius+'范围消敌弹\n持续'+this.duration+'秒或格挡耗尽即结束\n不消光束/场地，消弹不消耗格挡';}},
    {id:'mirror',name:'反相镜面',duration:5,reflectionMul:1,get desc(){return '保留'+base('aegis').guards(base('aegis').maxLv)+'层相位格挡，真正挡住敌弹才反射\n原弹伤害'+percent(this.reflectionMul)+'%，不暴击/附魔/递归\n持续'+this.duration+'秒或格挡耗尽即结束';}}
  ]}};
  RG.DATA_ACTIVES_VER="v12027";
  RG.freezeConfig(RG.ACTIVES);RG.freezeConfig(RG.ACTIVE_EVOLVE);
})(window.RG);
