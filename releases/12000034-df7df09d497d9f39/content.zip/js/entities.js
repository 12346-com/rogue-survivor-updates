// ============ 实体逻辑 v6.1:秘境/分身守卫/惩戒光环/品质卡池/节奏放缓 ============
(function (RG) {
  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgBALANCECombatCommon=RG.BALANCE.combat.common,
    cfgBALANCECombatStrikeHammer=RG.BALANCE.combat.strikeHammer,
    cfgOATH_NODESSin_lustConversion=RG.OATH_NODES.sin_lust.rules.conversion,
    cfgBALANCECombatFriendlyShot=RG.BALANCE.combat.friendlyShot,
    cfgBALANCECombatPuppetAttack=RG.BALANCE.combat.puppetAttack,
    cfgBOSS_SKILLSEyePuppetAttack=RG.BOSS_SKILLS.eye.puppetAttack,
    cfgOATH_NODESSin_wrathKillEnemy=RG.OATH_NODES.sin_wrath.rules.killEnemy,
    cfgPASSIVESSporesKillEnemy=RG.PASSIVES.spores.rules.killEnemy,
    cfgBALANCECombatKillEnemy=RG.BALANCE.combat.killEnemy,
    cfgPASSIVESRicochetKillEnemy=RG.PASSIVES.ricochet.rules.killEnemy,
    cfgPASSIVESCrystalKillEnemy=RG.PASSIVES.crystal.rules.killEnemy,
    cfgPASSIVESAshKillEnemy=RG.PASSIVES.ash.rules.killEnemy,
    cfgPASSIVESSlaughterKillEnemy=RG.PASSIVES.slaughter.rules.killEnemy,
    cfgETYPESSplitterKillEnemy=RG.ETYPES.splitter.rules.killEnemy,
    cfgETYPESSporepodKillEnemy=RG.ETYPES.sporepod.rules.killEnemy,
    cfgPASSIVESLoyalKillEnemy=RG.PASSIVES.loyal.rules.killEnemy,
    cfgBOSS_SKILLSShadowKillEnemy=RG.BOSS_SKILLS.shadow.killEnemy,
    cfgBALANCECombatOrbsHeal=RG.BALANCE.combat.orbsHeal,
    cfgBALANCECombatReceiveDamage=RG.BALANCE.combat.receiveDamage,
    cfgBALANCECombatElementResist=RG.BALANCE.combat.elementResist,
    cfgBALANCECombatChainReaction=RG.BALANCE.combat.chainReaction,
    cfgBALANCECombatLavaZone=RG.BALANCE.combat.lavaZone,
    cfgBALANCECombatResolveReaction=RG.BALANCE.combat.resolveReaction,
    cfgBALANCECombatElemReaction=RG.BALANCE.combat.elemReaction,
    cfgPASSIVESReactionchainApplyElem=RG.PASSIVES.reactionchain.rules.applyElem,
    cfgBALANCECombatApplyElem=RG.BALANCE.combat.applyElem,
    cfgBALANCECombatWeaponElementHit=RG.BALANCE.combat.weaponElementHit,
    cfgBALANCECombatHurtEnemy=RG.BALANCE.combat.hurtEnemy,
    cfgETYPESBulwarkHurtEnemy=RG.ETYPES.bulwark.rules.hurtEnemy,
    cfgBOSS_SKILLSFurnaceHurtEnemy=RG.BOSS_SKILLS.furnace.hurtEnemy,
    cfgPASSIVESShardHurtEnemy=RG.PASSIVES.shard.rules.hurtEnemy,
    cfgPASSIVESEchoHurtEnemy=RG.PASSIVES.echo.rules.hurtEnemy,
    cfgPASSIVESPetrifyHurtEnemy=RG.PASSIVES.petrify.rules.hurtEnemy,
    cfgPASSIVESEmberHurtEnemy=RG.PASSIVES.ember.rules.hurtEnemy,
    cfgBALANCECombatReflectPhaseBullet=RG.BALANCE.combat.reflectPhaseBullet,
    cfgBALANCECombatHurtPlayer=RG.BALANCE.combat.hurtPlayer,
    cfgPASSIVESPrismHurtPlayer=RG.PASSIVES.prism.rules.hurtPlayer,
    cfgPASSIVESGoldbellHurtPlayer=RG.PASSIVES.goldbell.rules.hurtPlayer,
    cfgPASSIVESInjuryHurtPlayer=RG.PASSIVES.injury.rules.hurtPlayer,
    cfgPASSIVESReviveHurtPlayer=RG.PASSIVES.revive.rules.hurtPlayer,
    cfgBALANCECombatSettleRunStats=RG.BALANCE.combat.settleRunStats,
    cfgBALANCECombatGameOver=RG.BALANCE.combat.gameOver,
    cfgBALANCECombatNovaPulse=RG.BALANCE.combat.novaPulse,
    cfgBALANCECombatBossSplit=RG.BALANCE.combat.bossSplit,
    cfgBALANCECombatFireHBeam=RG.BALANCE.combat.fireHBeam,
    cfgBALANCECombatHomingShot=RG.BALANCE.combat.homingShot,
    cfgBALANCECombatBigShots=RG.BALANCE.combat.bigShots,
    cfgBALANCECombatRadialWaves=RG.BALANCE.combat.radialWaves,
    cfgBALANCECombatBossTeleport=RG.BALANCE.combat.bossTeleport,
    cfgBALANCECombatBossRealSplit=RG.BALANCE.combat.bossRealSplit,
    cfgBALANCECombatUpdateEnvyPower=RG.BALANCE.combat.updateEnvyPower,
    cfgBOSS_SKILLSGolemUpdateEnvyPower=RG.BOSS_SKILLS.golem.updateEnvyPower,
    cfgBOSS_SKILLSEyeUpdateEnvyPower=RG.BOSS_SKILLS.eye.updateEnvyPower,
    cfgETYPESHomingUpdateEnvyPower=RG.ETYPES.homing.rules.updateEnvyPower,
    cfgBOSS_SKILLSGluttonyUpdateEnvyPower=RG.BOSS_SKILLS.gluttony.updateEnvyPower,
    cfgBALANCECombatRepulseEnemies=RG.BALANCE.combat.repulseEnemies,
    cfgPASSIVESMeteorUpdateAutoCards=RG.PASSIVES.meteor.rules.updateAutoCards,
    cfgPASSIVESPoisontrailUpdateAutoCards=RG.PASSIVES.poisontrail.rules.updateAutoCards,
    cfgPASSIVESEcosystemUpdateAutoCards=RG.PASSIVES.ecosystem.rules.updateAutoCards,
    cfgPASSIVESPushwaveUpdateAutoCards=RG.PASSIVES.pushwave.rules.updateAutoCards,
    cfgPASSIVESScapegoatUpdateAutoCards=RG.PASSIVES.scapegoat.rules.updateAutoCards,
    cfgPASSIVESHolylightUpdateAutoCards=RG.PASSIVES.holylight.rules.updateAutoCards,
    cfgBALANCECombatUpdatePlayerMovement=RG.BALANCE.combat.updatePlayerMovement,
    cfgBOSS_SKILLSShadowUpdatePlayerMovement=RG.BOSS_SKILLS.shadow.updatePlayerMovement,
    cfgBALANCECombatUpdateWeapons=RG.BALANCE.combat.updateWeapons,
    cfgWEAPONSLaserUpdateWeapons=RG.WEAPONS.laser.rules.updateWeapons,
    cfgWEAPONSOrbitUpdateWeapons=RG.WEAPONS.orbit.rules.updateWeapons,
    cfgWEAPONSNovaUpdateWeapons=RG.WEAPONS.nova.rules.updateWeapons,
    cfgWEAPONSScytheUpdateWeapons=RG.WEAPONS.scythe.rules.updateWeapons,
    cfgWEAPONSSpinnerUpdateWeapons=RG.WEAPONS.spinner.rules.updateWeapons,
    cfgWEAPONSKiwaveUpdateWeapons=RG.WEAPONS.kiwave.rules.updateWeapons,
    cfgWEAPONSBeamUpdateWeapons=RG.WEAPONS.beam.rules.updateWeapons,
    cfgWEAPONSVialUpdateWeapons=RG.WEAPONS.vial.rules.updateWeapons,
    cfgWEAPONSHammerUpdateWeapons=RG.WEAPONS.hammer.rules.updateWeapons,
    cfgWEAPONSScatterUpdateWeapons=RG.WEAPONS.scatter.rules.updateWeapons,
    cfgBALANCECombatUpdateEnemies=RG.BALANCE.combat.updateEnemies,
    cfgPASSIVESPrismUpdateEnemies=RG.PASSIVES.prism.rules.updateEnemies,
    cfgETYPESAmplifierUpdateEnemies=RG.ETYPES.amplifier.rules.updateEnemies,
    cfgETYPESStalkerUpdateEnemies=RG.ETYPES.stalker.rules.updateEnemies,
    cfgETYPESHowlerUpdateEnemies=RG.ETYPES.howler.rules.updateEnemies,
    cfgETYPESHoundUpdateEnemies=RG.ETYPES.hound.rules.updateEnemies,
    cfgETYPESBulwarkUpdateEnemies=RG.ETYPES.bulwark.rules.updateEnemies,
    cfgETYPESFlamerUpdateEnemies=RG.ETYPES.flamer.rules.updateEnemies,
    cfgETYPESSmasherUpdateEnemies=RG.ETYPES.smasher.rules.updateEnemies,
    cfgETYPESVoltUpdateEnemies=RG.ETYPES.volt.rules.updateEnemies,
    cfgETYPESHealerUpdateEnemies=RG.ETYPES.healer.rules.updateEnemies,
    cfgETYPESBomberUpdateEnemies=RG.ETYPES.bomber.rules.updateEnemies,
    cfgBALANCECombatUpdatePlayerBullets=RG.BALANCE.combat.updatePlayerBullets,
    cfgBALANCECombatMove=RG.BALANCE.combat.move,
    cfgPASSIVESScavengerUpdateMeadowMob=RG.PASSIVES.scavenger.rules.updateMeadowMob,
    cfgETYPESPhantasmUpdateMeadowMob=RG.ETYPES.phantasm.rules.updateMeadowMob,
    cfgETYPESWarderUpdateMeadowMob=RG.ETYPES.warder.rules.updateMeadowMob,
    cfgETYPESMortarUpdateMeadowMob=RG.ETYPES.mortar.rules.updateMeadowMob,
    cfgETYPESCrucibleUpdateMeadowMob=RG.ETYPES.crucible.rules.updateMeadowMob,
    cfgETYPESTetherUpdateMeadowMob=RG.ETYPES.tether.rules.updateMeadowMob,
    cfgBALANCECombatUpdate=RG.BALANCE.combat.update,
    cfgPASSIVESDebtUpdate=RG.PASSIVES.debt.rules.update,
    cfgPASSIVESPhantomUpdate=RG.PASSIVES.phantom.rules.update,
    cfgPASSIVESHeartUpdate=RG.PASSIVES.heart.rules.update,
    cfgBALANCECombatHit=RG.BALANCE.combat.hit;

  const enemyCause=(e,action)=>({source:(e.name||RG.ETYPES[e.type]?.name||'敌人')+' · '+action,attacker:e,element:e.type==='volt'?'elec':null});
  function prepareStalk(e,target){
    const skill=RG.MOB_SKILLS.stalker,a=Math.atan2(target.y-e.y,target.x-e.x)+(Math.random()<.5?1:-1)*1.2;
    // 在蓄势开始时锁定目标位置，并先解算墙体，标记和实际落点始终一致。
    const landing={x:target.x+Math.cos(a)*skill.offset,y:target.y+Math.sin(a)*skill.offset,r:e.r};
    RG.pushOutOfWalls(landing,RG.walls);
    landing.x=clamp(landing.x,-ARENA_R-60,ARENA_R+60);landing.y=clamp(landing.y,-ARENA_R-60,ARENA_R+60);
    e.stalkX=landing.x;e.stalkY=landing.y;e.stalkRadius=e.r+target.r;e.stalkWind=skill.wind;e.stalkCd=skill.cd;
    RG.addText(e.x,e.y-e.r-8,'潜袭预警','#ff5470',12);
  }
  RG.enemyHitSource=enemyCause;
  const { rand, clamp, dist2, pick, TAU } = RG;
  const ARENA_R = cfgBALANCECombatCommon.ARENA_R;
  const ATTACK_BUDGET=8, DELAY_LIMIT=64;
  let pendingFinalBoss=null;
  const bulletHits=[];
  // 最多补发八次；保留超时余量，但不在卡顿后无限追赶历史攻击。
  function advanceCd(owner,key,period){owner[key]=(owner[key]||0)+Math.max(.01,period);}
  function segmentDistance2(ax,ay,bx,by,x,y){const dx=bx-ax,dy=by-ay,t=clamp(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy||1),0,1);return dist2(ax+dx*t,ay+dy*t,x,y);}
  function pushDelayed(queue,item){if(queue.length<DELAY_LIMIT)queue.push(item);}
  function fireBoltVolley(P,st,baseA,n){
    for(let i=0;i<n;i++){const a=baseA+(i-(n-1)/2)*(st.spread||.14);RG.bullets.push({x:P.x,y:P.y,vx:Math.cos(a)*st.speed,vy:Math.sin(a)*st.speed,r:RG.BALANCE.combat.fireBoltVolley.r_factor*P.bulletR,dmg:st.dmg,pierce:st.pierce||0,life:st.range/st.speed,hitSet:new Set(),col:st.evo?'#ffd166':null,weapon:'bolt'});}
  }

  function fireSeekerVolley(P, st) {
    const n=st.count+P.extraShots, target=nearestEnemy(P.x,P.y,st.targetRange);
    const aim=target?Math.atan2(target.y-P.y,target.x-P.x):P.face;
    for(let i=0;i<n;i++){
      const a=aim+(i-(n-1)/2)*.18;
      RG.bullets.push({x:P.x,y:P.y,vx:Math.cos(a)*st.speed,vy:Math.sin(a)*st.speed,r:RG.BALANCE.combat.fireSeekerVolley.r_factor*P.bulletR,dmg:st.dmg,pierce:0,life:st.life,seek:true,targetRange:st.targetRange,turn:st.turn,speed:st.speed,hitSet:new Set(),col:st.evo?"#e9d5ff":null,weapon:"seeker"});
    }
    RG.playSfxVar("shoot",.78,.05);
  }
  RG.hammerHits = function (attack, e) {
    const dx=e.x-attack.x,dy=e.y-attack.y,ca=Math.cos(attack.a),sa=Math.sin(attack.a);
    const along=dx*ca+dy*sa,side=-dx*sa+dy*ca;
    const ex=along-clamp(along,0,attack.length),ey=side-clamp(side,-attack.width/2,attack.width/2);
    return ex*ex+ey*ey <= e.r*e.r;
  };
  function strikeHammer(attack, st) {
    RG.slashes.push({...attack,rect:true,life:.3,maxLife:.3,col:"#fbbf24"});
    let hit=false;
    for(const e of RG.enemies)if(!e.dead&&!e.dying&&RG.hammerHits(attack,e)){
      const knock=st.heavyKnock?cfgBALANCECombatStrikeHammer.knock:cfgBALANCECombatStrikeHammer.knock_2;
      RG.hurtEnemy(e,st.dmg,Math.cos(attack.a)*knock,Math.sin(attack.a)*knock,false,false,false,"hammer");hit=true;
    }
    if(hit)RG.requestHitStop(.06);
    RG.cam.shake=Math.max(RG.cam.shake||0,9);RG.playSfx("boom",.66);
  }

  // H5:对局生命周期已迁移至 systems_run.js。
  // H5:成长与构筑已迁移至 systems_growth.js。
  // H5:敌人、首领与场景生成已迁移至 systems_spawning.js。
  // ---------- 死亡与受击 ----------
  RG.tryConvertPuppet = function(e) {
    const P=RG.P;
    if(!P||!e||P.sinId!=="sin_lust"||e.isClone||e.isEcho) return false;
    const allies=RG.allies||(RG.allies=[]);
    if(allies.filter(a=>a.puppet&&!a.dead&&a.hp>0).length>=RG.summonLimit(cfgOATH_NODESSin_lustConversion.limit)) return false;
    if(Math.random()>=(e.boss ? cfgOATH_NODESSin_lustConversion.bossChance : cfgOATH_NODESSin_lustConversion.mobChance))return false;
    const hp=e.maxhp*(e.boss ? cfgOATH_NODESSin_lustConversion.bossHpMul : cfgOATH_NODESSin_lustConversion.mobHpMul);
    allies.push({x:e.x,y:e.y,r:e.r,hp,maxhp:hp,dmg:e.dmg*cfgOATH_NODESSin_lustConversion.damageMul,speed:e.speed,
      fireT:cfgOATH_NODESSin_lustConversion.firstAttack,source:'lust',puppet:true,converted:true,type:e.type,boss:!!e.boss,bossKind:e.bossKind,face:0,flash:0});
    if(Math.random()<cfgOATH_NODESSin_lustConversion.healthCostChance&&P.hp>cfgOATH_NODESSin_lustConversion.healthFloor)P.hp=Math.max(cfgOATH_NODESSin_lustConversion.healthFloor,P.hp-cfgOATH_NODESSin_lustConversion.healthCost);
    RG.addText(e.x,e.y-e.r-20,e.boss?"BOSS仆人":"仆人","#4ade80",13);
    return true;
  };
  function friendlyShot(from,a,dmg,seek=false) {
    RG.bullets.push({x:from.x,y:from.y,vx:Math.cos(a)*cfgBALANCECombatFriendlyShot.vx_factor,vy:Math.sin(a)*cfgBALANCECombatFriendlyShot.vy_factor,r:cfgBALANCECombatFriendlyShot.r,dmg,
      pierce:0,life:cfgBALANCECombatFriendlyShot.life,hitSet:new Set(),col:"#4ade80",raw:true,summon:true,seek,turn:cfgBALANCECombatFriendlyShot.turn,speed:cfgBALANCECombatFriendlyShot.speed});
  }
  // 仅基础形态：地震、凝视、追踪和辐射弹；不复制狂暴、召唤、领域或阶段转换。
  RG.puppetAttack = function(al,tgt) {
    const a=Math.atan2(tgt.y-al.y,tgt.x-al.x),d=Math.hypot(tgt.x-al.x,tgt.y-al.y);
    al.fireT=al.boss?cfgBALANCECombatPuppetAttack.fireT:cfgBALANCECombatPuppetAttack.fireT_2;
    if(al.boss&&al.bossKind==="golem") {
      RG.rings.push({x:al.x,y:al.y,r:8,maxR:180,life:.3,maxLife:.3,color:"#4ade80"});
      for(const e of RG.enemies)if(!e.dead&&!e.dying&&Math.hypot(e.x-al.x,e.y-al.y)<RG.BOSS_SKILLS.golem.puppetAttack.puppetAttack_offset+e.r)RG.dealPure(e,al.dmg,false,false,undefined,{summon:true});
    } else if(al.boss&&al.bossKind==="eye") {
      RG.beams.push({x:al.x,y:al.y,a,len:400,life:.18,maxLife:.18,w:6,chainCol:true,color:"#4ade80"});
      for(const e of RG.enemies){const dx=e.x-al.x,dy=e.y-al.y,along=dx*Math.cos(a)+dy*Math.sin(a),side=Math.abs(dy*Math.cos(a)-dx*Math.sin(a));if(!e.dead&&!e.dying&&along>0&&along<cfgBOSS_SKILLSEyePuppetAttack.along_threshold&&side<e.r+cfgBOSS_SKILLSEyePuppetAttack.puppetAttack_offset)RG.dealPure(e,al.dmg,false,false,undefined,{summon:true});}
    } else if(al.boss) {
      const seeking=["shadow","domain","guard"].includes(al.bossKind),n=seeking?cfgBALANCECombatPuppetAttack.n:cfgBALANCECombatPuppetAttack.n_2;
      for(let i=0;i<n;i++)friendlyShot(al,a+(seeking?(i-cfgBALANCECombatPuppetAttack.puppetAttack_offset)*cfgBALANCECombatPuppetAttack.puppetAttack_factor:i/n*TAU),al.dmg,seeking);
    } else if(RG.ETYPES[al.type]?.ranged||["flamer","crystal"].includes(al.type))friendlyShot(al,a,al.dmg);
    else if(d<al.r+tgt.r+cfgBALANCECombatPuppetAttack.puppetAttack_offset_2)RG.dealPure(tgt,al.dmg,false,false,undefined,{summon:true});
    else al.fireT=cfgBALANCECombatPuppetAttack.fireT_3;
  };

  RG.killEnemy = function (e) {
    if (!e || e.dead) return;
    if(e.workshopHole){RG.closeWorkshopHole(e,true);return;}
    if(e.workshopWorm){e.dead=true;return;}
    if(e.deathDamageSource&&damageSource!==e.deathDamageSource)return RG.withDamageSource(e.deathDamageSource,()=>RG.killEnemy(e));
    const mainBoss=RG.run.boss===e,playerKill=damageSource!=='enemyCrossfire';
    if(!playerKill&&RG.run.crossfireStats)RG.run.crossfireStats.kills++;
    if(e.boss)RG.checkpointPending=true;
    e.dead = true; RG.run.kills++;
    const player=RG.P,bloodLv=player.passives.bloodheal;
    if(playerKill&&bloodLv&&!e.isClone&&!e.isEcho&&player.hp>0&&player.hp/player.maxhp<RG.lowHpThreshold(RG.PASSIVES.bloodheal.threshold,player)){
      if(player.sinId==='sin_wrath'&&player.healBan&&!e.noCoin&&e.xp>0){player.wrathBloodStacks=Math.min(cfgOATH_NODESSin_wrathKillEnemy.wrathBloodStacks_cap,(player.wrathBloodStacks||0)+bloodLv);RG.refreshStatus(player,'wrathBloodT',cfgOATH_NODESSin_wrathKillEnemy.killEnemy_refreshStatusArg3);}
      else if(!player.healBan&&!player.healBlocked&&!player.hpLocked){const gain=Math.min(player.maxhp-player.hp,RG.PASSIVES.bloodheal.heals[bloodLv]);if(gain>0){player.hp+=gain;RG.addText(player.x,player.y-30,'浴血续命 +'+gain,'#4ade80',13,{pop:true});}}
    }
    if(playerKill)RG.extendOverdrive(e);
    // 孢子毒雾与其施毒/衍生击杀不再产雾；同屏严格八片，不替换已生效的圈。
    const spores=playerKill&&RG.P.passives.spores,sporeDef=RG.PASSIVES.spores;
    if(spores&&e.el?.poison>0&&e.elDmg?.poison>0&&!e.poisonSpore&&e.deathDamageSource!=='spore'&&RG.vials.filter(v=>v.poisonSpore&&v.t>0).length<cfgPASSIVESSporesKillEnemy.length_threshold){
      RG.vials.push({x:e.x,y:e.y,r:sporeDef.radius[spores],t:cfgPASSIVESSporesKillEnemy.t,arm:0,tick:cfgPASSIVESSporesKillEnemy.tick,dmg:sporeDef.damage[spores]*(1+Math.min(RG.run.t,cfgPASSIVESSporesKillEnemy.dmg_cap)/60*cfgPASSIVESSporesKillEnemy.dmg_factor),noSlow:true,poison:true,poisonSpore:true});
    }
    if(e.type==='amplifier')RG.clearAmplifierSource(e);
    if(e.ampSource)setAmplifier(e,null);   // 转化仆人不把敌方临时光环固化成永久基础伤害。
    if(e.frost)RG.clearFrostBoss(e);
    if(RG.isWorkshopBoss(e))RG.clearWorkshopBoss(e);
    if(playerKill)RG.tryConvertPuppet(e);
    // 互伤只计本局击杀，不积累可驱动连击风暴的玩家连击。
    if(playerKill){
      // 击杀连击衰减计数
      RG.combo = (RG.combo || 0) + 1; RG.comboT = cfgBALANCECombatKillEnemy.comboT;
      if (RG.unlockAchievement) {
        RG.unlockAchievement("first_blood");
        if (RG.combo === cfgBALANCECombatKillEnemy.killEnemy) RG.unlockAchievement("combo_50");
      }
      // v11.0 多杀:0.4s 内连杀计数
      RG.killTimes = (RG.killTimes || []).filter(t => (RG.run.t || 0) - t < cfgBALANCECombatKillEnemy.killTimes_threshold);
      RG.killTimes.push(RG.run.t || 0);
      if (RG.killTimes.length >= cfgBALANCECombatKillEnemy.length_threshold_2) {
        const mk = RG.killTimes.length;
        const label = mk >= cfgBALANCECombatKillEnemy.label_threshold ? "灭世 ×" + mk : mk >= cfgBALANCECombatKillEnemy.label_threshold_2 ? "屠杀 ×" + mk : "多杀 ×" + mk;
        RG.addText(RG.P.x, RG.P.y - 48, label, "#ff7b7b", mk >= 4 ? 20 : 17, { pop: true, life: 1.0 });
        if (mk >= cfgBALANCECombatKillEnemy.mk_threshold) RG.requestHitStop(0.05);
        if (mk >= cfgBALANCECombatKillEnemy.mk_threshold_2 && RG.unlockAchievement) RG.unlockAchievement("multikill_5");

      }
      if (RG.combo === cfgBALANCECombatKillEnemy.killEnemy_2 || RG.combo === cfgBALANCECombatKillEnemy.killEnemy_3 || RG.combo === cfgBALANCECombatKillEnemy.killEnemy || RG.combo === cfgBALANCECombatKillEnemy.killEnemy_4) {
        const title=RG.combo===cfgBALANCECombatKillEnemy.title?"☄ 湮灭 100!":RG.combo===cfgBALANCECombatKillEnemy.title_2?"⚡ 横扫 50!":"⚡ "+RG.combo+" 连击!";
        RG.addText(RG.P.x,RG.P.y-56,title,RG.combo>=100?"#ff5470":"#ffd166",RG.combo>=50?22:18,{pop:true,life:1.1});
        RG.cam.shake=Math.max(RG.cam.shake||0,RG.combo>=100?12:RG.combo>=50?8:4);
        RG.addSpark(RG.P.x, RG.P.y - cfgBALANCECombatKillEnemy.killEnemy_offset, "crit", RG.combo >= cfgBALANCECombatKillEnemy.combo_threshold ? "#ff5470" : "#ffd166");
      }
    }
    // proc:弹射之刃(击杀弹射)
    const ric = playerKill&&RG.passiveValue(RG.P,"ricochet");
    // v8.15:0.5 秒触发上限(后期怪海不再连环弹射);弹射弹 noFeel,命中不再触发震动/顿帧(玩家反馈"延迟震动")
    if (ric && !e.boss && RG.run.t - (RG.ricLast ?? -Infinity) >= cfgPASSIVESRicochetKillEnemy.range_threshold && Math.random() < Math.min(1,ric)) {
      RG.ricLast = RG.run.t;
      let shots = 0;
      for (const o of RG.enemies) {
        if (o.dead || o === e || shots >= cfgPASSIVESRicochetKillEnemy.shots_threshold) continue;
        if (Math.hypot(o.x - e.x, o.y - e.y) < cfgPASSIVESRicochetKillEnemy.range_threshold_2) {
          const ba = Math.atan2(o.y - e.y, o.x - e.x);
          // 弹射属于衍生伤害：基础倍率只结算一次，不再暴击或触发命中特效；时间成长止于首次终焉。
          RG.bullets.push({ x: e.x, y: e.y, vx: Math.cos(ba) * cfgPASSIVESRicochetKillEnemy.vx_factor, vy: Math.sin(ba) * cfgPASSIVESRicochetKillEnemy.vy_factor, r: cfgPASSIVESRicochetKillEnemy.r, dmg: (cfgPASSIVESRicochetKillEnemy.dmg_offset + Math.min(RG.run.t, cfgPASSIVESRicochetKillEnemy.dmg_cap) * cfgPASSIVESRicochetKillEnemy.dmg_factor_2) * RG.playerDamageMul(), pierce: 0, life: cfgPASSIVESRicochetKillEnemy.life, hitSet: new Set(), col: "#c4b5fd", noFeel: true, raw:true, source:"ricochet" });
          shots++;
        }
      }
    }
    // proc:凝晶碎裂(冰冻敌人死亡→冰系范围碎裂,raw 基准)
    if (playerKill && RG.P.passives.crystal && e.frozen > 0) {
      const lv = RG.P.passives.crystal, rr = Math.min(cfgPASSIVESCrystalKillEnemy.rr_cap, cfgPASSIVESCrystalKillEnemy.rr_offset + cfgPASSIVESCrystalKillEnemy.rr_factor * (lv - 1));   // v8.15:半径缩小且 85 封顶(玩家反馈)
      const dmg = (cfgPASSIVESCrystalKillEnemy.dmg_offset + RG.P.level * cfgPASSIVESCrystalKillEnemy.dmg_factor) * cfgPASSIVESCrystalKillEnemy.dmg_factor_2 * (1 + RG.run.t / 60 * cfgPASSIVESCrystalKillEnemy.dmg_factor_3) * RG.playerDamageMul();
      RG.rings.push({ x: e.x, y: e.y, r: 8, maxR: rr, life: 0.25, maxLife: 0.25, color: "#7dd3fc" });
      for (const o of RG.enemies) {
        if (o.dead || o === e) continue;
        if (Math.hypot(o.x - e.x, o.y - e.y) < rr + o.r) RG.dealElement(o,dmg*RG.playerElementMul(RG.P),"ice");
      }
      RG.addText(e.x, e.y - e.r - 10, "凝晶碎裂!", "#7dd3fc", 13);
    }
    // proc:灰烬爆发(燃烧敌人死亡→火系范围爆开,raw 基准)
    if (playerKill && RG.P.passives.ash && e.el?.fire > 0 && (e.burnDps || 0) > 0) {
      const lv = RG.P.passives.ash, rr = Math.min(cfgPASSIVESAshKillEnemy.rr_cap, cfgPASSIVESAshKillEnemy.rr_offset + cfgPASSIVESAshKillEnemy.rr_factor * (lv - 1));   // v8.15:半径缩小且 75 封顶(玩家反馈)
      const dmg = (cfgPASSIVESAshKillEnemy.dmg_offset + RG.P.level * cfgPASSIVESAshKillEnemy.dmg_factor) * cfgPASSIVESAshKillEnemy.dmg_factor_2 * (1 + RG.run.t / 60 * cfgPASSIVESAshKillEnemy.dmg_factor_3) * RG.playerDamageMul();
      RG.rings.push({ x: e.x, y: e.y, r: 8, maxR: rr, life: 0.25, maxLife: 0.25, color: "#fb923c" });
      for (const o of RG.enemies) {
        if (o.dead || o === e) continue;
        if (Math.hypot(o.x - e.x, o.y - e.y) < rr + o.r) RG.dealElement(o,dmg*RG.playerElementMul(RG.P),"fire");
      }
      RG.addText(e.x, e.y - e.r - 10, "灰烬爆发!", "#fb923c", 13);
    }
    // 顿帧:精英/BOSS 击杀更有分量
    if (e.boss) RG.requestHitStop(e.final ? 0.2 : 0.14);
    else if (e.elite) RG.requestHitStop(0.06);
    RG.burst(e.x, e.y, e.boss ? "#a855f7" : RG.ETYPES[e.type].color, e.boss ? 40 : e.elite ? 18 : 7, e.boss ? 260 : 150);
    if(playerKill){
      RG.killStreak = RG.combo;
      RG.comboKills=(RG.comboKills||[]).filter(t=>(RG.run.t||0)-t<cfgBALANCECombatKillEnemy.comboKills_threshold);
      RG.comboKills.push(RG.run.t||0);
      RG.comboBurst(RG.comboKills.length);   // 屏幕连击仍保留原2.5秒窗口与视觉冷却。
      if(RG.playKillFeedback)RG.playKillFeedback();
      else RG.playSfx("kill",RG.comboFeedback(RG.comboKills.length).pitch);   // 无音频模块的测试入口仍能安全运行。
    }else RG.playSfx("kill");
    // 屠戮意志:每 50 杀 → 伤害 +1%，最多 100 层。
    if (playerKill&&RG.P.passives.slaughter&&!e.isClone&&!e.isEcho) {
      RG.run.slaughN = (RG.run.slaughN || 0) + 1;
      RG.run.slaughterStacks = RG.run.slaughterStacks || 0;
      if (RG.run.slaughN >= cfgPASSIVESSlaughterKillEnemy.slaughN_threshold && RG.run.slaughterStacks < cfgPASSIVESSlaughterKillEnemy.slaughterStacks_threshold) {
        RG.run.slaughN -= cfgPASSIVESSlaughterKillEnemy.slaughN; RG.run.slaughterStacks++; RG.P.dmgMul *= cfgPASSIVESSlaughterKillEnemy.dmgMul;
        const n=RG.run.slaughterStacks,milestone=n===25?'25层 · 攻频+3%':n===50?'50层 · 暴率+3点':n===100?'100层 · 输出+5%':'+1% 伤害';
        RG.addText(RG.P.x, RG.P.y - 40, '屠戮意志 '+milestone, "#f87171", 13);
      }
    }
    // 词缀死亡效果
    if (e.affix === "boom") {
      RG.rings.push({ x: e.x, y: e.y, r: 14, maxR: 130, life: 0.3, maxLife: 0.3, color: "#fb923c" });
      if (dist2(e.x, e.y, RG.P.x, RG.P.y) < cfgBALANCECombatKillEnemy.killEnemy_factor * cfgBALANCECombatKillEnemy.killEnemy_factor) RG.hurtPlayer(e.dmg * cfgBALANCECombatKillEnemy.killEnemy_factor_2,false,false,enemyCause(e,'死亡爆炸'));
    }
    if (e.affix === "split" && e.type !== "splitter") {
      for (let i = 0; i < RG.SPAWN_COUNTS.affixSplit; i++) {
        const m = RG.spawnEnemy(e.type, false);
        m.x = e.x + rand(-36, 36); m.y = e.y + rand(-36, 36);
        m.hp *= cfgETYPESSplitterKillEnemy.hp; m.maxhp *= cfgETYPESSplitterKillEnemy.maxhp; m.r *= cfgETYPESSplitterKillEnemy.r; m.xp = Math.max(1, Math.round(m.xp * cfgETYPESSplitterKillEnemy.xp_factor));
      }
      RG.addText(e.x, e.y - e.r - 12, "分裂!", "#c4b5fd", 13);
    }
    // 召唤型死亡:清巢(召唤物一并消散,给击杀正反馈)
    if (e.minions) for (const m of e.minions) if (!m.dead) { m.dead = true; RG.burst(m.x, m.y, "#8b5cf6", 5, 80); }
    // 母巢生物:死亡裂解为幼体(与"分"词缀取较高值不叠加;幼体不再裂)——v8.5 幼体更快更硬,是贴脸小虫不是经验包
    if(e.type==='sporepod'&&RG.hazards.filter(h=>h.meadow&&!h.dead).length<cfgETYPESSporepodKillEnemy.length_threshold){
      RG.hazards.push({x:e.x,y:e.y,r:cfgETYPESSporepodKillEnemy.r,phase:'warn',t:cfgETYPESSporepodKillEnemy.t,dur:cfgETYPESSporepodKillEnemy.dur,hitCd:0,dmg:e.dmg,meadow:true,source:'虚空孢囊 · 孢子爆裂'});
    }
    if (e.type === "crystal") {
      RG.rings.push({ x: e.x, y: e.y, r: 8, maxR: 100, life: 0.3, maxLife: 0.3, color: "#a5f3fc" });
      for (const o of RG.enemies) {
        if (o.dead || o === e) continue;
        if (Math.hypot(o.x - e.x, o.y - e.y) < cfgPASSIVESCrystalKillEnemy.killEnemy_offset + o.r && !o.boss) RG.applyIceFreeze(o,cfgPASSIVESCrystalKillEnemy.killEnemy_applyIceFreezeArg2);
      }
      if (dist2(e.x, e.y, RG.P.x, RG.P.y) < 100 * 100 && RG.applyPlayerDebuff({slowT:cfgPASSIVESCrystalKillEnemy.slowT})) RG.addText(RG.P.x, RG.P.y + 18, "结晶寒意!", "#a5f3fc", 12);
    }
    if (e.type === "splitter" && (e.splitGeneration||0)<(e.splitLimit??(e.elite?RG.MOB_SKILLS.splitter.eliteGenerations:RG.MOB_SKILLS.splitter.generations))) {
      const n = e.affix === "split" ? cfgETYPESSplitterKillEnemy.n : cfgETYPESSplitterKillEnemy.n_2;
      for (let i = 0; i < n; i++) {
        const m = RG.spawnEnemy("splitter", false);
        m.isJuvenile = true;m.splitGeneration=(e.splitGeneration||0)+1;m.splitLimit=e.splitLimit??(e.elite?RG.MOB_SKILLS.splitter.eliteGenerations:RG.MOB_SKILLS.splitter.generations);
        m.x = e.x + rand(-30, 30); m.y = e.y + rand(-30, 30);
        m.hp *= cfgETYPESSplitterKillEnemy.hp_2; m.maxhp *= cfgETYPESSplitterKillEnemy.maxhp_2; m.r = cfgETYPESSplitterKillEnemy.r_2; m.speed = RG.enemyContractSpeed(cfgETYPESSplitterKillEnemy.speed_enemyContractSpeedArg1); m.dmg *= cfgETYPESSplitterKillEnemy.dmg; m.xp = 1;
      }
      RG.addText(e.x, e.y - e.r - 12, "裂解!", "#a3e635", 13);
    }
    // 忠诚残兵:传说卡不该只靠一次小概率“可能没效果”。提高复苏率，并让炮台有可感知的持续输出。
    if (playerKill && e.elite && RG.P.passives.loyal && (RG.allies || []).filter(a=>a.source==='loyal'&&!a.dead).length < RG.summonLimit(cfgPASSIVESLoyalKillEnemy.killEnemy_summonLimitArg1) && Math.random() < cfgPASSIVESLoyalKillEnemy.chance_threshold) {
      (RG.allies = RG.allies || []).push({ source:'loyal', x: e.x, y: e.y, r: Math.max(cfgPASSIVESLoyalKillEnemy.r_floor, e.r * cfgPASSIVESLoyalKillEnemy.r_factor), fireT: cfgPASSIVESLoyalKillEnemy.fireT, dmg: Math.max(cfgPASSIVESLoyalKillEnemy.dmg_floor, e.dmg * cfgPASSIVESLoyalKillEnemy.dmg_factor) });
      RG.addText(e.x, e.y - e.r - 12, "残兵复苏!", "#4ade80", 13);
      RG.burst(e.x, e.y, "#4ade80", 10, 100);
    }
    if(e.boss&&!e.noCoin&&!e.isClone&&!e.isEcho&&!e.splitChild){const key='boss:'+(e.bossKind||e.type);RG.meta.seenMobs=RG.meta.seenMobs||[];if(!RG.meta.seenMobs.includes(key)){RG.meta.seenMobs.push(key);RG.saveMeta();}}
    // 金币
    if(!RG.run.rushMode&&!e.noCoin&&!e.isClone&&!e.isEcho&&!e.splitChild&&e.xp>0){
      const drop=RG.BALANCE.economy.drops[e.boss?'boss':e.elite?'elite':'normal'];
      if(Math.random()<drop.chance){RG.addCoin(drop.gold);RG.addText(e.x,e.y-e.r-16,'金币 +'+drop.gold,'#ffd166',16);}
    }
    if(playerKill)RG.onWealthKill(e);
    // 宝箱精英:免费升级 + 金币
    if (e.chest) {
      // 宝箱保留免费升级，金币统一走概率掉落。
      RG.addText(e.x, e.y - e.r - 16, "箱 宝箱精英!免费强化!", "#ffd166", 16);
      RG.levelUp(0);
    }
    const gnum = e.boss ? (e.splitChild ? cfgBALANCECombatKillEnemy.gnum : cfgBALANCECombatKillEnemy.gnum_2) : e.elite ? cfgBALANCECombatKillEnemy.gnum : 1;
    const gval = e.boss ? (e.splitChild ? e.xp / cfgBALANCECombatKillEnemy.gval_divisor : e.xp / cfgBALANCECombatKillEnemy.gval_divisor_2 * cfgBALANCECombatKillEnemy.gval_factor) : e.elite ? e.xp / cfgBALANCECombatKillEnemy.gval_divisor : e.xp;
    const tier = e.boss ? cfgBALANCECombatKillEnemy.tier : (e.elite || e.type === "colossus") ? 1 : 0;
    const luck=RG.passiveValue(RG.P,"luck"),double=luck>0&&Math.random()<Math.min(1,luck)?RG.PASSIVES.luck.rules.killEnemy.double:1;
    const frostBoss=!e.boss&&RG.enemies.find(b=>b.frost&&!b.dead&&!b.dying&&dist2(e.x,e.y,b.x,b.y)<=RG.FROST_BOSS.corpseRange**2);
    let frozenXp=0;
    for(let i=0;i<gnum;i++){
      const gem={x:e.x+rand(-14,14),y:e.y+rand(-14,14),v:gval*double*(tier===2?cfgBALANCECombatKillEnemy.v:tier===1?cfgBALANCECombatKillEnemy.v_2:1)*rand(cfgBALANCECombatKillEnemy.v_min,cfgBALANCECombatKillEnemy.v_max),tier,big:tier>0,pull:false,delay:cfgBALANCECombatKillEnemy.delay};
      if(frostBoss)frozenXp+=gem.v;else RG.gems.push(gem);
    }
    if(frostBoss){
      const list=frostBoss.frost.corpses;
      // 保存生前朝向与动画帧；冻结尸体复用同一像素图，不恢复为旧几何图案。
      if(list.length<cfgBALANCECombatKillEnemy.length_threshold_3)list.push({x:e.x,y:e.y,r:e.r,type:e.type,tier,xp:frozenXp,frozen:1,animClock:e.animClock??((e.animFrame||0)/cfgBALANCECombatKillEnemy.animClock_divisor),faceDir:e.faceDir||0,faceA:e.faceA,vx:e.vx||0,vy:e.vy||0});
      else list[0].xp+=frozenXp; // 长战只合并储存值，不重复结算或丢失经验。
    }
    if (e.elite && Math.random() < cfgBALANCECombatKillEnemy.chance_threshold) RG.orbs.push({ x: e.x, y: e.y, r: cfgBALANCECombatKillEnemy.r_2, heal: cfgBALANCECombatKillEnemy.heal });
    if (playerKill && e.elite && !e.isClone && !e.isEcho && RG.P && RG.P.hp>0 && RG.P.soulSuck && !RG.P.healBan && !RG.P.healBlocked && !RG.P.hpLocked) {
      const heal = RG.PASSIVES.soul.healBase + RG.PASSIVES.soul.healPerLevel * RG.P.soulSuck;
      RG.P.hp = Math.min(RG.P.maxhp, RG.P.hp + heal);
      RG.addText(RG.P.x, RG.P.y - 30, "灵魂虹吸 +" + heal, "#4ade80", 13, { pop: true });
    }
    // 影分身(W2 终焉之影):死亡原地爆毒圈
    if (e.isEcho && e.bossKind === "shadow" && (e.cycle || 1) >= cfgBOSS_SKILLSShadowKillEnemy.range_threshold) RG.poisonZone(e.x, e.y, cfgBOSS_SKILLSShadowKillEnemy.killEnemy_poisonZoneArg3, cfgBOSS_SKILLSShadowKillEnemy.killEnemy_poisonZoneArg4, e.dmg * cfgBOSS_SKILLSShadowKillEnemy.killEnemy_factor,enemyCause(e,'残影毒域'));
    // BOSS 连战:击杀 = 结算(首通/复刷金币 + 最短通关纪录),展示 1.6s 后回选关
    if (RG.run.rushMode && e.rushBoss && !e.isClone && !e.splitChild) {
      const br = RG.meta.bossRush || (RG.meta.bossRush = { unlocked: 1, cleared: [], best: {} });
      const lv = RG.run.rushLv, t = Math.round(RG.run.t * cfgBALANCECombatKillEnemy.t_factor) / cfgBALANCECombatKillEnemy.t_divisor;
      const diff=RG.run.rushDifficulty||1,first = !br.cleared.includes(lv), prev = RG.rushBestTime(lv,diff);
      const byDiff=br.bestByDifficulty||(br.bestByDifficulty={}),table=byDiff[diff]||(byDiff[diff]={});
      let rec;
      if (prev === undefined || t < prev) {
        table[lv] = t;if(diff===1)br.best[lv]=t;
        rec = prev === undefined ? "★ 纪录 " + t.toFixed(1) + "s" : "★ 新纪录 " + t.toFixed(1) + "s!";
      } else rec = "通关 " + t.toFixed(1) + "s(纪录 " + prev.toFixed(1) + "s)";
      if (first) { br.cleared.push(lv); RG.run.coins+=RG.BALANCE.economy.rushFirst; rec = "† 首通 +"+RG.BALANCE.economy.rushFirst+"金 · " + rec; }
      else if(prev!==undefined&&t<prev)RG.run.coins+=RG.BALANCE.economy.rushRecord;
      const earned=RG.unlockBossWeapons(lv);
      if(earned.length)RG.addText(RG.P.x,RG.P.y-108,'武器解锁 · '+earned.map(id=>RG.WEAPONS[id].name).join(' / '),'#7dd3fc',13);
      br.unlocked = Math.max(br.unlocked || 1, Math.min(cfgBALANCECombatKillEnemy.unlocked_cap, lv + 1));
      RG.addText(RG.P.x, RG.P.y - 84, rec, first ? "#ffd166" : "#c9c7d8", first ? 17 : 14);   // C-04 修复:单行,手机 UIS 放大也不再叠字
      if (RG.unlockAchievement) RG.unlockAchievement("rush_clear");
      RG.saveMeta();
      RG.run.rushEndT = cfgBALANCECombatKillEnemy.rushEndT;
    }
    if(e.rushBoss)for(const m of RG.enemies)if(m.rushEscort)m.dead=true;
    if (e.final) {
      // 帧内击杀先完成碰撞/爆炸裁决，死亡终态不能被通关或奖励覆盖。
      if(RG.battleUpdating){pendingFinalBoss=e;return;}
      settleFinalBoss(e);return;
    }
    if (e.boss && e.realmBoss) {
      if(!RG.run.rushMode&&['valley','legacy'].includes(RG.run.mapId||'legacy')){
        const maps=RG.meta.maps||(RG.meta.maps={}),progress=maps.workshop||(maps.workshop={});
        if(!progress.unlocked){progress.unlocked=true;RG.saveMeta();RG.addText(e.x,e.y-84,RG.mapConfig('workshop').name+'已解锁','#a5f3fc',16);}
      }
      for (const c of RG.enemies) if (c.isClone && !c.dead) { c.dead = true; RG.burst(c.x, c.y, "#c084fc", 10, 120); }
      orbsHeal(e);
      if (RG.unlockAchievement) RG.unlockAchievement("boss_slayer");
      RG.addText(e.x, e.y - 60, "秘境守卫 击破!", "#ffd166", 20);
      RG.legendaryOffer();
      RG.portal = { x: e.x + 60, y: e.y + 40, r: cfgBALANCECombatKillEnemy.r_3, swirl: 0, exit: true };
    } else if (e.boss) {
      // v8.20:终焉之影本体死亡 → 影分身随本体消散(玩家反馈)
      if (e.bossKind === "shadow" && !e.isEcho) {
        for (const m of RG.enemies) {
          if (m.isEcho && m.bossKind === "shadow" && !m.dead) { m.dead = true; RG.burst(m.x, m.y, "#7c3aed", 14, 130); }
        }
        RG.addText(e.x, e.y - e.r - 40, "影分身随本体消散!", "#7c3aed", 13);
      }
      orbsHeal(e);
      if (RG.unlockAchievement) RG.unlockAchievement("boss_slayer");
      RG.cam.shake = 14;
      RG.addText(e.x, e.y - 50, "BOSS 击破!", "#ffd166", 20);
      RG.vibrate([50, 30, 50, 30, 100]);
      if (RG.run.boss === e) RG.run.boss = null;
      if(mainBoss&&!RG.run.rushMode&&!e.realmBoss&&!e.splitChild&&!e.isEcho&&!e.isClone){
        RG.run.bossDelayUntil=RG.run.t+cfgBALANCECombatKillEnemy.bossDelayUntil_offset;RG.run.rampT=Math.max(RG.run.rampT||0,cfgBALANCECombatKillEnemy.rampT_floor);
        if((e.bossNumber||RG.run.bossNum)>=cfgBALANCECombatKillEnemy.range_threshold_3&&RG.unlockAchievement)RG.unlockAchievement("cycle_2");
      }
    }
  };
  function settleFinalBoss(e){
    RG.run.finalBoss=null;
    if(RG.P.hp<=0||RG.state==='over')return;
    orbsHeal(e);
    if(RG.unlockAchievement)RG.unlockAchievement('win_final');
    if(!RG.run.won){
      RG.run.won=true;RG.settleRunStats();RG.settleRunCoins();RG.saveMeta();
      if(RG.pushRunLog)RG.pushRunLog(true);RG.settleDaily(true);RG.saveMeta();
      RG.state='win';RG.playSfx('levelup');
      if(RG.clearRunCheckpoint)RG.clearRunCheckpoint();RG.checkpointPending=false;return;
    }
    RG.run.finalT=RG.run.t+cfgBALANCECombatKillEnemy.finalT_offset;RG.run.finalStacks++;
    RG.addText(e.x,e.y-60,'终焉再破!奖励已入账','#ffd166',20);
  }
  function orbsHeal(e) { RG.orbs.push({ x: e.x, y: e.y, r: cfgBALANCECombatOrbsHeal.r, heal: cfgBALANCECombatOrbsHeal.heal }); if (RG.run.boss === e) RG.run.boss = null; }
  // 状态只共用创建/刷新/到期/清理操作；各机制仍决定叠加、免疫和更新顺序。
  const STATUS_END={stunT:{freezeT:0},giantT:{giantStacks:0,r:RG.BALANCE.player.r},superdmgT:{superdmgMul:null},reactionSlowT:{reactionSlow:1},poisonAmpT:{poisonAmp:1},corrodeT:{corrode:0}};
  const ENEMY_STATUS_KEYS=['elCd','superdmgT','armorBreakT','reactionSlowT','cardSlowT','vialSlowT','controlCd','poisonAmpT','corrodeT','earthImbalanceT'];
  RG.refreshStatus=function(entity,key,time,values){entity[key]=Math.max(entity[key]||0,time);if(values)Object.assign(entity,values);return entity[key];};
  RG.clearStatus=function(entity,key){entity[key]=0;if(STATUS_END[key])Object.assign(entity,STATUS_END[key]);};
  function setAmplifier(e,source){
    const c=RG.WORKSHOP_MOBS.amplifier,mul=source?c.damage:1;
    if((e.ampDmgMul||1)!==mul)e.dmg=e.dmg/(e.ampDmgMul||1)*mul;
    e.ampDmgMul=mul;e.ampSpeedMul=source?c.speed:1;e.ampSource=source||null;if(!source)e.ampT=0;
  }
  RG.clearAmplifierSource=function(source){
    for(const e of RG.enemies)if(e.ampSource===source)setAmplifier(e,null);
    RG.run.amplifierPresent=RG.enemies.some(e=>e!==source&&e.type==='amplifier'&&!e.dead&&!e.dying);
  };
  RG.updateAmplifierAuras=function(dt){
    const c=RG.WORKSHOP_MOBS.amplifier,sources=RG.enemies.filter(e=>e.type==='amplifier'&&!e.dead&&!e.dying&&!(e.frozen>0)&&!(e.petrifyT>0)&&!(e.chronoT>0));
    for(const e of RG.enemies){
      if(e.boss||e.type==='amplifier'||e.dead||e.dying){if(e.ampSource)setAmplifier(e,null);continue;}
      const source=sources.find(s=>dist2(e.x,e.y,s.x,s.y)<=c.radius*c.radius);
      if(source){setAmplifier(e,source);e.ampT=c.hold;}
      else{e.ampT=Math.max(0,(e.ampT||0)-dt);if(!e.ampT||e.ampSource?.dead||e.ampSource?.dying)setAmplifier(e,null);}
    }
  };
  RG.tickStatus=function(entity,key,dt){
    if(!(entity[key]>0)){
      if(key==='stunT'&&entity.freezeT>0)RG.clearStatus(entity,key);
      if(entity[key]<0)RG.clearStatus(entity,key);   // 旧现场可能留下负计时，首次更新归零并清附加值。
      if(entity===RG.P)entity[key]=0;
      if(key==='poisonAmpT')entity.poisonAmp=1;else if(key==='corrodeT')entity.corrode=0;
      return false;
    }
    entity[key]=Math.max(0,entity[key]-dt);if(!entity[key])RG.clearStatus(entity,key);return true;
  };
  // 寒冰控制另记实际来源时长，时停/幽影/践踏复用的硬直表现不能冒充寒冰。
  RG.applyIceFreeze=function(e,duration){RG.refreshStatus(e,'frozen',duration);RG.refreshStatus(e,'iceFreezeT',duration);};
  RG.tickIceFreeze=function(e,dt){if(e.iceFreezeT!==undefined)RG.tickStatus(e,'iceFreezeT',dt);return RG.tickStatus(e,'frozen',dt);};
  // ---------- 元素系统(v10.1):五元素独立伤害层；异种状态相遇触发十种反应 ----------
  // 冲锋犬只抵挡基础攻击；捶地兽施法期间也抵挡元素和直接伤害。
  RG.enemyCastDamageMul = (e, base) => e.type === "smasher" && ((e.slamWind || 0) > 0 || (e.slamGuardT || 0) > 0) ? RG.ETYPES.smasher.rules.enemyCastDamageMul.enemyCastDamageMul : base && e.type === "hound" && e.chargeRun > 0 ? RG.ETYPES.hound.rules.enemyCastDamageMul.enemyCastDamageMul : 1;
  // 来源范围仅包住同步结算，三钥匙奖励及其即时连锁不污染最高伤害。
  let damageSource=null;
  RG.withDamageSource=function(source,fn){
    const previous=damageSource,keys=source==='reactionchain'?['bullets','storms','echoQ','hazards','vials']:['bullets','storms','echoQ','hazards'],before=source==='keyAura'||source==='reactionchain'?keys.map(k=>(RG[k]||[]).length):null;
    damageSource=source;try{return fn();}finally{
      if(before)keys.forEach((key,i)=>{for(const item of (RG[key]||[]).slice(before[i]))item.damageSource=source;});
      damageSource=previous;
    }
  };
  RG.ELEMENT_COLORS={fire:'#fb923c',ice:'#7dd3fc',elec:'#fde047',poison:'#a3e635',earth:'#d6a85f',reaction:'#c084fc'};
  function absorbFrostShield(e,dmg){
    if(!e.frost||!(e.shieldHp>0))return dmg;
    const shield=e.shieldHp;e.shieldHp=Math.max(0,shield-dmg);
    if(!e.shieldHp)RG.addText(e.x,e.y-e.r-14,'冰盾碎裂','#38bdf8',14);
    return Math.max(0,dmg-shield);
  }
  RG.recordHitDamage=function(dmg,element){if(damageSource==='keyAura'||!RG.run||!Number.isFinite(dmg)||dmg<=0)return;RG.run.highestDamage=Math.max(RG.run.highestDamage||0,dmg);if(element)RG.run.highestElementDamage=Math.max(RG.run.highestElementDamage||0,dmg);};
  // 受击方最后裁决；保留基础命中/直接伤害各自的石肤、易伤和护盾机制。
  // 本函数只计算结果，扣血、命中特效和暴击联动读取同一结果，不改攻击方输出。
  RG.receiveDamage = function(target,hit,options={}) {
    const crit=!!hit.crit&&!target.critImmune;
    let dmg=crit?hit.dmg:hit.normal;
    if(target===RG.P){
      const P=target,takenMul=(P.hurtMul||1)*(P.debtT>0?RG.PASSIVES.debt.hurtMul:1)*(P.passives.greed?1+RG.PASSIVES.greed.rules.receiveDamage.takenMul_factor*P.passives.greed:1)*(P.passives.allin?RG.PASSIVES.allin.rules.receiveDamage.takenMul:1);
      const armor=Math.max(0,Math.min(Math.max(cfgBALANCECombatReceiveDamage.armor_floor,P.armor),P.armor+(P.ecoGuard||0))-(P.howlDebuffT>0?cfgBALANCECombatReceiveDamage.armor:0));
      const typeMul=(options.projectile?1-Math.min(cfgBALANCECombatReceiveDamage.typeMul_cap,RG.passiveValue(P,'projectile_guard')):1)*(options.element==='elec'?1-Math.min(cfgBALANCECombatReceiveDamage.typeMul_cap,RG.passiveValue(P,'electric_guard')):1);
      return {dmg,taken:Math.max(1,dmg*(1-armor)*takenMul*typeMul*(1-RG.wealthGuard(P))),crit};
    }
    // 互伤使用敌方攻击快照，不读玩家暴击、元素、易伤或召唤加成。
    if(options.crossfire){
      dmg*=RG.enemyCastDamageMul(target,true);
      if(target.stoneT>0)dmg*=cfgBALANCECombatReceiveDamage.dmg_2;
      dmg=Math.min(dmg,options.crossfireCap);
      return {dmg,taken:dmg,crit:false,shieldBlocked:target.shieldHp>0&&!target.frost};
    }
    let raw=hit.raw,elementBase=crit?hit.elementBase:hit.elementNormal;
    if(!options.direct&&target.isMirror&&options.noSplash){dmg*=cfgBALANCECombatReceiveDamage.dmg;raw*=cfgBALANCECombatReceiveDamage.raw;elementBase*=cfgBALANCECombatReceiveDamage.elementBase;}
    const resistance=options.resist?RG.elementDamageMultiplier(target,options.element,hit.weakness||0):1;
    dmg*=resistance;
    const poison=options.poisonAmp&&target.poisonAmpT>0?(target.poisonAmp||1):1;
    dmg*=poison;
    if(options.summon)dmg*=(1+(RG.resonanceBonus(RG.P).summonDamage||0))*(1+RG.legionBonus());
    const statusDamage=elementBase*resistance*poison;
    if(!options.exact)dmg*=RG.enemyCastDamageMul(target,!options.direct);
    if(!options.direct&&target.stoneT>0)dmg*=cfgBALANCECombatReceiveDamage.dmg_2;
    if(options.element==='fire'&&target.bossKind==='mirror'&&target.frost)dmg*=RG.BOSS_SKILLS.mirror.receiveDamage.dmg;
    const shieldBlocked=!options.direct&&target.shieldHp>0&&!target.frost;
    let taken=dmg;
    if(!options.exact&&target.chronoT>0)taken*=RG.ACTIVES.chrono.effect.vulnerableMul;
    if(!options.exact&&crit&&target.earthImbalanceT>0&&RG.P.passives.earthbalance)taken*=1+RG.PASSIVES.earthbalance.values[RG.P.passives.earthbalance];
    if(!options.exact&&target.workshopColdT>0&&RG.isWorkshopBoss(target)&&target.bossKind==='furnace')taken*=RG.BOSS_SKILLS.furnace.receiveDamage.taken;
    if(!options.exact&&target.workshopRiftT>0&&RG.isWorkshopBoss(target)&&target.bossKind==='void')taken*=RG.BOSS_SKILLS.void.receiveDamage.taken;
    if(!options.direct&&!shieldBlocked){
      if(target.el?.elec>0)taken*=cfgBALANCECombatReceiveDamage.taken_2;
      if(target.superdmgT>0)taken*=1+(target.superdmgMul==null?cfgBALANCECombatReceiveDamage.taken_3:target.superdmgMul);
      if(target.armorBreakT>0)taken*=cfgBALANCECombatReceiveDamage.taken_2;
    }
    return {dmg,taken,crit,raw,elementBase,statusDamage,shieldBlocked,poisonMul:poison};
  };
  function applyEnemyDamage(e,hit,element,direct) {
    if(damageSource!=='enemyCrossfire')RG.recordHitDamage(hit.taken,element);
    if(hit.shieldBlocked){
      e.shieldHp=Math.max(0,e.shieldHp-hit.dmg);e.flash=.08;
      if(Math.random()<RG.BALANCE.combat.applyEnemyDamage.value_threshold)RG.addText(e.x+rand(-6,6),e.y-e.r-4,'盾','#38bdf8',12);
      if(!e.shieldHp){RG.addText(e.x,e.y-e.r-14,'盾破!','#38bdf8',14);RG.burst(e.x,e.y,'#38bdf8',10,140);}
    }else{e.hp-=absorbFrostShield(e,hit.taken);e.flash=direct?.06:.08;}
  }
  // 生成时锁定攻击身份，Set由图存档保留引用；不借玩家命中入口触发被动。
  RG.crossfireAttack=function(kind,owner){
    return RG.enemyCrossfireEnabled()&&!RG.realm.active?{crossfireKind:kind,crossfireOwner:owner,crossfireSource:'enemyCrossfire',crossfireHit:new Set()}:{};
  };
  RG.hitEnemyCrossfire=function(attack,e){
    const rule=RG.MOB_SKILLS[attack.crossfireKind]?.friendlyFire;
    if(!RG.enemyCrossfireEnabled()||RG.realm.active||attack.crossfireSource!=='enemyCrossfire'||!rule||!e||e===attack.crossfireOwner||e.dead||e.dying||e.boss||e.isClone||e.isEcho||e.workshopHole||e.workshopWorm||e.spaceHidden||!Number.isFinite(e.maxhp)||e.maxhp<=0||!(attack.dmg>0))return 0;
    if(!(attack.crossfireHit instanceof Set)||attack.crossfireHit.has(e))return 0;
    attack.crossfireHit.add(e);
    return RG.withDamageSource('enemyCrossfire',()=>{
      const cap=e.maxhp*(e.elite?rule.eliteCap:rule.normalCap),base=attack.dmg*rule.damageMul;
      const hit=RG.receiveDamage(e,{normal:base,dmg:base,crit:false},{crossfire:true,crossfireCap:cap}),before=e.hp;
      applyEnemyDamage(e,hit,false,true);
      const taken=Math.max(0,Math.min(before,before-e.hp));
      const stats=RG.run.crossfireStats;if(stats){stats.hits++;stats.damage+=taken;}
      if(taken>0){
        RG.addText(e.x,e.y-e.r-10,'互 '+Math.round(taken),'#f5d7a1',12);
        if(rule.knockback&&e.hp>0){
          const a=Math.atan2(e.y-attack.y,e.x-attack.x),steps=Math.ceil(rule.knockback/Math.max(1,e.r/2));
          for(let i=0;i<steps;i++){const x=e.x,y=e.y;e.x+=Math.cos(a)*rule.knockback/steps;e.y+=Math.sin(a)*rule.knockback/steps;RG.pushOutOfWalls(e,RG.walls);RG.constrain(e);if(Math.hypot(e.x-x,e.y-y)<rule.knockback/steps*.5)break;}
        }
      }
      if(e.hp<=0){e.deathCrossfireKind=attack.crossfireKind;RG.startDying(e);}
      return taken;
    });
  };
  RG.dealPure = function (e, dmg, element, exact, source, options={}) {
    if(source&&source!==damageSource)return RG.withDamageSource(source,()=>RG.dealPure(e,dmg,element,exact,undefined,options));
    // 无视暴击/护甲的直接伤害(DoT/反应),仍可击杀
    if (!e || e.dead || e.dying || e.isClone || e.spaceHidden) return;
    const output=RG.outgoingDamage(dmg,e,true,exact);
    if(options.resist)output.weakness=RG.passiveValue(RG.P,'weakness');
    const hit=RG.receiveDamage(e,output,{...options,direct:true,element,exact});dmg=hit.taken;
    const slow=element&&dmg>0&&damageSource!=='reactionchain'?RG.passiveValue(RG.P,"element_slow"):0;if(slow>0&&Math.random()<Math.min(1,slow))RG.refreshStatus(e,'cardSlowT',RG.PASSIVES.element_slow.duration);
    applyEnemyDamage(e,hit,element,true);
    if (Math.random() < RG.BALANCE.combat.dealPure.chance_threshold) RG.addText(e.x + rand(-6, 6), e.y - e.r - 4, Math.round(dmg), RG.ELEMENT_COLORS[element]||(element?RG.ELEMENT_COLORS.reaction:"#e2e8f0"), element?cfgBALANCECombatWeaponElementHit.textSize:12, { pop: true });
    if (e.hp <= 0) RG.startDying(e);
    return hit;
  };
  // 新生成的元素输出在受击入口结算抗性；持续状态沿用已接受的基准，不重复加抗性。
  RG.dealElement = function(e,dmg,type,source,options){return RG.dealPure(e,dmg,type,false,source,{...options,resist:true})?.statusDamage||0;};
  // 致命反馈分级：普通短促、精英稍重、BOSS留出连续崩裂时间；濒死期间不参与碰撞和AI。
  // 同一段打击只取较强反馈；两次慢放之间留出正常移动时间。
  RG.requestHitStop = function (duration) {
    if ((RG.hitStopGate || 0) > 0) return;
    RG.hitStop = Math.max(RG.hitStop || 0, duration);
  };
  RG.startDying = function (e) {
    if (e.dying || e.dead) return;
    if(e.workshopHole){RG.closeWorkshopHole(e,true);return;}
    e.deathDamageSource=damageSource;
    const dur=e.boss ? 1.25 : e.elite ? .46 : .28;
    e.dying = true; e.dyingT = dur; e.dyingMax = dur; e.flash = Math.min(.3,dur);
    if(e.type==='amplifier')RG.clearAmplifierSource(e);
    if(RG.isWorkshopBoss(e))RG.clearWorkshopBoss(e);
    RG.addSpark(e.x,e.y,e.boss?'big':e.elite?'crit':'heavy',e.boss?'#c084fc':RG.ETYPES[e.type]?.color||'#c084fc');
    RG.requestHitStop(e.boss ? .10 : e.elite ? .07 : .04);
    RG.cam.shake=Math.max(RG.cam.shake||0,e.boss?10:e.elite?5:2);
    if(e.boss){e.deathPulseT=.16;e.deathPulseN=0;}
  };
  const RX={
    "fire+ice":{name:"融化",mul:cfgBALANCECombatCommon.mul,color:"#f8fafc"},"elec+fire":{name:"超载",mul:cfgBALANCECombatCommon.mul_2,color:"#fb923c"},
    "fire+poison":{name:"燃爆",mul:cfgBALANCECombatCommon.mul_3,color:"#bef264"},"earth+fire":{name:"熔岩",mul:cfgBALANCECombatCommon.mul_3,color:"#f97316"},
    "elec+ice":{name:"超导",mul:cfgBALANCECombatCommon.mul_2,color:"#7dd3fc"},"ice+poison":{name:"冻毒",mul:cfgBALANCECombatCommon.mul_3,color:"#a3e635"},
    "earth+ice":{name:"冻土",mul:cfgBALANCECombatCommon.mul_4,color:"#bae6fd"},"elec+poison":{name:"感电中毒",mul:cfgBALANCECombatCommon.mul_5,color:"#bef264"},
    "earth+elec":{name:"导电",mul:cfgBALANCECombatCommon.mul_2,color:"#fde047"},"earth+poison":{name:"腐蚀",mul:cfgBALANCECombatCommon.mul_4,color:"#d6a85f"},
  };
  RG.ELEMENT_REACTIONS=RX;
  RG.elementResist=function(e,type){
    const map=e.resists||(e.boss?RG.BOSS_RESISTS[e.bossKind]:(RG.ETYPES[e.type]&&RG.ETYPES[e.type].res))||{};
    let value=map[type]||0;
    if(e.boss&&e.enraged&&value<0)value-=cfgBALANCECombatElementResist.value;
    return Math.min(cfgBALANCECombatElementResist.elementResist_cap,Math.max(-1,value-(e.corrode||0)));
  };
  RG.elementDamageMultiplier=function(e,type,weakness=RG.passiveValue(RG.P,'weakness')){const res=RG.elementResist(e,type);return res<0?1-res*(1+weakness):1-res;};
  function resistedReaction(e,a,b,raw,cap){return Math.min(raw*(RG.elementDamageMultiplier(e,a)+RG.elementDamageMultiplier(e,b))/RG.BALANCE.combat.resistedReaction.value_divisor,cap);}
  function chainReaction(e,a,b,raw,cap,max,color){
    let n=0;
    for(const o of RG.enemies){
      if(o.dead||o.dying||o===e||n>=max||Math.hypot(o.x-e.x,o.y-e.y)>RG.reactionRange(cfgBALANCECombatChainReaction.reactionRange_reactionRangeArg1))continue;
      const d=Math.hypot(o.x-e.x,o.y-e.y);
      RG.beams.push({x:e.x,y:e.y,a:Math.atan2(o.y-e.y,o.x-e.x),len:d,life:.12,maxLife:.12,w:3,chainCol:true,color});
      RG.dealPure(o,resistedReaction(o,a,b,raw,cap)*cfgBALANCECombatChainReaction.value_factor,true);n++;
    }
  }
  function lavaZone(e,dps){
    const old=RG.hazards.find(h=>h.friendlyLava&&Math.hypot(h.x-e.x,h.y-e.y)<=cfgBALANCECombatLavaZone.old_threshold);
    if(old){old.t=cfgBALANCECombatLavaZone.t;old.r=RG.reactionRange(cfgBALANCECombatLavaZone.r_reactionRangeArg1);if(dps>=old.dps){old.dps=dps;old.damageSource=damageSource;}return;}
    RG.hazards.push({x:e.x,y:e.y,r:RG.reactionRange(cfgBALANCECombatLavaZone.r_reactionRangeArg1),t:cfgBALANCECombatLavaZone.t,dur:cfgBALANCECombatLavaZone.dur,phase:"active",hitCd:0,friendlyLava:true,dps,damageSource});
  }
  // 原始与复制共用反应效果；复制沿用未抗性输出/上限，由新接收者独立裁决。
  function resolveReaction(a,b,e,raw,cap,derived){
    const pair=[a,b].sort().join('+'),def=RX[pair],oldPoison=e.el&&e.el.poison||0,dmg=resistedReaction(e,a,b,raw,cap);
    const poisonDmg=e.elDmg?.poison||0,poisonSpore=e.poisonSpore;
    e.el??={fire:0,ice:0,elec:0,poison:0,earth:0};e.elDmg??={fire:0,ice:0,elec:0,poison:0,earth:0};
    clearElement(e,a);clearElement(e,b);e.elCd=cfgBALANCECombatResolveReaction.elCd;
    if(pair==="elec+fire"){
      const radius=RG.reactionRange(cfgBALANCECombatResolveReaction.radius_reactionRangeArg1);RG.rings.push({x:e.x,y:e.y,r:12,maxR:radius,life:.3,maxLife:.3,color:def.color});
      for(const o of RG.enemies)if(!o.dead&&!o.dying&&Math.hypot(o.x-e.x,o.y-e.y)<radius+o.r)RG.dealPure(o,resistedReaction(o,a,b,raw,cap),true);
    }else{
      RG.dealPure(e,dmg,true);
      if(pair==="fire+poison"){RG.refreshStatus(e,'poisonAmpT',cfgBALANCECombatResolveReaction.refreshStatus_refreshStatusArg3,{poisonAmp:cfgBALANCECombatResolveReaction.poisonAmp});}
      else if(pair==="earth+fire"){RG.refreshStatus(e,'armorBreakT',cfgBALANCECombatResolveReaction.refreshStatus_refreshStatusArg3_2);lavaZone(e,dmg/cfgBALANCECombatResolveReaction.dmg_divisor);}
      else if(pair==="elec+ice"){RG.refreshStatus(e,'superdmgT',cfgBALANCECombatResolveReaction.value_4_offset+(RG.P.passives.supercore||0)*RG.PASSIVES.supercore.durationPerLevel,{superdmgMul:cfgBALANCECombatResolveReaction.superdmgMul});RG.refreshStatus(e,'reactionSlowT',cfgBALANCECombatResolveReaction.refreshStatus_refreshStatusArg3,{reactionSlow:cfgBALANCECombatResolveReaction.reactionSlow});chainReaction(e,a,b,raw,cap,cfgBALANCECombatResolveReaction.value_3_offset+(RG.P.passives.supercore||0)*RG.PASSIVES.supercore.arcsPerLevel,def.color);}
      else if(pair==="ice+poison"){e.el.poison=Math.max(e.el.poison||0,oldPoison*cfgBALANCECombatResolveReaction.poison_factor);e.elDmg.poison=poisonDmg;e.poisonSpore=poisonSpore;RG.refreshStatus(e,'reactionSlowT',cfgBALANCECombatResolveReaction.refreshStatus_refreshStatusArg3,{reactionSlow:cfgBALANCECombatResolveReaction.reactionSlow_2});}
      else if(pair==="earth+ice"&&(!e.controlCd||e.controlCd<=0)){RG.applyIceFreeze(e,e.boss?cfgBALANCECombatResolveReaction.value:1);e.controlCd=cfgBALANCECombatResolveReaction.controlCd;}
      else if(pair==="elec+poison")chainReaction(e,a,b,raw,cap,cfgBALANCECombatResolveReaction.chainReaction_chainReactionArg6,def.color);
      else if(pair==="earth+elec")chainReaction(e,a,b,raw,cap,cfgBALANCECombatResolveReaction.chainReaction_chainReactionArg6_2,def.color);
      else if(pair==="earth+poison"){
        const devourer=e.bossKind==="devourer",step=devourer ? cfgBALANCECombatResolveReaction.step : cfgBALANCECombatResolveReaction.step_2,limit=devourer ? cfgBALANCECombatResolveReaction.limit : (e.boss ? cfgBALANCECombatResolveReaction.limit_2 : cfgBALANCECombatResolveReaction.limit_3);
        RG.refreshStatus(e,'corrodeT',cfgBALANCECombatResolveReaction.refreshStatus_refreshStatusArg3_3,{corrode:Math.min(limit,(e.corrode||0)+step)});
      }
    }
    RG.addText(e.x,e.y-e.r-10,def.name+(derived?'·连锁!':'!'),def.color,18,{pop:true,life:1.0});
    RG.rings.push({x:e.x,y:e.y,r:10,maxR:RG.reactionRange(pair==="elec+fire"?170:110),life:.28,maxLife:.28,color:def.color});
    RG.addSpark(e.x, e.y - 8, "crit", def.color);
    RG.burst(e.x, e.y, def.color, 8, 160);
    RG.requestHitStop(0.03);
    RG.playSfx(pair==="fire+ice"?"evaporate":pair==="elec+fire"?"overload":"superconduct");
  }
  RG.elemReaction = function (a,b,e,newDmg,baseHit) {
    const def=RX[[a,b].sort().join('+')];if(!def||!e||e.dead||e.dying||e.isClone||(e.elCd||0)>0)return;
    if(RG.P.passives.aftershock&&damageSource!=='reactionchain')RG.refreshStatus(RG.P,'reactionAfterT',RG.PASSIVES.aftershock.rules.elemReaction.elemReaction_refreshStatusArg3);
    const oldDmg=(e.elDmg&&e.elDmg[a])||newDmg||0,avg=(oldDmg+(newDmg||0))/cfgBALANCECombatElemReaction.avg_divisor;
    const bonus=(RG.P.reactionMul||1)*(1+(RG.resonanceBonus(RG.P).reactionDamage||0)),amp=(RG.P.passives.harmony?RG.PASSIVES.harmony.rules.elemReaction.amp:1)*bonus,cap=(baseHit||newDmg||cfgBALANCECombatElemReaction.cap)*RG.effectiveCritDamage(RG.P,false)*cfgBALANCECombatElemReaction.cap_factor*bonus;
    const raw=avg*def.mul*amp;
    resolveReaction(a,b,e,raw,cap,false);
    const lv=RG.P.passives.reactionchain;if(!lv||damageSource==='reactionchain'||Math.random()>=RG.PASSIVES.reactionchain.values[lv])return;
    let next=null,best=RG.reactionRange(RG.PASSIVES.reactionchain.range)**2;
    for(const o of RG.enemies){
      if(o===e||o.dead||o.dying||o.isClone||o.workshopHole||(o.elCd||0)>0)continue;
      const d=dist2(o.x,o.y,e.x,e.y);if(d<=best&&(!next||d<best)){next=o;best=d;}
    }
    if(next)RG.withDamageSource('reactionchain',()=>resolveReaction(a,b,next,raw,cap,true));
  };
  // 每种元素独立生命周期；反应消费与自然到期都清掉旧伤害基准。
  function clearElement(e,type){
    if(e.el)e.el[type]=0;if(e.elDmg)e.elDmg[type]=0;
    if(type==='fire'){e.burnDps=0;e.burnTick=0;e.burnSource=null;}
    if(type==='poison')e.poisonSpore=false;
  }
  RG.clearElement=clearElement;
  // 附加状态的伤害基准也由受击方接受；保留溅射/怪物点燃原有的克制适用范围。
  RG.applyElementOutput=function(e,type,dur,dmg,baseHit,chained,weakness=true){return RG.applyElem(e,type,dur,dmg*(weakness?RG.elementDamageMultiplier(e,type):1-RG.elementResist(e,type)),baseHit,chained);};
  RG.applyElem = function (e,type,dur,elemDmg,baseHit,chained) {
    if(!e||e.dead||e.dying||e.isClone||!RG.ELEMENTS[type])return;
    if(!e.el)e.el={fire:0,ice:0,elec:0,poison:0,earth:0};
    if(!e.elDmg)e.elDmg={fire:0,ice:0,elec:0,poison:0,earth:0};
    if(!(e.el[type]>0))clearElement(e,type);
    if(type==='earth'&&elemDmg>0&&RG.P.passives.earthbalance)RG.refreshStatus(e,'earthImbalanceT',RG.PASSIVES.earthbalance.rules.applyElem.applyElem_refreshStatusArg3);
    if(type==='poison'&&elemDmg>0)e.poisonSpore=damageSource==='spore'||damageSource==='reactionchain';
    // 只跳到一个近邻；传播不会再次传播，避免递归风暴。
    const doom=RG.passiveValue(RG.P,'doom');
    if (!chained && damageSource!=='reactionchain' && doom>0 && Math.random() < Math.min(1,doom)) {
      let near = null, best = cfgPASSIVESReactionchainApplyElem.best_factor * cfgPASSIVESReactionchainApplyElem.best_factor;
      for (const o of RG.enemies) {
        if (o === e || o.dead || o.dying || o.isClone) continue;
        const d = dist2(e.x, e.y, o.x, o.y);
        if (d < best) { best = d; near = o; }
      }
      if (near) RG.applyElem(near,type,dur,elemDmg,baseHit,true);
    }
    const harmonize=RG.P.passives.harmony?RG.PASSIVES.harmony.rules.applyElem.harmonize:1;
    RG.refreshStatus(e.el,type,dur*harmonize);e.elDmg[type]=Math.max(e.elDmg[type]||0,elemDmg||0);
    if((e.elCd||0)<=0){const other=RG.ELEMENT_ORDER.find(k=>k!==type&&e.el[k]>0);if(other){RG.elemReaction(other,type,e,elemDmg||0,baseHit||elemDmg);return;}}
    if(type==='fire'){const next=(elemDmg||cfgBALANCECombatApplyElem.next)*cfgBALANCECombatApplyElem.next_factor;if(next>=(e.burnDps||0)){e.burnDps=next;e.burnSource=damageSource;}}
  };

  // 武器附魔是独立伤害层：复用本次基础命中的暴击结果，不再单独掷暴击。
  RG.weaponElementHit = function(e, weaponId, rolledBaseDmg) {
    const P=RG.P, el=RG.weaponElement(P,weaponId),type=el&&el.type;
    if(!type||!e||e.dead||e.dying||e.isClone||e.spaceHidden)return 0;
    const raw=Math.max(1,(rolledBaseDmg||0)*RG.elementEfficiency(P,weaponId)*RG.playerElementMul(P));
    const dmg=RG.dealElement(e,Math.max(0,rolledBaseDmg||0)*cfgBALANCECombatWeaponElementHit.directFactor*RG.playerElementMul(P),type);
    if(!e.dead&&!e.dying&&Math.random()<cfgBALANCECombatWeaponElementHit.chance_threshold)RG.applyElem(e,type,type==="fire"?cfgBALANCECombatWeaponElementHit.weaponElementHit:type==="ice"?RG.ETYPES.ice.rules.weaponElementHit.weaponElementHit:type==="poison"?cfgBALANCECombatWeaponElementHit.weaponElementHit_2:cfgBALANCECombatWeaponElementHit.weaponElementHit_3,raw*RG.elementDamageMultiplier(e,type),rolledBaseDmg||cfgBALANCECombatWeaponElementHit.weaponElementHit_4);
    return dmg;
  };

  RG.hurtEnemy = function (e, dmg, kx, ky, noSplash, noFeel, rangedHit, weaponId, origin) {
    if (e.isClone) { if (Math.random() < cfgBALANCECombatHurtEnemy.chance_threshold) RG.addText(e.x + rand(-8, 8), e.y - e.r - 8, "幻象!", "#c084fc", 12); return; }
    if (e.dead || e.dying) return;   // 死亡与濒死演出中不再结算
    if(e.spaceHidden)return;
    if(['beam','chain'].includes(weaponId)&&!origin?.spaceRouted&&RG.routeSpaceHit(e,dmg,weaponId,origin))return;
    // 武器身份优先于弹丸的布尔标记；近程霰弹也以弹丸结算。
    if (weaponId && RG.WEAPONS[weaponId]) rangedHit = RG.weaponIsRanged(weaponId);
    if(e.type==="bulwark"&&rangedHit){
      const from=origin||RG.P,want=Math.atan2(from.y-e.y,from.x-e.x),face=e.face==null?want:e.face;let da=want-face;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;
      if(Math.abs(da)<cfgETYPESBulwarkHurtEnemy.range_threshold){e.flash=.12;RG.rings.push({x:e.x,y:e.y,r:e.r,maxR:e.r+12,life:.16,maxLife:.16,color:"#94a3b8"});if(Math.random()<cfgETYPESBulwarkHurtEnemy.chance_threshold)RG.addText(e.x,e.y-e.r-8,"格挡","#e2e8f0",12);RG.playSfx("block");return;}
    }

    if(e.isMirror&&noSplash)e.splitFlash=cfgBALANCECombatHurtEnemy.splitFlash;
    const primary=damageSource==null;
    const r=RG.receiveDamage(e,RG.outgoingDamage(dmg,e,false,false,RG.P,primary,weaponId),{noSplash});
    const elementBase=r.elementBase;
    if (r.crit && !noFeel) RG.requestHitStop(0.025);   // 暴击微顿帧(noFeel 衍生弹不触发)
    // 护盾词缀:优先吸收
    applyEnemyDamage(e,r,false,false);
    if(primary){RG.consumeDashEcho(r);RG.consumeShieldCounter(r);}
    if (r.shieldBlocked) {
      if (!noSplash) RG.splash(e.x, e.y, dmg, e);
      return;
    }
    if(primary)RG.onCriticalCardHit(e,r);
    if (!noFeel && (e.elite || e.boss)) RG.cam.shake = Math.min(14, Math.max(RG.cam.shake || 0, e.boss ? 3.2 : 2.2));   // P2:精英/BOSS 受击更沉(noFeel 衍生弹除外)
    if (e.bossKind === "furnace"&&!(RG.isWorkshopBoss(e)&&(e.coolingT>0||e.overOrigin))) e.heat = Math.min(cfgBOSS_SKILLSFurnaceHurtEnemy.heat_cap, (e.heat || 0) + (r.dmg / (e.maxhp || 1)) * cfgBOSS_SKILLSFurnaceHurtEnemy.heat_factor);
    // 打击感:命中三档音 / 大体型局部脉冲 / 暴击震动 / 大伤害特殊反馈
    const pct = e.maxhp ? r.dmg / e.maxhp : 0;
    const bigBody = e.r > cfgBALANCECombatHurtEnemy.bigBody_threshold;
    if (bigBody) RG.rings.push({ x: e.x, y: e.y, r: e.r * 0.5, maxR: e.r * 1.05, life: 0.12, maxLife: 0.12, color: "#ffffff" });
    if (!noFeel && weaponId && (weaponId === "scythe" || weaponId === "spinner")) RG.addSpark(e.x, e.y - RG.WEAPONS.scythe.rules.hurtEnemy.hurtEnemy_offset, "melee", "#FFD166");
    if (r.crit && !noFeel) RG.vibrate(15, "crit", 120);
    const bigHit = pct >= cfgBALANCECombatHurtEnemy.bigHit_threshold && r.dmg >= cfgBALANCECombatHurtEnemy.bigHit_threshold_2;
    if (bigHit) {
      RG.requestHitStop(0.06);
      RG.cam.shake = Math.max(RG.cam.shake || 0, 12);
      RG.addText(e.x + rand(-6, 6), e.y - e.r - 12, (r.crit?"暴击 ":"")+Math.round(r.taken)+"!!", r.crit?"#fff0a8":"#ff7b7b", r.crit?32:28, { pop: true, life: 1.0, critical:r.crit });
      RG.addSpark(e.x, e.y - cfgBALANCECombatHurtEnemy.hurtEnemy_offset, "big", "#FF7B7B");
    }
    if(r.crit && !noFeel){RG.playSfx("crit",1,4);RG.addSpark(e.x,e.y-cfgBALANCECombatHurtEnemy.hurtEnemy_offset,"critical","#ffe8a1");}
    else if (!noFeel && !e.dead && e.hp > 0) RG.hitTier(pct >= 0.15 ? "heavy" : pct >= 0.03 ? "heavy" : "light", bigBody ? 0.8 : 1);   // v8.22:致命一击不叠打击层(与击杀音重叠,用户反馈"新旧声音叠在一起")
    // proc:碎片风暴(暴击 30%)——dps 用 raw 基准,不继承连击/完美闪避/狂血/暴伤链
    if (r.crit && RG.P.passives.shard && Math.random() < cfgPASSIVESShardHurtEnemy.chance_threshold) {
      RG.storms.push({ x: e.x, y: e.y, t: cfgPASSIVESShardHurtEnemy.t, r: cfgPASSIVESShardHurtEnemy.r, dps: r.raw * cfgPASSIVESShardHurtEnemy.dps_factor, rot: rand(0, TAU), hitN: new Map() });
    }
    // proc:回响弹头(暴击 12%:0.3 秒后原地回响 60% raw 伤害,目标已死则弹向 50px 内最近)
    if (r.crit && RG.P.passives.echo && Math.random() < cfgPASSIVESEchoHurtEnemy.chance_threshold) {
      (RG.echoQ = RG.echoQ || []).push({ x: e.x, y: e.y, tgt: e, t: cfgPASSIVESEchoHurtEnemy.t, dmg: r.raw * cfgPASSIVESEchoHurtEnemy.dmg_factor });
    }
    const petLv = RG.passiveValue(RG.P,"petrify");
    if (r.crit && petLv && Math.random() < Math.min(1,petLv)) {
      RG.refreshStatus(e,'petrifyT',e.boss?cfgPASSIVESPetrifyHurtEnemy.hurtEnemy:cfgPASSIVESPetrifyHurtEnemy.hurtEnemy_2);
      RG.addText(e.x,e.y-e.r-14,"石化!","#d6d3d1",14);
    }
    // proc:余烬(命中附燃)
    const emberLv = RG.passiveValue(RG.P,"ember");
    if (emberLv && !e.dead && Math.random() < Math.min(1,emberLv)) RG.applyElementOutput(e,"fire",cfgPASSIVESEmberHurtEnemy.hurtEnemy_applyElementOutputArg3,elementBase*cfgPASSIVESEmberHurtEnemy.hurtEnemy_factor*RG.playerElementMul(RG.P),elementBase);
    if ((kx || ky)&&!e.workshopHole) { const k = e.boss ? cfgBALANCECombatHurtEnemy.k : e.elite ? cfgBALANCECombatHurtEnemy.k_2 : 1; e.x += (kx || 0) * k; e.y += (ky || 0) * k; }
    if (r.crit && !bigHit) {
      RG.addText(e.x + rand(-6, 6), e.y - e.r - 6, "暴击 "+Math.round(r.taken)+"!", "#fff0a8", 26, { pop: true, life: .85, critical:true });
      // 暴击贴花已在独立反馈入口生成，避免叠播普通命中火花。
    } else if (!bigHit) {
      const show = pct >= cfgBALANCECombatHurtEnemy.show_threshold || Math.random() < cfgBALANCECombatHurtEnemy.show_threshold_2;
      if (show) RG.addText(e.x + rand(-6, 6), e.y - e.r - 4, Math.round(r.taken), "#ffffff", 13, { pop: true });
      if (!noFeel) RG.addSpark(e.x, e.y - cfgBALANCECombatHurtEnemy.hurtEnemy_offset, pct >= cfgBALANCECombatHurtEnemy.pct_threshold ? "heavy" : "light", "#F1F0FA");
    }
    if (RG.P.freezeC > 0 && !e.dead && e.frozen <= 0 && Math.random() < RG.P.freezeC) {
      RG.applyIceFreeze(e,e.boss?cfgBALANCECombatHurtEnemy.hurtEnemy_3:cfgBALANCECombatHurtEnemy.hurtEnemy_4);
      RG.applyElem(e,"ice",cfgBALANCECombatHurtEnemy.hurtEnemy_applyElemArg3,elementBase*cfgBALANCECombatHurtEnemy.hurtEnemy_factor*RG.playerElementMul(RG.P),elementBase);
      RG.addText(e.x, e.y - e.r - 14, "冻", "#7dd3fc", 13);
      RG.playSfx("freeze");
    }
    if (weaponId && e.hp > 0) RG.weaponElementHit(e,weaponId,elementBase);
    if (e.hp <= 0) {
      e.killWeapon = weaponId || null;
      const overflow = -e.hp;
      if (!e.boss && overflow > (e.maxhp || 1) * cfgBALANCECombatHurtEnemy.hurtEnemy_factor_2 && overflow > cfgBALANCECombatHurtEnemy.overflow_threshold) {
        RG.addText(e.x, e.y - e.r - 18, "过杀!", "#ff7b7b", 16, { pop: true, life: 0.9 });
        RG.addSpark(e.x, e.y - cfgBALANCECombatHurtEnemy.hurtEnemy_offset_2, "big", "#FF7B7B");
        RG.rings.push({ x: e.x, y: e.y, r: 8, maxR: 70, life: 0.22, maxLife: 0.22, color: "#ff7b7b" });
        const splashD = Math.min(overflow * cfgBALANCECombatHurtEnemy.splashD_factor, cfgBALANCECombatHurtEnemy.splashD_cap);
        for (const o of RG.enemies) {
          if (o.dead || o.dying || o === e || o.boss) continue;
          if (Math.hypot(o.x - e.x, o.y - e.y) < cfgBALANCECombatHurtEnemy.hurtEnemy_offset_3 + o.r) RG.dealPure(o, splashD);
        }
      }
      RG.startDying(e);
    }
    if (!noSplash) RG.splash(e.x, e.y, dmg, e);
  };
  RG.blockPlayerPhase = function () {
    const P=RG.P;
    if(!P || !(P.activeGuard>0))return false;
    P.activeGuard--;P.iTimer=Math.max(P.iTimer||0,RG.BALANCE.combat.blockPlayerPhase.iTimer_floor);
    if(!P.activeGuard&&P.aegisEvoT>0)P.aegisEvoT=0;
    RG.addText(P.x,P.y-28,"相位格挡"+(P.activeGuard?" ×"+P.activeGuard:""),"#38bdf8",14);
    RG.burst(P.x,P.y,"#38bdf8",7,110);RG.playSfx("block");return true;
  };
  // 抵挡只阻止本次效果，不清除已有负面；普通护盾不阻止附带效果。
  RG.applyPlayerDebuff = function (effects, outcome) {
    const P=RG.P;if(!P || RG.state!=="play")return false;
    if(outcome!==undefined){if(!["hurt","shield"].includes(outcome))return false;}
    else {if(P.iTimer>0)return false;if(RG.blockPlayerPhase())return false;}
    for(const [key,time]of Object.entries(effects))RG.refreshStatus(P,key,time);
    return true;
  };
  function reflectPhaseBullet(b){
    if(b.phaseReflected)return;b.phaseReflected=true;const P=RG.P;let target=null,nearest=cfgBALANCECombatReflectPhaseBullet.nearest_factor*cfgBALANCECombatReflectPhaseBullet.nearest_factor;
    for(const e of RG.enemies){if(e.dead||e.dying)continue;const d=dist2(P.x,P.y,e.x,e.y);if(d<nearest){nearest=d;target=e;}}
    const angle=target?Math.atan2(target.y-P.y,target.x-P.x):Math.atan2(-b.vy,-b.vx),speed=clamp(Math.hypot(b.vx,b.vy)||cfgBALANCECombatReflectPhaseBullet.speed,cfgBALANCECombatReflectPhaseBullet.speed_clampArg2,cfgBALANCECombatReflectPhaseBullet.speed_clampArg3);
    RG.bullets.push({x:P.x,y:P.y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,r:clamp(b.r||cfgBALANCECombatReflectPhaseBullet.r,1,cfgBALANCECombatReflectPhaseBullet.r_clampArg3),dmg:Math.max(0,b.dmg||0)*RG.ACTIVE_EVOLVE.aegis.branches.find(d=>d.id==='mirror').reflectionMul,pierce:0,life:cfgBALANCECombatReflectPhaseBullet.life,hitSet:new Set(),col:'#67e8f9',raw:true,active:'aegis',phaseReflected:true,damageSource:'active:aegis:mirror'});
    P.aegisReflected=Math.min(RG.ACTIVES.aegis.guards(RG.ACTIVES.aegis.maxLv),(P.aegisReflected||0)+1);
  };
  RG.hurtPlayer = function (dmg, shieldPierce, projectile, source) {
    const context=source&&typeof source==="object"?source:{};if(context.source)source=context.source;
    if(typeof shieldPierce==='string'){source=shieldPierce;shieldPierce=false;}
    const P = RG.P;
    if (P.iTimer > 0 || RG.state !== "play") return "immune";
    if (P.evade > 0 && Math.random() < P.evade) { P.iTimer = cfgBALANCECombatHurtPlayer.iTimer;if(P.passives.evade&&Number.isFinite(dmg)&&dmg>0)RG.refreshStatus(P,'dodgeSpeedT',RG.PASSIVES.evade.dodgeDuration); RG.addText(P.x, P.y - 26, "闪避!", "#c4b5fd", 15); return "evade"; }
    if (projectile && RG.passiveValue(P,"deflect") && Math.random() < Math.min(1,RG.passiveValue(P,"deflect"))) { P.iTimer = RG.PASSIVES.deflect.rules.hurtPlayer.iTimer; RG.addText(P.x, P.y - 26, "弹幕偏转!", "#38bdf8", 14, { pop: true }); RG.playSfx("block"); return false; }
    if (RG.blockPlayerPhase()) return "phase";
    P.shieldT = 0;
    if (P.shield > 0 && !shieldPierce) {
      const cost=dmg>cfgBALANCECombatHurtPlayer.tripleThreshold?cfgBALANCECombatHurtPlayer.tripleCost:dmg>=cfgBALANCECombatHurtPlayer.cost_threshold?cfgBALANCECombatHurtPlayer.cost:1;
      const missing=Math.max(0,cost-P.shield);
      P.shield = Math.max(0,P.shield-cost); P.iTimer = cfgBALANCECombatHurtPlayer.iTimer_2;
      if(P.passives.shieldcounter&&Number.isFinite(dmg)&&dmg>0)RG.refreshStatus(P,'shieldCounterT',RG.PASSIVES.shieldcounter.duration);
      const resonance=RG.resonanceBonus(P);
      if(!P.shield&&resonance.shieldBreakInvul&&!(P.resonanceShieldCd>0)){P.iTimer=Math.max(P.iTimer,resonance.shieldBreakInvul);P.resonanceShieldCd=resonance.shieldBreakCooldown;}
      if(cost>1&&P.shield===0){P.shieldRecoverSlow=true;P.shieldRecoverExtra=missing*cfgBALANCECombatHurtPlayer.missingRecovery;}
      // 荆棘反射:被抵挡的伤害按比例弹给 120px 内最近敌人(raw 基准;弹道无"攻击者"概念,取最近代替)
      const thLv = RG.passiveValue(P,"thorns");
      if (thLv) {
        const td = dmg * thLv * RG.mountainReflection(P);
        let tgt = null, bd = Infinity;
        for (const e of RG.enemies) { if (e.dead || e.dying) continue; const dv = dist2(P.x, P.y, e.x, e.y); if (dv < RG.PASSIVES.thorns.rules.hurtPlayer.dv_threshold && dv < bd) { bd = dv; tgt = e; } }
        if (tgt) {
          RG.dealPure(tgt, td);
          RG.beams.push({ x: P.x, y: P.y, a: Math.atan2(tgt.y - P.y, tgt.x - P.x), len: Math.sqrt(bd), life: 0.1, maxLife: 0.1, w: 2, chainCol: true });
        }
      }
      // 棱能护壁:最后一层盾破碎时产生范围冲击(raw 基准)
      if (P.shield <= 0 && RG.P.passives.prism) {
        const rr = cfgPASSIVESPrismHurtPlayer.rr, pd = (cfgPASSIVESPrismHurtPlayer.pd_offset + RG.P.level * cfgPASSIVESPrismHurtPlayer.pd_factor) * (1 + RG.run.t / 60 * cfgPASSIVESPrismHurtPlayer.pd_factor_2);
        RG.rings.push({ x: P.x, y: P.y, r: 10, maxR: rr, life: 0.25, maxLife: 0.25, color: "#38bdf8" });
        for (const e of RG.enemies) { if (!e.dead && Math.hypot(e.x - P.x, e.y - P.y) < rr + e.r) RG.dealPure(e, pd); }
        RG.addText(P.x, P.y - 26, "棱能冲击!", "#38bdf8", 14);
      }
      RG.addText(P.x, P.y - 26, "护盾抵消", "#38bdf8", 14);
      RG.burst(P.x, P.y, "#38bdf8", 8, 120);
      RG.playSfx("block");
      return "shield";
    }
    const real=RG.receiveDamage(P,RG.outgoingDamage(dmg,P,true,false,context.attacker||null),{projectile,element:context.element}).taken;
    if (P.passives.goldbell && (P.autoCd.goldbell || 0) <= 0 && (P.hp - real) / P.maxhp <= RG.lowHpThreshold(cfgPASSIVESGoldbellHurtPlayer.hurtPlayer_lowHpThresholdArg1,P)) {
      P.autoCd.goldbell = cfgPASSIVESGoldbellHurtPlayer.goldbell_factor * (P.globalCdMul || 1); P.iTimer = cfgPASSIVESGoldbellHurtPlayer.iTimer;
      RG.rings.push({x:P.x,y:P.y,r:12,maxR:92,life:0.5,maxLife:0.5,color:"#ffd166"});
      RG.addText(P.x,P.y-34,"金钟罩 · 5秒无敌!","#ffd166",17); RG.playSfx("block");
      return "immune";
    }
    // 承伤归因只记本次实际损失的生命；过量伤害、闪避和抵挡不参与复盘。
    const effective=Math.min(Math.max(0,P.hp),real);
    P.hp -= real; P.iTimer = cfgBALANCECombatHurtPlayer.iTimer_3;P.hurtFlash=cfgBALANCECombatHurtPlayer.hurtFlash;RG.hurtFx={freeze:cfgBALANCECombatHurtPlayer.freeze,slow:cfgBALANCECombatHurtPlayer.slow,red:cfgBALANCECombatHurtPlayer.red};RG.addSpark(P.x,P.y,'big','#ff7b7b');RG.burst(P.x,P.y,'#ff7b7b',6,110);
    if(Number.isFinite(effective)&&effective>0&&RG.run){
      const cause=typeof source==='string'&&source.trim()?source.trim().slice(0,cfgBALANCECombatHurtPlayer.cause_sliceArg2):'未知来源';
      RG.run.lastHit={source:cause,damage:effective,t:RG.run.t||0};
      const taken=RG.run.damageTakenBySource||(RG.run.damageTakenBySource={});taken[cause]=(taken[cause]||0)+effective;
      RG.run.totalDamageTaken=(RG.run.totalDamageTaken||0)+effective;
      if(P.hp<=0)RG.run.deathSource=cause;
    }
    if (P.comboBreakOnHit && RG.combo > 0) { RG.combo = 0; RG.comboT = 0; RG.comboKills=[]; RG.comboGlow=null; RG.comboGlowTier=0; RG.addText(P.x, P.y - 42, "连击中断", "#8b8fa8", 12); }
    RG.cam.shake = Math.max(RG.cam.shake, 5);
    RG.addText(P.x, P.y - 24, "-" + Math.round(real), "#ff5470", 15);
    RG.playSfx("hurt");
    if(effective>0 && P.passives.injury)P.injuryBonus=Math.min(cfgPASSIVESInjuryHurtPlayer.injuryBonus_cap,(P.injuryBonus||0)+cfgPASSIVESInjuryHurtPlayer.injuryBonus_factor*P.passives.injury);
    if(effective>0&&P.passives.pain)RG.refreshStatus(P,'painT',RG.PASSIVES.pain.duration);
    if(effective>RG.PASSIVES.retaliation.minimumHit && context.attacker && RG.passiveValue(P,"retaliation"))RG.dealPure(context.attacker,effective*RG.passiveValue(P,"retaliation")*RG.mountainReflection(P),false,true);
    if(P.hp<=0 && P.passives.revive && !P.reviveSpent){P.reviveSpent=true;P.hp=P.hpLocked?RG.OATH_NODES.sin_pride.lockedHp:Math.max(1,P.maxhp*cfgPASSIVESReviveHurtPlayer.hp_factor);P.iTimer=cfgPASSIVESReviveHurtPlayer.iTimer;RG.run.deathSource=null;RG.addText(P.x,P.y-48,"复生火种 · 复活！","#ffd166",22);}
    else if (P.hp <= 0) RG.gameOver();
    return "hurt";
  };
  // 通关、死亡、主动结束共用统计；无尽续玩只更新纪录，不重复累计局数。
  RG.settleRunCoins=function(){
    if(!RG.run)return 0;const coins=Math.round(RG.run.coins||0);RG.run.openingGold=0;
    const receipt=RG.namedRunReceipt?.();
    RG.run.earnedCoins=(RG.run.earnedCoins||0)+coins;
    const paid=receipt?Math.max(0,RG.run.earnedCoins-receipt.coins):coins;
    if(receipt)receipt.coins=Math.max(receipt.coins,RG.run.earnedCoins);
    RG.meta.coins+=paid;RG.run.coins=0;return paid;
  };
  RG.settleRunStats = function () {
    if (RG.unlockAchievement) {
      if ((RG.run.t || 0) >= cfgBALANCECombatSettleRunStats.range_threshold) RG.unlockAchievement("survivor_10");
      if ((RG.run.t || 0) >= cfgBALANCECombatSettleRunStats.range_threshold_2) RG.unlockAchievement("survivor_20");
      if ((RG.run.coins || 0) >= cfgBALANCECombatSettleRunStats.range_threshold_3) RG.unlockAchievement("rich");
    }
    const receipt=RG.namedRunReceipt?.();
    if (!RG.run.counted) { if(!receipt?.counted)RG.meta.runs = (RG.meta.runs || 0) + 1; RG.run.counted = true; }
    if(receipt)receipt.counted=true;
    if(!RG.run.rushMode&&['valley','workshop'].includes(RG.run.mapId)){
      const maps=RG.meta.maps||(RG.meta.maps={}),m=maps[RG.run.mapId]||(maps[RG.run.mapId]={});
      // 首通固定入局外余额，与普通金币高水位分开，命名现场重播也不会再领。
      if(RG.run.won&&!m.firstClearPaid){
        m.firstClearPaid=true;
        if(!(m.wins>0)){
          const bonus=RG.mapConfig().firstClearGold;
          RG.meta.coins+=bonus;RG.run.firstClearBonus=bonus;
          RG.addText(RG.P.x,RG.P.y-68,'地图首通 +'+bonus+'金','#ffd166',18);
        }
      }
      if(!RG.run.mapCounted&&!receipt?.mapCounted){m.runs=(m.runs||0)+1;RG.run.mapCounted=true;if(receipt)receipt.mapCounted=true;}
      if(RG.run.won&&!RG.run.mapWonCounted&&!receipt?.mapWonCounted){m.wins=(m.wins||0)+1;RG.run.mapWonCounted=true;if(receipt)receipt.mapWonCounted=true;}
      const claimed=RG.recordClaimedTime(m),tiers=Math.max(0,RG.recordTier(RG.run.t)-RG.recordTier(claimed));
      if(tiers){const bonus=tiers*RG.BALANCE.economy.mapRecord;RG.meta.coins+=bonus;RG.run.recordPaid=true;RG.run.recordBonus=(RG.run.recordBonus||0)+bonus;if(receipt)receipt.recordPaid=true;RG.addText(RG.P.x,RG.P.y-92,'地图新纪录档位 +'+bonus+'金','#ffd166',18);}
      m.recordRewardTime=Math.max(claimed,RG.run.t);
      m.bestTime=Math.max(m.bestTime||0,RG.run.t);m.bestKills=Math.max(m.bestKills||0,RG.run.kills);m.bestLevel=Math.max(m.bestLevel||1,RG.P.level);
    }
    const rec = { time: RG.run.t, kills: RG.run.kills, level: RG.P.level };
    if (RG.run.t > RG.best.time) {
      RG.best = rec;
      if (RG.saveBest) RG.saveBest();
      RG.addText(RG.P.x, RG.P.y - 40, "新纪录!", "#ffd166", 22);
    }
  };
  RG.gameOver = function () {
    if (RG.state === "over") return;
    if(RG.clearRunCheckpoint)RG.clearRunCheckpoint();RG.checkpointPending=false;
    RG.state = "over"; RG.playSfx("over");
    RG.offers=[];RG.offerRects=[];RG.selectedOffer=null;RG.P.levelQueue=[];
    RG.hurtFx=null; RG.deathFx={freeze:cfgBALANCECombatGameOver.freeze,slow:cfgBALANCECombatGameOver.slow,remaining:cfgBALANCECombatGameOver.remaining,duration:cfgBALANCECombatGameOver.duration};
    RG.cam.shake=Math.max(RG.cam.shake||0,16);
    RG.settleRunStats();
    if (RG.pushRunLog) RG.pushRunLog(false);
    RG.settleDaily(false);
    RG.settleRunCoins();
    RG.saveMeta();
  };
  // 暂停页主动结束:本局金币只结算一次，保留一条菜单回执后释放战场对象。
  RG.abandonRun = function () {
    if(RG.clearRunCheckpoint)RG.clearRunCheckpoint();RG.checkpointPending=false;
    if (!RG.run || !RG.P) { RG.state = "menu"; return; }
    const coins = Math.round(RG.run.coins || 0), time = RG.run.t || 0, kills = RG.run.kills || 0, level = RG.P.level || 1;
    RG.settleRunStats();
    RG.settleRunCoins(); RG.saveMeta();
    RG.menuNotice = { text:"本局已结算 · " + RG.fmtTime(time) + " · 击杀 " + kills + " · Lv " + level + " · 金 +" + coins, until:Date.now()+RG.BALANCE.combat.abandonRun.until_offset };
    RG.resetBattleState(); RG.state = "menu";
  };

  // ---------- 寻路:直路被墙挡时,探测斜向绕行 ----------
  function pathBlocked(ex, ey, px, py) {
    for (let i = 1; i <= 4; i++) {
      const t = i / 4;
      if (RG.blockedPoint(ex + (px - ex) * t, ey + (py - ey) * t)) return true;
    }
    return false;
  }
  function steerDir(e, ang) {
    for (const off of [0.6, -0.6, 1.2, -1.2, 1.8, -1.8]) {
      const a = ang + off;
      let clear = true;
      for (let i = 1; i <= 3; i++) if (RG.blockedPoint(e.x + Math.cos(a) * 70 * i, e.y + Math.sin(a) * 70 * i)) { clear = false; break; }
      if (clear) return a;
    }
    return ang + Math.PI / 2;
  }

  // ---------- BOSS AI ----------
  // H5:BOSS AI 已迁移至 systems_bosses.js。
  function novaPulse(st, knockMul, radiusMul) {
    const P = RG.P, rad = st.radius * (radiusMul || 1);
    RG.rings.push({ x: P.x, y: P.y, r: 12, maxR: rad, life: 0.35, maxLife: 0.35, color: st.evo ? "#ffd166" : "#ff8fa3" });
    if (st.pull) {
      for (const e of RG.enemies) {
        if (e.dead || e.boss || e.workshopHole) continue;
        const d = Math.hypot(e.x - P.x, e.y - P.y);
        if (d < rad + cfgBALANCECombatNovaPulse.rad_offset && d > cfgBALANCECombatNovaPulse.d_threshold) { e.x += (P.x - e.x) / d * 70; e.y += (P.y - e.y) / d * 70; }
      }
    }
    for (const e of RG.enemies) {
      if (e.dead || e.dying) continue;
      if (Math.hypot(e.x - P.x, e.y - P.y) < rad + e.r) {
        const ka = Math.atan2(e.y - P.y, e.x - P.x);
        RG.hurtEnemy(e, st.dmg, Math.cos(ka) * st.knock * knockMul, Math.sin(ka) * st.knock * knockMul, false, false, false, "nova");
      }
    }
    RG.playSfx("nova");
  }

  function nearestEnemy(x, y, range) {
    let tgt = null, bd = range * range;
    for (const e of RG.enemies) {
      if (e.dead || e.dying) continue;
      const dx=x-e.x,dy=y-e.y,d=dx*dx+dy*dy;
      if (d < bd) { bd = d; tgt = e; }
    }
    return tgt;
  }

  // 分身:复制真身外观与攻击,但不可被伤害;真身保留金环,分身微透明
  RG.bossSplit = function (src) {
    src.splitFlash = cfgBALANCECombatBossSplit.splitFlash;
    for (let i = 0; i < RG.SPAWN_COUNTS.bossSplit; i++) {
      const a = i / RG.SPAWN_COUNTS.bossSplit * TAU + rand(0, TAU);
      const c = {
        type: src.type, name: src.name, pattern: src.pattern, bossKind: src.bossKind,
        x: src.x + Math.cos(a) * 110, y: src.y + Math.sin(a) * 110, r: src.r,
        hp: src.hp, maxhp: src.maxhp, speed: src.speed * cfgBALANCECombatBossSplit.speed_factor, dmg: src.dmg, xp: 0,
        flash: 0, hitCds: {}, boss: true, elite: false, ranged: false, slow: false, homing: false, ghost: true,
        life: 0, vx: 0, vy: 0, frozen: 0, alpha: 0.85,
        burstT: rand(cfgBALANCECombatBossSplit.burstT_min, cfgBALANCECombatBossSplit.burstT_max), chargeT: rand(cfgBALANCECombatBossSplit.chargeT_min, cfgBALANCECombatBossSplit.chargeT_max), charging: 0, slamT: rand(cfgBALANCECombatBossSplit.slamT_min, cfgBALANCECombatBossSplit.slamT_max),
        spiralA: rand(0, TAU), spiralT: 0, summonT: rand(cfgBALANCECombatBossSplit.summonT_min, cfgBALANCECombatBossSplit.summonT_max), enraged: false,
        navT: 0, steerA: null, realmBoss: false, isClone: true, cloneLife: cfgBALANCECombatBossSplit.cloneLife,
      };
      RG.pushOutOfWalls(c, RG.walls); RG.constrain(c);
      RG.enemies.push(c);
    }
    RG.addText(src.x, src.y - src.r - 26, "✦ 分身!别打错目标!", "#c084fc", 16);
    RG.playSfx("boss"); RG.cam.shake = 9;
  };

  // ---------- BOSS 技能原语(v8.5):激光/追踪弹/超大弹/快慢辐射波/毒气/瞬移/真分裂 ----------
  RG.hbeams = [];   // 敌用直线激光:warn 虚线预警 → 点火一次性判定
  RG.fireHBeam = function (x, y, a, len, dmg, w, warn, source) {
    len = Math.max(len, cfgBALANCECombatFireHBeam.len_floor, Math.hypot(RG.W, RG.H) + cfgBALANCECombatFireHBeam.len_offset);
    RG.hbeams.push({ x, y, a, len, dmg, w: w || cfgBALANCECombatFireHBeam.w, warn: warn === undefined ? cfgBALANCECombatFireHBeam.warn : warn, fire: cfgBALANCECombatFireHBeam.fire, hitP: false,source });
    RG.playSfx("nova", 0.7);
  };
  RG.homingShot = function (e, n, speed, dmgMul, col, life) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU);
      RG.ebullets.push({source:enemyCause(e,'弹幕'), x: e.x, y: e.y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, r: cfgBALANCECombatHomingShot.r, dmg: e.dmg * dmgMul, life: (life || cfgBALANCECombatHomingShot.life) * cfgBALANCECombatHomingShot.life_factor, turn: cfgBALANCECombatHomingShot.turn, col: "#facc15", shape:"square" });
    }
  };
  RG.bigShots = function (e, n, speed, dmgMul, spread) {
    const a0 = Math.atan2(RG.P.y - e.y, RG.P.x - e.x);
    for (let i = 0; i < n; i++) {
      const a = a0 + (n > 1 ? (i / (n - 1) - 0.5) * (spread || 0.5) : 0);
      RG.ebullets.push({source:enemyCause(e,'弹幕'), x: e.x, y: e.y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, r: cfgBALANCECombatBigShots.r, dmg: e.dmg * dmgMul, life: cfgBALANCECombatBigShots.life, col: "#ff8c42" });
    }
  };
  RG.radialWaves = function (e, n, dmg) {
    // 快慢刀:快速层 + 慢速层(错半角)同心射出,逼"穿缝 + 重定位"两种走位
    const sm = e.spdMul || 1;
    for (let i = 0; i < n; i++) { const a = i / n * TAU; RG.ebullets.push({source:enemyCause(e,'弹幕'), x: e.x, y: e.y, vx: Math.cos(a) * cfgBALANCECombatRadialWaves.vx_factor * sm, vy: Math.sin(a) * cfgBALANCECombatRadialWaves.vy_factor * sm, r: cfgBALANCECombatRadialWaves.r, dmg, life: cfgBALANCECombatRadialWaves.life }); }
    for (let i = 0; i < n; i++) { const a = (i + 0.5) / n * TAU; RG.ebullets.push({source:enemyCause(e,'弹幕'), x: e.x, y: e.y, vx: Math.cos(a) * cfgBALANCECombatRadialWaves.vx_factor_2 * sm, vy: Math.sin(a) * cfgBALANCECombatRadialWaves.vy_factor_2 * sm, r: cfgBALANCECombatRadialWaves.r, dmg, life: cfgBALANCECombatRadialWaves.life_2 }); }
    RG.tone(150, 0.12, "square", 0.025, -70);
  };
  RG.poisonZone = function (x, y, r, dur, dps, source) {
    (RG.domains = RG.domains || []).push({ x, y, r, t: dur, type: "poison", dps, ptick: 0,source });
  };
  RG.bossTeleport = function (e) {
    // 瞬移:原地消散 → 玩家方位角附近 160~220px 重现(落点红环)
    const pa = Math.atan2(RG.P.y - e.y, RG.P.x - e.x) + rand(cfgBALANCECombatBossTeleport.pa_min, cfgBALANCECombatBossTeleport.pa_max);
    const d = rand(cfgBALANCECombatBossTeleport.d_min, cfgBALANCECombatBossTeleport.d_max);
    RG.rings.push({ x: e.x, y: e.y, r: e.r, maxR: e.r + 40, life: 0.25, maxLife: 0.25, color: "#c084fc" });
    e.x = RG.P.x + Math.cos(pa) * d; e.y = RG.P.y + Math.sin(pa) * d;
    RG.pushOutOfWalls(e, RG.walls); RG.constrain(e);
    RG.rings.push({ x: e.x, y: e.y, r: 4, maxR: e.r + 34, life: 0.32, maxLife: 0.32, color: "#ff5470" });
    RG.burst(e.x, e.y, "#c084fc", 10, 120);
    RG.playSfx("portal", 1.3);
  };
  RG.bossRealSplit = function (src, n, hpFrac, opts) {
    // 真分裂:可受伤子体(弹幕密度减半、不召唤、不冲锋只留环形弹),击杀掉经验不掉金币
    const o = opts || {};
    for (let i = 0; i < n; i++) {
      const a = i / n * TAU + rand(0, TAU);
      const c = {
        type: src.type, name: src.name, pattern: o.ringOnly ? 1 : src.pattern, bossKind: src.bossKind,
        x: src.x + Math.cos(a) * 100, y: src.y + Math.sin(a) * 100, r: src.r * cfgBALANCECombatBossRealSplit.r_factor,
        hp: src.maxhp * hpFrac, maxhp: src.maxhp * hpFrac, speed: src.speed * cfgBALANCECombatBossRealSplit.speed_factor, dmg: src.dmg * cfgBALANCECombatBossRealSplit.dmg_factor, xp: cfgBALANCECombatBossRealSplit.xp,
        flash: 0, hitCds: {}, boss: true, elite: false, ranged: false, slow: false, homing: false, ghost: true,
        life: 0, vx: 0, vy: 0, frozen: 0, alpha: 1,
        burstT: rand(cfgBALANCECombatBossRealSplit.burstT_min, cfgBALANCECombatBossRealSplit.burstT_max), chargeT: cfgBALANCECombatBossRealSplit.chargeT, charging: 0, slamT: cfgBALANCECombatBossRealSplit.slamT, spiralA: rand(0, TAU), spiralT: 0, summonT: cfgBALANCECombatBossRealSplit.summonT, enraged: false,
        navT: 0, steerA: null, cycle: src.cycle || 1, spdMul: src.spdMul || 1, enrageAt: cfgBALANCECombatBossRealSplit.enrageAt,attackMul:src.attackMul||1,
        isEcho: true, noCharge: true, splitChild: true, noCoin: true, densMul: cfgBALANCECombatBossRealSplit.densMul,
      };
      RG.pushOutOfWalls(c, RG.walls); RG.constrain(c);
      RG.enemies.push(c);
    }
    RG.addText(src.x, src.y - src.r - 28, "✦ 分裂!", "#ff5470", 15);
    RG.playSfx("boss");
  };

  // ---------- 空间哈希网格:每帧把敌人按圆心插入格子,子弹/回旋镖碰撞从"遍历全部敌人"降为"查邻近 3×3 格" ----------
  // 格子 128px:最大敌人 r=58(BOSS) + 最大弹体 r≈15 = 73 < 128,中心插入 + 3×3 查询保证不漏
  const GRID_CELL = 128, GRID_OFF = 2048, GRID_KEY = cfgBALANCECombatCommon.GRID_KEY;
  const grid = new Map();
  let gridTick = 0;
  RG.clearEnemyGrid=function(){const count=grid.size;grid.clear();gridTick=0;return count;};
  function gridRebuild() {
    gridTick++;
    for (const e of RG.enemies) {
      if (e.dead || e.dying) continue;
      const k = (Math.floor(e.x / GRID_CELL) + GRID_OFF) * GRID_KEY + (Math.floor(e.y / GRID_CELL) + GRID_OFF);
      let b = grid.get(k);
      if (!b) { b = []; b._tick = gridTick; grid.set(k, b); }
      else if (b._tick !== gridTick) { b.length = 0; b._tick = gridTick; }
      b.push(e);
    }
  }
  // 内联使用的格子取桶:返回当帧有效桶或 null
  function gridBucket(ix, iy) {
    const b = grid.get(ix * GRID_KEY + iy);
    return b && b._tick === gridTick ? b : null;
  }
  // 当前格及相邻八格足以证明最近目标时直接返回；否则沿用全表查询。
  // 子弹命中会击退敌人，此后本帧放弃此入口，避免使用移动前的格子。
  function nearestGridEnemy(x,y,range) {
    const gx=Math.floor(x/GRID_CELL),gy=Math.floor(y/GRID_CELL);
    let tgt=null,bd=range*range;
    for(let ix=gx-1;ix<=gx+1;ix++)for(let iy=gy-1;iy<=gy+1;iy++){
      const cell=gridBucket(ix+GRID_OFF,iy+GRID_OFF);if(!cell)continue;
      for(const e of cell){
        if(e.dead||e.dying)continue;
        const dx=x-e.x,dy=y-e.y,d=dx*dx+dy*dy;
        if(d<bd||(tgt&&d===bd&&e.bodyIndex<tgt.bodyIndex)){bd=d;tgt=e;}
      }
    }
    const outside=Math.min(x-(gx-1)*GRID_CELL,(gx+2)*GRID_CELL-x,y-(gy-1)*GRID_CELL,(gy+2)*GRID_CELL-y);
    return bd<outside*outside?tgt:nearestEnemy(x,y,range);
  }
  // 检查空间邻居，不再只检查数组中后8个单位；重合圆心也有确定的分离方向。
  RG.separateEnemies=function(){
    const fixed=e=>e.boss||e.workshopHole||e.chronoT>0||(e.type==="volt"&&e.voltCastT>0)||e.chargeRun>0;
    for(let i=0;i<RG.enemies.length;i++)RG.enemies[i].bodyIndex=i;
    const maxBody=RG.enemies.reduce((r,e)=>e.dead||e.dying||e.workshopHole?r:Math.max(r,RG.enemyBodyRadius(e)),0);
    for(let pass=0;pass<4;pass++){
      gridRebuild();
      for(const a of RG.enemies){
        if(a.dead||a.dying||a.workshopHole)continue;
        const ix=Math.floor(a.x/GRID_CELL)+GRID_OFF,iy=Math.floor(a.y/GRID_CELL)+GRID_OFF;
        const reach=Math.ceil((RG.enemyBodyRadius(a)+maxBody)/GRID_CELL);
        for(let gx=ix-reach;gx<=ix+reach;gx++)for(let gy=iy-reach;gy<=iy+reach;gy++){
          const bucket=gridBucket(gx,gy);if(!bucket)continue;
          for(const b of bucket){
            if(b.bodyIndex<=a.bodyIndex||b.dead||b.dying||b.workshopHole)continue;
            const rr=RG.enemyBodyRadius(a)+RG.enemyBodyRadius(b),dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy;
            if(d2>=rr*rr)continue;
            const af=fixed(a),bf=fixed(b);if(af&&bf)continue;
            const d=Math.sqrt(d2),angle=(b.bodyIndex-a.bodyIndex)*2.4;
            const nx=d>.001?dx/d:Math.cos(angle),ny=d>.001?dy/d:Math.sin(angle),push=Math.min(16,rr-d);
            const share=af||bf?1:.5;
            if(!af){a.x-=nx*push*share;a.y-=ny*push*share;}
            if(!bf){b.x+=nx*push*share;b.y+=ny*push*share;}
          }
        }
      }
    }
    for(const e of RG.enemies)if(!e.dead&&!e.dying&&!fixed(e)){RG.pushOutOfWalls(e,RG.walls);RG.constrain(e);}
  };

  // 嫉妒罪印:窃取的 BOSS 权能走独立自动冷却，不占 Q/E。
  function updateEnvyPower(P, dt) {
    const power = P.envyPower;
    if (!power || power === "shadow") return;
    P.envyCd = (P.envyCd || 0) - dt;
    if (P.envyCd > 0) return;
    const scale = (1 + Math.min(cfgBALANCECombatUpdateEnvyPower.scale_cap, RG.run.t / 60) * cfgBALANCECombatUpdateEnvyPower.scale_factor) * RG.playerDamageMul();
    if (power === "golem") {
      P.envyCd = cfgBOSS_SKILLSGolemUpdateEnvyPower.envyCd;
      RG.rings.push({ x:P.x, y:P.y, r:12, maxR:360, life:0.35, maxLife:0.35, color:"#fb923c" });
      for (const e of RG.enemies) {
        if (e.dead || e.dying) continue;
        const dx = Math.abs(e.x - P.x), dy = Math.abs(e.y - P.y);
        if ((dx < 48 && dy < 360) || (dy < 48 && dx < 360)) RG.dealPure(e, cfgBOSS_SKILLSGolemUpdateEnvyPower.value_165_factor * scale);
      }
      RG.addText(P.x, P.y - 42, "窃取权能 · 裂地十字", "#fb923c", 14);
    } else if (power === "eye") {
      P.envyCd = cfgBOSS_SKILLSEyeUpdateEnvyPower.envyCd;
      for (let k = 0; k < 8; k++) RG.beams.push({ x:P.x, y:P.y, a:k/8*TAU, len:520, life:0.22, maxLife:0.22, w:8, chainCol:true });
      for (const e of RG.enemies) {
        if (e.dead || e.dying) continue;
        const dx=e.x-P.x, dy=e.y-P.y, d=Math.hypot(dx,dy);
        if (d > cfgBOSS_SKILLSEyeUpdateEnvyPower.d_threshold) continue;
        let da=Math.atan2(dy,dx)%(Math.PI/4); if (da<0) da+=Math.PI/4;
        da=Math.min(da,Math.PI/4-da);
        if (Math.sin(da)*d < cfgBOSS_SKILLSEyeUpdateEnvyPower.value_18_offset+e.r) RG.dealPure(e, cfgBOSS_SKILLSEyeUpdateEnvyPower.value_135_factor * scale);
      }
      RG.addText(P.x, P.y - 42, "窃取权能 · 米字凝视", "#7dd3fc", 14);
    } else if (power === "homing" || power === "barrage") {
      P.envyCd = power === "homing" ? cfgETYPESHomingUpdateEnvyPower.envyCd : cfgETYPESHomingUpdateEnvyPower.envyCd_2;
      const target = RG.enemies.find(e=>!e.dead&&!e.dying);
      if (!target) { P.envyCd = 1; return; }
      const a = Math.atan2(target.y-P.y,target.x-P.x), n = power === "homing" ? cfgETYPESHomingUpdateEnvyPower.n : cfgETYPESHomingUpdateEnvyPower.n_2;
      for(let i=0;i<n;i++) friendlyShot(P,a+(power==="homing"?(i-1)*cfgETYPESHomingUpdateEnvyPower.value_factor:i/n*TAU), (power==="homing"?cfgETYPESHomingUpdateEnvyPower.value:cfgETYPESHomingUpdateEnvyPower.value_2)*scale, power==="homing");
      RG.addText(P.x,P.y-42,"窃取权能 · "+(power==="homing"?"追踪弹":"密集弹幕"),"#7dd3fc",14);
    } else if (power === "gluttony") {
      P.envyCd = cfgBOSS_SKILLSGluttonyUpdateEnvyPower.envyCd;
      RG.rings.push({ x:P.x, y:P.y, r:320, maxR:20, life:0.45, maxLife:0.45, color:"#f59e0b", shrink:260 });
      for (const e of RG.enemies) {
        if (e.dead || e.dying) continue;
        const dx=P.x-e.x, dy=P.y-e.y, d=Math.hypot(dx,dy)||1;
        if (d > cfgBOSS_SKILLSGluttonyUpdateEnvyPower.value_320_offset+e.r) continue;
        if (!e.boss&&!e.workshopHole) { e.x += dx/d*90; e.y += dy/d*90; }
        RG.dealPure(e, cfgBOSS_SKILLSGluttonyUpdateEnvyPower.value_115_factor * scale);
      }
      RG.addText(P.x, P.y - 42, "窃取权能 · 吞噬", "#fbbf24", 14);
    }
  }

  RG.hurtAlly = function (al, dmg) {
    if (!al || al.dead || al.hp == null) return;
    if((al.iTimer||0)>0)return;
    al.hp -= Math.max(1,dmg); al.flash=0.12;al.iTimer=RG.BALANCE.combat.hurtAlly.iTimer;
    if(al.hp<=0){al.dead=true;RG.onSummonExit(al);RG.burst(al.x,al.y,al.decoy?"#fbbf24":"#4ade80",10,120);if(al.decoy)RG.addText(al.x,al.y-28,"替罪羊破碎","#fbbf24",13);}
  };
  RG.enemyTarget = function (e, P) {
    if(e.boss) return P;
    const bait=(RG.decoys||[]).find(a=>!a.dead&&a.t>0&&a.hp>0);
    if(bait) return bait;
    let target=P,bd=dist2(e.x,e.y,P.x,P.y);
    for(const a of RG.allies||[]){if(a.dead||a.hp==null||a.hp<=0)continue;const d=dist2(e.x,e.y,a.x,a.y);if(d<bd){bd=d;target=a;}}
    return target;
  };

  function autoReset(P, id, seconds) {
    P.autoCd[id] = seconds * (P.globalCdMul || 1);
  }
  // 同一波使用位移前的实体快照，避免数组顺序改变撞击；每只小怪至多结算一次。
  RG.repulseEnemies=function(P,lv){
    const radius=cfgBALANCECombatRepulseEnemies.radius_offset+lv*cfgBALANCECombatRepulseEnemies.radius_factor,distance=cfgBALANCECombatRepulseEnemies.distance_offset+lv*cfgBALANCECombatRepulseEnemies.distance_factor,damage=(cfgBALANCECombatRepulseEnemies.damage_offset+lv*cfgBALANCECombatRepulseEnemies.damage_factor)*(1+RG.run.t/60*cfgBALANCECombatRepulseEnemies.damage_factor_2)*RG.playerDamageMul();
    const bodies=RG.enemies.filter(e=>!e.dead&&!e.dying&&!e.isClone&&!e.isEcho&&!e.workshopHole&&!e.workshopWorm).map(e=>({e,x:e.x,y:e.y,r:e.r}));
    RG.rings.push({x:P.x,y:P.y,r:10,maxR:radius,life:.35,maxLife:.35,color:'#60a5fa'});
    for(const body of bodies){
      const e=body.e,dx=body.x-P.x,dy=body.y-P.y,d=Math.hypot(dx,dy);
      if(d>radius+e.r)continue;
      let collision=false;
      if(!e.boss&&e.r<=cfgBALANCECombatRepulseEnemies.r_threshold&&d>0){
        const nx=dx/d,ny=dy/d;let travel=distance;
        for(const other of bodies){
          if(other===body)continue;
          const ox=other.x-body.x,oy=other.y-body.y,projection=ox*nx+oy*ny,rr=body.r+other.r;
          if(projection<=0||projection>distance+rr)continue;
          const cross=ox*ny-oy*nx,disc=rr*rr-cross*cross;
          if(disc<=0)continue;
          const hit=Math.max(0,projection-Math.sqrt(disc));
          if(hit<travel){travel=hit;collision=true;}
        }
        // 小步只用于墙和边界：不跳过薄墙，也不把怪推到场外。
        const steps=Math.ceil(travel/Math.min(cfgBALANCECombatRepulseEnemies.steps_cap,e.r)),step=steps?travel/steps:0;
        for(let i=0;i<steps;i++){
          e.x+=nx*step;e.y+=ny*step;const x=e.x,y=e.y;
          const wall=RG.pushOutOfWalls(e,RG.walls);RG.constrain(e);
          if(wall||Math.abs(e.x-x)>1e-7||Math.abs(e.y-y)>1e-7){collision=true;break;}
        }
      }
      RG.dealPure(e,damage,false,false,'pushwave');
      if(collision&&!e.dead&&!e.dying)RG.dealPure(e,damage*RG.PASSIVES.pushwave.collisionMul,false,false,'pushwave');
    }
  };
  // F2 自动机制卡:独立冷却，不占 Q/E；队列均有硬上限。
  function updateAutoCards(P, dt) {
    P.autoCd = P.autoCd || {};
    for (const id in P.autoCd) P.autoCd[id] = Math.max(0, P.autoCd[id] - dt);
    if(P.passives.mirrorecho&&(P.autoCd.mirrorecho||0)<=0){if(P.lastActiveId)RG.useActive(P.lastActiveId,true);P.autoCd.mirrorecho=RG.PASSIVES.mirrorecho.period;}
    if(P.passives.goldrain&&(P.autoCd.goldrain||0)<=0){RG.triggerGoldRain(P);autoReset(P,'goldrain',RG.PASSIVES.goldrain.period);}

    const meteorLv = P.passives.meteor || 0;
    if (meteorLv && (P.autoCd.meteor || 0) <= 0) {
      const visible = RG.enemies.filter(e => !e.dead && !e.dying && Math.abs(e.x-P.x) < RG.W*cfgPASSIVESMeteorUpdateAutoCards.visible_factor && Math.abs(e.y-P.y) < RG.H*cfgPASSIVESMeteorUpdateAutoCards.visible_factor);
      const tgt = visible.length ? pick(visible) : RG.enemies.find(e=>!e.dead&&!e.dying);
      if (tgt) {
        RG.autoFx = RG.autoFx || [];
        if (RG.autoFx.filter(f=>f.type==="meteor").length >= cfgPASSIVESMeteorUpdateAutoCards.length_threshold) RG.autoFx.splice(RG.autoFx.findIndex(f=>f.type==="meteor"),1);
        RG.autoFx.push({ type:"meteor", x:tgt.x+rand(-22,22), y:tgt.y+rand(-22,22), t:0.75, max:0.75, r:82+meteorLv*8, dmg:[0,200,280,380][meteorLv]*(1+RG.run.t/60*0.18)*RG.playerDamageMul() });
        autoReset(P,"meteor",cfgPASSIVESMeteorUpdateAutoCards.autoReset_autoResetArg3);
      } else P.autoCd.meteor = cfgPASSIVESMeteorUpdateAutoCards.meteor;
    }

    const poisonLv = P.passives.poisontrail || 0;
    if (poisonLv && P.moving && (P.autoCd.poisontrail || 0) <= 0) {
      const owned = (RG.vials||[]).filter(v=>v.poisonTrail);
      if (owned.length >= cfgPASSIVESPoisontrailUpdateAutoCards.length_threshold_2) owned[0].t = 0;
      RG.vials.push({ x:P.x, y:P.y, r:cfgPASSIVESPoisontrailUpdateAutoCards.r_offset+poisonLv*cfgPASSIVESPoisontrailUpdateAutoCards.r_factor, t:cfgPASSIVESPoisontrailUpdateAutoCards.t, arm:0, tick:0, dmg:(cfgPASSIVESPoisontrailUpdateAutoCards.dmg_offset+poisonLv*cfgPASSIVESPoisontrailUpdateAutoCards.dmg_factor)*(1+RG.run.t/60*cfgPASSIVESPoisontrailUpdateAutoCards.dmg_factor_2), noSlow:true, poison:true, poisonTrail:true });
      autoReset(P,"poisontrail",poisonLv>=cfgPASSIVESPoisontrailUpdateAutoCards.poisonLv_threshold?cfgPASSIVESPoisontrailUpdateAutoCards.value:RG.AUTO_CARD_CDS.poisontrail);
    }

    const ecoLv = P.passives.ecosystem || 0;
    if (ecoLv && (P.autoCd.ecosystem || 0) <= 0) {
      RG.healFields = [{ x:P.x, y:P.y, r:cfgPASSIVESEcosystemUpdateAutoCards.r_offset_2+ecoLv*cfgPASSIVESEcosystemUpdateAutoCards.r_factor_2, t:cfgPASSIVESEcosystemUpdateAutoCards.t_2, max:cfgPASSIVESEcosystemUpdateAutoCards.max, hps:ecoLv>=cfgPASSIVESEcosystemUpdateAutoCards.hps_threshold?cfgPASSIVESEcosystemUpdateAutoCards.hps:cfgPASSIVESEcosystemUpdateAutoCards.hps_2 }];
      autoReset(P,"ecosystem",ecoLv>=cfgPASSIVESEcosystemUpdateAutoCards.ecoLv_threshold?cfgPASSIVESEcosystemUpdateAutoCards.value_3:RG.AUTO_CARD_CDS.ecosystem);
      RG.addText(P.x,P.y-40,"生命生态圈 展开","#4ade80",14);
    }
    P.ecoGuard = 0;
    for (const f of RG.healFields||[]) {
      f.t -= dt;
      if (f.t>0 && dist2(P.x,P.y,f.x,f.y)<f.r*f.r) {
        if (P.healBan || P.healBlocked || P.hpLocked) P.ecoGuard = Math.max(P.ecoGuard,RG.BALANCE.combat.updateAutoCards.ecoGuard_floor);
        else P.hp = Math.min(P.maxhp,P.hp+f.hps*dt);
      }
    }
    RG.healFields = (RG.healFields||[]).filter(f=>f.t>0);

    const pushLv = P.passives.pushwave || 0;
    if (pushLv && (P.autoCd.pushwave || 0) <= 0) {
      RG.repulseEnemies(P,pushLv);
      autoReset(P,"pushwave",[0,RG.AUTO_CARD_CDS.pushwave,cfgPASSIVESPushwaveUpdateAutoCards.value_6,cfgPASSIVESPushwaveUpdateAutoCards.value_2][pushLv]);
      RG.playSfx("nova");
    }

    const scapegoatLv=P.passives.scapegoat||0;
    if(scapegoatLv&&(P.autoCd.scapegoat||0)<=0){
      if((RG.decoys||[]).filter(a=>!a.dead&&a.hp>0&&a.t>0).length<RG.decoyLimit(P)){
        const duration=RG.summonDuration(cfgPASSIVESScapegoatUpdateAutoCards.duration_summonDurationArg1,P);
        RG.decoys.push({x:P.x+Math.cos(P.face+Math.PI)*54,y:P.y+Math.sin(P.face+Math.PI)*54,r:cfgPASSIVESScapegoatUpdateAutoCards.r,hp:scapegoatLv>=cfgPASSIVESScapegoatUpdateAutoCards.hp_threshold?cfgPASSIVESScapegoatUpdateAutoCards.hp:cfgPASSIVESScapegoatUpdateAutoCards.hp_2,maxhp:scapegoatLv>=cfgPASSIVESScapegoatUpdateAutoCards.maxhp_threshold?cfgPASSIVESScapegoatUpdateAutoCards.hp:cfgPASSIVESScapegoatUpdateAutoCards.hp_2,t:duration,max:duration,rallyLv:P.passives.rally||0,decoy:true});
        autoReset(P,"scapegoat",scapegoatLv>=cfgPASSIVESScapegoatUpdateAutoCards.scapegoatLv_threshold?cfgPASSIVESScapegoatUpdateAutoCards.value_7:RG.AUTO_CARD_CDS.scapegoat);RG.addText(P.x,P.y-42,"替罪羊 · 全体嘲讽","#fbbf24",14);
      }else P.autoCd.scapegoat=cfgPASSIVESScapegoatUpdateAutoCards.scapegoat;
    }
    for(const d of RG.decoys||[]){d.t-=dt;d.iTimer=Math.max(0,(d.iTimer||0)-dt);if(d.t<=0&&!d.dead){d.dead=true;RG.onSummonExit(d);}}
    RG.decoys=(RG.decoys||[]).filter(d=>!d.dead&&d.hp>0&&d.t>0);

    if(P.passives.holylight&&(P.autoCd.holylight||0)<=0){
      const room=Math.max(0,RG.holyLightLimit(P)-(RG.allies||[]).filter(a=>a.source==='holylight'&&!a.dead&&a.hp>0&&a.t>0).length);
      const chosen=RG.enemies.filter(e=>!e.dead&&!e.dying&&!e.boss&&!e.elite&&!e.support&&!e.homing&&!e.workshopHole)
        .sort((a,b)=>dist2(a.x,a.y,P.x,P.y)-dist2(b.x,b.y,P.x,P.y)).slice(0,Math.min(room,RG.PASSIVES.holylight.targets));
      if(chosen.length){
        const duration=RG.summonDuration(cfgPASSIVESHolylightUpdateAutoCards.duration_summonDurationArg1,P);
        for(const e of chosen){e.dead=true;(RG.allies=RG.allies||[]).push({source:'holylight',x:e.x,y:e.y,r:e.r,hp:Math.max(cfgPASSIVESHolylightUpdateAutoCards.hp_floor,e.maxhp*cfgPASSIVESHolylightUpdateAutoCards.hp_factor),maxhp:Math.max(cfgPASSIVESHolylightUpdateAutoCards.maxhp_floor,e.maxhp*cfgPASSIVESHolylightUpdateAutoCards.maxhp_factor),dmg:Math.max(cfgPASSIVESHolylightUpdateAutoCards.dmg_floor,e.dmg*cfgPASSIVESHolylightUpdateAutoCards.dmg_factor),fireT:cfgPASSIVESHolylightUpdateAutoCards.fireT,t:duration,max:duration,rallyLv:P.passives.rally||0,converted:true,type:e.type,face:0,flash:0});RG.burst(e.x,e.y,"#fde68a",6,80);}
        RG.enemies=RG.enemies.filter(e=>!chosen.includes(e));autoReset(P,"holylight",cfgPASSIVESHolylightUpdateAutoCards.autoReset_autoResetArg3);RG.addText(P.x,P.y-62,"圣光感化 ×"+chosen.length,"#fde68a",16);
      }else P.autoCd.holylight=cfgPASSIVESHolylightUpdateAutoCards.holylight;
    }

    for (const f of RG.autoFx||[]) {
      if(f.done)continue;
      if(f.type==='valhalla'){
        f.done=true;
        if(P.passives.valhalla&&P.hp>0){
          const damage=f.dmg*RG.playerDamageMul(false);
          for(const e of RG.enemies)if(!e.dead&&!e.dying&&dist2(f.x,f.y,e.x,e.y)<=Math.pow(f.r+e.r,2))RG.dealPure(e,damage,false,false,'valhalla',{summon:true});
          RG.rings.push({x:f.x,y:f.y,r:8,maxR:f.r,life:.3,maxLife:.3,color:'#a7f3d0'});
        }
        continue;
      }
      if(f.active==='collapse'){
        const branch=RG.ACTIVE_EVOLVE.collapse.branches.find(b=>b.id===f.branch),step=Math.min(dt,Math.max(0,f.t));f.t=Math.max(0,f.t-dt);
        if(f.type==='collapseWell'){
          for(const e of RG.enemies){if(e.dead||e.dying||e.workshopHole||e.frozen>0||e.chronoT>0||RG.timeStop>0)continue;const dx=f.x-e.x,dy=f.y-e.y,d=Math.hypot(dx,dy);if(d>1&&d<=f.r+e.r){const pull=Math.min(d-1,(e.boss?branch.bossPull:branch.mobPull)*step*(f.copyScale??1));e.x+=dx/d*pull;e.y+=dy/d*pull;if(RG.collideWalls)RG.collideWalls(e);}}
          f.tick-=step;while(f.tick<=1e-9){f.tick=Math.min(branch.period,f.tick+branch.period);for(const e of RG.enemies)if(!e.dead&&!e.dying&&dist2(f.x,f.y,e.x,e.y)<=Math.pow(f.r+e.r,2))RG.dealPure(e,f.dmg*branch.pulse,false,false,f.damageSource);}
        }else if(f.t<=0){
          for(const e of RG.enemies)if(!e.dead&&!e.dying&&dist2(f.x,f.y,e.x,e.y)<=Math.pow(f.r+e.r,2))RG.dealPure(e,f.dmg*branch.multiplier,false,false,f.damageSource);
          RG.rings.push({x:f.x,y:f.y,r:12,maxR:f.r,life:.35,maxLife:.35,color:'#fde047'});RG.playSfx('nova');
        }
        if(f.t<=0)f.done=true;continue;
      }
      f.t -= dt;
      if (f.done || f.t>0) continue;
      f.done=true;
      if(f.type==="meteor"){
        RG.rings.push({x:f.x,y:f.y,r:8,maxR:f.r,life:0.3,maxLife:0.3,color:"#fb923c"});
        RG.burst(f.x,f.y,"#fb923c",20,240); RG.cam.shake=Math.max(RG.cam.shake,8); RG.playSfx("boom");
        for(const e of RG.enemies) if(!e.dead&&!e.dying&&dist2(e.x,e.y,f.x,f.y)<(f.r+e.r)*(f.r+e.r)) RG.dealPure(e,f.dmg);
      }
    }
    RG.autoFx=(RG.autoFx||[]).filter(f=>!f.done);
  }

  // ---------- 主更新 ----------
  // 用真实时间推进停帧和慢动作，战斗时钟只接收缩放后的时间。
  RG.damageFeedbackStep=function(dt,fx,mul){
    if(!fx)return dt;if(fx.red!=null)fx.red=Math.max(0,fx.red-dt);
    const frozen=Math.min(dt,fx.freeze);fx.freeze=Math.max(0,fx.freeze-frozen);dt-=frozen;
    const slow=Math.min(dt,fx.slow);fx.slow=Math.max(0,fx.slow-slow);return dt-slow*(1-mul);
  };
  RG.updateDeathFeedback=function(dt){
    const fx=RG.deathFx;if(!fx)return;fx.remaining=Math.max(0,fx.remaining-dt);const motion=RG.damageFeedbackStep(dt,fx,.12);
    // 结算后只推进视觉，禁止再次伤害、刷怪或增加奖励。
    for(const list of [RG.bullets,RG.ebullets,RG.parts])for(const b of list){b.x+=(b.vx||0)*motion;b.y+=(b.vy||0)*motion;}
    for(const e of RG.enemies)if(!e.dead&&!e.dying){e.x+=(e.motionX||0)*motion;e.y+=(e.motionY||0)*motion;}
    for(const r of RG.rings)if(!(r.delay>0)){r.life=Math.max(0,r.life-motion);if(!r.static)r.r+=(r.speed||(r.hazard?210:r.maxR/r.maxLife))*motion;}
    RG.cam.shake=Math.max(0,(RG.cam.shake||0)-dt*12);if(fx.remaining<=0)RG.deathFx=null;
  };
  RG.fanWaveHits=function(wave,target,previous){
    const dx=target.x-wave.x,dy=target.y-wave.y,d=Math.hypot(dx,dy),radius=target.r||0;
    if(d-radius>Math.min(wave.r,wave.maxR)+7||d+radius<previous-7)return false;
    let angle=Math.atan2(dy,dx)-wave.a;while(angle>Math.PI)angle-=TAU;while(angle<-Math.PI)angle+=TAU;
    return Math.abs(angle)<=wave.half+Math.asin(Math.min(1,radius/Math.max(1,d)));
  };
  let lastMotionPlayer=null,lastMotionX=0,lastMotionY=0;
  // 五类更新保留原调用位置；真实时间仅传给原本使用它的死亡结算。
  function updatePlayerMovement(P,dt,externalMove,frameStartX,frameStartY){
    // 移动:静止起步 0.2s / 冲刺收势 0.1s 缓起；仅闪现位移本身允许穿墙。
    RG.tickStatus(P,'stunT',dt);
    const inp = P.stunT > 0 ? { x: 0, y: 0 } : RG.getInput();
    const ghost = P.dashT > 0 && (P.dashGhost || 0) > 0;
    const wasDash=P.dashT>0,warped=externalMove||dist2(P.x,P.y,frameStartX,frameStartY)>1e-8;
    const moveStartX=P.x,moveStartY=P.y;
    if (P.dashT > 0) {
      // 冲刺:高速位移 + 残影
      const dashX = P.x, dashY = P.y;
      P.dashT -= dt;
      const dsp = P.speed * cfgBALANCECombatUpdatePlayerMovement.dsp_factor;
      P.x += Math.cos(P.dashA) * dsp * dt; P.y += Math.sin(P.dashA) * dsp * dt;
      RG.hitVoidstep(dashX, dashY);
      if (Math.random() < cfgBALANCECombatUpdatePlayerMovement.value_threshold) RG.burst(P.x, P.y, "#7c6cf0", 1, 60);
      if (P.dashT <= 0) {   // 落点反馈:收势环+尘土;随后 0.1s 缓起但不再拥有穿墙权限
        P.dashT = 0; P.dashGhost = 0;
        RG.rings.push({ x: P.x, y: P.y, r: 6, maxR: P.r + 16, life: 0.22, maxLife: 0.22, color: "#8f85f2" });
        RG.burst(P.x, P.y, "#a5a0f5", 5, 85);
        if (P.envyPower === "shadow") {
          const pd = (cfgBOSS_SKILLSShadowUpdatePlayerMovement.pd_offset + P.level * cfgBOSS_SKILLSShadowUpdatePlayerMovement.pd_factor) * (1 + RG.run.t / 60 * cfgBOSS_SKILLSShadowUpdatePlayerMovement.pd_factor_2) * RG.playerDamageMul();
          for (let k = 0; k < RG.SPAWN_COUNTS.envyShadow; k++) {
            const a = k / RG.SPAWN_COUNTS.envyShadow * TAU;
            RG.bullets.push({ x:P.x, y:P.y, vx:Math.cos(a)*cfgBOSS_SKILLSShadowUpdatePlayerMovement.vx_factor, vy:Math.sin(a)*cfgBOSS_SKILLSShadowUpdatePlayerMovement.vy_factor, r:cfgBOSS_SKILLSShadowUpdatePlayerMovement.r, dmg:pd, pierce:1, life:cfgBOSS_SKILLSShadowUpdatePlayerMovement.life, hitSet:new Set(), col:"#c084fc", raw:true });
          }
          RG.addText(P.x, P.y - 38, "影跃 · 八方影弹", "#c084fc", 13);
        }
        P.moveRamp = 0; P.rampFast = true;
        RG.pushOutOfWalls(P, RG.walls);
      }
    } else if (inp.x || inp.y) {
      P.moveRamp = Math.min(1, (P.moveRamp || 0) + dt / (P.rampFast ? cfgBALANCECombatUpdatePlayerMovement.moveRamp : cfgBALANCECombatUpdatePlayerMovement.moveRamp_2));   // 0→1 爬升(静止起步 0.2s,闪现后 0.1s)
      if (P.moveRamp >= 1) P.rampFast = false;
      const l = Math.max(1, Math.hypot(inp.x, inp.y));
      const spd = RG.walkSpeed(P) * P.moveRamp;
      // 贴墙滑行:轴分离移动+各自推挤，普通行走永远参与墙体碰撞。
      P.x += inp.x / l * spd * dt; RG.pushOutOfWalls(P, RG.walls);
      P.y += inp.y / l * spd * dt; RG.pushOutOfWalls(P, RG.walls);
      P.face = Math.atan2(inp.y, inp.x);
    } else { P.moveRamp = 0; P.rampFast = false; }
    if (!ghost) RG.pushOutOfWalls(P, RG.walls);
    RG.constrain(P);
    if(!ghost)RG.resolveFrostWalls(P,moveStartX,moveStartY);
    const moved=dist2(P.x,P.y,moveStartX,moveStartY)>1e-8;
    P.moving=moved||warped;P.stillT=P.moving?0:(P.stillT||0)+dt;
    if(P.passives.windwalker)P.windMoveT=moved&&!warped?Math.min(RG.PASSIVES.windwalker.maxStacks,(P.windMoveT||0)+dt):0;
    else if(P.windMoveT!==undefined)P.windMoveT=0;
    if(warped){
      if(P.dashEchoT!==undefined)RG.clearStatus(P,'dashEchoT');
      if(P.echoDashActive!==undefined)P.echoDashActive=false;
      if(P.echoDashMoved!==undefined)P.echoDashMoved=false;
    }else if(wasDash&&P.echoDashActive){
      if(moved)P.echoDashMoved=true;
      if(!P.dashT){
        if(P.echoDashMoved&&P.passives.dashecho)RG.refreshStatus(P,'dashEchoT',RG.PASSIVES.dashecho.duration);
        P.echoDashActive=false;P.echoDashMoved=false;
      }
    }
    P.iTimer = Math.max(0, P.iTimer - dt);
    P.hurtFlash=Math.max(0,(P.hurtFlash||0)-dt);
    P.dashCd = Math.max(0, P.dashCd - dt);
    P.dashGraze = Math.max(0, (P.dashGraze || 0) - dt);
    P.pdBuff = Math.max(0, (P.pdBuff || 0) - dt);
    RG.tickStatus(P,'slowT',dt);RG.tickStatus(P,'giantT',dt);RG.tickStatus(P,'howlDebuffT',dt);RG.tickStatus(P,'tetherGuardT',dt);
    if (P.regen && !P.healBan && !P.hpLocked && !P.healBlocked) P.hp = Math.min(P.maxhp, P.hp + P.regen * dt);
    if(P.shopRegen){P.shopRegenT+=dt;const ticks=Math.floor((P.shopRegenT+1e-9)/RG.perkConfig("p_regen").period);if(ticks){P.shopRegenT=Math.max(0,P.shopRegenT-ticks*RG.perkConfig("p_regen").period);if((!P.healBan||P.wrathMetaHeal)&&!P.healBlocked&&!P.hpLocked)P.hp=Math.min(P.maxhp,P.hp+ticks*RG.perkConfig("p_regen").health);}}
    updateAutoCards(P, dt);
    if (P.shieldMax > 0) { P.shieldT += dt*(1+(RG.resonanceBonus(P).shieldRecovery||0)+(RG.mountainReady(P)?RG.PASSIVES.mountain.recovery[P.passives.mountain]:0)); if (P.shieldT >= (P.shieldRecoverSlow?cfgBALANCECombatUpdatePlayerMovement.value+(P.shieldRecoverExtra||0):cfgBALANCECombatUpdatePlayerMovement.value_2) && P.shield < P.shieldMax) { P.shield += 1; P.shieldT = 0; P.shieldRecoverSlow=false;P.shieldRecoverExtra=0; } }
    if (P.passives.barrier) {
      P.barrierT -= dt;
      if (P.barrierT <= 0) {
        const alive = RG.walls.filter(w => w.temp).length;
        if (alive < RG.PASSIVES.barrier.wallBaseLimit + P.passives.barrier) RG.addTempWall();
        P.barrierT = RG.PASSIVES.barrier.period;
      }
    }
  }

  function updateWeapons(P,dt){
    // 武器
    for (const id in P.weapons) {
      const lv = P.weapons[id], baseSt = RG.weaponStat(id, lv, P.evolved[id]);
      const continuous=id==='orbit'||id==='kiwave'||id==='beam';
      const isRanged = RG.weaponIsRanged(id);
      const rb = isRanged ? (P.rangedMul || 1) : 1+RG.passiveValue(P,"melee_power"), vb = isRanged ? (P.visionMul || 1) : 1+RG.passiveValue(P,"melee_range");
      let st = baseSt;
      if (rb !== 1 || vb !== 1) {
        st = Object.assign({}, baseSt);
        if (rb !== 1) {
          if (typeof st.dmg === "number") st.dmg *= rb;
          if (typeof st.dot === "number") st.dot *= rb;
        }
        if(vb!==1){if(isRanged){for(const field of ['range','targetRange','hop'])if(st[field])st[field]*=vb;}else for(const field of ["range","radius","length","width"])if(typeof st[field]==="number")st[field]*=vb;}
      }
      P.weaponCd[id] = (P.weaponCd[id] || 0) - dt;
      // 先推进旧队列，新一轮只追加自己的攻击，绝不覆盖正在等待的后段。
      const delayed=id==='bolt'?P.boltBurstQueue:id==='seeker'?P.seekerBurstQueue:id==='hammer'?P.hammerQueue:id==='nova'?P.novaQueue:null;
      if(delayed){
        for(const event of delayed){event.t-=dt;if(event.t>1e-9)continue;
          const firstBullet=RG.bullets.length,age=clamp(-event.t,0,dt);
          if(id==='bolt')fireBoltVolley(P,event.st,event.a,event.n);
          else if(id==='seeker')fireSeekerVolley(P,event.st);
          else if(id==='hammer')strikeHammer(event.attack,event.st);
          else novaPulse(event.st,0,cfgBALANCECombatUpdateWeapons.novaPulse_novaPulseArg3);
          for(let i=firstBullet;i<RG.bullets.length;i++)RG.bullets[i].frameDt=age;
        }
        const live=delayed.filter(event=>event.t>1e-9);
        if(id==='bolt')P.boltBurstQueue=live;else if(id==='seeker')P.seekerBurstQueue=live;else if(id==='hammer')P.hammerQueue=live;else P.novaQueue=live;
      }
      for(let attempt=0;attempt<ATTACK_BUDGET;attempt++){
      const readyCd=P.weaponCd[id],bulletsBefore=RG.bullets.length,boomsBefore=RG.booms.length,vialsBefore=RG.vials.length,shotAge=clamp(-readyCd,0,dt);
      if (id === "bolt") {
        if (P.weaponCd[id] <= 0) {
          let tgt = null, bd = st.range * st.range;
          for (const e of RG.enemies) { if(e.dead||e.dying)continue;const d = dist2(P.x, P.y, e.x, e.y); if (d < bd) { bd = d; tgt = e; } }
          if (tgt) {
            advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
            const baseA = Math.atan2(tgt.y - P.y, tgt.x - P.x), n = st.count + P.extraShots;
            fireBoltVolley(P,st,baseA,n);
            if(P.boltDouble)pushDelayed(P.boltBurstQueue,{t:RG.perkConfig("p_boltburst").delay-shotAge,st:{...st},a:baseA,n});
            RG.playSfxVar("shoot", 1.06, 0.045);   // P2 魔弹:清脆稳定
          }
        }
      } else if (id === "seeker") {
        if (P.weaponCd[id] <= 0) {
          advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
          fireSeekerVolley(P,st);
          if(st.burstDelay)pushDelayed(P.seekerBurstQueue,{t:st.burstDelay-shotAge,st:{...st}});
        }
      } else if (id === "laser") {
        if (P.weaponCd[id] <= 0) {
          // 目标按距离排序;歼星射线(lv9)双射线
          const cands = [];
          for (const e of RG.enemies) { if (e.dead || e.dying) continue; const d = dist2(P.x, P.y, e.x, e.y); if (d < st.range * st.range) cands.push([d, e]); }
          if (cands.length) {
            cands.sort((a, b) => a[0] - b[0]);
            advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
            const shots = st.twin ? cfgWEAPONSLaserUpdateWeapons.shots : 1;
            for (let si = 0; si < Math.min(shots, cands.length); si++) {
              const tgt = cands[si][1];
              const a = Math.atan2(tgt.y - P.y, tgt.x - P.x);
              const segments=RG.traceLaser(P.x,P.y,a,st.range,st.reflections);
              RG.playSfxVar("nova", 1.4, 0.05);   // P2 激光:高频 zap
              for(const segment of segments){
                RG.beams.push({...segment,shield:null,life:.14,maxLife:.14,w:st.width,dmg:st.dmg,evo:st.evo});
                if(segment.shield){segment.shield.flash=.12;RG.playSfx("block");}
                if(segment.hostile){RG.hbeams.push({...segment,shield:null,w:st.width,warn:0,fire:.14,dmg:st.dmg,hitP:false,source:'领域主宰 · 反射玩家激光'});continue;}
                for (const e of RG.enemies) {
                if (e.dead || e.dying) continue;
                if(e===segment.shield)continue;
                const t=clamp((e.x-segment.x)*Math.cos(segment.a)+(e.y-segment.y)*Math.sin(segment.a),0,segment.len);
                const lx=segment.x+Math.cos(segment.a)*t,ly=segment.y+Math.sin(segment.a)*t;
                if(dist2(lx,ly,e.x,e.y)<(e.r+st.width/cfgWEAPONSLaserUpdateWeapons.width_divisor)**2)RG.hurtEnemy(e,st.dmg,0,0,true,false,true,"laser",segment);
                }
              }
            }
        }
      }
    } else if (id === "orbit") {
        const sweep=st.spin / Math.max(cfgWEAPONSOrbitUpdateWeapons.sweep_floor, P.cdMulEff || 1) * dt;
        const fromAngle=P.orbitAngle;P.orbitAngle+=sweep;
        // 每个目标只计算一次圆弧角度；先用平方距离排除远处敌人。
        const candidates=[];
        for(const e of RG.enemies){
          if(e.dead||e.dying||(e.hitCds.orbit||0)>0)continue;
          const d2=dist2(P.x,P.y,e.x,e.y),body=e.r+cfgWEAPONSOrbitUpdateWeapons.body_factor*(st.size||1);
          if(d2>(st.radius+body)**2||d2<Math.max(0,st.radius-body)**2)continue;
          const d=Math.sqrt(d2),half=d?Math.acos(clamp((st.radius*st.radius+d2-body*body)/(cfgWEAPONSOrbitUpdateWeapons.half_factor*st.radius*d),-1,1)):Math.PI;
          candidates.push({e,half,angle:Math.atan2(e.y-P.y,e.x-P.x)});
        }
        for (let i = 0; i < st.blades; i++) {
          for (const {e,half,angle} of candidates) {
            if (e.dead || e.dying || (e.hitCds["orbit"] || 0) > 0) continue;
            const readyAt=e.hitCds.orbit==null?0:clamp(dt+e.hitCds.orbit,0,dt),rate=sweep/dt;
            let arc=angle-(fromAngle+rate*readyAt+i/st.blades*TAU);arc=((arc%TAU)+TAU)%TAU;
            const availableSweep=sweep-rate*readyAt;
            const crossed=arc<=availableSweep||TAU-arc<=half||arc-availableSweep<=half;
            if (crossed) {
              const ka = Math.atan2(e.y - P.y, e.x - P.x);
              RG.hurtEnemy(e, st.dmg, Math.cos(ka) * cfgWEAPONSOrbitUpdateWeapons.value_factor, Math.sin(ka) * cfgWEAPONSOrbitUpdateWeapons.value_factor, false, false, false, "orbit");
              RG.playSfxVar("hit", 1.25, 0.14);   // P2 环刃:切割声随机音高
              const hitAt=TAU-arc<=half?readyAt:clamp(readyAt+(arc-half)/rate,readyAt,dt);
              e.hitCds["orbit"] = st.hitCd-(dt-hitAt);
            }
          }
        }
      } else if (id === "nova") {
        if (P.weaponCd[id] > 0 && P.weaponCd[id] < cfgWEAPONSNovaUpdateWeapons.id_threshold && !P["pre_nova"]) {   // P2 冲击波蓄力预警
          P["pre_nova"] = true;
          RG.rings.push({ x: P.x, y: P.y, r: st.radius, maxR: st.radius, life: 0.2, maxLife: 0.2, color: "rgba(255,143,163,0.5)", shrink: st.radius / 0.2 });
        }
        if (P.weaponCd[id] <= 0) {
          P["pre_nova"] = false;
          advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
          novaPulse(st, st.pulses > 1 ? cfgWEAPONSNovaUpdateWeapons.value : 1, 1);   // v8.24:多连冲时首脉冲击退减半,给后续脉冲留目标
          const extra = (st.pulses || 1) - 1;
          for(let pulse=1;pulse<=extra;pulse++)pushDelayed(P.novaQueue,{t:cfgWEAPONSNovaUpdateWeapons.t_factor*pulse-shotAge,st:{...st}});
        }
      } else if (id === "scythe") {
        if (P.weaponCd[id] <= 0) {
          const tgt = nearestEnemy(P.x, P.y, st.radius + cfgWEAPONSScytheUpdateWeapons.tgt_offset);
          if (tgt) {
            advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
            const a = Math.atan2(tgt.y-P.y,tgt.x-P.x);
            RG.slashes.push({x:P.x,y:P.y,a,r:st.radius,arc:st.arc,life:.2,maxLife:.2,col:"#f472b6"});
            for (const e of RG.enemies) {
              if (e.dead || e.dying) continue;
              const dx=e.x-P.x,dy=e.y-P.y,d=Math.hypot(dx,dy)||1;
              if (d>st.radius+e.r) continue;
              let da=Math.atan2(dy,dx)-a;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;
              if(Math.abs(da)<=st.arc/cfgWEAPONSScytheUpdateWeapons.arc_divisor+Math.asin(Math.min(1,e.r/d))){
                const executeMul=st.execute&&e.maxhp&&e.hp/e.maxhp<=st.execute?cfgWEAPONSScytheUpdateWeapons.executeMul:1;
                RG.hurtEnemy(e,st.dmg*executeMul,dx/d*cfgWEAPONSScytheUpdateWeapons.value_factor,dy/d*cfgWEAPONSScytheUpdateWeapons.value_factor,false,false,false,"scythe");
              }
            }
            RG.playSfxVar("hit",.72,.06);
          } else P.weaponCd[id]=cfgWEAPONSScytheUpdateWeapons.id;
        }
      } else if (id === "spinner") {
        if (P.weaponCd[id] <= 0) {
          const tgt=nearestEnemy(P.x,P.y,st.targetRange);
          if(tgt){
            advanceCd(P.weaponCd,id,st.cd*P.cdMulEff);const a=Math.atan2(tgt.y-P.y,tgt.x-P.x),d=Math.hypot(tgt.x-P.x,tgt.y-P.y);
            const count=st.count||1;
            while(RG.spinners.length+count>cfgWEAPONSSpinnerUpdateWeapons.value_threshold)RG.spinners.shift();
            for(let si=0;si<count;si++){
              const sa=a+(si-(count-1)/cfgWEAPONSSpinnerUpdateWeapons.sa_divisor)*cfgWEAPONSSpinnerUpdateWeapons.sa_factor;
              RG.spinners.push({id:++RG.spinnerSeq,x:P.x,y:P.y,a:sa,spin:0,vx:Math.cos(sa)*st.speed,vy:Math.sin(sa)*st.speed,travel:Math.min(cfgWEAPONSSpinnerUpdateWeapons.travel_cap,d/st.speed),t:st.duration,r:st.radius,dmg:st.dmg,hitCd:st.hitCd,weapon:"spinner",frameDt:shotAge});
            }
            RG.playSfxVar("shoot",.68,.05);
          }else P.weaponCd[id]=cfgWEAPONSSpinnerUpdateWeapons.id;
        }
      } else if (id === "kiwave") {
        if(P.weaponCd[id]<=0){
          advanceCd(P.weaponCd,id,st.spawnCd*(P.globalCdMul||1));
          if(RG.qiOrbs.length<st.max){RG.qiOrbs.push({a:rand(0,TAU),shot:rand(cfgWEAPONSKiwaveUpdateWeapons.shot_min,cfgWEAPONSKiwaveUpdateWeapons.shot_max)});RG.playSfxVar("choose",1.35,.05);}
        }
        while(RG.qiOrbs.length>st.max)RG.qiOrbs.pop();
        for(let qi=0;qi<RG.qiOrbs.length;qi++){
          const q=RG.qiOrbs[qi];q.a+=dt*(1.15+qi*.025);q.x=P.x+Math.cos(q.a+qi/Math.max(1,RG.qiOrbs.length)*TAU)*st.radius;q.y=P.y+Math.sin(q.a+qi/Math.max(1,RG.qiOrbs.length)*TAU)*st.radius;
          q.shot-=dt;
          for(let shot=0;q.shot<=1e-9&&shot<ATTACK_BUDGET;shot++){
            const tgt=nearestEnemy(q.x,q.y,st.range);
            if(!tgt){q.shot=cfgWEAPONSKiwaveUpdateWeapons.shot;break;}
            const age=clamp(-q.shot,0,dt);advanceCd(q,'shot',st.shotCd*P.cdMulEff);
            const a=Math.atan2(tgt.y-q.y,tgt.x-q.x)+rand(-st.aimSpread,st.aimSpread);
            RG.bullets.push({x:q.x,y:q.y,vx:Math.cos(a)*st.speed,vy:Math.sin(a)*st.speed,r:(st.pierce?cfgWEAPONSKiwaveUpdateWeapons.r:cfgWEAPONSKiwaveUpdateWeapons.r_2)*P.bulletR,dmg:st.dmg,pierce:st.pierce||0,life:st.range/st.speed,hitSet:new Set(),col:"#67e8f9",ki:true,weapon:"kiwave",frameDt:age});
          }
          q.shot=Math.max(0,q.shot);
        }
      } else if (id === "chain") {
        if (P.weaponCd[id] <= 0) {
          // 闪电链:最近目标起跳,向附近敌人逐个传导
          const hitSet = new Set();
          let prev = { x: P.x, y: P.y };
          for (let h = 0; h < st.jumps; h++) {
            let tgt = null, bd = (h === 0 ? st.range : st.hop); bd *= bd;
            for (const e of RG.enemies) {
              if (e.dead || e.dying || hitSet.has(e)) continue;
              const d = dist2(prev.x, prev.y, e.x, e.y);
              if (d < bd) { bd = d; tgt = e; }
            }
            if (!tgt) break;
            if(!RG.routeSpaceHit(tgt,st.dmg,'chain',prev)){
              RG.beams.push({ x: prev.x, y: prev.y, a: Math.atan2(tgt.y - prev.y, tgt.x - prev.x), len: Math.hypot(tgt.x - prev.x, tgt.y - prev.y), life: 0.12, maxLife: 0.12, w: 3.5, chainCol: true });
              RG.hurtEnemy(tgt, st.dmg, 0, 0, true, false, true, "chain",{spaceRouted:true});
            }
            hitSet.add(tgt); prev = tgt;
          }
          if (hitSet.size) { advanceCd(P.weaponCd,id,st.cd * P.cdMulEff); }
        }
      } else if (id === "beam") {
        // 熔断射线:持续锁定最近敌人,同一目标锁得越久伤越高(0.5s+40%,1.5s+80%),切目标重置
        // 同一目标锁定 >5s → 过热 1s；射线击杀任一目标后固定冷却 0.5s。
        P.beamOver = Math.max(0, (P.beamOver || 0) - dt);
        if (P.beamOver > 0) { P.beamTgt = null; P.beamLock = 0; }
        else {
          P.beamTick = (P.beamTick || 0) - dt;
          for(let pulse=0;P.beamTick<=1e-9&&pulse<ATTACK_BUDGET;pulse++) {
            const beamStep = st.cd * Math.max(cfgWEAPONSBeamUpdateWeapons.beamStep_floor, P.cdMulEff || 1);
            advanceCd(P,'beamTick',beamStep);
            let tgt = null, bd = Infinity;
            for (const e of RG.enemies) { if (e.dead || e.dying) continue; const dv = dist2(P.x, P.y, e.x, e.y); if (dv < st.range * st.range && dv < bd) { bd = dv; tgt = e; } }
            if (tgt) {
              if (P.beamTgt !== tgt) { P.beamTgt = tgt; P.beamLock = 0; }
              P.beamLock += beamStep;
              if (P.beamLock > cfgWEAPONSBeamUpdateWeapons.beamLock_threshold && !st.noOverheat) {
                P.beamOver = RG.WEAPONS.beam.overheatCooldown;
                RG.addText(P.x, P.y - 44, "熔断过热!", "#ff9d5c", 14);
                break;
              } else {
                if(st.noOverheat)P.beamLock=Math.min(P.beamLock,cfgWEAPONSBeamUpdateWeapons.beamLock_cap);
                const ramp = P.beamLock > cfgWEAPONSBeamUpdateWeapons.ramp_threshold ? cfgWEAPONSBeamUpdateWeapons.ramp : P.beamLock > cfgWEAPONSBeamUpdateWeapons.ramp_threshold_2 ? cfgWEAPONSBeamUpdateWeapons.ramp_2 : 1;
                const aa = Math.atan2(tgt.y - P.y, tgt.x - P.x);
                if(!RG.routeSpaceHit(tgt,st.dmg*ramp,'beam',P)){
                  RG.beams.push({ x: P.x, y: P.y, a: aa, len: Math.hypot(tgt.x - P.x, tgt.y - P.y), life: 0.14, maxLife: 0.14, w: st.width, col: "#ff9d5c" });
                  RG.hurtEnemy(tgt, st.dmg * ramp, 0, 0, true, false, true, "beam",{spaceRouted:true});
                }
                if (tgt.dying && tgt.killWeapon === "beam") {
                  P.beamOver = Math.max(P.beamOver, cfgWEAPONSBeamUpdateWeapons.beamOver_floor); P.beamTgt = null; P.beamLock = 0;
                  break;
                }
                if (Math.random() < cfgWEAPONSBeamUpdateWeapons.value_threshold) RG.playSfxVar("hit", 1.5, 0.1);   // P2 熔断:持续滋滋
              }
            } else { P.beamTgt = null; P.beamLock = 0; }
          }
          P.beamTick=Math.max(0,P.beamTick);
        }
      } else if (id === "vial") {
        if (P.weaponCd[id] <= 0) {
          let tgt = null, bd = Infinity;
          for (const e of RG.enemies) { if (e.dead || e.dying) continue; const dv = dist2(P.x, P.y, e.x, e.y); if (dv < cfgWEAPONSVialUpdateWeapons.value_90000_factor*vb*vb && dv < bd) { bd = dv; tgt = e; } }
          if (tgt) {
            advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
            (RG.vials = RG.vials || []).push({ x: tgt.x, y: tgt.y, r: st.radius, t: st.duration || cfgWEAPONSVialUpdateWeapons.t, arm: cfgWEAPONSVialUpdateWeapons.arm, tick: 0, dmg: st.dot, weapon:"vial", forcedElement:st.forcedElement });
            RG.rings.push({ x: tgt.x, y: tgt.y, r: 6, maxR: st.radius, life: 0.3, maxLife: 0.3, color: "#a3e635" });
            RG.playSfx("nova", 1.2);
          } else P.weaponCd[id] = cfgWEAPONSVialUpdateWeapons.id;
        }
      } else if (id === "hammer") {
        if(P.weaponCd[id]<=0){
          const tgt=nearestEnemy(P.x,P.y,st.length);
          if(tgt){
            const attack={x:P.x,y:P.y,a:Math.atan2(tgt.y-P.y,tgt.x-P.x),length:st.length,width:st.width};
            strikeHammer(attack,st);advanceCd(P.weaponCd,id,st.cd*P.cdMulEff);
            if(st.aftershock)pushDelayed(P.hammerQueue,{t:cfgWEAPONSHammerUpdateWeapons.t_offset-shotAge,attack:{...attack,length:attack.length*cfgWEAPONSHammerUpdateWeapons.length_factor,width:attack.width*cfgWEAPONSHammerUpdateWeapons.width_factor},st:{...st,dmg:st.dmg*cfgWEAPONSHammerUpdateWeapons.dmg_factor}});
          }
        }
      } else if (id === "scatter") {
        if (P.weaponCd[id] <= 0) {
          advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
          const n = st.count + P.extraShots;
          for (let i = 0; i < n; i++) {
            const a = P.face + (n > 1 ? (i / (n - 1) - 0.5) * st.spread * 2 : 0);
            RG.bullets.push({ x: P.x, y: P.y, sx: P.x, sy: P.y, falloff: !st.slug, maxDist: st.range, vx: Math.cos(a) * st.speed, vy: Math.sin(a) * st.speed, r: (st.slug?cfgWEAPONSScatterUpdateWeapons.r:cfgWEAPONSScatterUpdateWeapons.r_2) * st.pelletSize * P.bulletR, dmg: st.dmg, pierce: st.pierce, life: st.range / st.speed, hitSet: new Set(), col: "#fbbf24", weapon:"scatter" });   // v8.23:穿透 2 + 距离衰减
          }
          RG.playSfxVar("shoot", 0.92, 0.09);   // P2 霰弹:宽散粗粝
        }
      } else if (id === "boomer") {
        if (P.weaponCd[id] <= 0) {
          let tgt = null, bd = st.targetRange * st.targetRange;
          for (const e of RG.enemies) { if(e.dead||e.dying)continue;const d = dist2(P.x, P.y, e.x, e.y); if (d < bd) { bd = d; tgt = e; } }
          const baseA = tgt ? Math.atan2(tgt.y - P.y, tgt.x - P.x) : P.face;
          advanceCd(P.weaponCd,id,st.cd * P.cdMulEff);
          const n = st.count + P.extraShots;
          for (let i = 0; i < n; i++) {
            const a = baseA + i / n * TAU;
            RG.booms.push({ x: P.x, y: P.y, a, dist: 0, dir: 1, spin: 0, dmg: st.dmg, speed: st.speed, range: st.range, evo: st.evo, size: st.size, hitCd:st.hitCd||RG.WEAPONS.boomer.rules.updateWeapons.hitCd, weapon:"boomer" });
          }
          RG.playSfx("boom");
        }
      }
      // 新弹体只走从实际发射时刻到本帧末尾的时间，补发不额外增加射程。
      if(!continuous){
        for(let i=bulletsBefore;i<RG.bullets.length;i++)RG.bullets[i].frameDt=shotAge;
        for(let i=boomsBefore;i<RG.booms.length;i++)RG.booms[i].frameDt=shotAge;
        for(let i=vialsBefore;i<RG.vials.length;i++)RG.vials[i].frameDt=shotAge;
      }
      if(continuous||P.weaponCd[id]>1e-9||P.weaponCd[id]===readyCd)break;
      }
      P.weaponCd[id]=Math.max(0,P.weaponCd[id]);
    }

    // 旋转连棍:短促飞向目标后驻场旋转；每根棍对每个目标有独立命中冷却。
    for(const sp of RG.spinners||[]){
      const moveDt=sp.frameDt??dt;delete sp.frameDt;
      const oldX=sp.x,oldY=sp.y,oldSpin=sp.spin,travelDt=Math.min(moveDt,Math.max(0,sp.travel));
      sp.spin+=moveDt*cfgBALANCECombatUpdateWeapons.spin_factor;sp.travel-=travelDt;sp.x+=sp.vx*travelDt;sp.y+=sp.vy*travelDt;sp.t-=moveDt-travelDt;
      if(RG.teleportSpaceProjectile(sp,oldX,oldY))continue;
      if(RG.blockedPoint(sp.x,sp.y))sp.travel=0;
      const steps=Math.min(cfgBALANCECombatUpdateWeapons.steps_cap,Math.max(1,Math.ceil(moveDt*cfgBALANCECombatUpdateWeapons.steps_factor/cfgBALANCECombatUpdateWeapons.steps_divisor)));
      for(const e of RG.enemies){
        const key='spinner'+sp.id;if(e.dead||e.dying||(e.hitCds[key]||0)>0)continue;
        for(let step=0;step<=steps;step++){
          const age=moveDt*step/steps,readyAt=e.hitCds[key]==null?0:Math.max(0,moveDt+e.hitCds[key]);if(age<readyAt)continue;
          const angle=oldSpin+age*11,ax=Math.cos(angle),ay=Math.sin(angle),cx=oldX+(sp.x-oldX)*step/steps,cy=oldY+(sp.y-oldY)*step/steps;
          const proj=clamp((e.x-cx)*ax+(e.y-cy)*ay,-sp.r,sp.r);
          if(dist2(cx+ax*proj,cy+ay*proj,e.x,e.y)<(e.r+cfgBALANCECombatUpdateWeapons.r_offset)**2){RG.hurtEnemy(e,sp.dmg,0,0,true,false,true,sp.weapon);e.hitCds[key]=sp.hitCd-(moveDt-age);break;}
        }
      }
      if(sp.t<=0)sp.dead=true;
    }
    RG.spinners=(RG.spinners||[]).filter(sp=>!sp.dead);

    // 回旋镖(越墙)
    for (const bm of RG.booms) {
      const moveDt=bm.frameDt??dt;delete bm.frameDt;const oldX=bm.x,oldY=bm.y;
      bm.spin += cfgBALANCECombatUpdateWeapons.spin_factor_2 * moveDt;
      if (bm.dir === 1) {
        const travel=(bm.range/cfgBALANCECombatUpdateWeapons.travel_divisor-bm.dist)*(1-Math.exp(cfgBALANCECombatUpdateWeapons.travel_factor*bm.speed*moveDt/bm.range));
        bm.x += Math.cos(bm.a) * travel; bm.y += Math.sin(bm.a) * travel;
        bm.dist += travel;
        if (bm.dist >= bm.range) { bm.dir = -1; RG.playSfx("shoot", 0.62); }   // P2 回程低鸣,与去程区别
      } else {
        const dx = P.x - bm.x, dy = P.y - bm.y, d = Math.hypot(dx, dy) || 1;
        const sp = bm.speed * cfgBALANCECombatUpdateWeapons.sp_factor;
        const travel=Math.min(d,sp*moveDt);bm.x += dx / d * travel; bm.y += dy / d * travel;
        if (d < cfgBALANCECombatUpdateWeapons.d_threshold) { bm.dead = true; continue; }
      }
      bm.vx=(bm.x-oldX)/Math.max(moveDt,.000001);bm.vy=(bm.y-oldY)/Math.max(moveDt,.000001);
      if(RG.teleportSpaceProjectile(bm,oldX,oldY)){bm.a=Math.atan2(bm.vy,bm.vx);continue;}
      for (const e of RG.enemies) {
        if (e.dead || e.dying || (e.hitCds["boom"] || 0) > 0) continue;
        if (segmentDistance2(oldX,oldY,bm.x,bm.y,e.x,e.y) < (e.r + cfgBALANCECombatUpdateWeapons.value_10_factor * (bm.size || 1)) ** 2) {
          const ka = rand(0, TAU);
          RG.hurtEnemy(e, bm.dmg, Math.cos(ka) * cfgBALANCECombatUpdateWeapons.value_factor, Math.sin(ka) * cfgBALANCECombatUpdateWeapons.value_factor, false, false, true, bm.weapon);
          e.hitCds["boom"] = bm.hitCd;
        }
      }
    }

  }

  function updateEnemies(P,dt,realDt){
    // v8.17:每帧重建墙体粗网格(小怪被墙挡后的热点优化)并缓存临时壁垒列表——
    // BOSS 移动/冲锋只被临时壁垒阻挡(地形墙无视),小怪仍被全部墙挡
    RG.rebuildWallGrid(RG.walls);
    RG._tempWalls = [];
    for (const w of RG.walls) if (w.temp) RG._tempWalls.push(w);

    if(RG.run.amplifierPresent&&RG.timeStop<=0)RG.updateAmplifierAuras(dt);
    // 敌人 AI(时间静止 = 全部停摆)
    if (RG.timeStop > 0) {
      // v8.15 时停修复:濒死结算照常推进,时停期击杀正常完成并掉落经验(玩家反馈 bug1)
      for (const e of RG.enemies) {
        e.frozen = Math.max(e.frozen, cfgBALANCECombatUpdateEnemies.frozen_floor); e.flash = Math.max(0, e.flash - dt);
        RG.tickStatus(e,'chronoT',dt);
        if(e.mobilityCritT!==undefined)RG.tickStatus(e,'mobilityCritT',dt);
        if (e.dying) { e.dyingT -= realDt; if(e.boss&&(e.deathPulseT-=realDt)<=0&&e.deathPulseN<5){e.deathPulseT=.18;e.deathPulseN++;const a=rand(0,TAU),d=rand(0,e.r*cfgBALANCECombatUpdateEnemies.d_factor);RG.burst(e.x+Math.cos(a)*d,e.y+Math.sin(a)*d,"#c084fc",5,100);RG.rings.push({x:e.x+Math.cos(a)*d,y:e.y+Math.sin(a)*d,r:4,maxR:32,life:.16,maxLife:.16,color:"#f5d0fe"});} if (e.dyingT <= 0) RG.killEnemy(e); }
      }
    } else {
      for (const e of RG.enemies) {
        if (e.dead) continue;
        if (e.dying) { e.dyingT -= realDt; if(e.boss&&(e.deathPulseT-=realDt)<=0&&e.deathPulseN<5){e.deathPulseT=.18;e.deathPulseN++;const a=rand(0,TAU),d=rand(0,e.r*cfgBALANCECombatUpdateEnemies.d_factor);RG.burst(e.x+Math.cos(a)*d,e.y+Math.sin(a)*d,"#c084fc",5,100);RG.rings.push({x:e.x+Math.cos(a)*d,y:e.y+Math.sin(a)*d,r:4,maxR:32,life:.16,maxLife:.16,color:"#f5d0fe"});} if (e.dyingT <= 0) RG.killEnemy(e); continue; }   // 分级死亡演出倒计时
        const motionStartX=e.x,motionStartY=e.y;e.motionX=e.motionY=0;
        // 元素状态衰减与燃烧 DoT
        if (e.el) {
          if (e.el.fire > 0) {
            e.burnTick = (e.burnTick || 0) - Math.min(dt,e.el.fire);
            for(let pulse=0;e.burnTick<=1e-9&&pulse<ATTACK_BUDGET;pulse++){
              advanceCd(e,'burnTick',cfgBALANCECombatUpdateEnemies.advanceCd_advanceCdArg3);
              RG.dealPure(e, (e.burnDps || 0) * cfgBALANCECombatUpdateEnemies.value_factor,"fire",false,e.burnSource);
              if (Math.random() < cfgBALANCECombatUpdateEnemies.value_threshold) RG.parts.push({ x: e.x + rand(-e.r, e.r), y: e.y + rand(-e.r, e.r), vx: rand(-10, 10), vy: -40, life: 0.3, max: 0.3, color: "#fb923c", r: 2.5 });
            }
          }
          if(!e.dying)for(const type of RG.ELEMENT_ORDER){if(e.el[type]>0)e.el[type]-=dt;if(!(e.el[type]>0))clearElement(e,type);}
        }
        for(const key of ENEMY_STATUS_KEYS)RG.tickStatus(e,key,dt);
        if(e.weakmarkCd!==undefined)RG.tickStatus(e,'weakmarkCd',dt);
        if(e.mobilityCritT!==undefined)RG.tickStatus(e,'mobilityCritT',dt);
        if(e.dying||e.dead)continue;
        if(RG.ETYPES[e.type]?.meadow&&(e.chronoT>0||e.petrifyT>0||e.frozen>0)&&e.meadowWind>0){e.meadowWind=0;e.meadowCd=cfgBALANCECombatUpdateEnemies.meadowCd;}
        if(RG.tickStatus(e,'chronoT',dt)){e.flash=Math.max(0,e.flash-dt);continue;}
        if (RG.tickStatus(e,'petrifyT',dt)||RG.tickIceFreeze(e,dt)) { e.flash = Math.max(0, e.flash - dt); continue; }
        if(e.workshopHole)continue;
        const target = RG.enemyTarget(e,P);
        const dx = target.x - e.x, dy = target.y - e.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
        e.faceA = Math.atan2(dy, dx); e.faceDir = (Math.abs(dx) > Math.abs(dy)) ? (dx < 0 ? 1 : 2) : (dy < 0 ? 3 : 0);
        let elSlow=(e.el&&e.el.ice>0) ? cfgBALANCECombatUpdateEnemies.elSlow : 1;
        if(e.vialSlowT>0)elSlow=Math.min(elSlow,RG.WEAPONS.vial.slowMul);
        if(e.reactionSlowT>0)elSlow=Math.min(elSlow,e.reactionSlow||1);
        if(e.boss)elSlow=1-(1-elSlow)*cfgBALANCECombatUpdateEnemies.elSlow_factor;if(e.cardSlowT>0)elSlow=Math.min(elSlow,RG.PASSIVES.element_slow.slowMul);
        if(!e.boss)elSlow*=e.ampSpeedMul||1;
        if (e.homing && !e.boss) {
          e.life -= dt;
          if (e.life <= 0) { e.dead = true; RG.burst(e.x, e.y, "#e0d0ff", 8, 100); continue; }
          e.vx += dx / d * cfgBALANCECombatUpdateEnemies.vx_factor * dt; e.vy += dy / d * cfgBALANCECombatUpdateEnemies.vy_factor * dt;
          const v = Math.hypot(e.vx, e.vy);
          if (v > e.speed) { e.vx = e.vx / v * e.speed; e.vy = e.vy / v * e.speed; }
          e.x += e.vx * dt * elSlow; e.y += e.vy * dt * elSlow;
          if (e.life < cfgBALANCECombatUpdateEnemies.life_threshold) e.alpha = e.life / 2;
        } else if (e.boss) {
          if (e.isClone) {
            e.cloneLife -= dt;
            if (e.cloneLife <= 0) { e.dead = true; RG.burst(e.x, e.y, "#c084fc", 12, 130); continue; }
            if (e.cloneLife < cfgBALANCECombatUpdateEnemies.cloneLife_threshold) e.alpha = Math.max(0.15, e.cloneLife / 1.5 * 0.85);
          }
          const lists=[RG.ebullets,RG.hbeams,RG.rings,RG.domains,RG.hazards],before=lists.map(a=>new Set(a));const eb0 = RG.ebullets.length;
          RG.updateBoss(e, dt, dx, dy, d, elSlow);
          lists.forEach((list,k)=>{for(const item of list)if(!before[k].has(item)){if(!item.source)item.source=enemyCause(e,"技能");if(RG.isWorkshopBoss(e))item.bossOwner=e;}});
          for (let i = eb0; i < RG.ebullets.length; i++) RG.ebullets[i].noWall = !RG.isWorkshopBoss(e);
          RG.pushOutOfWalls(e, RG._tempWalls);   // v8.17:BOSS 无视地形墙,只被玩家临时壁垒阻挡
        } else if(RG.ETYPES[e.type]?.meadow){
          RG.updateMeadowMob(e,target,dt,elSlow);
        } else if(e.type==='prism'){
          const c=RG.WORKSHOP_MOBS.prism;e.prismCd=(e.prismCd??cfgPASSIVESPrismUpdateEnemies.prismCd)-dt;e.prismCastT=Math.max(0,(e.prismCastT||0)-dt);
          if(e.prismCastT<=0){
            const dir=d>cfgPASSIVESPrismUpdateEnemies.dir_threshold?1:d<cfgPASSIVESPrismUpdateEnemies.dir_threshold_2?-1:0;e.x+=dx/d*e.speed*dir*dt*elSlow;e.y+=dy/d*e.speed*dir*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);
            if(e.prismCd<=0&&d<c.range&&RG.hbeams.filter(b=>b.prism&&!b.dead).length<cfgPASSIVESPrismUpdateEnemies.length_threshold){
              const a=Math.atan2(target.y-e.y,target.x-e.x),seg=RG.traceLaser(e.x,e.y,a,c.range,0,true)[0];
              RG.hbeams.push({x:e.x,y:e.y,a,len:seg.len,dmg:e.dmg,w:c.width,warn:c.warn,fire:c.fire,hitP:false,source:'棱镜哨兵 · 光束',...RG.crossfireAttack('prism',e),prism:true,owner:e,col:'#67e8f9'});
              e.prismCastT=c.warn+c.fire+c.recover;e.prismCd=c.cd;e.face=a;RG.playSfx('laser',.7);
            }
          }
        } else if(e.type==='amplifier'){
          const dir=d>cfgETYPESAmplifierUpdateEnemies.dir_threshold?1:d<cfgETYPESAmplifierUpdateEnemies.dir_threshold_2?-1:0;e.x+=dx/d*e.speed*dir*dt*elSlow;e.y+=dy/d*e.speed*dir*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);
        } else if(e.type==="stalker"){
          const skill=RG.MOB_SKILLS.stalker;
          e.face=Math.atan2(dy,dx);e.faceA=e.face;e.vx=dx/d*e.speed;e.vy=dy/d*e.speed;
          e.stalkCd=(e.stalkCd===undefined?cfgETYPESStalkerUpdateEnemies.stalkCd:e.stalkCd)-dt;
          // 旧现场缺少落点时重新给完整预警，不能恢复后直接闪到玩家身边。
          e.stalkSafe=e.stalkWind>0||e.stalkRecover>0;
          if(e.stalkWind>0&&(!Number.isFinite(e.stalkX)||!Number.isFinite(e.stalkY)))prepareStalk(e,target);
          else if(e.stalkWind>0){e.stalkWind=Math.max(0,e.stalkWind-dt);if(e.stalkWind<=1e-9){
            e.stalkWind=0;
            e.x=e.stalkX;e.y=e.stalkY;e.stalkRecover=skill.recover;e.stalkCd=skill.cd;
            RG.burst(e.x,e.y,"#c084fc",10,120);
          }}
          else if(e.stalkRecover>0){e.stalkRecover=Math.max(0,e.stalkRecover-dt);if(e.stalkRecover<1e-9)e.stalkRecover=0;}
          else if(e.stalkCd<=0&&d<cfgETYPESStalkerUpdateEnemies.d_threshold){prepareStalk(e,target);e.stalkSafe=true;}
          else {e.x+=dx/d*e.speed*dt*elSlow;e.y+=dy/d*e.speed*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);}
        } else if(e.type==="howler"){
          e.face=Math.atan2(dy,dx);e.faceA=e.face;
          const want=cfgETYPESHowlerUpdateEnemies.want, dir=d>want+cfgETYPESHowlerUpdateEnemies.dir_offset?1:d<want-cfgETYPESHowlerUpdateEnemies.dir_offset?-1:0;
          e.x+=dx/d*e.speed*dir*dt*elSlow;e.y+=dy/d*e.speed*dir*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);
          e.howlCd=(e.howlCd===undefined?cfgETYPESHowlerUpdateEnemies.howlCd:e.howlCd)-dt;
          if(e.howlCd<=0&&d<RG.MOB_SKILLS.howler.range){e.howlCd=cfgETYPESHowlerUpdateEnemies.howlCd_2;
            const skill=RG.MOB_SKILLS.howler;
            for(let layer=0;layer<cfgETYPESHowlerUpdateEnemies.layer_threshold;layer++)RG.rings.push({x:e.x,y:e.y,r:10,maxR:skill.range,speed:skill.speed,life:1.6,maxLife:1.6,delay:layer*skill.interval,fan:true,a:e.face,half:.6,color:"#f0abfc",hazard:true,dmg:RG.randi(skill.minDamage,skill.maxDamage),source:enemyCause(e,'哀嚎冲击波'),howl:true,hitP:false});
            RG.addText(e.x,e.y-e.r-8,"三重哀嚎!","#f0abfc",12);RG.playSfx("nova",.5);
          }
        } else if(e.type==="crystal"){
          e.face=Math.atan2(dy,dx);e.faceA=e.face;
          if(d>RG.PASSIVES.crystal.rules.updateEnemies.d_threshold){e.x+=dx/d*e.speed*dt*elSlow;e.y+=dy/d*e.speed*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);}
        } else if(e.type==="hound"){
          e.face=Math.atan2(dy,dx);e.chargeCd=(e.chargeCd===undefined?cfgETYPESHoundUpdateEnemies.chargeCd:e.chargeCd)-dt;
          if((e.chargeWind||0)>0){e.chargeWind-=dt;if(e.chargeWind<=0){e.chargeRun=RG.MOB_SKILLS.hound.distance/RG.MOB_SKILLS.hound.speed;e.vx=Math.cos(e.chargeAim)*RG.MOB_SKILLS.hound.speed;e.vy=Math.sin(e.chargeAim)*RG.MOB_SKILLS.hound.speed;}}
          else if((e.chargeRun||0)>0){const moveDt=Math.min(dt,e.chargeRun);e.chargeRun=Math.max(0,e.chargeRun-dt);e.x+=e.vx*moveDt*elSlow;e.y+=e.vy*moveDt*elSlow;RG.pushOutOfWalls(e,RG.walls);}
          else {if(e.chargeCd<=0&&d<cfgETYPESHoundUpdateEnemies.d_threshold){e.chargeCd=cfgETYPESHoundUpdateEnemies.chargeCd_2;e.chargeWind=1;e.chargeAim=Math.atan2(dy,dx);RG.addText(e.x,e.y-e.r-8,"冲锋!","#f97316",12);}else{e.x+=dx/d*e.speed*.65*dt*elSlow;e.y+=dy/d*e.speed*.65*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);}}
        } else if(e.type==="bulwark"){
          // 同编组有远程队友时，盾兽追到其朝向玩家的一侧；落后超过90px才获得最多35%追赶速度。
          let mate=null,md=Infinity;
          if(e.squadId!=null)for(const o of RG.enemies){if(o===e||o.dead||o.dying||o.squadId!==e.squadId||!(o.ranged||o.type==="flamer"))continue;const od=dist2(e.x,e.y,o.x,o.y);if(od<md){md=od;mate=o;}}
          let gx=target.x,gy=target.y,stop=cfgETYPESBulwarkUpdateEnemies.stop,speed=e.speed;
          if(mate){const pa=Math.atan2(P.y-mate.y,P.x-mate.x);gx=mate.x+Math.cos(pa)*cfgETYPESBulwarkUpdateEnemies.gx_factor;gy=mate.y+Math.sin(pa)*cfgETYPESBulwarkUpdateEnemies.gy_factor;stop=cfgETYPESBulwarkUpdateEnemies.stop_2;const lag=Math.hypot(gx-e.x,gy-e.y);if(lag>cfgETYPESBulwarkUpdateEnemies.lag_threshold)speed*=Math.min(cfgETYPESBulwarkUpdateEnemies.speed_cap,1+(lag-cfgETYPESBulwarkUpdateEnemies.speed_offset)/cfgETYPESBulwarkUpdateEnemies.speed_divisor*cfgETYPESBulwarkUpdateEnemies.speed_factor);}
          e.guardFollowing=!!mate;e.guardSpeedMul=speed/e.speed;
          const gdx=gx-e.x,gdy=gy-e.y,gd=Math.hypot(gdx,gdy)||1,want=Math.atan2(P.y-e.y,P.x-e.x);e.face=e.face===undefined?want:e.face;let da=want-e.face;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;e.face+=clamp(da,cfgETYPESBulwarkUpdateEnemies.face_factor*dt,cfgETYPESBulwarkUpdateEnemies.face_factor_2*dt);
          if(gd>stop){e.x+=gdx/gd*speed*elSlow*dt;e.y+=gdy/gd*speed*elSlow*dt;RG.pushOutOfWalls(e,RG.walls);}
        } else if(e.type==="flamer"){
          e.face=Math.atan2(dy,dx);e.flameCd=(e.flameCd===undefined?cfgETYPESFlamerUpdateEnemies.flameCd:e.flameCd)-dt;
          if((e.flameWind||0)>0){e.flameWind-=dt;if(e.flameWind<=0){const a=e.flameAim;RG.ebullets.push({source:enemyCause(e,'弹幕'),x:e.x,y:e.y,vx:Math.cos(a)*cfgETYPESFlamerUpdateEnemies.vx_factor,vy:Math.sin(a)*cfgETYPESFlamerUpdateEnemies.vy_factor,r:cfgETYPESFlamerUpdateEnemies.r,dmg:e.dmg*cfgETYPESFlamerUpdateEnemies.dmg_factor,life:cfgETYPESFlamerUpdateEnemies.life,fire:true,targetAlly:target!==P?target:null});RG.playSfx("boom",.7);}}
          else {const dir=d>cfgETYPESFlamerUpdateEnemies.dir_threshold?1:d<cfgETYPESFlamerUpdateEnemies.dir_threshold_2?-1:0;e.x+=dx/d*e.speed*dir*dt*elSlow;e.y+=dy/d*e.speed*dir*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);if(e.flameCd<=0&&d<cfgETYPESFlamerUpdateEnemies.d_threshold){e.flameCd=cfgETYPESFlamerUpdateEnemies.flameCd_2;e.flameWind=cfgETYPESFlamerUpdateEnemies.flameWind;e.flameAim=Math.atan2(dy,dx);RG.addText(e.x,e.y-e.r-8,"蓄火","#fb923c",12);}}
        } else if(e.type==="smasher"){
          e.slamGuardT=Math.max(0,(e.slamGuardT||0)-dt);e.face=Math.atan2(dy,dx);e.slamCd=(e.slamCd===undefined?cfgETYPESSmasherUpdateEnemies.slamCd:e.slamCd)-dt;
          const slam=RG.MOB_SKILLS.smasher,radius=e.elite?slam.eliteRadius:slam.radius;
          if((e.slamWind||0)>0){e.slamWind-=dt;if(e.slamWind<=0){e.slamGuardT=cfgETYPESSmasherUpdateEnemies.slamGuardT;RG.rings.push({x:e.x,y:e.y,r:0,maxR:radius,frameDt:Math.min(dt,-e.slamWind),speed:radius/slam.strike,life:slam.strike,maxLife:slam.strike,fan:true,a:e.slamAim,half:slam.half,color:'#f59e0b',hazard:true,dmg:e.dmg,source:enemyCause(e,'震地'),...RG.crossfireAttack('smasher',e),hitP:false,stun:slam.stun});RG.cam.shake=Math.max(RG.cam.shake,7);RG.playSfx('boom');}}
          else if(e.slamCd<=0&&d<cfgETYPESSmasherUpdateEnemies.d_threshold){e.slamCd=cfgETYPESSmasherUpdateEnemies.slamCd_2;e.slamWind=e.elite?slam.eliteWind:slam.wind;e.slamAim=Math.atan2(dy,dx);RG.rings.push({x:e.x,y:e.y,r:radius,maxR:radius,life:e.slamWind,maxLife:e.slamWind,fan:true,a:e.slamAim,half:slam.half,color:'#ff5470',static:true,warning:true,...RG.crossfireAttack('smasher',e)});}
          else if(d>cfgETYPESSmasherUpdateEnemies.d_threshold_2){e.x+=dx/d*e.speed*dt*elSlow;e.y+=dy/d*e.speed*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);}
        } else if(e.type==="volt"){
          e.face=Math.atan2(dy,dx);e.voltCd=(e.voltCd===undefined?cfgETYPESVoltUpdateEnemies.voltCd:e.voltCd)-dt;const casting=(e.voltCastT||0)>0;e.voltCastT=Math.max(0,(e.voltCastT||0)-dt);if(!casting&&e.voltCd>0){const dir=d>cfgETYPESVoltUpdateEnemies.dir_threshold?1:d<cfgETYPESVoltUpdateEnemies.dir_threshold_2?-1:0;e.x+=dx/d*e.speed*dir*dt*elSlow;e.y+=dy/d*e.speed*dir*dt*elSlow;RG.pushOutOfWalls(e,RG.walls);}
          if(!casting&&e.voltCd<=0&&d<cfgETYPESVoltUpdateEnemies.d_threshold){e.voltCd=cfgETYPESVoltUpdateEnemies.voltCd_2;e.voltCastT=cfgETYPESVoltUpdateEnemies.voltCastT;const a=Math.atan2(dy,dx),fx=Math.cos(a),fy=Math.sin(a),px=-fy,py=fx,L=Math.min(cfgETYPESVoltUpdateEnemies.L_cap,d);RG.voltBeams.push({points:[[e.x,e.y],[e.x+fx*L/cfgETYPESVoltUpdateEnemies.points_divisor+px*cfgETYPESVoltUpdateEnemies.points_factor,e.y+fy*L/cfgETYPESVoltUpdateEnemies.points_divisor+py*cfgETYPESVoltUpdateEnemies.points_factor],[e.x+fx*L*cfgETYPESVoltUpdateEnemies.points_factor_2/cfgETYPESVoltUpdateEnemies.points_divisor-px*cfgETYPESVoltUpdateEnemies.points_factor,e.y+fy*L*cfgETYPESVoltUpdateEnemies.points_factor_2/cfgETYPESVoltUpdateEnemies.points_divisor-py*cfgETYPESVoltUpdateEnemies.points_factor],[e.x+fx*L,e.y+fy*L]],warn:cfgETYPESVoltUpdateEnemies.warn,fire:cfgETYPESVoltUpdateEnemies.fire,dmg:e.dmg,source:enemyCause(e,'Z字电击'),hitP:false,targetAlly:target!==P?target:null});RG.addText(e.x,e.y-e.r-8,"Z字电击","#22d3ee",12);}
        } else if (e.support) {
          // 辅助怪(唤生者/唤兽祭司):保持距离机动,无接触伤害不攻击;v8.17 被墙挡 + 接近时绕行
          const want = e.keep || cfgBALANCECombatUpdateEnemies.want, dir = d > want + cfgBALANCECombatUpdateEnemies.dir_offset ? 1 : d < want - cfgBALANCECombatUpdateEnemies.dir_offset ? -1 : 0;
          e.navT -= dt;
          if (e.navT <= 0) { e.navT = cfgBALANCECombatUpdateEnemies.navT; e.steerA = (dir > 0 && pathBlocked(e.x, e.y, target.x, target.y)) ? steerDir(e, Math.atan2(dy, dx)) : null; }
          if (dir > 0 && e.steerA !== null) {
            e.x += Math.cos(e.steerA) * e.speed * dt * elSlow; e.y += Math.sin(e.steerA) * e.speed * dt * elSlow;
            if (!pathBlocked(e.x, e.y, target.x, target.y)) e.steerA = null;
          } else {
            e.x += dx / d * e.speed * dir * dt * elSlow; e.y += dy / d * e.speed * dir * dt * elSlow;
          }
          RG.pushOutOfWalls(e, RG.walls);
          if (e.type === "healer") {
            // 唤生者:每 2.5s 对 170px 内友军群疗 8% 最大生命(每目标 4s 内不重复吃);范围大,逼玩家优先击杀
            e.healT = (e.healT === undefined ? cfgETYPESHealerUpdateEnemies.healT : e.healT) - dt;
            if (e.healT <= 0) {
              e.healT = cfgETYPESHealerUpdateEnemies.healT;
              let healed = 0;
              for (const o of RG.enemies) {
                if (o.dead || o === e || o.dmg <= 0) continue;
                if (Math.hypot(o.x - e.x, o.y - e.y) < cfgETYPESHealerUpdateEnemies.value_threshold && (o.healCd || 0) <= 0) {
                  o.hp = Math.min(o.maxhp, o.hp + o.maxhp * cfgETYPESHealerUpdateEnemies.hp_factor);
                  o.healCd = cfgETYPESHealerUpdateEnemies.healCd; healed++;
                }
              }
              if (healed) { RG.rings.push({ x: e.x, y: e.y, r: 10, maxR: 170, life: 0.4, maxLife: 0.4, color: "#b14fe8" }); RG.addText(e.x, e.y - e.r - 10, "治愈波!", "#b14fe8", 12); }
            }
          } else {
            // 唤兽祭司:每 8s 召唤 2 只小怪(场上召唤物至多 6 只),死亡清巢
            e.summonOwnT = (e.summonOwnT === undefined ? cfgBALANCECombatUpdateEnemies.summonOwnT : e.summonOwnT) - dt;
            if (e.summonOwnT <= 0) {
              e.summonOwnT = cfgBALANCECombatUpdateEnemies.summonOwnT_2;
              const alive = (e.minions || []).filter(m => !m.dead).length;
              if (alive < cfgBALANCECombatUpdateEnemies.alive_threshold) {
                e.minions = e.minions || [];
                for (let k = 0; k < 2 && alive + k < cfgBALANCECombatUpdateEnemies.value_threshold_2; k++) {
                  const m = RG.spawnEnemy(Math.random() < cfgBALANCECombatUpdateEnemies.m_threshold ? "grunt" : "swarm", false);
                  m.x = e.x + rand(-40, 40); m.y = e.y + rand(-40, 40);
                  e.minions.push(m);
                  RG.burst(m.x, m.y, "#8b5cf6", 6, 80);
                }
                RG.addText(e.x, e.y - e.r - 10, "召唤!", "#8b5cf6", 12);
              }
            }
          }
        } else if (e.type === "bomber") {
          // 引爆者:高速冲脸 → 45px 内点燃0.75s引信 → 爆炸伤人并给周围怪"点火"(补火源);v8.17 被墙挡 + 绕行
          if (!e.fuseLit) {
            e.navT -= dt;
            if (e.navT <= 0) { e.navT = cfgETYPESBomberUpdateEnemies.navT; e.steerA = pathBlocked(e.x, e.y, target.x, target.y) ? steerDir(e, Math.atan2(dy, dx)) : null; }
            if (e.steerA !== null) {
              e.x += Math.cos(e.steerA) * e.speed * dt * elSlow; e.y += Math.sin(e.steerA) * e.speed * dt * elSlow;
              if (!pathBlocked(e.x, e.y, target.x, target.y)) e.steerA = null;
            } else {
              e.x += dx / d * e.speed * dt * elSlow; e.y += dy / d * e.speed * dt * elSlow;
            }
            RG.pushOutOfWalls(e, RG.walls);
            if (d < cfgETYPESBomberUpdateEnemies.value_45_offset + target.r) { e.fuseLit = true; if(RG.enemyCrossfireEnabled())e.crossfireKind='bomber'; e.fuseT = RG.MOB_SKILLS.bomber.fuse; }
          } else {
            e.fuseT -= dt;
            if (e.fuseT <= 0) {
              e.dead = true;
              RG.rings.push({ x: e.x, y: e.y, r: 10, maxR: (e.elite?RG.MOB_SKILLS.bomber.eliteRadius:RG.MOB_SKILLS.bomber.radius), life: 0.3, maxLife: 0.3, color: "#f97316" });
              RG.cam.shake = Math.max(RG.cam.shake || 0, 8);
              RG.playSfx("boom");
              if (dist2(e.x, e.y, P.x, P.y) < Math.pow((e.elite?RG.MOB_SKILLS.bomber.eliteRadius:RG.MOB_SKILLS.bomber.radius) + P.r, 2)) RG.hurtPlayer(cfgETYPESBomberUpdateEnemies.value_22_factor * (1 + RG.run.t / 60 * cfgETYPESBomberUpdateEnemies.value_factor)*(e.elite?RG.MOB_SKILLS.bomber.eliteDamage:1),false,false,enemyCause(e,'自爆'));
              if(target!==P&&dist2(e.x,e.y,target.x,target.y)<Math.pow((e.elite?RG.MOB_SKILLS.bomber.eliteRadius:RG.MOB_SKILLS.bomber.radius)+target.r,2))RG.hurtAlly(target,cfgETYPESBomberUpdateEnemies.value_22_factor*(1+RG.run.t/60*cfgETYPESBomberUpdateEnemies.value_factor)*(e.elite?RG.MOB_SKILLS.bomber.eliteDamage:1));
              for (const o of RG.enemies) {
                if (o.dead || o === e || o.boss) continue;
                if (Math.hypot(o.x-e.x,o.y-e.y)<(e.elite?RG.MOB_SKILLS.bomber.eliteRadius:RG.MOB_SKILLS.bomber.radius)+o.r){const fire=cfgETYPESBomberUpdateEnemies.fire_offset+RG.run.t*cfgETYPESBomberUpdateEnemies.fire_factor;if(RG.enemyCrossfireEnabled()){o.lastEnemyAttackKind='bomber';RG.addText(o.x,o.y-o.r-10,'互 · 灼烧','#f5d7a1',12);}RG.applyElementOutput(o,"fire",cfgETYPESBomberUpdateEnemies.applyElementOutput_applyElementOutputArg3,fire,fire,false,false);}
              }
            }
          }
        } else if (e.ranged) {
          const want = cfgBALANCECombatUpdateEnemies.want_2, dir = d > want + cfgBALANCECombatUpdateEnemies.dir_offset ? 1 : d < want - cfgBALANCECombatUpdateEnemies.dir_offset ? -1 : 0;
          e.navT -= dt;
          if (e.navT <= 0) { e.navT = cfgBALANCECombatUpdateEnemies.navT; e.steerA = (dir > 0 && pathBlocked(e.x, e.y, target.x, target.y)) ? steerDir(e, Math.atan2(dy, dx)) : null; }
          if (dir > 0 && e.steerA !== null) {
            e.x += Math.cos(e.steerA) * e.speed * dt * elSlow; e.y += Math.sin(e.steerA) * e.speed * dt * elSlow;
            if (!pathBlocked(e.x, e.y, target.x, target.y)) e.steerA = null;
          } else {
            e.x += dx / d * e.speed * dir * dt * elSlow; e.y += dy / d * e.speed * dir * dt * elSlow;
          }
          RG.pushOutOfWalls(e, RG.walls);   // v8.17:被墙挡(原 ignore=true 直穿墙,玩家反馈修正)
          e.shootT -= dt;
          if(e.type==='shooter'&&e.shootT<=0&&d<cfgBALANCECombatUpdateEnemies.d_threshold&&e.spitWind===undefined){e.spitWind=e.elite?RG.MOB_SKILLS.shooter.eliteWind:RG.MOB_SKILLS.shooter.wind;e.spitAim=Math.atan2(dy,dx);}
          if(e.spitWind>0){e.spitWind=Math.max(0,e.spitWind-dt);}

          if (e.shootT <= 0 && d < cfgBALANCECombatUpdateEnemies.d_threshold && !(e.spitWind>0)) {
            const a = Math.atan2(dy, dx);
            if (e.slow) {
              // 寒霜吐息:低频三向散射,弹速慢
              e.shootT = rand(cfgBALANCECombatUpdateEnemies.shootT_min, cfgBALANCECombatUpdateEnemies.shootT_max);
              for (let k = -1; k <= 1; k++) {
                const aa = a + k * cfgBALANCECombatUpdateEnemies.aa_factor + rand(cfgBALANCECombatUpdateEnemies.aa_min, cfgBALANCECombatUpdateEnemies.aa_max);
                RG.ebullets.push({source:enemyCause(e,'弹幕'), x: e.x, y: e.y, vx: Math.cos(aa) * cfgBALANCECombatUpdateEnemies.vx_factor_2, vy: Math.sin(aa) * cfgBALANCECombatUpdateEnemies.vy_factor_2, r: cfgBALANCECombatUpdateEnemies.r, dmg: e.dmg, life: cfgBALANCECombatUpdateEnemies.life, slow: true, targetAlly:target!==P?target:null });
              }
            } else {
              // 喷吐者:高频单发直射
              const cooldown=e.elite?RG.MOB_SKILLS.shooter.eliteCd:RG.MOB_SKILLS.shooter.cd;e.shootT=rand(...cooldown);delete e.spitWind;
              const aa = (e.spitAim??a) + rand(cfgBALANCECombatUpdateEnemies.aa_min_2, cfgBALANCECombatUpdateEnemies.aa_max_2);
              RG.ebullets.push({source:enemyCause(e,'弹幕'), x: e.x, y: e.y, vx: Math.cos(aa) * cfgBALANCECombatUpdateEnemies.vx_factor_3, vy: Math.sin(aa) * cfgBALANCECombatUpdateEnemies.vy_factor_3, r: cfgBALANCECombatUpdateEnemies.r, dmg: e.dmg, life: cfgBALANCECombatUpdateEnemies.life_2, targetAlly:target!==P?target:null });
            }
          }
        } else {
          // 寻路:直路被墙挡 → 探测斜向绕行
          e.navT -= dt;
          if (e.navT <= 0) { e.navT = cfgBALANCECombatUpdateEnemies.navT_2; e.steerA = pathBlocked(e.x, e.y, target.x, target.y) ? steerDir(e, Math.atan2(dy, dx)) : null; }
          if (e.steerA !== null) {
            e.x += Math.cos(e.steerA) * e.speed * dt * elSlow; e.y += Math.sin(e.steerA) * e.speed * dt * elSlow;
            if (!pathBlocked(e.x, e.y, target.x, target.y)) e.steerA = null;
          } else {
            e.x += dx / d * e.speed * dt * elSlow; e.y += dy / d * e.speed * dt * elSlow;
          }
          RG.pushOutOfWalls(e, RG.walls);   // v8.17:近战被墙挡(原 ignore=true 直穿墙,玩家反馈修正)
        }
        e.motionX=(e.x-motionStartX)/dt;e.motionY=(e.y-motionStartY)/dt;
        const contactDistance=e.type==='stalker'||RG.isWorkshopBoss(e)?Math.hypot(target.x-e.x,target.y-e.y):d;
        if (contactDistance < e.r + target.r && e.dmg > 0 && !(e.type==='stalker'&&e.stalkSafe) && !e.workshopSafe && !(e.workshopColdT>0) && !(e.workshopRiftT>0)) {
          if(target!==P) RG.hurtAlly(target,e.dmg);
          else if ((P.dashGraze || 0) > 0) RG.perfectDodge();
          else {const outcome=RG.hurtPlayer(e.dmg*(e.frost?RG.FROST_BOSS.contact:1),false,false,enemyCause(e,'接触'));if(e.bossKind==='domain'&&e.space?.gates.some(g=>g.kind==='hole'&&g.life>0))RG.applyPlayerDebuff({spaceWoundT:RG.BOSS_SKILLS.domain.space.hole.wound},outcome);}
        }
        e.flash = Math.max(0, e.flash - dt);
        if ((e.healCd || 0) > 0) e.healCd -= dt;
        e.x = clamp(e.x, -ARENA_R - 60, ARENA_R + 60); e.y = clamp(e.y, -ARENA_R - 60, ARENA_R + 60);
      }
      RG.separateEnemies();
    }

  }

  function updatePlayerBullets(P,dt){
    // 玩家子弹(追踪/爆炸/体积;被墙挡)。碰撞走空间网格:敌人刚完成本帧移动,此处重建一次
    gridRebuild();
    let targetGridValid=true;
    for (const b of RG.bullets) {
      const moveDt=Math.min(b.frameDt??dt,Math.max(0,b.life)),oldX=b.x,oldY=b.y;delete b.frameDt;
      if (b.seek) {
        const range=b.targetRange?Math.abs(b.targetRange):Infinity;
        const tgt=targetGridValid?nearestGridEnemy(b.x,b.y,range):nearestEnemy(b.x,b.y,range);
        if (tgt) {
          const want = Math.atan2(tgt.y - b.y, tgt.x - b.x);
          let cur = Math.atan2(b.vy, b.vx);
          let da = want - cur;
          while (da > Math.PI) da -= TAU;
          while (da < -Math.PI) da += TAU;
          const turn = clamp(da, -b.turn * moveDt, b.turn * moveDt);
          cur += turn;
          b.vx = Math.cos(cur) * b.speed; b.vy = Math.sin(cur) * b.speed;
        }
      }
      b.life -= moveDt;b.x+=b.vx*moveDt;b.y+=b.vy*moveDt;
      if(RG.teleportSpaceProjectile(b,oldX,oldY))continue;
      const wall=RG.firstWallFraction(oldX,oldY,b.x,b.y),pathX=b.x-oldX,pathY=b.y-oldY,length2=pathX*pathX+pathY*pathY;
      const hits=bulletHits;hits.length=0;
      const minX=Math.floor(Math.min(oldX,b.x)/GRID_CELL)+GRID_OFF-1,maxX=Math.floor(Math.max(oldX,b.x)/GRID_CELL)+GRID_OFF+1;
      const minY=Math.floor(Math.min(oldY,b.y)/GRID_CELL)+GRID_OFF-1,maxY=Math.floor(Math.max(oldY,b.y)/GRID_CELL)+GRID_OFF+1;
      for (let ix = minX; ix <= maxX; ix++) {
        for (let iy = minY; iy <= maxY; iy++) {
          const cell = gridBucket(ix, iy);
          if (!cell) continue;
          for (let ci = 0; ci < cell.length; ci++) {
            const e = cell[ci];
            if (e.dead || e.dying || b.hitSet.has(e)) continue;
            const proj=length2?((e.x-oldX)*pathX+(e.y-oldY)*pathY)/length2:0;
            const nearest=clamp(proj,0,1),radius=e.r+b.r,offset=dist2(oldX+pathX*nearest,oldY+pathY*nearest,e.x,e.y);
            if(offset>=radius*radius)continue;
            const side2=length2?dist2(oldX+pathX*proj,oldY+pathY*proj,e.x,e.y):offset;
            const entry=clamp(proj-Math.sqrt(Math.max(0,(radius*radius-side2)/(length2||1))),0,1);
            if(entry<wall)hits.push({e,t:entry});
          }
        }
      }
      if(hits.length>1)hits.sort((a,c)=>a.t-c.t);
      for(const {e,t}of hits){
              if(e.dead||e.dying)continue;
              targetGridValid=false;
              b.hitSet.add(e);
              const ka = Math.atan2(b.vy, b.vx);
              if (b.raw) RG.dealPure(e, b.dmg,false,false,b.damageSource,{summon:!!b.summon});   // 只给显式友军来源共鸣，不给普通衍生弹。
              else {
                let bd2 = b.dmg;
                if (b.falloff) bd2 *= 1 - cfgBALANCECombatUpdatePlayerBullets.bd2_factor * Math.min(1, Math.hypot(oldX+pathX*t-b.sx,oldY+pathY*t-b.sy) / (b.maxDist || cfgBALANCECombatUpdatePlayerBullets.bd2));
                if(b.damageSource)RG.withDamageSource(b.damageSource,()=>RG.hurtEnemy(e,bd2,Math.cos(ka)*cfgBALANCECombatUpdatePlayerBullets.value_factor,Math.sin(ka)*cfgBALANCECombatUpdatePlayerBullets.value_factor,false,b.noFeel,true,b.weapon));
                else RG.hurtEnemy(e, bd2, Math.cos(ka) * cfgBALANCECombatUpdatePlayerBullets.value_factor, Math.sin(ka) * cfgBALANCECombatUpdatePlayerBullets.value_factor, false, b.noFeel, true, b.weapon);
              }
              if (b.seek) { RG.burst(b.x, b.y, "#e9d5ff", 8, 130); RG.rings.push({ x: b.x, y: b.y, r: 4, maxR: 26, life: 0.18, maxLife: 0.18, color: "#c4b5fd" }); }   // P2 追踪弹命中爆裂
              else RG.burst(b.x, b.y, "#7ecbff", 3, 90);
              if (b.hitSet.size > b.pierce) { b.dead = true; break; }
      }
      if(wall<=1&&!b.dead){b.dead=true;RG.burst(oldX+pathX*wall,oldY+pathY*wall,"#8a83b8",3,70);}
      if(b.life<=1e-9)b.dead=true;
    }
  }

  function updateEnemyBullets(P,dt){
    // 敌人子弹(追踪弹:有限转向速率,可绕行甩掉)
    for (const b of RG.ebullets) {
      if(b.dead)continue;const previousX=b.x,previousY=b.y;
      if (b.turn) {
        const bt=b.targetAlly&&!b.targetAlly.dead?b.targetAlly:P;
        const want = Math.atan2(bt.y - b.y, bt.x - b.x);
        let cur = Math.atan2(b.vy, b.vx), da = want - cur;
        while (da > Math.PI) da -= TAU;
        while (da < -Math.PI) da += TAU;
        cur += clamp(da, -b.turn * dt, b.turn * dt);
        const sp = Math.hypot(b.vx, b.vy) || 1;
        b.vx = Math.cos(cur) * sp; b.vy = Math.sin(cur) * sp;
      }
      b.life -= dt; b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.life <= 0) { b.dead = true; continue; }
      if (RG.blockedPoint(b.x, b.y, b.noWall ? RG._tempWalls : null)) { b.dead = true; continue; }
      if(P.aegisEvoT>0&&P.activeGuard>0&&RG.aegisCast(P)?.id==='void'&&segmentDistance2(previousX,previousY,b.x,b.y,P.x,P.y)<=Math.pow(RG.aegisCast(P).radius+b.r,2)){
        b.dead=true;P.aegisCleared=Math.min(RG.BOSS_SKILLS.void.updateEnemyBullets.aegisCleared_cap,(P.aegisCleared||0)+1);continue;
      }
      if(b.targetAlly&&!b.targetAlly.dead&&dist2(b.x,b.y,b.targetAlly.x,b.targetAlly.y)<(b.targetAlly.r+b.r)*(b.targetAlly.r+b.r)){
        RG.hurtAlly(b.targetAlly,b.dmg);b.dead=true;continue;
      }
      if (dist2(b.x, b.y, P.x, P.y) < (P.r + b.r) * (P.r + b.r)) {
        if ((P.dashGraze || 0) > 0) { RG.perfectDodge(); b.dead = true; continue; }
        const mirror=P.aegisEvoT>0&&RG.aegisCast(P)?.id==='mirror';
        const outcome = RG.hurtPlayer(b.dmg, false, true,b.source||(b.slow?'寒霜敌弹':b.fire?'火焰敌弹':'敌人弹幕'));
        if(mirror&&outcome==='phase')reflectPhaseBullet(b);
        if (b.slow && RG.applyPlayerDebuff({slowT:RG.BALANCE.combat.updateEnemyBullets.slowT},outcome)) RG.addText(P.x, P.y + 20, "被减速!", "#7dd3fc", 13);
        b.dead = true;
      }
    }
  }

  // 草原新怪共用现有碰撞、控制和伤害入口；定点攻击先锁定落点，预警期间可走开。
  RG.updateMeadowMob=function(e,target,dt,slow){
    const dx=target.x-e.x,dy=target.y-e.y,d=Math.hypot(dx,dy)||1;
    const color=RG.ETYPES[e.type].color;
    e.meadowAge=(e.meadowAge||0)+dt;
    e.meadowCd=(e.meadowCd??RG.BALANCE.combat.updateMeadowMob.meadowCd)-dt;
    const move=(want=0,mul=1,angle=0)=>{
      const dir=d>want+cfgBALANCECombatMove.dir_offset?1:d<want-cfgBALANCECombatMove.dir_offset?-1:0;
      e.navT-=dt;if(e.navT<=0){e.navT=cfgBALANCECombatMove.navT;e.steerA=dir>0&&pathBlocked(e.x,e.y,target.x,target.y)?steerDir(e,Math.atan2(dy,dx)):null;}
      const a=(dir>0&&e.steerA!=null?e.steerA:Math.atan2(dy,dx))+angle;
      e.x+=Math.cos(a)*e.speed*dir*mul*dt*slow;e.y+=Math.sin(a)*e.speed*dir*mul*dt*slow;
      RG.pushOutOfWalls(e,RG.walls);RG.constrain(e);
    };
    if(e.type==='scavenger'){move(0,1,Math.sin(e.meadowAge*cfgPASSIVESScavengerUpdateMeadowMob.updateMeadowMob_factor)*cfgPASSIVESScavengerUpdateMeadowMob.updateMeadowMob_factor_2);return;}
    if(e.type==='sporepod'){move();return;}
    if(e.type==='phantasm'){
      const dart=e.meadowAge%cfgETYPESPhantasmUpdateMeadowMob.dart>cfgETYPESPhantasmUpdateMeadowMob.dart_threshold;e.alpha=dart?.6:1;move(0,dart?cfgETYPESPhantasmUpdateMeadowMob.updateMeadowMob:1);return;
    }
    if(e.type==='warder'){
      move(cfgETYPESWarderUpdateMeadowMob.updateMeadowMob_moveArg1);
      if(e.meadowCd<=0){e.meadowCd=cfgETYPESWarderUpdateMeadowMob.meadowCd;let count=0;
        for(const o of RG.enemies)if(o!==e&&!o.dead&&!o.dying&&!o.boss&&dist2(e.x,e.y,o.x,o.y)<cfgETYPESWarderUpdateMeadowMob.updateMeadowMob_factor*cfgETYPESWarderUpdateMeadowMob.updateMeadowMob_factor){
          // 每次仅补到最大生命的15%，两只结界官不能叠成无限盾。
          o.shieldHp=Math.max(o.shieldHp||0,o.maxhp*cfgETYPESWarderUpdateMeadowMob.shieldHp_factor);count++;
        }
        if(count)RG.rings.push({x:e.x,y:e.y,r:10,maxR:180,life:.5,maxLife:.5,color});
      }return;
    }
    if(e.type==='mortar'){
      move(cfgETYPESMortarUpdateMeadowMob.updateMeadowMob_moveArg1);
      if(e.meadowCd<=0&&d<cfgETYPESMortarUpdateMeadowMob.d_threshold&&RG.hazards.filter(h=>h.meadow&&!h.dead).length<cfgETYPESMortarUpdateMeadowMob.length_threshold){
        e.meadowCd=cfgETYPESMortarUpdateMeadowMob.meadowCd;RG.hazards.push({x:target.x,y:target.y,r:cfgETYPESMortarUpdateMeadowMob.r,phase:'warn',t:cfgETYPESMortarUpdateMeadowMob.t,dur:cfgETYPESMortarUpdateMeadowMob.dur,hitCd:0,dmg:e.dmg,source:'熔渣迫击兵 · 炮击',meadow:true});
      }return;
    }
    if(e.type==='crucible'){
      if(e.meadowWind>0){e.meadowWind=Math.max(0,e.meadowWind-dt);if(e.meadowWind<=0)RG.rings.push({x:e.x,y:e.y,r:12,maxR:150,speed:260,life:.6,maxLife:.6,color,hazard:true,dmg:e.dmg,source:'熔炉坩埚兵 · 重砸',hitP:false});}
      else if(e.meadowCd<=0&&d<cfgETYPESCrucibleUpdateMeadowMob.d_threshold){
        e.meadowCd=cfgETYPESCrucibleUpdateMeadowMob.meadowCd;e.meadowWind=1;
        RG.rings.push({x:e.x,y:e.y,r:150,maxR:150,life:1,maxLife:1,color:'#ff5470',static:true,warning:true});
      }else move(cfgETYPESCrucibleUpdateMeadowMob.updateMeadowMob_moveArg1);return;
    }
    if(e.type==='tether'){
      if(e.meadowWind>0){e.meadowWind=Math.max(0,e.meadowWind-dt);if(e.meadowWind<=0){
        const P=RG.P;
        if(dist2(P.x,P.y,e.tetherX,e.tetherY)<cfgETYPESTetherUpdateMeadowMob.updateMeadowMob_factor*cfgETYPESTetherUpdateMeadowMob.updateMeadowMob_factor&&!(P.dashT>0)&&!(P.iTimer>0)&&!(P.tetherGuardT>0)&&RG.applyPlayerDebuff({slowT:cfgETYPESTetherUpdateMeadowMob.slowT})){
          // 分小步拉动并逐步推出墙体，不能把玩家拽穿墙；全场共用短保护期。
          for(let i=0;i<10;i++){const a=Math.atan2(e.y-P.y,e.x-P.x);P.x+=Math.cos(a)*9;P.y+=Math.sin(a)*9;RG.pushOutOfWalls(P,RG.walls);RG.constrain(P);}
          P.tetherGuardT=cfgETYPESTetherUpdateMeadowMob.tetherGuardT;
        }
      }}else{
        move(cfgETYPESTetherUpdateMeadowMob.updateMeadowMob_moveArg1);
        if(e.meadowCd<=0&&d<cfgETYPESTetherUpdateMeadowMob.d_threshold){e.meadowCd=cfgETYPESTetherUpdateMeadowMob.meadowCd;e.meadowWind=1;e.tetherX=RG.P.x;e.tetherY=RG.P.y;
          RG.rings.push({x:e.tetherX,y:e.tetherY,r:80,maxR:80,life:1,maxLife:1,color,static:true,warning:true});
        }
      }
    }
  };
  function updateBattle(dt) {
    if(RG.state==="countdown"||RG.state==="pause")return;
    const realDt = dt;
    const P = RG.P;
    const frameStartX=P.x,frameStartY=P.y;
    const externalMove=P===lastMotionPlayer&&dist2(P.x,P.y,lastMotionX,lastMotionY)>1e-8;
    if(externalMove){P.moving=true;P.stillT=0;if(P.windMoveT!==undefined)P.windMoveT=0;}
    RG.refreshResonance(P);
    dt=RG.damageFeedbackStep(dt,RG.hurtFx,cfgBALANCECombatUpdate.dt_damageFeedbackStepArg3);
    if(dt<=0)return;
    // BOSS 连战:每 50s 自动三选一;通关展示 1.6s 后结算回选关
    if (RG.run.rushMode) {
      RG.run.cardT -= dt;
      if (RG.run.cardT <= 0 && RG.state === "play") { RG.run.cardT = cfgBALANCECombatUpdate.cardT; RG.levelUp(0); RG.addText(P.x, P.y - 60, "✦ 连战补给:三选一!", "#ffd166", 15); }
      if (RG.run.rushEndT > 0) {
        RG.run.rushEndT -= dt;
        if (RG.run.rushEndT <= 0) {
          if(RG.clearRunCheckpoint)RG.clearRunCheckpoint();RG.checkpointPending=false;
          RG.settleRunCoins(); RG.saveMeta();
          RG.resetBattleState(); RG.state = "rush";
          return;
        }
      }
    }
    // 打击停顿:命中大事件时短暂慢放
    RG.hitStopGate = Math.max(0, (RG.hitStopGate || 0) - realDt);
    if (RG.hitStop > 0) {
      const slow = Math.min(dt, RG.hitStop);
      RG.hitStop = Math.max(0, RG.hitStop - dt);
      RG.hitStopGate = Math.max(RG.hitStopGate, RG.hitStop + cfgBALANCECombatUpdate.hitStopGate_offset);
      dt -= slow * cfgBALANCECombatUpdate.dt_factor;
    }
    RG.run.t += dt;
    RG.tickStatus(P,'summonAfterT',dt);RG.tickStatus(P,'resonanceShieldCd',dt);
    for (const id in P.activeCd) P.activeCd[id] = Math.max(0, P.activeCd[id] - dt);
    updateEnvyPower(P, dt);
    RG.tickOverdrive(P,dt);
    RG.tickAegis(P,dt);
    RG.tickStatus(P,'xpWindT',dt);RG.tickStatus(P,'levelHasteT',dt);
    if(P.painT!==undefined)RG.tickStatus(P,'painT',dt);
    if(P.dashEchoT!==undefined)RG.tickStatus(P,'dashEchoT',dt);
    if(P.shieldCounterT!==undefined)RG.tickStatus(P,'shieldCounterT',dt);
    if(P.dodgeSpeedT!==undefined)RG.tickStatus(P,'dodgeSpeedT',dt);
    if(P.causalityCd!==undefined)RG.tickStatus(P,'causalityCd',dt);RG.refreshCriticalState(P);
    RG.tickStatus(P,'reactionAfterT',dt);RG.tickStatus(P,'chargeAfterT',dt);
    if (RG.timeStop > 0) RG.timeStop -= dt;
    // 击杀连击衰减
    if(RG.comboGlow){RG.comboGlow.life-=dt;if(RG.comboGlow.life<=0)RG.comboGlow=null;}
    if (RG.comboT > 0) { RG.comboT -= dt; if (RG.comboT <= 0) { RG.combo = 0; RG.killStreak = 0; } }
    // 领域结算:禁疗(治疗归零)/减速(复用玩家减速体系)
    P.spaceWoundT=Math.max(0,(P.spaceWoundT||0)-dt);P.freezeT=Math.max(0,(P.freezeT||0)-dt);P.poisonContactT=Math.max(0,(P.poisonContactT||0)-dt);P.healBlocked=P.spaceWoundT>0;
    P.workshopRuneT=Math.max(0,(P.workshopRuneT||0)-dt);
    P.workshopCoolT=Math.max(0,(P.workshopCoolT||0)-dt);
    const runeBoss=RG.run.boss;if(runeBoss&&RG.isWorkshopBoss(runeBoss))RG.updateWorkshopRunes(runeBoss,dt);
    if(runeBoss&&RG.isWorkshopBoss(runeBoss))RG.updateWorkshopValves(runeBoss,dt);
    if(runeBoss&&RG.isWorkshopBoss(runeBoss))RG.updateWorkshopHoles(runeBoss,dt);
    if (RG.domains && RG.domains.length) {
      for (const dm of RG.domains) {
        dm.t -= dt;
        if (dm.t <= 0) { dm.dead = true; continue; }
        if(dm.warn>0){dm.warn=Math.max(0,dm.warn-dt);continue;}
        if(P.workshopRuneT>0&&P.workshopRuneOwner===dm.bossOwner){dm.playerInside=false;dm.playerDebuffBlocked=false;continue;}
        if (Math.hypot(P.x - dm.x, P.y - dm.y) < dm.r) {
          if (dm.type === "poison") {
            dm.ptick = (dm.ptick || 0) - dt;
            if (dm.ptick <= 0) { dm.ptick = cfgBALANCECombatUpdate.ptick; const outcome=RG.hurtPlayer(dm.dps * cfgBALANCECombatUpdate.outcome_factor,false,false,dm.source||'剧毒领域');RG.applyPlayerDebuff({slowT:cfgBALANCECombatUpdate.slowT,poisonContactT:cfgBALANCECombatUpdate.ptick},outcome); }
          }
          else {
            if(!dm.playerInside){dm.playerInside=true;dm.playerDebuffBlocked=!RG.applyPlayerDebuff(dm.type==="healnull"?{healBlocked:1}:{slowT:cfgBALANCECombatUpdate.slowT_2});}
            if(!dm.playerDebuffBlocked){if(dm.type==="healnull")P.healBlocked=true;else RG.refreshStatus(P,'slowT',cfgBALANCECombatUpdate.update_refreshStatusArg3);}
          }
        } else {dm.playerInside=false;dm.playerDebuffBlocked=false;}
      }
      RG.domains = RG.domains.filter(dm => !dm.dead && dm.t > 0);
    }
    // 虫洞:玩家踏入 → 传送到另一虫洞(纯位移,1 秒冷却防回弹)
    if (RG.wormholes && RG.wormholes.length >= cfgBALANCECombatUpdate.length_threshold) {
      for (const w2 of RG.wormholes) {
        if(w2.dead||w2.warn>0)continue;
        if ((w2.cool || 0) > 0) { w2.cool -= dt; continue; }
        if (dist2(P.x, P.y, w2.x, w2.y) < w2.r * w2.r) {
          const others = RG.wormholes.filter(o2 => o2 !== w2&&!o2.dead&&!(o2.warn>0));
          if(!others.length)continue;
          const to = pick(others);
          if(w2.bossOwner){
            if(!RG.workshopPointFree(to.x,to.y,P.r))continue;
            P.iTimer=Math.max(P.iTimer||0,1);
          }
          P.x = to.x; P.y = to.y;
          for (const o2 of RG.wormholes) o2.cool = 1;
          RG.playSfx("portal", 1.5);
          break;
        }
      }
    }
    // 连击风暴：25连击起按各档固定收益累计，跌破阈值即失效。
    RG.tickStatus(P,'valhallaT',dt);
    if(P.wrathBloodT!==undefined){RG.tickStatus(P,'wrathBloodT',dt);if(!P.wrathBloodT)P.wrathBloodStacks=0;}
    const cardFrequency=(P.reactionAfterT>0?RG.PASSIVES.aftershock.values[P.passives.aftershock||0]:0)+(P.chargeAfterT>0?RG.PASSIVES.chargecircuit.values[P.passives.chargecircuit||0]:0)+(P.summonAfterT>0?RG.resonanceBonus(P).summonExitFrequency||0:0)+(P.levelHasteT>0?RG.PASSIVES.leveldash.values[P.passives.leveldash||0]:0)+RG.painFrequency(P)+RG.slaughterBonus('frequency');
    P.cdMulEff = (P.cdMul || 1) / (1 + (RG.combo >= RG.PASSIVES.combostorm.minCombo ? RG.passiveValue(P,"combostorm") : 0)) * (P.overdriveT > 0 ? RG.ACTIVES.overdrive.cooldownMul : 1) * (P.globalCdMul || 1)/(1+cardFrequency)/(P.overdriveWeakT>0?(RG.overdriveCast(P)?.weaknessFrequency??1):1);
    // 血债血偿(v7.4):血量<30% 自动触发,10s 强力期 + 20s 冷却
    if (P.passives.debt) {
      if ((P.debtT || 0) > 0) P.debtT -= dt;
      else if ((P.debtCd || 0) > 0) P.debtCd -= dt;
      else if (P.hp / P.maxhp < RG.lowHpThreshold(cfgPASSIVESDebtUpdate.update_lowHpThresholdArg1,P)) { P.debtT = cfgPASSIVESDebtUpdate.debtT; P.debtCd = cfgPASSIVESDebtUpdate.debtCd;if(RG.PASSIVES.debt.cleanseControl){RG.clearStatus(P,'stunT');RG.clearStatus(P,'slowT');} RG.addText(P.x, P.y - 40, "血债血偿!", "#ff7b7b", 16); }
    }
    updatePlayerMovement(P,dt,externalMove,frameStartX,frameStartY);

    // 临时墙寿命
    for (const w of RG.walls) if (w.ttl !== undefined) { w.ttl -= dt; if (w.ttl <= 0) w.expired = true; }
    RG.walls = RG.walls.filter(w => !w.expired);

    RG.cam.x += (P.x - RG.cam.x) * Math.min(1, dt * 8);
    RG.cam.y += (P.y - RG.cam.y) * Math.min(1, dt * 8);
    RG.cam.shake = Math.min(16, Math.max(0, RG.cam.shake - dt * 30));   // P2 屏震上限
    // BOSS 出场:持续低频震屏,结尾渐弱
    if (RG.bossIntro > 0) {
      RG.bossIntro -= dt;
      RG.cam.shake = Math.max(RG.cam.shake, 12 * clamp(RG.bossIntro / 0.7, 0, 1) * (0.65 + 0.35 * Math.sin(RG.bossIntro * 24)));
    }
    // 惩戒光环:集齐钥匙的奖励,时停期间安全刷经验
    if (RG.auraT > 0) {
      RG.auraT -= dt;
      RG.auraPulse -= dt;
      if (RG.auraPulse <= 0) {
        RG.auraPulse = cfgBALANCECombatUpdate.auraPulse;
        const R = cfgBALANCECombatUpdate.R;
        RG.rings.push({ x: P.x, y: P.y, r: 24, maxR: R, life: 0.32, maxLife: 0.32, color: "#ffd166" });
        for (const e of RG.enemies) {
          if (e.dead || e.boss || e.isClone) continue;
          if (Math.hypot(e.x - P.x, e.y - P.y) < R + e.r) RG.withDamageSource('keyAura',()=>RG.hurtEnemy(e, cfgBALANCECombatUpdate.update_offset + RG.run.t * cfgBALANCECombatUpdate.update_factor, 0, 0, true));
        }
        RG.playSfx("nova");
      }
    }

    // 常客编队按整局时间推进；首领使用独立的5分钟时间表。
    if (!RG.realm.active && !RG.run.boss && !RG.run.finalBoss && RG.timeStop <= 0 && !RG.run.rushMode) RG.updateSpawnDirector(dt);
    RG.updateBossSchedule();
    // 钥匙刷新(3 分钟一次,秘境中顺延)
    if (!RG.realm.active && !RG.run.rushMode && !RG.keyItems.length && !RG.portal) {
      RG.run.keyT -= dt;
      if (RG.run.keyT <= 0) RG.spawnKeys();
    }
    // 钥匙拾取
    for (const k of RG.keyItems) {
      k.bob += dt * cfgBALANCECombatUpdate.bob_factor;
      if (dist2(k.x, k.y, P.x, P.y) < cfgBALANCECombatUpdate.update_factor_2 * cfgBALANCECombatUpdate.update_factor_2) {
        k.taken = true; RG.keysHeld++;
        RG.playSfx("key");
        RG.addText(P.x, P.y - 30, "钥 " + RG.keysHeld + " / 3", "#ffd166", 16);
        RG.playSfx("gem");
      }
    }
    RG.keyItems = RG.keyItems.filter(k => !k.taken);
    if (RG.keysHeld >= cfgBALANCECombatUpdate.keysHeld_threshold && !RG.portal) { RG.keysHeld = 0; RG.openPortal(); }
    // 传送门
    if (RG.portal) {
      RG.portal.swirl += dt * cfgBALANCECombatUpdate.swirl_factor;
      if (dist2(RG.portal.x, RG.portal.y, P.x, P.y) < (RG.portal.r + P.r) * (RG.portal.r + P.r)) {
        if (RG.portal.exit) { RG.portal = null; RG.exitRealm(); }
        else if (RG.enterRealm()) RG.playSfx("nova");
      }
    }
    // 神秘雕像(秘境外,120s 起每 90s 一座,靠近出现献祭提示;连战模式不出)
    if (!RG.realm.active && !RG.run.rushMode) {
      if (!RG.statues.length && RG.run.t >= RG.run.statueT) {
        let st=null;for(let i=0;i<24;i++){const a=rand(0,TAU),d=rand(cfgBALANCECombatUpdate.d_min,cfgBALANCECombatUpdate.d_max),candidate={x:P.x+Math.cos(a)*d,y:P.y+Math.sin(a)*d,r:cfgBALANCECombatUpdate.r};
          RG.constrain(candidate);if(RG.blockedPoint(candidate.x,candidate.y)||RG.run.lastStatue&&dist2(candidate.x,candidate.y,RG.run.lastStatue.x,RG.run.lastStatue.y)<cfgBALANCECombatUpdate.update_factor_3*cfgBALANCECombatUpdate.update_factor_3)continue;st=candidate;break;}
        RG.run.statueT=RG.run.t+cfgBALANCECombatUpdate.statueT_offset;
        if(st){RG.statues.push({...st,life:cfgBALANCECombatUpdate.life,bob:rand(0,TAU)});RG.run.lastStatue={x:st.x,y:st.y};RG.addText(P.x,P.y-60,"像 附近出现神秘雕像...","#c9c7d8",14);}
      }
      for (const st of RG.statues) {
        st.life -= dt; st.bob += dt * cfgBALANCECombatUpdate.bob_factor_2;
        if (dist2(st.x, st.y, P.x, P.y) < cfgBALANCECombatUpdate.update_factor_4 * cfgBALANCECombatUpdate.update_factor_4) st.life = Math.max(st.life, 1);   // 靠近不过期
      }
      RG.statues = RG.statues.filter(s => s.life > 0);
    }
    P.statueNear = null;
    for (const st of RG.statues) {
      if (dist2(st.x, st.y, P.x, P.y) < cfgBALANCECombatUpdate.update_factor_4 * cfgBALANCECombatUpdate.update_factor_4) { P.statueNear = st; break; }
    }

    for(const e of RG.enemies)for(const key in e.hitCds)e.hitCds[key]-=dt;
    updateWeapons(P,dt);

    updateEnemies(P,dt,realDt);

    updatePlayerBullets(P,dt);

    // 激光与近战斩击衰减
    for (const bm of RG.beams) { bm.life -= dt; if (bm.life <= 0) bm.dead = true; }
    for (const sl of RG.slashes||[]) { sl.life -= dt; if(sl.life<=0)sl.dead=true; }
    RG.slashes=(RG.slashes||[]).filter(sl=>!sl.dead);
    // 碎片风暴
    for (const s of RG.storms) {
      s.t -= dt; s.rot += dt * cfgBALANCECombatUpdate.rot_factor;
      s.tick = (s.tick || 0) - dt;
      for(let pulse=0;s.tick<=1e-9&&pulse<ATTACK_BUDGET;pulse++){
        advanceCd(s,'tick',cfgBALANCECombatUpdate.update_advanceCdArg3); s.tickN = (s.tickN || 0) + 1;
        for (const e of RG.enemies) {
          if (e.dead || Math.hypot(e.x - s.x, e.y - s.y) >= s.r + e.r) continue;
          const n = (s.hitN.get(e) || 0) + 1; s.hitN.set(e, n);
          const decay = n <= 1 ? 1 : n === 2 ? cfgBALANCECombatUpdate.decay : cfgBALANCECombatUpdate.decay_2;   // 同风暴对同目标重复命中递减:防大体型BOSS被反复判定叠伤
          RG.dealPure(e, s.dps * cfgBALANCECombatUpdate.update_factor_5 * decay,false,false,s.damageSource);
        }
      }
    }
    RG.storms = RG.storms.filter(s => s.t > 0);
    // 回响弹头结算:0.3 秒后原地 60% raw 伤害;目标已死则弹向 50px 内最近敌人
    if (RG.echoQ && RG.echoQ.length) {
      for (const q of RG.echoQ) {
        q.t -= dt;
        if (q.t > 0 || q.done) continue;
        q.done = true;
        let tgt = q.tgt && !q.tgt.dead && !q.tgt.dying ? q.tgt : null;
        if (!tgt) { let bd = Infinity; for (const e of RG.enemies) { if (e.dead || e.dying) continue; const d = dist2(q.x, q.y, e.x, e.y); if (d < cfgBALANCECombatUpdate.d_threshold && d < bd) { bd = d; tgt = e; } } }
        if (tgt) RG.dealPure(tgt, q.dmg,false,false,q.damageSource);
        RG.rings.push({ x: q.x, y: q.y, r: 6, maxR: 60, life: 0.18, maxLife: 0.18, color: "#ffd166" });
      }
      RG.echoQ = RG.echoQ.filter(q => !q.done);
    }
    // 友军系统:幻影分身(索敌开火 raw 子弹) + 忠诚残兵(精英复苏炮台)
    if (RG.phantoms && RG.phantoms.length) {
      for (const ph of RG.phantoms) {
        if(ph.dead)continue;
        ph.t -= dt;
        if (ph.t <= 0) { ph.dead = true; RG.onSummonExit(ph);continue; }
        ph.fireT = (ph.fireT === undefined ? cfgBALANCECombatUpdate.fireT : ph.fireT) - dt;
        if (ph.fireT <= 0) {
          ph.fireT = cfgBALANCECombatUpdate.fireT_2;
          let tgt = null, bd = Infinity;
          for (const e of RG.enemies) { if (e.dead || e.dying) continue; const dv = dist2(ph.x, ph.y, e.x, e.y); if (dv < bd) { bd = dv; tgt = e; } }
          if (tgt) {
            const aa = Math.atan2(tgt.y - ph.y, tgt.x - ph.x);
            RG.bullets.push({ x: ph.x, y: ph.y, vx: Math.cos(aa) * cfgBALANCECombatUpdate.vx_factor, vy: Math.sin(aa) * cfgBALANCECombatUpdate.vy_factor, r: cfgBALANCECombatUpdate.r_2, dmg: ph.dmg, pierce: 0, life: cfgBALANCECombatUpdate.life_2, hitSet: new Set(), col: "#a78bfa", raw: true,summon:true });
            RG.playSfx("shoot", 1.3);
          }
        }
        const fd = Math.hypot(P.x - ph.x, P.y - ph.y) || 1;
        if (fd > cfgBALANCECombatUpdate.fd_threshold) { ph.x += (P.x - ph.x) / fd * 160 * dt; ph.y += (P.y - ph.y) / fd * 160 * dt; }
      }
      RG.phantoms = RG.phantoms.filter(p2 => !p2.dead && p2.t > 0);
    }
    if (P.passives.phantom) {
      P.phantomT = (P.phantomT === undefined ? cfgPASSIVESPhantomUpdate.phantomT : P.phantomT) - dt;
      const period = Math.max(cfgPASSIVESPhantomUpdate.period_floor, cfgPASSIVESPhantomUpdate.period_offset - cfgPASSIVESPhantomUpdate.period_factor * P.passives.phantom);
      if (P.phantomT <= 0) {
        if ((RG.phantoms || []).length < RG.summonLimit(cfgPASSIVESPhantomUpdate.update_summonLimitArg1)) {
          P.phantomT = period;
          const phW = Object.keys(P.weapons)[0] || "bolt", phSt = RG.WEAPONS[phW] && RG.weaponStat(phW, P.weapons[phW] || 1, P.evolved[phW]);
          const phBase = phSt && phSt.dmg ? phSt.dmg : cfgPASSIVESPhantomUpdate.phBase_offset + RG.P.level * cfgPASSIVESPhantomUpdate.phBase_factor;   // v8.15:幻影伤害 = 初始武器当前伤害的 75%
          const duration=RG.summonDuration(cfgPASSIVESPhantomUpdate.duration_summonDurationArg1,P);
          (RG.phantoms = RG.phantoms || []).push({ x: P.x + rand(-30, 30), y: P.y + 30, t: duration,max:duration,rallyLv:P.passives.rally||0,baseDamage:phBase, dmg: phBase * RG.playerDamageMul(false) * cfgPASSIVESPhantomUpdate.dmg_factor, fireT: cfgPASSIVESPhantomUpdate.fireT });
          RG.addText(P.x, P.y - 44, "幻影分身 出现!", "#a78bfa", 13);
        } else P.phantomT = cfgPASSIVESPhantomUpdate.phantomT_2;
      }
    }
    if (RG.allies && RG.allies.length) {
      for (const al of RG.allies) {
        if(al.dead)continue;
        al.iTimer=Math.max(0,(al.iTimer||0)-dt);
        if(al.converted){
          if(al.t!=null){al.t-=dt;if(al.t<=0){al.dead=true;RG.onSummonExit(al);continue;}}
          let moveT=null,md=Infinity;for(const e of RG.enemies){if(e.dead||e.dying)continue;const dv=dist2(al.x,al.y,e.x,e.y);if(dv<md){md=dv;moveT=e;}}
          const range=al.puppet&&!al.boss&&!RG.ETYPES[al.type]?.ranged?al.r+(moveT?.r||0)+cfgBALANCECombatUpdate.range_offset:cfgBALANCECombatUpdate.range;
          if(moveT&&md>range*range){const d=Math.sqrt(md)||1;al.x+=(moveT.x-al.x)/d*(al.speed||95)*dt;al.y+=(moveT.y-al.y)/d*(al.speed||95)*dt;al.face=Math.atan2(moveT.y-al.y,moveT.x-al.x);if(RG.collideWalls)RG.collideWalls(al);}
        }
        al.fireT -= dt;
        if (al.fireT > 0) continue;
        al.fireT = cfgBALANCECombatUpdate.fireT_3;
        let tgt = null, bd = Infinity;
        for (const e of RG.enemies) { if (e.dead || e.dying) continue; const dv = dist2(al.x, al.y, e.x, e.y); if (dv < cfgBALANCECombatUpdate.dv_threshold && dv < bd) { bd = dv; tgt = e; } }
        if (tgt) {
          if(al.puppet){RG.puppetAttack(al,tgt);continue;}
          const aa = Math.atan2(tgt.y - al.y, tgt.x - al.x);
          RG.bullets.push({ x: al.x, y: al.y, vx: Math.cos(aa) * cfgBALANCECombatUpdate.vx_factor_2, vy: Math.sin(aa) * cfgBALANCECombatUpdate.vy_factor_2, r: cfgBALANCECombatUpdate.r_3, dmg: al.dmg, pierce: 0, life: cfgBALANCECombatUpdate.life_3, hitSet: new Set(), col: "#4ade80", raw: true,summon:true });
          RG.playSfx("shoot", 0.9);
        }
      }
      RG.allies=RG.allies.filter(a=>!a.dead&&(a.t==null||a.t>0));
    }
    // 幽影残像结算:对接触敌人造成 raw 创伤 + 0.3 秒硬直(复用冻结表现)
    if (RG.afterimages && RG.afterimages.length) {
      for (const g of RG.afterimages) {
        g.t -= dt;
        if (g.t <= 0) continue;
        for (const e of RG.enemies) {
          if (e.dead || g.hitSet.has(e)) continue;
          if (dist2(g.x, g.y, e.x, e.y) < (g.r + e.r) * (g.r + e.r)) {
            g.hitSet.add(e);
            const hit=RG.dealPure(e, g.dmg);
            RG.markMobilityHit(e,hit,'ghost_img');
            e.frozen = Math.max(e.frozen, cfgBALANCECombatUpdate.frozen_floor);
          }
        }
      }
      RG.afterimages = RG.afterimages.filter(g => g.t > 0);
    }
    // 幸存者之心:长局成长牌要在一局中至少触发一次，才能形成“越活越稳”的亮点。
    if (P.passives.heart) {
      P.heartT = (P.heartT === undefined ? cfgPASSIVESHeartUpdate.heartT : P.heartT) - dt;
      if (P.heartT <= 0 && (P.heartN || 0) < cfgPASSIVESHeartUpdate.range_threshold) {
        P.heartT = cfgPASSIVESHeartUpdate.heartT; P.heartN = Math.min(cfgPASSIVESHeartUpdate.heartN_cap, (P.heartN || 0) + 1);
        if (!P.hpLocked) P.maxhp = Math.round(P.maxhp * cfgPASSIVESHeartUpdate.maxhp_factor);
        if (!P.healBan && !P.healBlocked) P.hp = Math.min(P.maxhp, P.hp + Math.max(cfgPASSIVESHeartUpdate.hp_floor, (P.maxhp - P.hp) * cfgPASSIVESHeartUpdate.hp_factor));
        RG.addText(P.x, P.y - 40, "幸存者之心 +4% 生命", "#4ade80", 13);
      }
    }
    // 酸池减速与毒区域共用容器；强制毒身份不覆盖武器已有的独立附魔层。
    if (RG.vials && RG.vials.length) {
      for (const v of RG.vials) {
        const moveDt=v.frameDt??dt;delete v.frameDt;
        const aliveDt=Math.min(moveDt,v.t);v.t -= moveDt;const oldArm=Math.max(0,v.arm||0);v.arm -= aliveDt;
        if (v.arm > 0 || aliveDt < oldArm) continue;
        v.tick -= Math.max(0,aliveDt-oldArm);
        for(let pulse=0;v.tick<=1e-9&&pulse<ATTACK_BUDGET;pulse++){
          advanceCd(v,'tick',cfgBALANCECombatUpdate.update_advanceCdArg3);
          for (const e of RG.enemies) {
            if (e.dead || e.dying) continue;
            if (Math.hypot(e.x - v.x, e.y - v.y) < v.r + e.r) {
              const tickDmg=v.dmg*RG.playerDamageMul()*(v.weapon==='vial'&&!v.damageSource&&!v.poisonSpore&&!v.poisonTrail&&damageSource==null?1+RG.crystalCloseBonus(e,'vial',P):1);
              const type=v.forcedElement||(v.poison?'poison':null);
              const hit=()=>{
                const received=RG.dealPure(e,type?tickDmg*RG.playerElementMul(P):tickDmg,type||false,false,undefined,{resist:!!type,poisonAmp:true});
                const damage=received?.statusDamage||0,elementBase=tickDmg*(received?.poisonMul||1);
                if(!v.noSlow)RG.refreshStatus(e,'vialSlowT',cfgBALANCECombatHit.hit_refreshStatusArg3);
                if(type&&!e.dead&&!e.dying)RG.applyElem(e,type,cfgBALANCECombatHit.hit_applyElemArg3,damage,elementBase);
                if(v.weapon&&!e.dead&&!e.dying)RG.weaponElementHit(e,v.weapon,elementBase);
              };
              if(v.damageSource)RG.withDamageSource(v.damageSource,hit);else if(v.poisonSpore)RG.withDamageSource('spore',hit);else hit();
            }
          }
        }
      }
      RG.vials = RG.vials.filter(v => v.t > 0);
    }
    updateEnemyBullets(P,dt);

    // 激光单次伤害；寒冰场有效期内持续控制，闪现免疫只覆盖位移过程。
    for (const hb of RG.hbeams) {
      if(hb.prism){
        if(!hb.owner||hb.owner.dead||hb.owner.dying||!RG.enemies.includes(hb.owner)||hb.warn>0&&(hb.owner.frozen>0||hb.owner.petrifyT>0||hb.owner.chronoT>0)){hb.dead=true;continue;}
        // 预警后出现的新墙可缩短射线；移走墙不能让攻击临时延伸到原预警之外。
        hb.len=Math.min(hb.len,RG.traceLaser(hb.x,hb.y,hb.a,hb.len,0,true)[0].len);
      }
      if(hb.spaceLaser&&(!hb.bossOwner||hb.bossOwner.dead||hb.bossOwner.dying)){hb.dead=true;continue;}
      if (hb.warn > 0) { hb.warn -= dt; continue; }
      if(hb.fire<=0){hb.dead=true;continue;}
      if(hb.crossfireKind){
        const ax=Math.cos(hb.a),ay=Math.sin(hb.a);
        for(const e of RG.enemies){const along=clamp((e.x-hb.x)*ax+(e.y-hb.y)*ay,0,hb.len);if(dist2(hb.x+ax*along,hb.y+ay*along,e.x,e.y)<(e.r+hb.w/2)**2)RG.hitEnemyCrossfire(hb,e);}
      }
      if(hb.spaceLaser){
        const c=RG.BOSS_SKILLS.domain.space.ultimate,t=clamp((P.x-hb.x)*Math.cos(hb.a)+(P.y-hb.y)*Math.sin(hb.a),0,hb.len),inside=dist2(hb.x+Math.cos(hb.a)*t,hb.y+Math.sin(hb.a)*t,P.x,P.y)<(P.r+hb.w/2)**2;
        if(inside&&RG.run.t-hb.spaceShot.lastHit>=c.tick){const result=RG.hurtPlayer(hb.dmg,false,true,hb.source);if(['hurt','shield','phase'].includes(result)){hb.spaceShot.lastHit=RG.run.t;hb.bossOwner.hp+=hb.bossOwner.maxhp*c.heal;}}
      } else if (hb.frostField) {
        const abx=Math.cos(hb.a),aby=Math.sin(hb.a),along=(P.x-hb.x)*abx+(P.y-hb.y)*aby,side=(P.y-hb.y)*abx-(P.x-hb.x)*aby;
        const inside=Math.hypot(along-clamp(along,0,hb.len),side-clamp(side,-hb.w/cfgBALANCECombatUpdate.inside_divisor,hb.w/cfgBALANCECombatUpdate.inside_divisor))<P.r;
        let outcome;
        if(!hb.hitP){hb.hitP=true;if(inside)outcome=RG.hurtPlayer(hb.dmg,false,false,hb.source||'寒冰场');RG.cam.shake=Math.max(RG.cam.shake,5);}
        if(inside&&!(P.dashT>0)){
          // 相位按每次进入抵挡一次整个控制接触；普通受伤无敌不免疫地面冻结。
          if(!hb.playerInside)hb.playerDebuffBlocked=outcome==='phase'||RG.blockPlayerPhase();
          hb.playerInside=true;
          if(!hb.playerDebuffBlocked&&RG.state==='play'){RG.refreshStatus(P,'stunT',hb.freeze);P.freezeT=hb.freeze;}
        }else{hb.playerInside=false;hb.playerDebuffBlocked=false;}
      } else if (!hb.hitP) {
        hb.hitP = true;
        const abx = Math.cos(hb.a), aby = Math.sin(hb.a);
        const t = clamp((P.x - hb.x) * abx + (P.y - hb.y) * aby, 0, hb.len);
        const along=(P.x-hb.x)*abx+(P.y-hb.y)*aby,side=(P.y-hb.y)*abx-(P.x-hb.x)*aby;
        const inside=hb.frostField?Math.hypot(along-clamp(along,0,hb.len),side-clamp(side,-hb.w/cfgBALANCECombatUpdate.inside_divisor,hb.w/cfgBALANCECombatUpdate.inside_divisor))<P.r:dist2(hb.x+abx*t,hb.y+aby*t,P.x,P.y)<(hb.w/cfgBALANCECombatUpdate.inside_divisor+P.r)**2;
        if(inside){const outcome=RG.hurtPlayer(hb.dmg,false,false,hb.source||'寒冰场');if(hb.frostField)RG.applyPlayerDebuff({stunT:hb.freeze},outcome);}
        RG.cam.shake = Math.max(RG.cam.shake, 5);
      }
      hb.fire -= dt;
      if (hb.fire <= 0) hb.dead = true;
    }
    RG.compact(RG.hbeams);
    for(const vb of RG.voltBeams||[]){
      if(vb.warn>0){vb.warn-=dt;continue;}
      if(!vb.hitP){
        vb.hitP=true;const target=vb.targetAlly&&!vb.targetAlly.dead?vb.targetAlly:P;let hit=false;
        for(let i=0;i<vb.points.length-1;i++){const a=vb.points[i],b=vb.points[i+1],abx=b[0]-a[0],aby=b[1]-a[1],den=abx*abx+aby*aby||1,t=clamp(((target.x-a[0])*abx+(target.y-a[1])*aby)/den,0,1);if(dist2(a[0]+abx*t,a[1]+aby*t,target.x,target.y)<(target.r+cfgBALANCECombatUpdate.update_offset_2)*(target.r+cfgBALANCECombatUpdate.update_offset_2)){hit=true;break;}}
        if(hit){if(target===P)RG.hurtPlayer(vb.dmg,true,false,vb.source||'Z字电击');else RG.hurtAlly(target,vb.dmg);}
      }
      vb.fire-=dt;if(vb.fire<=0)vb.dead=true;
    }
    RG.voltBeams=(RG.voltBeams||[]).filter(v=>!v.dead);
    // 熔岩区属于玩家反应伤害：相邻 96px 合并；重叠范围内每个目标只取最高 DPS。
    const lava=RG.hazards.filter(h=>h.friendlyLava&&!h.dead);
    for(const e of RG.enemies){
      if(e.dead||e.dying)continue;
      let dps=0,lavaSource=null;
      for(const h of lava)if(dist2(h.x,h.y,e.x,e.y)<(h.r+e.r)*(h.r+e.r)&&(h.dps||0)>=dps){dps=h.dps||0;lavaSource=h.damageSource;}
      if(dps>0){e.lavaTick=(e.lavaTick||0)-dt;e.armorBreakT=Math.max(e.armorBreakT||0,cfgBALANCECombatUpdate.armorBreakT_floor);for(let pulse=0;e.lavaTick<=1e-9&&pulse<ATTACK_BUDGET;pulse++){advanceCd(e,'lavaTick',cfgBALANCECombatUpdate.update_advanceCdArg3_2);RG.dealPure(e,dps*cfgBALANCECombatUpdate.update_factor_6,"fire",false,lavaSource);}}
      else e.lavaTick=0;
    }
    // 陷阱
    for (const h of RG.hazards) {
      h.t -= dt;
      if(h.friendlyLava){if(h.t<=0)h.dead=true;continue;}
      if (h.phase === "warn") { if (h.t <= 0) { h.phase = "active"; h.t = h.dur || cfgBALANCECombatUpdate.t; RG.playSfx("trap"); } }
      else {
        h.hitCd -= dt;
        if (h.hitCd <= 0 && dist2(h.x, h.y, P.x, P.y) < (h.r + P.r) * (h.r + P.r) * cfgBALANCECombatUpdate.update_factor) {
          if(!(h.workshopSlag&&P.workshopCoolT>0&&P.workshopCoolOwner===h.bossOwner))RG.hurtPlayer(h.dmg??cfgBALANCECombatUpdate.update_factor_7 * (1 + RG.run.t / 60 * cfgBALANCECombatUpdate.update_factor_8),false,false,h.source||'地面陷阱');
          h.hitCd = cfgBALANCECombatUpdate.hitCd;
        }
        if (h.t <= 0) h.dead = true;
      }
    }
    // 秘境内血包:保持 2 个,每 10~15 秒随机补一个
    if (RG.realm.active && RG.orbs.length < cfgBALANCECombatUpdate.length_threshold) {
      RG.realm.orbT = (RG.realm.orbT || cfgBALANCECombatUpdate.orbT) - dt;
      if (RG.realm.orbT <= 0) {
        RG.realm.orbT = rand(cfgBALANCECombatUpdate.orbT_min, cfgBALANCECombatUpdate.orbT_max);
        const half = RG.walls[0].w / cfgBALANCECombatUpdate.half_divisor;
        RG.orbs.push({ x: rand(-half + 100, half - 100), y: rand(-half + 100, half - 100), r: cfgBALANCECombatUpdate.r_4, heal: cfgBALANCECombatUpdate.heal });
        RG.addText(RG.P.x, RG.P.y - 40, "血包已刷新", "#4ade80", 13);
      }
    }
    // 经验
    for (const g of RG.gems) {
      if (g.dead) continue;
      // 异常旧现场恢复为可拾取宝石，不让坏坐标继续参与吸引计算。
      if (!Number.isFinite(g.x) || !Number.isFinite(g.y)) { g.x=P.x; g.y=P.y; }
      if((g.delay||0)>0){g.delay-=dt;continue;}
      const gdx = P.x - g.x, gdy = P.y - g.y;
      const d = Math.hypot(gdx, gdy);
      if (g.pull || d < P.pickup) {
        g.pull = true;
        const a = Math.atan2(P.y - g.y, P.x - g.x);
        const sp = Math.max(cfgBALANCECombatUpdate.sp_floor, cfgBALANCECombatUpdate.sp_offset + (P.pickup - d) * cfgBALANCECombatUpdate.sp_factor);
        const step = Math.min(d, sp * dt);
        g.x += Math.cos(a) * step; g.y += Math.sin(a) * step;
        if (d < P.r + cfgBALANCECombatUpdate.update_offset_3) { g.dead = true;if(g.v>0&&P.passives.xpwind){if(!(P.xpWindT>0))RG.addText(P.x,P.y-48,'经验疾风','#4ade80',14);RG.refreshStatus(P,'xpWindT',RG.PASSIVES.xpwind.rules.update.update_refreshStatusArg3);} RG.gainXP(g.v * (RG.DEBUG ? cfgBALANCECombatUpdate.update : 1)); RG.playSfx("gem"); }
      }
    }
    if (RG.gems.length > cfgBALANCECombatUpdate.length_threshold_2) RG.compact(RG.gems);
    if (RG.gems.length > cfgBALANCECombatUpdate.length_threshold_2) {
      const old = RG.gems.splice(0, RG.gems.length - cfgBALANCECombatUpdate.old_offset);
      let sum = 0; old.forEach(g => sum += g.v);
      if (sum) RG.gainXP(sum * (RG.DEBUG ? cfgBALANCECombatUpdate.update : 1));
    }
    for (const o of RG.orbs) {
      if (dist2(o.x, o.y, P.x, P.y) < (P.r + o.r) * (P.r + o.r)) {
        o.dead = true;
        if (P.healBan) { RG.addCoin(cfgBALANCECombatUpdate.update_addCoinArg1); RG.addText(P.x, P.y - 26, "金 +4 (禁疗)", "#ffd166", 13); }
        else if (P.healBlocked) { RG.addText(P.x, P.y - 26, "禁疗领域!", "#ff5470", 13); }
        else { P.hp = Math.min(P.maxhp, P.hp + o.heal); RG.addText(P.x, P.y - 26, "+" + o.heal, "#4ade80", 15); }
        RG.playSfx("gem");
      }
    }
    if (RG.tickInterest) RG.tickInterest(dt);
    const particleDrag=Math.exp(cfgBALANCECombatUpdate.particleDrag_factor*dt);
    for (const p of RG.parts) { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= particleDrag; p.vy *= particleDrag; if (p.life <= 0) p.dead = true; }
    for (const t of RG.texts) {
      t.life -= dt; t.y += t.vy * dt;
      if (t.vy < cfgBALANCECombatUpdate.vy_threshold) t.vy *= (1 - Math.min(cfgBALANCECombatUpdate.vy_cap, dt * cfgBALANCECombatUpdate.vy_factor_3));
      if ((t.scale || 1) > 1) t.scale = Math.max(1, t.scale - dt * cfgBALANCECombatUpdate.scale_factor);
      if (t.life <= 0) t.dead = true;
    }
    for (const sp of RG.sparks || []) { sp.life -= dt; if (sp.life <= 0) sp.dead = true; }
    for (const fl of RG.flashes || []) { fl.t -= dt; if (fl.t <= 0) fl.dead = true; }
    if (RG.sparks && RG.sparks.length) RG.compact(RG.sparks);
    if (RG.flashes && RG.flashes.length) RG.compact(RG.flashes);
    for (const r of RG.rings) {
      let waveDt=r.frameDt??dt;delete r.frameDt;if(r.delay>0){const wait=Math.min(waveDt,r.delay);r.delay-=wait;waveDt-=wait;if(waveDt<=0)continue;}
      waveDt=Math.min(waveDt,Math.max(0,r.life));const previous=r.r;r.life-=waveDt;r.r+=(r.static?0:(r.speed||(r.hazard?cfgBALANCECombatUpdate.r_5:r.maxR/r.maxLife)))*waveDt;
      if(Number.isFinite(r.maxR))r.r=Math.min(r.maxR,r.r);
      if(r.shrink)r.r=Math.max(cfgBALANCECombatUpdate.r_floor,r.r-r.shrink*waveDt);
      const hits=a=>r.fan?RG.fanWaveHits(r,a,previous):dist2(r.x,r.y,a.x,a.y)<(r.r+a.r)*(r.r+a.r);
      if(r.hazard&&r.crossfireKind)for(const e of RG.enemies)if(hits(e))RG.hitEnemyCrossfire(r,e);
      if(r.hazard&&!r.hitP&&hits(P)){r.hitP=true;const outcome=RG.hurtPlayer(r.dmg,false,false,r.source||'敌人震荡波');if(r.stun)RG.applyPlayerDebuff({stunT:r.stun},outcome);if(r.howl&&RG.applyPlayerDebuff({howlDebuffT:RG.MOB_SKILLS.howler.debuff},outcome))RG.addText(P.x,P.y-35,"哀嚎 · 攻击-20% / 减伤-15%","#f0abfc",13);}
      if(r.hazard){r.hitA=r.hitA||new Set();for(const a of [...(RG.decoys||[]),...(RG.allies||[])])if(a.hp!=null&&!a.dead&&!r.hitA.has(a)&&hits(a)){r.hitA.add(a);RG.hurtAlly(a,r.dmg);}}
      if(r.life<=0||(r.hazard&&r.r>r.maxR))r.dead=true;
    }
    RG.compact(RG.enemies);
    RG.compact(RG.bullets);
    RG.compact(RG.ebullets);
    RG.compact(RG.booms);
    RG.compact(RG.beams);
    RG.compact(RG.gems);
    RG.compact(RG.orbs);
    RG.compact(RG.parts);
    RG.compact(RG.texts);
    RG.compact(RG.rings);
    RG.compact(RG.hazards);
    lastMotionPlayer=P;lastMotionX=P.x;lastMotionY=P.y;
  }
  RG.update=function(dt){
    if(RG.state!=='play')return;
    pendingFinalBoss=null;RG.battleUpdating=true;
    try{updateBattle(dt);}finally{RG.battleUpdating=false;}
    const final=pendingFinalBoss;pendingFinalBoss=null;
    if(final)settleFinalBoss(final);
    if(RG.state==='play'&&RG.P?.hp>0)RG.openNextLevelUp();
  };
  RG.SYSTEM_ENTITIES_VER="v12034";
})(window.RG);
