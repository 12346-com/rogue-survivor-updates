// ============ 墙体系统:碰撞 + 空间索引；生成归 systems_run.js ============
(function (RG) {
  RG.walls = [];

  // 实体推挤(ghost = 穿墙,如怨灵不调用)
  RG.collideWalls = function (ent, tangentSlide) {
    const hit = RG.pushOutOfWalls(ent, RG.walls);
    if (hit && tangentSlide) {
      ent.x += (Math.random() - 0.5) * 22;
      ent.y += (Math.random() - 0.5) * 22;
    }
    return hit;
  };

  RG.blockedPoint = function (x, y, walls) { return RG.pointInWall(x, y, walls || RG.walls); };

  // 草原树干采用确定布局，画面与小碰撞体一一对应；不消耗刷怪/掉落随机数。
  RG.makeMeadowTrees=function(walls,occupied=[]){
    if(walls.some(w=>w.meadowTree))return [];
    const hash=(x,y)=>{let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263);n=Math.imul(n^(n>>>13),1274126177);return(n^(n>>>16))>>>0;};
    const creek=y=>160+Math.sin(y/240)*130+Math.sin(y/90)*25,width=y=>29+Math.sin(y/145)*9,trees=[];
    const add=(x,y,id,size)=>{
      if(trees.length>=36||Math.abs(x)>1600||Math.abs(y)>1600||Math.abs(x)<55||Math.abs(y)<55)return;
      if(walls.some(w=>x>w.x-30&&x<w.x+w.w+30&&y>w.y-30&&y<w.y+w.h+30))return;
      if(occupied.some(e=>e&&Math.hypot(x-e.x,y-e.y)<(e.r||14)+50))return;
      trees.push({x:x-13,y:y-9,w:26,h:18,meadowTree:true,treeCell:id,treeSize:size});
    };
    const anchors=[[80,620,0,180],[940,810,2,155]];
    for(const a of anchors)add(...a);
    for(let gy=-3;gy<=3;gy++)for(let gx=-3;gx<=3;gx++){
      const n=hash(gx+21,gy+19),x=gx*520+(n%161-80),y=gy*520+((n>>>8)%161-80);
      if(n%3===0||Math.hypot(x,y)<125||Math.abs(x-creek(y))<width(y)+70||anchors.some(a=>Math.hypot(a[0]-x,a[1]-y)<190))continue;
      const id=n%17===0?3:n%10>=8?2:n%10>=5?1:0;add(x,y,id,id===3?100:155+n%30);
    }
    return trees;
  };

  // 瞬时激光使用真实几何交点；所有折线路段共用一份射程预算。
  RG.traceLaser = function (x, y, angle, range, reflections, ignoreShields=false) {
    let dx = Math.cos(angle), dy = Math.sin(angle), remaining = range;
    const segments = [], epsilon = .001;
    for (let bounce = 0; bounce <= reflections && remaining > epsilon; bounce++) {
      let collision = null;
      function edge(ax, ay, bx, by) {
        const ex = bx - ax, ey = by - ay, cross = dx * ey - dy * ex;
        if (Math.abs(cross) < 1e-9) return;
        const qx = ax - x, qy = ay - y;
        const t = (qx * ey - qy * ex) / cross, u = (qx * dy - qy * dx) / cross;
        if (t <= epsilon || t > remaining || u < -1e-9 || u > 1 + 1e-9 || collision && t >= collision.t) return;
        const length = Math.hypot(ex, ey);
        collision = { t, nx: -ey / length, ny: ex / length };
      }
      for (const w of RG.walls) {
        edge(w.x,w.y,w.x+w.w,w.y); edge(w.x+w.w,w.y,w.x+w.w,w.y+w.h);
        edge(w.x+w.w,w.y+w.h,w.x,w.y+w.h); edge(w.x,w.y+w.h,w.x,w.y);
      }
      const pts = RG.boundary?.pts || [];
      for (let i = 0; i < pts.length; i++) { const a=pts[i],b=pts[(i+1)%pts.length]; edge(a.x,a.y,b.x,b.y); }
      // 盾面按画面上的前方圆弧计算，仅正面来光会反射，背面仍可命中。
      for (const e of RG.enemies) {
        if (ignoreShields || e.dead || e.dying || e.type !== "bulwark") continue;
        const radius=e.r+7,qx=x-e.x,qy=y-e.y,proj=qx*dx+qy*dy,disc=proj*proj-(qx*qx+qy*qy-radius*radius);
        if (disc < 0) continue;
        const t=-proj-Math.sqrt(disc);
        if (t <= epsilon || t > remaining || collision && t >= collision.t) continue;
        const nx=(x+dx*t-e.x)/radius,ny=(y+dy*t-e.y)/radius;
        let da=Math.atan2(ny,nx)-(e.face || 0); while(da>Math.PI)da-=Math.PI*2;while(da<-Math.PI)da+=Math.PI*2;
        if (Math.abs(da) <= .85 && dx*nx+dy*ny < 0) collision={t,nx,ny,shield:e};
      }
      const length=collision ? collision.t : remaining;
      segments.push({x,y,a:Math.atan2(dy,dx),len:length,shield:collision?.shield || null});
      remaining -= length;
      if (!collision || bounce === reflections) break;
      x += dx * length; y += dy * length;
      const dot=dx*collision.nx+dy*collision.ny;
      dx -= 2*dot*collision.nx;dy -= 2*dot*collision.ny;
      // 微小推进只用于避免再次命中同一面，不额外延长总射程。
      x += dx*epsilon;y += dy*epsilon;remaining -= epsilon;
    }
    return segments;
  };

  // ---------- v8.17 墙体粗网格:小怪被墙挡后,全量遍历墙成为热点(实测 bench +33%)----------
  // 每帧由 entities.update 重建(clear 复用 Map,无分配 churn);pointInWall 对 RG.walls 走网格查询,
  // 自定义墙列表(临时壁垒/测试)仍走线性扫描。
  const WCELL = 256;
  let gmap = null, gx0 = 0, gy0 = 0, gcols = 1;
  RG.rebuildWallGrid = function (walls) {
    _near.length=0;
    if (!gmap) gmap = new Map();
    gmap.clear();
    if (!walls || !walls.length) return;
    let minx = Infinity, miny = Infinity, maxx = -Infinity, maxy = -Infinity;
    for (const w of walls) {
      if (w.x < minx) minx = w.x;
      if (w.y < miny) miny = w.y;
      if (w.x + w.w > maxx) maxx = w.x + w.w;
      if (w.y + w.h > maxy) maxy = w.y + w.h;
    }
    gx0 = minx - WCELL; gy0 = miny - WCELL;
    gcols = Math.ceil((maxx - minx + WCELL * 2) / WCELL) + 1;
    for (const w of walls) {
      const cx0 = Math.floor((w.x - gx0) / WCELL), cx1 = Math.floor((w.x + w.w - gx0) / WCELL);
      const cy0 = Math.floor((w.y - gy0) / WCELL), cy1 = Math.floor((w.y + w.h - gy0) / WCELL);
      for (let cy = cy0; cy <= cy1; cy++) {
        for (let cx = cx0; cx <= cx1; cx++) {
          const key = cy * gcols + cx;
          let arr = gmap.get(key);
          if (!arr) { arr = []; gmap.set(key, arr); }
          arr.push(w);
        }
      }
    }
  };
  const _near = [];
  RG.clearWallGrid=()=>{gmap=null;_near.length=0;};
  RG.nearWalls = function (x, y, r) {
    _near.length = 0;
    if (!gmap) return null;   // 网格未建:调用方回退全量扫描
    const cx0 = Math.floor((x - r - gx0) / WCELL), cx1 = Math.floor((x + r - gx0) / WCELL);
    const cy0 = Math.floor((y - r - gy0) / WCELL), cy1 = Math.floor((y + r - gy0) / WCELL);
    for (let cy = cy0; cy <= cy1; cy++) {
      for (let cx = cx0; cx <= cx1; cx++) {
        const arr = gmap.get(cy * gcols + cx);
        if (arr) for (let i = 0; i < arr.length; i++) if (!_near.includes(arr[i])) _near.push(arr[i]);
      }
    }
    return _near;
  };
  // 返回线段上第一堵墙的比例；利用现有墙网格，避免高速弹丸跨过薄墙。
  RG.firstWallFraction=function(ax,ay,bx,by){
    const walls=RG.nearWalls((ax+bx)/2,(ay+by)/2,Math.max(Math.abs(bx-ax),Math.abs(by-ay))/2)||RG.walls;
    let first=Infinity;const dx=bx-ax,dy=by-ay;
    for(const w of walls){
      let lo=0,hi=1;
      if(Math.abs(dx)<1e-12){if(ax<w.x||ax>w.x+w.w)continue;}
      else{const a=(w.x-ax)/dx,b=(w.x+w.w-ax)/dx;lo=Math.max(lo,Math.min(a,b));hi=Math.min(hi,Math.max(a,b));}
      if(Math.abs(dy)<1e-12){if(ay<w.y||ay>w.y+w.h)continue;}
      else{const a=(w.y-ay)/dy,b=(w.y+w.h-ay)/dy;lo=Math.max(lo,Math.min(a,b));hi=Math.min(hi,Math.max(a,b));}
      if(lo<=hi&&lo<first)first=lo;
    }
    return first;
  };
  RG.WALLS_VER="v12023";
})(window.RG);
