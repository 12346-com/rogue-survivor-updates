// ============ 工具层:全局命名空间与通用函数 ============
"use strict";
window.RG = {
  W: 960, H: 600,      // 逻辑画布尺寸(随窗口自适应,可变)
  UIS: 1,              // UI 缩放(小屏放大字)
  DEBUG: location.search.includes("debug"),
  TAU: Math.PI * 2,
};
(function (RG) {
  // 静态表递归只读；不执行getter，避免跨表描述在注册阶段提前读取后置模块。
  RG.freezeConfig=function(value,path='配置'){
    if(typeof value==='number'&&!Number.isFinite(value))throw Error(path+'必须是有限数值');
    if(value&&typeof value==='object'){
      for(const [key,d] of Object.entries(Object.getOwnPropertyDescriptors(value)))if('value'in d)RG.freezeConfig(d.value,path+'.'+key);
      if(!Object.isFrozen(value))Object.freeze(value);
    }
    return value;
  };
  RG.configNumber=value=>Number(value.toFixed(8));
  RG.configChinese=function(value,original,previous){
    if(value===previous)return original;
    const digits=['零','一','二','三','四','五','六','七','八','九'];
    return Number.isInteger(value)&&value>0&&value<100?(value<10?digits[value]:(value<20?'':digits[Math.floor(value/10)])+'十'+(value%10?digits[value%10]:'')):String(RG.configNumber(value));
  };
  RG.SETTINGS_DEFAULTS=RG.freezeConfig({
    display:{frameRate:'60',renderQuality:'medium',fxQuality:'medium',fxAuto:true},
    mix:{volumes:{ shoot: .25, hit: .32, crit: 1.45, combo: 1.00, kill: .60, "kill-1": .60, "kill-2": .60, gem: .33, hurt: 1.10, levelup: .70, choose: .50, nova: .48, boom: .55, trap: .45, boss: .85, over: 1.15, block: .50, freeze: .38, key: .60, timestop: .65, portal: .48, realm: .70, evaporate: .40, overload: .48, superconduct: .38, statue: .55, oath: .50, buy: .48, buypower: .58 },focus:{ hurt:6, boss:8, over:9, levelup:7, realm:7, timestop:7 },pickup:{ gem:1, choose:3, key:4, statue:4, oath:3, buy:3, buypower:4 },combat:{ shoot:0, hit:1, crit:4, combo:5, kill:2, block:2, freeze:2, nova:2, boom:3, trap:2, portal:3, evaporate:3, overload:3, superconduct:3 },cooldowns:{ shoot:120, hit:100, crit:95, kill:65, gem:150, hurt:240, boss:900, over:1000, levelup:400, realm:600, timestop:600 }},
    render:{frameRates:["30","60","120","auto"],qualities:["low","medium","high"],pixelRatio:{low:1,high:2,coarse:1.5,desktop:2},fxScale:{low:.38,medium:.68,high:1},reducedScale:.58,monitor:{ceiling:60,smoothing:.95,sample:.05,dtCap:.1,lowRatio:.7,recoverRatio:.9,decay:2,reduceAfter:3,recoverAfter:8},toleranceMs:.05},
    audio:{master:1,sfx:.85,music:.5,ambient:.35,sfxBus:.85,musicBus:.5},
    touch:{dead:14,sens:1.1,analog:false},
  });
  // 可续局对象只有这一份清单；纯绘制反馈单独清理，不写入现场。
  RG.BATTLE_ARRAYS = ["enemies", "bullets", "ebullets", "booms", "gems", "orbs", "rings", "hazards", "beams", "keyItems", "storms", "statues", "phantoms", "allies", "decoys", "afterimages", "echoQ", "vials", "hbeams", "voltBeams", "wormholes", "domains", "slashes", "spinners", "qiOrbs", "autoFx", "healFields", "offers"];
  RG.BATTLE_FX_ARRAYS = ["parts", "texts", "sparks", "flashes"];
  RG.clearBattleCollections = keys => { for (const key of keys) RG[key] = []; };
  RG.removeBattleEffects = (field,owner,keys) => { for (const key of keys) RG[key]=(RG[key]||[]).filter(item=>item[field]!==owner); };
  RG.clearBattleFeedback = function () {
    RG.clearBattleCollections(RG.BATTLE_FX_ARRAYS);
    RG.hitStop=0; RG.hitStopGate=0; RG.hurtFx=null; RG.deathFx=null;
    RG.comboGlow=null; RG.comboGlowTier=0; RG.comboGlowNext=0;
    RG.offerRects=[]; RG.btnRects=[]; RG.activeRects=[]; RG.statueRect=null; RG.selectedOffer=null;
  };
  // 显示设置只有这一份口径；玩法更新继续使用真实经过时间。
  RG.normalizeDisplaySettings = function (raw = {}) {
    return { frameRate: RG.SETTINGS_DEFAULTS.render.frameRates.includes(raw.frameRate) ? raw.frameRate : RG.SETTINGS_DEFAULTS.display.frameRate,
      renderQuality: RG.SETTINGS_DEFAULTS.render.qualities.includes(raw.renderQuality) ? raw.renderQuality : RG.SETTINGS_DEFAULTS.display.renderQuality,
      fxQuality: RG.SETTINGS_DEFAULTS.render.qualities.includes(raw.fxQuality) ? raw.fxQuality : RG.SETTINGS_DEFAULTS.display.fxQuality, fxAuto: raw.fxAuto === undefined ? RG.SETTINGS_DEFAULTS.display.fxAuto : raw.fxAuto !== false };
  };
  RG.canvasPixelRatio = function (ratio, coarse, quality) {
    const device = Number.isFinite(ratio) && ratio > 0 ? ratio : 1;
    return Math.min(device, quality === "low" ? RG.SETTINGS_DEFAULTS.render.pixelRatio.low : quality === "high" ? RG.SETTINGS_DEFAULTS.render.pixelRatio.high : coarse ? RG.SETTINGS_DEFAULTS.render.pixelRatio.coarse : RG.SETTINGS_DEFAULTS.render.pixelRatio.desktop);
  };
  RG.resetFramePacing = function () { RG.framePacing = { last: null, next: null }; };
  RG.takeDisplayFrame = function (timestamp) {
    if (!Number.isFinite(timestamp)) return null;
    const pacing = RG.framePacing || (RG.resetFramePacing(), RG.framePacing), period = RG.frameRate === "auto" ? 0 : 1000 / (+RG.frameRate || +RG.SETTINGS_DEFAULTS.display.frameRate);
    if (period && pacing.next != null && timestamp + RG.SETTINGS_DEFAULTS.render.toleranceMs < pacing.next) return null;
    const elapsed = pacing.last == null ? 0 : Math.max(0, (timestamp - pacing.last) / 1000);
    pacing.last = timestamp;
    if (period) pacing.next = pacing.next == null ? timestamp + period : pacing.next + Math.max(1, Math.floor((timestamp - pacing.next + RG.SETTINGS_DEFAULTS.render.toleranceMs) / period) + 1) * period;
    else pacing.next = null;
    return elapsed;
  };
  RG.resetFxMonitor = function () {
    RG.fxAutoReduced = false; RG.fxLowTime = RG.fxRecoverTime = 0;
    RG.displayFps = Math.min(+RG.frameRate || +RG.SETTINGS_DEFAULTS.display.frameRate, RG.SETTINGS_DEFAULTS.render.monitor.ceiling);
  };
  RG.monitorDisplayFrame = function (elapsed) {
    if (!Number.isFinite(elapsed) || elapsed <= 0) return;
    RG.displayFps = (RG.displayFps || +RG.SETTINGS_DEFAULTS.display.frameRate) * RG.SETTINGS_DEFAULTS.render.monitor.smoothing + (1 / elapsed) * RG.SETTINGS_DEFAULTS.render.monitor.sample;
    if (RG.state !== "play" || !RG.fxAuto) { RG.fxLowTime = RG.fxRecoverTime = 0; if (!RG.fxAuto) RG.fxAutoReduced = false; return; }
    const target = Math.min(+RG.frameRate || +RG.SETTINGS_DEFAULTS.display.frameRate, 60), dt = Math.min(RG.SETTINGS_DEFAULTS.render.monitor.dtCap, elapsed);
    if (RG.displayFps < target * RG.SETTINGS_DEFAULTS.render.monitor.lowRatio) { RG.fxLowTime += dt; RG.fxRecoverTime = 0; }
    else if (RG.displayFps > target * RG.SETTINGS_DEFAULTS.render.monitor.recoverRatio) { RG.fxRecoverTime += dt; RG.fxLowTime = Math.max(0, RG.fxLowTime - dt * RG.SETTINGS_DEFAULTS.render.monitor.decay); }
    else { RG.fxLowTime = Math.max(0, RG.fxLowTime - dt); RG.fxRecoverTime = 0; }
    if (!RG.fxAutoReduced && RG.fxLowTime >= RG.SETTINGS_DEFAULTS.render.monitor.reduceAfter) { RG.fxAutoReduced = true; RG.fxLowTime = 0; if (RG.P) RG.addText(RG.P.x, RG.P.y - 40, "特效已自动降级", "#fbbf24", 12); }
    if (RG.fxAutoReduced && RG.fxRecoverTime >= RG.SETTINGS_DEFAULTS.render.monitor.recoverAfter) { RG.fxAutoReduced = false; RG.fxRecoverTime = 0; }
  };
  RG.UTIL_VER = "v12027";
  RG.rand = (a, b) => a + Math.random() * (b - a);
  RG.randi = (a, b) => Math.floor(RG.rand(a, b + 1));
  RG.clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  RG.dist2 = (ax, ay, bx, by) => { const dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; };
  RG.pick = arr => arr[Math.floor(Math.random() * arr.length)];
  RG.fmtTime = s => { s = Math.floor(s); const m = Math.floor(s / 60); return m + ":" + String(s % 60).padStart(2, "0"); };
  // 字体助手:自动乘 UI 缩放;PixelCN 为像素中文字体(assets/fonts/ 由美术侧提供,缺文件回退雅黑)
  RG.fnt = (size, bold) => (bold ? "bold " : "") + Math.round(size * RG.UIS) + 'px "PixelCN", "Microsoft YaHei", sans-serif';
  RG.fxScale = () => (RG.SETTINGS_DEFAULTS.render.fxScale[RG.fxQuality] || 1) * (RG.fxAutoReduced ? RG.SETTINGS_DEFAULTS.render.reducedScale : 1);
  RG.pageScroll = {};
  RG.scrollablePage = state => ["menu", "loadout", "growth", "guide", "shop", "settings", "oaths", "rush", "rushweapon", "levelup", "achievements"].includes(state);
  RG.pageScrollOffset = state => RG.scrollablePage(state) ? ((RG.pageScroll[state] && RG.pageScroll[state].y) || 0) : 0;
  RG.setPageScrollBounds = function (state, bottom) {
    if (!RG.scrollablePage(state)) return;
    const safe = RG.safe || { top: 0, bottom: 0 }, view = Math.max(1, RG.H - safe.top - safe.bottom - 12);
    const s = RG.pageScroll[state] || (RG.pageScroll[state] = { y: 0, max: 0 });
    s.max = Math.max(0, bottom - view);
    s.y = RG.clamp(s.y, 0, s.max);
  };
  RG.scrollPageBy = function (state, dy) {
    if (!RG.scrollablePage(state)) return false;
    const s = RG.pageScroll[state] || (RG.pageScroll[state] = { y: 0, max: 0 });
    if (s.max <= 0) return false;
    s.y = RG.clamp(s.y + dy, 0, s.max);
    return true;
  };

  // ---------- 特效(飘字/粒子,依赖 RG.texts / RG.parts) ----------
  // opt: { life, vy, pop, outline } — pop 给伤害/暴击做出场弹跳,outline 为像素描边
  RG.addText = (x, y, str, color, size, opt) => {
    const cap = RG.fxQuality === "low" || RG.fxAutoReduced ? 8 : RG.fxQuality === "medium" ? 12 : 14;
    if (RG.texts.length > cap) {
      if(!opt || !opt.critical)return;
      const replace=RG.texts.findIndex(t=>!t.critical);if(replace<0)return;RG.texts.splice(replace,1);
    }   // 飘字上限随特效档位收紧,危险提示不走本函数
    const life = (opt && opt.life) || 0.8;
    RG.texts.push({
      x, y, str, color,
      size: size || 13,
      life, maxLife: life,
      vy: opt && opt.vy != null ? opt.vy : -46,
      scale: opt && opt.critical ? 1.5 : opt && opt.pop ? 1.28 : 1,
      critical: !!(opt && opt.critical),
      outline: !opt || opt.outline !== false,
    });
  };
  // 命中火花(硬边像素贴花,对齐 feel-pack 四档):light/heavy/melee/crit/big
  RG.addSpark = (x, y, tier, color) => {
    const low = RG.fxQuality === "low" || RG.fxAutoReduced;
    if (low && tier !== "crit" && tier !== "critical" && tier !== "big") return;
    if (RG.fxQuality === "medium" && tier === "light") return;
    RG.sparks = RG.sparks || [];
    if (RG.sparks.length > 28) {
      if(tier!=="critical")return;const replace=RG.sparks.findIndex(s=>s.tier!=="critical");if(replace<0)return;RG.sparks.splice(replace,1);
    }
    const life = tier === "critical" ? .24 : tier === "big" ? 0.16 : tier === "crit" ? 0.14 : tier === "heavy" ? 0.12 : 0.09;
    RG.sparks.push({
      x, y, tier,
      color: color || "#F1F0FA",
      life, maxLife: life,
      rot: (Math.random() * 4) | 0,
    });
  };
  // 同一连杀强度同时驱动颜色、透明度和声音，低档仍保留核心反馈。
  RG.comboFeedback = n => {
    const strength=RG.clamp(Math.log2(1+Math.max(0,n))/8,0,1);
    const rgb=[Math.round(255-strength*105),Math.round(120-strength*95),Math.round(90-strength*38)];
    return {strength,rgb,color:'rgb('+rgb.join(',')+')',alpha:.14+strength*.20,
      radius:110+strength*120,pitch:1+strength*.85,gain:.70+strength*.70};
  };
  RG.comboGlowEnvelope = glow => {
    const age=glow.maxLife-glow.life,smooth=x=>{x=RG.clamp(x,0,1);return x*x*(3-2*x);};
    return smooth(age/.045)*(1-smooth((age-.045)/.235));
  };
  RG.comboBurst = function(n) {
    if(!RG.P||!RG.run)return false;
    if(n<5){RG.comboGlowTier=0;return false;}
    const tier=[5,10,25,50,100,200].filter(v=>n>=v).length,now=RG.run.t||0;
    if(tier<=(RG.comboGlowTier||0))return false;
    RG.comboGlowTier=tier;  // 冷却中跨过的档位直接合并，不排队补闪。
    if(now<(RG.comboGlowNext||0))return false;
    RG.comboGlowNext=now+1.2;
    const profile=RG.comboFeedback(n);
    RG.comboGlow={strength:profile.strength,color:"rgb(255,"+Math.round(205-profile.strength*65)+","+Math.round(140-profile.strength*35)+")",opacity:.18+profile.strength*.16,life:.28,maxLife:.28};
    // 声音由真实击杀的独立1秒窗口触发，不再与边光冷却捆绑。
    return true;
  };
  RG.burst = (x, y, color, n, spd) => {
    const scale = RG.fxScale ? RG.fxScale() : 1;
    const cap = Math.max(90, Math.round((RG.touchMode ? 420 : 700) * scale));
    const count = Math.min(Math.max(1, Math.round((n || 6) * scale)), Math.max(0, cap - RG.parts.length));
    for (let i = 0; i < count; i++) {
      const a = RG.rand(0, RG.TAU), v = RG.rand(30, spd || 140);
      RG.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: RG.rand(0.25, 0.6), max: 0.6, color, r: RG.rand(1.5, 3.5) });
    }
  };

  // 设置存档独立于游戏进度，键位冲突交换，触屏布局使用安全区内的相对坐标。
  RG.KEY_ACTIONS={up:'向上',down:'向下',left:'向左',right:'向右',dash:'冲刺',active1:'主动技能一',active2:'主动技能二',pause:'暂停',mute:'静音',interact:'祭坛交互',reroll:'重骰/重开'};
  RG.DEFAULT_KEYS={up:'w',down:'s',left:'a',right:'d',dash:' ',active1:'q',active2:'e',pause:'p',mute:'m',interact:'f',reroll:'r'};
  RG.validBinding=k=>typeof k==='string'&&(/^[a-z]$/.test(k)||[' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k));
  RG.normalizeControls=function(raw){
    const bindings={...RG.DEFAULT_KEYS},used=new Set(),source=raw&&raw.bindings;
    if(source&&Object.keys(bindings).every(id=>RG.validBinding(source[id])&&!used.has(source[id])&&used.add(source[id])))Object.assign(bindings,source);
    const touch={};for(const id of ['dash','active1','active2']){const p=raw?.touch?.[id];if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y))touch[id]={x:RG.clamp(p.x,0,1),y:RG.clamp(p.y,0,1)};}
    return {bindings,touch,scale:Number.isFinite(raw?.scale)?RG.clamp(raw.scale,.8,1.25):1};
  };
  RG.keyLabel=k=>({' ':'空格',arrowup:'↑',arrowdown:'↓',arrowleft:'←',arrowright:'→'}[k]||String(k||'').toUpperCase());
  RG.bindKey=function(id,key){key=String(key).toLowerCase();if(!RG.KEY_ACTIONS[id]||!RG.validBinding(key))return false;const b=RG.controls.bindings,other=Object.keys(b).find(k=>k!==id&&b[k]===key);if(other)b[other]=b[id];b[id]=key;if(RG.saveControls)RG.saveControls();return true;};
  RG.getControlLayout=function(w,h,safe){
    const s=safe||{},l=(s.left||0)+8,t=(s.top||0)+8,r=w-(s.right||0)-8,bt=h-(s.bottom||0)-8,config=RG.controls||RG.normalizeControls(),scale=config.scale;
    const dr=Math.max(26,Math.min((RG.touchMode||RG.controlEditing)?50:42,(bt-t)*.17)*scale),ar=Math.max(23,Math.min((RG.touchMode||RG.controlEditing)?32:28,(bt-t)*.115)*scale);
    const dx=r-dr-14,dy=bt-dr-12,portrait=h>w;
    const defaults=[{id:'dash',x:dx,y:dy,r:dr},{id:'active1',x:portrait?dx:dx-dr-ar-18,y:portrait?dy-dr-ar-18:dy,r:ar},{id:'active2',x:portrait?dx:dx-dr-ar*3-30,y:portrait?dy-dr-ar*3-30:dy,r:ar}];
    const placed=[];
    for(const d of defaults){const p=config.touch[d.id],v={...d,x:RG.clamp(p?l+p.x*(r-l):d.x,l+d.r+5,r-d.r-5),y:RG.clamp(p?t+p.y*(bt-t):d.y,t+112+d.r+5,bt-d.r-5)};
      const collides=()=>placed.some(o=>Math.abs(v.x-o.x)<v.r+o.r+10&&Math.abs(v.y-o.y)<v.r+o.r+10);
      if(collides()){v.x=d.x;v.y=d.y;}
      if(collides()){let found=false;for(let yy=bt-d.r-5;yy>=t+112+d.r+5&&!found;yy-=12)for(let xx=r-d.r-5;xx>=l+d.r+5;xx-=12){v.x=xx;v.y=yy;if(!collides()){found=true;break;}}}
      placed.push(v);
    }return placed;
  };
  RG.setControlPosition=function(id,x,y){const s=RG.safe||{},l=(s.left||0)+8,t=(s.top||0)+8,w=RG.W-(s.right||0)-8-l,h=RG.H-(s.bottom||0)-8-t;RG.controls.touch[id]={x:RG.clamp((x-l)/w,0,1),y:RG.clamp((y-t)/h,0,1)};};
  RG.mobFrame=function(e,time){const now=Math.max(0,time||0),last=e.animAt??now;e.animAt=now;const phase=e.animPhase??(e.animPhase=((((e.x||0)*.017+(e.y||0)*.031)%1)+1)%1),stopped=(e.type==='crystal'||RG.ETYPES?.[e.type]?.meadow)&&e.motionX!=null&&e.motionY!=null&&Math.hypot(e.motionX,e.motionY)<1;if(!(stopped||e.frozen>0||e.petrifyT>0||e.chronoT>0||e.dying))e.animClock=(e.animClock??phase)+Math.min(.15,Math.max(0,now-last));return e.animFrame=Math.floor((e.animClock??phase)*8)%4;};

  // ---------- 原地压缩:替代 filter(),实体数组每帧重建是手机 GC 卡顿的主要来源 ----------
  RG.compact = function (a) {
    let w = 0;
    for (let i = 0; i < a.length; i++) { const o = a[i]; if (!o.dead) a[w++] = o; }
    a.length = w;
    return a;
  };

  // ---------- 圆 vs 矩形碰撞(墙体用),返回是否发生推挤 ----------
  RG.pushOutOfWalls = (ent, walls, ignore) => {
    if (!walls || ignore) return false;
    if (walls === RG.walls && RG.nearWalls) { const nw = RG.nearWalls(ent.x, ent.y, ent.r); if (nw) walls = nw; }   // v8.17:网格筛近邻(未建网格回退全量)
    let hit = false;
    for (const w of walls) {
      const cx = RG.clamp(ent.x, w.x, w.x + w.w), cy = RG.clamp(ent.y, w.y, w.y + w.h);
      let dx = ent.x - cx, dy = ent.y - cy;
      let d2 = dx * dx + dy * dy;
      if (d2 >= ent.r * ent.r) continue;
      hit = true;
      if (d2 < 0.0001) {
        // 圆心在矩形内:沿最浅轴推出
        const l = ent.x - w.x, r = w.x + w.w - ent.x, t = ent.y - w.y, b = w.y + w.h - ent.y;
        const m = Math.min(l, r, t, b);
        if (m === l) ent.x = w.x - ent.r; else if (m === r) ent.x = w.x + w.w + ent.r;
        else if (m === t) ent.y = w.y - ent.r; else ent.y = w.y + w.h + ent.r;
      } else {
        const d = Math.sqrt(d2), push = ent.r - d;
        ent.x += dx / d * push; ent.y += dy / d * push;
      }
    }
    return hit;
  };
  RG.pointInWall = (x, y, walls) => {
    if (!walls) return false;
    if (walls === RG.walls && RG.nearWalls) {   // v8.17:主墙表走网格查询(未建网格回退线性)
      const arr = RG.nearWalls(x, y, 0);
      if (arr) {
        for (let i = 0; i < arr.length; i++) { const w = arr[i]; if (x >= w.x && x <= w.x + w.w && y >= w.y && y <= w.y + w.h) return true; }
        return false;
      }
    }
    for (const w of walls) if (x >= w.x && x <= w.x + w.w && y >= w.y && y <= w.y + w.h) return true;
    return false;
  };
})(window.RG);
