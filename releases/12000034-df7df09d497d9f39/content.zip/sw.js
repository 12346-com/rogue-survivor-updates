// ============ PWA：完整资源快照、原子升级与离线状态 ============
importScripts("./release-assets.js?v=12034");
const CACHE = "rogue-v12-0-34";
const MANIFEST = self.RG_RELEASE_ASSETS;
if (!MANIFEST || MANIFEST.schema !== 1 || MANIFEST.version !== "v12.0.34" || MANIFEST.cache !== CACHE) throw Error("离线资源清单与游戏版本不一致");
const ROOT = self.registration.scope;
const STATUS_KEY = new URL("__rg_offline_status__", ROOT).href;
const ENTRIES = new Map(MANIFEST.files.map(file => [new URL(file.url, ROOT).href, file]));
const INDEX = new URL("index.html", ROOT).href;
let installing = false;
let population = null;
let statusRead = Promise.resolve();
let status = state("installing", 0, 0);
function state(name, completed, bytes, error) {
  return { type: "RG_OFFLINE_STATUS", version: MANIFEST.version, cache: CACHE, revision: MANIFEST.revision, state: name, completed, total: MANIFEST.files.length, bytes, totalBytes: MANIFEST.totalBytes, ...(error ? { error } : {}) };
}
async function announce(value) {
  status = value;
  const clients = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
  clients.forEach(client => client.postMessage(value));
}
function getStatus() {
  // 状态查询串行返回，避免旧ready查询晚于回收后的failed抵达页面。
  const next = statusRead.then(readStatus, readStatus);
  statusRead = next.catch(() => {});
  return next;
}
async function readStatus() {
  if (installing) return status;
  if (!(await caches.keys()).includes(CACHE)) return status.state === "failed" ? status : status = state("failed", 0, 0, "离线资源未完整保存，请联网重新加载");
  const cache = await caches.open(CACHE), saved = await cache.match(STATUS_KEY);
  if (saved) {
    try {
      const marker = await saved.json(), keys = new Set((await cache.keys()).map(request => request.url));
      if (installing) return status;
      // 删除CacheStorage后，旧Cache句柄仍能返回原keys，不能当成当前缓存。
      if (marker.revision === MANIFEST.revision && marker.state === "ready" && [...ENTRIES.keys()].every(url => keys.has(url)) && (await caches.keys()).includes(CACHE)) return status = state("ready", MANIFEST.files.length, MANIFEST.totalBytes);
    } catch (error) {}
  }
  return status = state("failed", 0, 0, "离线资源未完整保存，请联网重新加载");
}
async function verifiedFetch(file) {
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(new URL(file.url, ROOT).href, { cache: "reload", credentials: "same-origin", signal: controller.signal });
    return await verifiedResponse(file, response);
  } catch (error) { throw Error(file.path + "：" + (error.name === "AbortError" ? "下载超时" : error.message)); }
  finally { clearTimeout(timer); }
}
async function verifiedResponse(file, response) {
  if (!response.ok || response.type === "opaque") throw Error("HTTP " + response.status);
  const body = await response.clone().arrayBuffer();
  if (body.byteLength !== file.bytes) throw Error("资源长度不符");
  const digest = await crypto.subtle.digest("SHA-256", body);
  const sha256 = Array.from(new Uint8Array(digest), value => value.toString(16).padStart(2, "0")).join("");
  if (sha256 !== file.sha256) throw Error("资源内容不符");
  return response;
}
function populateCache(firstInstall) {
  if (population) return population; // online和多个页面同时重试仍只执行一轮。
  population = (async () => {
    installing = true;
    let cursor = 0, completed = 0, bytes = 0, failed = null;
    let cache;
    try {
      cache = await caches.open(CACHE);
      await announce(state("installing", 0, 0));
      // 四路下载兼顾首次安装速度与手机内存；全部校验完成才发布新缓存。
      await Promise.all(Array.from({ length: 4 }, async () => {
        while (!failed && cursor < MANIFEST.files.length) {
          const file = MANIFEST.files[cursor++];
          try {
            let response;
            if (!firstInstall) {
              const hit = await cache.match(new URL(file.url, ROOT).href);
              // 被回收的是局部资源时，校验并保留已有完整项，仅补下载缺失/损坏项。
              if (hit) { try { response = await verifiedResponse(file, hit); } catch (error) {} }
            }
            if (!response) response = await verifiedFetch(file);
            if (failed) return;
            await cache.put(new URL(file.url, ROOT).href, response);
            await announce(state("installing", ++completed, bytes += file.bytes));
          } catch (error) { failed = failed || error; }
        }
      }));
      if (failed) throw failed;
      const ready = state("ready", completed, bytes);
      await cache.put(STATUS_KEY, new Response(JSON.stringify(ready), { headers: { "Content-Type": "application/json" } }));
      await announce(ready);
      if (firstInstall) await self.skipWaiting();
      return ready;
    } catch (error) {
      // 安装失败的新版本不接管页面；旧版本完整缓存继续可用。
      try { if (firstInstall) await caches.delete(CACHE); else if (cache) await cache.delete(STATUS_KEY); } catch (cleanupError) {}
      await announce(state("failed", completed, bytes, error.message));
      throw error;
    } finally { installing = false; }
  })().finally(() => { population = null; });
  return population;
}
self.addEventListener("install", event => {
  event.waitUntil(populateCache(true));
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const value = await getStatus();
    if (value.state !== "ready") throw Error(value.error);
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith("rogue-") && name !== CACHE).map(name => caches.delete(name)));
    await self.clients.claim();
    await announce(value);
  })());
});
self.addEventListener("message", event => {
  if (event.data?.type !== "RG_OFFLINE_STATUS" && event.data?.type !== "RG_OFFLINE_RETRY") return;
  event.waitUntil((async () => {
    const value = event.data.type === "RG_OFFLINE_RETRY" ? await populateCache(false).catch(() => status) : await getStatus();
    if (event.source) event.source.postMessage(value);
  })());
});
async function rangeResponse(request, response) {
  const range = request.headers.get("Range");
  if (!range) return response;
  const match = range.match(/^bytes=(\d*)-(\d*)$/);
  if (!match || !match[1] && !match[2]) return response;
  const body = await response.arrayBuffer(), size = body.byteLength;
  const start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
  const end = match[1] ? (match[2] ? Math.min(Number(match[2]), size - 1) : size - 1) : size - 1;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start > end || start >= size) return new Response(null, { status: 416, headers: { "Content-Range": "bytes */" + size } });
  const headers = new Headers(response.headers);
  headers.delete("Content-Encoding");
  headers.set("Content-Range", "bytes " + start + "-" + end + "/" + size);
  headers.set("Content-Length", String(end - start + 1));
  headers.set("Accept-Ranges", "bytes");
  return new Response(body.slice(start, end + 1), { status: 206, headers });
}
self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== location.origin) return;
  const key = request.mode === "navigate" ? INDEX : url.href;
  if (!ENTRIES.has(key)) return; // 缺图、缺音候选格式仍由原有几何/合成兜底处理。
  event.respondWith((async () => {
    const cache = await caches.open(CACHE), hit = await cache.match(key);
    if (hit) return rangeResponse(request, hit);
    await announce(state("failed", 0, 0, "离线缓存缺失，请联网重新加载"));
    // 浏览器回收缓存后只接受当前版本原文件，不混入其他版本的页面或脚本。
    const response = await verifiedFetch(ENTRIES.get(key));
    await cache.put(key, response.clone());
    return rangeResponse(request, response);
  })());
});
