# 素材来源与许可
- 音效:Kenney "Sci-Fi Sounds" 包(CC0 / Creative Commons Zero),经 Boyquotes/kenney-sci-fi-sounds-for-godot 仓库分发
- 背景音乐 ccambient4.ogg 与死亡音效 udiedfinal.ogg:来自 Cortex Command Base.rte 音频,经 basxto/blackCortex(CC0 合集)分发,音乐作者 dBSoundworks
- 上述音频素材为 CC0,可自由商用,无需署名(本文件仅为来源记录)
- 主页齿轮、图鉴书册和银紫按钮边框：内置 imagegen 原创生成，来自 collab/previews/2026-10-14-主页按钮质感-v2 与 v3 的已认可预览；正式透明尺寸导出见 tests/v1209-ui-assets.cjs，原始生成提示保留在预览目录。蓝钢按钮由 Canvas 独立绘制，不包含付费 UI 素材包贴图。
- 金币与九格辅助图标：内置 imagegen 原创生成，透明像素素材；原图与完整提示见 collab/art-sources/20261014-ui-icons/，发布导出见 tests/v12010-ui-assets.cjs。辅助图集依次为返回、上页、下页、已拥有、锁、保存、重骰、查看、数值；缺图时使用几何图案回退。
- 荒谷/工坊模块场景：内置 imagegen 原创透明组件图集，原图及完整提示保存在 collab/previews/20261015-modular-environment/；地图按真实世界坐标拼装，没有使用参考游戏贴图。三条 amb-*.wav 是 scripts/build-environment-audio.py 原创周期频谱合成音床，无第三方采样。
- v12.0.20场景退修：土苔、两种细密石材与植物/墙根/工业碎件图集由内置imagegen原创生成，参考素材仅用于尺度与材质层次研究；原图及提示见collab/art-sources/20261015-map-rework/。它们是材质与独立组件，真实场景由地形和图层拼装；未使用参考游戏的原始贴图。
