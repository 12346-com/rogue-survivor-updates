// ============ 数据：基础平衡配置（单位与调参边界见数据管理方案）============
(function(RG){
  // 只保存静态参数；开局复制为玩家状态，战斗与存档不得修改配置对象。
  RG.BALANCE=RG.freezeConfig({
    economy:{wealthUnit:100,openingGold:50,shopEvery:6,openingExpiresAfter:2,rushFirst:200,rushRecord:50,mapRecord:50,recordStepSeconds:60,
      drops:{normal:{chance:.05,gold:5},elite:{chance:.10,gold:20},boss:{chance:.20,gold:50}}},mobility:{criticalBonus:.10,markDuration:2},
    // 运行规则按系统/行为归属，数值单位沿用原表达式；详见参数目录。
    "run": {
  "common": {
    "ARENA_R": 1690
  },
  "continueRun": {
    "finalT_offset": 300
  },
  "addTempWall": {
    "d_min": 95,
    "d_max": 175,
    "horizontal_threshold": 0.5,
    "w_min": 120,
    "w_max": 200,
    "w": 36,
    "h": 36,
    "h_min": 120,
    "h_max": 200
  },
  "startRun": {
    "length_threshold": 3,
    "eliteT": 70,
    "packT": 75,
    "trapT": 90,
    "id_sliceArg1": 2,
    "statueT": 120,
    "squadRestT": 8,
    "rareSquadAt": -999,
    "n": 16,
    "startRun_setTimeoutArg2": 400
  },
  "startRush": {
    "cardT": 50
  },
  "spawnRushBoss": {
    "escortT": 8,
    "bossIntro": 2.2
  }
},
    "spawning": {
  crossfireTrial:{startAt:90,groups:[['phantasm','prism'],['phantasm','smasher'],['phantasm','bomber']]},
  "common": {
    "BOSS_INTERVAL": 300,
    "MAIN_FINAL_TIME": 2700,
    "SQUAD_ENTRY_SECONDS": 40,
    "OPENING_ENTRY_SECONDS": 60,
    "REALM_SEAL_SECONDS": 15
  },
  "enemyTimeScale": {
    "base_cap": 45,
    "extra_offset": 45,
    "hp_factor": 0.2,
    "hp_factor_2": 0.016,
    "hp_factor_3": 0.04,
    "dmg_factor": 0.065,
    "dmg_factor_2": 0.001,
    "dmg_factor_3": 0.015,
    "xp_factor": 0.04,
    "speed_cap": 0.12,
    "speed_factor": 0.004
  },
  "makeEncounterRoster": {
    "revision": 25
  },
  "spawnCycleTime": {
    "spawnCycleTime_cap": 480
  },
  "spawnCadence": {
    "spawnCadence_floor": 0.34,
    "spawnCadence_offset": 1.05,
    "spawnCadence_cap": 600,
    "spawnCadence_factor": 0.0008,
    "spawnCadence_cap_2": 2700,
    "spawnCadence_offset_2": 600,
    "spawnCadence_factor_2": 0.00011
  },
  "spawnBatchSize": {
    "spawnBatchSize_cap": 4,
    "spawnBatchSize_divisor": 180
  },
  "spawnArrivalRate": {
    "spawnArrivalRate_cap": 12,
    "spawnArrivalRate_factor": 2.3
  },
  "spawnSquadRate": {
    "initial": 0.5,
    "opening_offset": 0.35
  },
  "spawnFieldCap": {
    "meleeExtra": 6,
    "rangedEvery": 600,
    "rangedExtra": 2,
    "base": 99,
    "spawnFieldCap": 99,
    "spawnFieldCap_offset": 12,
    "spawnFieldCap_divisor": 90
  },
  "baseEnemy": {
    "R_divisor": 2,
    "R_offset": 60,
    "r": 1.6,
    "r_min": 0.9,
    "r_max": 1.1,
    "hp": 7,
    get maxhp(){return this.hp;},
    "speed": 0.85,
    "speed_min": 0.9,
    "speed_max": 1.12,
    "dmg": 1.5,
    "xp": 8,
    "shootT_max": 2.5,
    "navT_max": 0.25
  },
  "placeFormationEnemy": {
    "opposite": 5,
    "opposite_2": 4,
    "sideSequence_divisor": 5,
    "columns": 9,
    "columns_2": 17,
    "span": 1.1,
    "span_2": 2.1,
    "radius_floor": 360,
    "radius_factor": 0.6,
    "radius_offset": 120,
    "placeFormationEnemy_factor": 6,
    "row": 3,
    "distance_factor": 96,
    "placeFormationEnemy_factor_2": 200,
    "clear_offset": 6
  },
  "spawnEnemy": {
    "chance_threshold": 0.15,
    "chance_threshold_2": 0.7,
    "speed": 1.5,
    "shieldHp_factor": 0.3,
    "t_threshold": 300,
    "chance_threshold_3": 0.25
  },
  "spawnPack": {
    "n_offset": 7,
    "n_cap": 4,
    "n_divisor": 75,
    "r_min": 0.9,
    "r_max": 1.1,
    "speed_min": 0.95,
    "speed_max": 1.1,
    "shootT": 9,
    "navT_max": 0.25
  },
  "makeSpawnSquad": {
    "groups_threshold": 90,
    "groups_threshold_2": 300,
    "groups_threshold_3": 600,
    "t_threshold": 600,
    "chance_threshold": 0.05,
    "makeSpawnSquad": -999,
    "range_threshold": 60
  },
  "updateSpawnDirector": {
    "ramp_threshold": 9,
    "screenCap": 64,
    "screenCap_2": 70,
    "screenCap_3": 76,
    "screenCap_4": 100,
    "normalTarget_offset": 28,
    "normalTarget_divisor": 15,
    "stage_divisor": 300,
    "target_offset": 6,
    "spawnT_floor": 2,
    "squadRestT_threshold": 1.5,
    "squadT_min": 28,
    "squadT_max": 38,
    "squad_threshold": 2,
    "t_threshold": 45,
    "eliteT_floor": 32,
    "eliteT_offset": 70,
    "eliteT_divisor": 90,
    "packT_floor": 24,
    "packT_offset": 38,
    "packT_divisor": 180,
    "t_threshold_2": 75,
    "updateSpawnDirector_offset": 7,
    "packPending_offset": 7,
    "packPending_cap": 4,
    "packPending_divisor": 75,
    "rate_divisor": 9,
    "rate_factor": 2.5,
    "keys_factor": 10,
    "keys_offset": 0.2,
    "keys_factor_2": 0.8,
    "k_threshold": 0.7,
    "updateSpawnDirector_offset_2": 0.15,
    "updateSpawnDirector_factor": 0.85,
    "chance_threshold": 0.3,
    "range_threshold": 10,
    "chance_threshold_2": 0.25,
    "trapT": 7,
    "t_threshold_3": 90,
    "d_min": 60,
    "d_max": 240
  },
  "handoff": {
    "squadRestT": 2
  },
  "allowed": {
    "size_threshold": 4
  },
  "updateRushEscorts": {
    "escortT": 8,
    "stageLimit_factor": 0.67,
    "stageLimit_threshold": 16,
    "stageLimit": 2,
    "escortT_2": 2.4,
    "escortT_3": 3.2,
    "escortT_4": 11,
    "k": 3,
    "k_2": 2,
    "scale_factor": 0.2,
    "xp": 0.35
  },
  "makeBoss": {
    "R_divisor": 2,
    "R_offset": 80,
    "m_cap": 45,
    "scale_factor": 0.3,
    "scale_factor_2": 0.018,
    "hp_factor": 720,
    "hp_powArg2": 1.12,
    "cycle_divisor": 8,
    "pattern": 8,
    "bossKind": 8,
    "r": 46,
    "r_2": 58,
    "r_3": 34,
    "r_4": 42,
    "r_5": 40,
    "r_6": 44,
    "r_7": 62,
    "r_8": 38,
    "r_9": 8,
    "r_factor": 3,
    "speed": 62,
    "speed_2": 44,
    "speed_3": 76,
    "speed_4": 68,
    "speed_5": 60,
    "speed_6": 50,
    "speed_7": 18,
    "speed_8": 55,
    "speed_9": 8,
    "speed_factor": 2,
    "dmg_offset": 28,
    "dmg_factor": 6,
    "dmg_factor_2": 1.3,
    "xp": 45,
    "burstT": 6,
    "burstT_2": 2.5,
    "chargeT": 12,
    "chargeT_2": 10,
    "chargeT_3": 8,
    "slamT": 7,
    "spiralT": 4,
    "spiralT_2": 1.2,
    "summonT": 9,
    "spdMul_factor": 0.08,
    "enrageAt": 0.4,
    "enrageAt_threshold": 4,
    "enrageAt_2": 0.3,
    "mechanicsTier": 3,
    "mechanicsTier_threshold": 2,
    "mechanicsTier_2": 2,
    "mechanicsTier_threshold_2": 4,
    "attackMul_threshold": 4,
    "attackMul": 0.9,
    "hunT": 14,
    "veinT": 12,
    "starT": 6,
    "rockT": 5,
    "gazeT": 8,
    "tpT": 9,
    "echoT": 18,
    "miT": 16,
    "domT": 12,
    "warpT": 10,
    "waveT": 5,
    "shwaveT": 6,
    "mwaveT": 5,
    "domShotT": 3,
    "fbigT": 4
  },
  "spawnBoss": {
    "r": 44,
    "r_2": 62,
    "r_3": 38,
    "bossIntro": 2.2
  },
  "spawnTrap": {
    "r": 2,
    "r_2": 78,
    "r_3": 54,
    "r_4": 36,
    "t": 1.2,
    "dur": 0.8,
    "dur_2": 1.5
  },
  "spawnKeys": {
    "d_min": 300,
    "d_max": 1500
  },
  "openPortal": {
    "d_min": 260,
    "d_max": 1100,
    "r": 26,
    "timeStop": 15,
    "auraT": 15
  },
  "enterRealm": {
    "C": 96,
    "N": 15,
    "half_divisor": 2,
    "h": 36,
    "w": 36,
    "enterRealm": 4,
    "enterRealm_2": 10,
    "w_offset": 16,
    "h_offset": 16,
    "orbT": 8,
    "r": 9,
    "heal": 20,
    "scale_factor": 0.22,
    "guardSkin": 8,
    "r_2": 46,
    "hp_factor": 2600,
    "hp_factor_2": 0.85,
    "maxhp_factor": 2600,
    "maxhp_factor_2": 0.85,
    "speed_offset": 66,
    "speed_factor": 6,
    "dmg_offset": 34,
    "dmg_factor": 6,
    "xp": 80,
    "burstT": 99,
    "chargeT": 99,
    "slamT": 99,
    "spiralT": 99,
    "summonT": 99,
    "keyT": 1.4,
    "gridT": 4.2,
    "realmOrbT": 6,
    "bossIntro": 1.6
  },
  "exitRealm": {
    "iTimer": 5,
    "hp_factor": 0.3,
    "exitRealm_addCoinArg1": 20,
    "rampT": 14,
    "bossDelayUntil_offset": 20,
    "bossT": 300,
    "bossT_floor": 20
  },
  "spawnFinalBoss": {
    "b_makeBossArg1": 8,
    "mul_factor": 0.25,
    "r": 38,
    "bossNumber": 8,
    "bossIntro": 2.2,
    "R_divisor": 2,
    "R_offset": 80,
    "pattern": 4,
    "r_2": 58,
    "hp_factor": 9000,
    "hp_factor_2": 0.6,
    "maxhp_factor": 9000,
    "maxhp_factor_2": 0.6,
    "speed_enemyContractSpeedArg1": 72,
    "dmg_offset": 40,
    "dmg_factor": 8,
    "xp": 300,
    "burstT": 2,
    "chargeT": 4,
    "slamT": 3,
    "summonT": 5,
    "cloneT": 999,
    "bossIntro_2": 2.8
  }
},
    "growth": {
  "infusedElementTypes": {
    "level_threshold": 5
  },
  "elementUnityBonus": {
    "range_threshold": 3
  },
  "refreshResonance": {
    "refreshResonance_offset": 10,
    "refreshResonance_offset_2": 2,
    "refreshResonance_offset_3": 4
  },
  "walkSpeed": {
    "walkSpeed": 0.55
  },
  "slaughterBonus": {
    "stacks_threshold": 100
  },
  "holyLightLimit": {
    "holyLightLimit_offset": 4
  },
  "onSummonExit": {
    "summonAfterT": 2
  },
  "wealthDamage": {
    "wealthDamage_cap": 0.1
  },
  "triggerGoldRain": {
    "targets_divisor": 2
  },
  "tryDash": {
    "dashT": 0.18,
    "dashCd_factor": 3,
    "dashGraze": 0.35,
    "iTimer_floor": 0.35
  },
  "perfectDodge": {
    "timeStop_floor": 0.6,
    "pdBuff": 2,
    "iTimer_floor": 0.5
  },
  "passiveAvailable": {
    "shell": 0.6,
    "evade": 0.65,
    "reflect_b": 0.65,
    "frost": 0.4,
    "projectile_guard": 0.6,
    "electric_guard": 0.6
  },
  "statueSacrifice": {
    "hp_threshold": 12,
    "hp_factor": 0.25,
    "hp_offset": 5,
    "iTimer": 0.5,
    "roll_threshold": 0.7,
    "pool_threshold": 3,
    "length_threshold": 3,
    "amount": 100,
    "roll_threshold_2": 0.9,
    "statueSacrifice_addCoinArg1": 80,
    "roll_threshold_3": 0.95,
    "lost_factor": 0.2
  },
  "playerDamageMul": {
    "playerDamageMul_factor": 0.5,
    "playerDamageMul_2": 0.8,
    "playerDamageMul_3": 1.1
  },
  "criticalDamageMultiplier": {
    "cb_offset": 1.5,
    "criticalDamageMultiplier_offset": 1.5,
    "cb_threshold": 3,
    "criticalDamageMultiplier_offset_2": 3,
    "criticalDamageMultiplier_factor": 0.6
  },
  "rollDamage": {
    "dmg_cap": 50,
    "dmg_factor": 0.01,
    "dmg": 1.5
  },
  "splash": {
    "r": 58,
    "splash_applyElementOutputArg3": 2,
    "splash_factor": 0.4
  },
  "buildOffers": {
    "ids": 5,
    "length_threshold": 3,
    "rarity": 5,
    "amount": 150,
    "length_threshold_2": 2,
    "buildOffers": 3,
    "rarity_2": 4,
    "rarity_3": 2,
    "targets_threshold": 5,
    "buildOffers_factor": 0.75,
    "heal": 30,
    "w": 2.4,
    "heal_2": 70,
    "rarity_4": 3,
    "w_2": 1.4,
    "heal_3": 150,
    "w_3": 0.5,
    "length_threshold_3": 6,
    "amount_2": 30,
    "w_4": 2,
    "amount_3": 80,
    "w_5": 1.5,
    "available": 2,
    "available_2": 3,
    "available_3": 4,
    "available_4": 5,
    "high_threshold": 4
  },
  "common": {
    "value_1": 3,
    "value_2": 2.4,
    "value_3": 1.7,
    "value_5": 0.5
  },
  "offerRarity": {
    "offerRarity": 4,
    "offerRarity_2": 5,
    "offerRarity_3": 2
  },
  "weaponOfferWeight": {
    "weaponOfferWeight_cap": 64,
    "weaponOfferWeight": 2.5
  },
  "countPity": {
    "high_threshold": 4,
    "highOfferMisses_cap": 3
  },
  "countWeaponPity": {
    "id_cap": 64
  },
  "levelUp": {
    "levelUp": 10,
    "highOfferGuaranteed_threshold": 3,
    "heal": 70,
    "rarity": 3
  },
  "rerollOffers": {
    "heal": 70,
    "rarity": 3
  },
  "applyOffer": {
    "hp": 50,
    "id": 8,
    "length_threshold": 2,
    "critD": 1.3,
    "id_2": 0.45
  },
  "chooseOffer": {
    "rarity": 2,
    "pickCats_sliceArg1": -4
  },
  "openElementWeaponOffer": {
    "offers_threshold": 5
  },
  "dailyChallenge": {
    "seed_factor": 31,
    "c2": 3,
    "dailyChallenge": 2,
    "bonus": 0.5
  },
  "settleDaily": {
    "target": 120,
    "target_2": 50,
    "target_3": 0.2,
    "target_4": 0.15,
    "until_offset": 6000
  },
  "hitVoidstep": {
    "hit_offset": 18,
    "hit_factor": 12,
    "hit_factor_2": 1.5,
    "frozen_floor": 0.35
  }
},
    "combat": {
  "common": {
    "ARENA_R": 1690,
    "mul": 2.2,
    "mul_2": 2,
    "mul_3": 1.8,
    "mul_4": 1.6,
    "mul_5": 1.9,
    "GRID_KEY": 4096
  },
  "fireBoltVolley": {
    "r_factor": 5
  },
  "fireSeekerVolley": {
    "r_factor": 6
  },
  "strikeHammer": {
    "knock": 120,
    "knock_2": 60
  },
  "friendlyShot": {
    "vx_factor": 380,
    "vy_factor": 380,
    "r": 5,
    "life": 1.8,
    "turn": 2.4,
    "speed": 380
  },
  "puppetAttack": {
    "fireT": 3,
    "fireT_2": 1.2,
    "n": 2,
    "n_2": 8,
    "puppetAttack_offset": 0.5,
    "puppetAttack_factor": 0.2,
    "puppetAttack_offset_2": 12,
    "fireT_3": 0.15
  },
  "killEnemy": {
    "comboT": 2.5,
    "killEnemy": 50,
    "killTimes_threshold": 0.4,
    "length_threshold_2": 3,
    "label_threshold": 6,
    "label_threshold_2": 4,
    "mk_threshold": 4,
    "mk_threshold_2": 5,
    "killEnemy_2": 10,
    "killEnemy_3": 25,
    "killEnemy_4": 100,
    "title": 100,
    "title_2": 50,
    "killEnemy_offset": 20,
    "combo_threshold": 100,
    "comboKills_threshold": 2.5,
    "killEnemy_factor": 130,
    "killEnemy_factor_2": 0.8,
    "killEnemy_5": 120,
    "killEnemy_6": 35,
    "killEnemy_addCoinArg1": 3,
    "killEnemy_floor": 0.15,
    "killEnemy_factor_3": 0.03,
    "killEnemy_addCoinArg1_2": 15,
    "gnum": 4,
    "gnum_2": 12,
    "gval_divisor": 4,
    "gval_divisor_2": 12,
    "gval_factor": 1.6,
    "tier": 2,
    "v": 4,
    "v_2": 2,
    "v_min": 0.85,
    "v_max": 1.15,
    "delay": 0.08,
    "length_threshold_3": 512,
    "animClock_divisor": 8,
    "chance_threshold": 0.6,
    "r_2": 9,
    "heal": 20,
    "t_factor": 10,
    "t_divisor": 10,
    "killEnemy_addCoinArg1_3": 100,
    "killEnemy_addCoinArg1_4": 30,
    "unlocked_cap": 8,
    "rushEndT": 1.6,
    "finalT_offset": 300,
    "r_3": 26,
    "bossDelayUntil_offset": 8,
    "rampT_floor": 6,
    "range_threshold_3": 4
  },
  "orbsHeal": {
    "r": 12,
    "heal": 50
  },
  "receiveDamage": {
    "armor_floor": 0.75,
    "armor": 0.15,
    "typeMul_cap": 0.6,
    "dmg": 0.3,
    "raw": 0.3,
    "elementBase": 0.3,
    "dmg_2": 0.2,
    "taken_2": 1.1,
    "taken_3": 0.25
  },
  "applyEnemyDamage": {
    "value_threshold": 0.4
  },
  "dealPure": {
    "chance_threshold": 0.4
  },
  "elementResist": {
    "value": 0.1,
    "elementResist_cap": 0.9
  },
  "resistedReaction": {
    "value_divisor": 2
  },
  "chainReaction": {
    "reactionRange_reactionRangeArg1": 250,
    "value_factor": 0.65
  },
  "lavaZone": {
    "old_threshold": 96,
    "t": 3,
    "r_reactionRangeArg1": 72,
    "dur": 3
  },
  "resolveReaction": {
    "elCd": 0.5,
    "radius_reactionRangeArg1": 160,
    "refreshStatus_refreshStatusArg3": 4,
    "poisonAmp": 1.5,
    "refreshStatus_refreshStatusArg3_2": 3,
    "dmg_divisor": 3,
    "value_4_offset": 4,
    "superdmgMul": 0.15,
    "reactionSlow": 0.7,
    "value_3_offset": 3,
    "poison_factor": 1.5,
    "reactionSlow_2": 0.75,
    "value": 0.2,
    "controlCd": 1.5,
    "chainReaction_chainReactionArg6": 3,
    "chainReaction_chainReactionArg6_2": 4,
    "step": 0.18,
    "step_2": 0.12,
    "limit": 0.35,
    "limit_2": 0.2,
    "limit_3": 0.3,
    "refreshStatus_refreshStatusArg3_3": 5
  },
  "elemReaction": {
    "avg_divisor": 2,
    "cap": 20,
    "cap_factor": 0.9
  },
  "applyElem": {
    "next": 20,
    "next_factor": 0.2
  },
  "weaponElementHit": {
    "directFactor": 0.5,
    "textSize": 18,
    "chance_threshold": 0.5,
    "weaponElementHit": 2.4,
    "weaponElementHit_2": 2.2,
    "weaponElementHit_3": 2,
    "weaponElementHit_4": 20
  },
  "hurtEnemy": {
    "chance_threshold": 0.3,
    "splitFlash": 0.3,
    "bigBody_threshold": 40,
    "bigHit_threshold": 0.25,
    "bigHit_threshold_2": 500,
    "hurtEnemy_offset": 4,
    "hurtEnemy_factor": 0.2,
    "k": 0.12,
    "k_2": 0.3,
    "show_threshold": 0.03,
    "show_threshold_2": 0.7,
    "pct_threshold": 0.03,
    "hurtEnemy_3": 0.4,
    "hurtEnemy_4": 1.2,
    "hurtEnemy_applyElemArg3": 2.5,
    "hurtEnemy_factor_2": 0.8,
    "overflow_threshold": 40,
    "hurtEnemy_offset_2": 6,
    "splashD_factor": 0.35,
    "splashD_cap": 80,
    "hurtEnemy_offset_3": 70
  },
  "blockPlayerPhase": {
    "iTimer_floor": 0.35
  },
  "reflectPhaseBullet": {
    "nearest_factor": 740,
    "speed": 380,
    "speed_clampArg2": 200,
    "speed_clampArg3": 600,
    "r": 5,
    "r_clampArg3": 8,
    "life": 2
  },
  "hurtPlayer": {
    "iTimer": 0.25,
    "tripleThreshold": 55,
    "tripleCost": 3,
    "missingRecovery": 2.5,
    "cost_threshold": 30,
    "cost": 2,
    "iTimer_2": 0.4,
    "hurtPlayer": 2,
    "iTimer_3": 0.6,
    "hurtFlash": 0.28,
    "freeze": 0.035,
    "slow": 0.18,
    "red": 0.28,
    "cause_sliceArg2": 72
  },
  "settleRunStats": {
    "range_threshold": 600,
    "range_threshold_2": 1200,
    "range_threshold_3": 500
  },
  "gameOver": {
    "freeze": 0.14,
    "slow": 0.9,
    "remaining": 1.04,
    "duration": 1.04
  },
  "abandonRun": {
    "until_offset": 6000
  },
  "novaPulse": {
    "rad_offset": 70,
    "d_threshold": 26
  },
  "bossSplit": {
    "splitFlash": 0.6,
    "speed_factor": 0.92,
    "burstT_min": 1.5,
    "burstT_max": 3,
    "chargeT_min": 3,
    "chargeT_max": 5,
    "slamT_min": 2,
    "slamT_max": 4,
    "summonT_min": 3,
    "summonT_max": 6,
    "cloneLife": 10
  },
  "fireHBeam": {
    "len_floor": 1800,
    "len_offset": 600,
    "w": 24,
    "warn": 0.7,
    "fire": 0.28
  },
  "homingShot": {
    "r": 7,
    "life": 4.5,
    "life_factor": 1.4,
    "turn": 2.1
  },
  "bigShots": {
    "r": 20,
    "life": 5
  },
  "radialWaves": {
    "vx_factor": 320,
    "vy_factor": 320,
    "r": 6,
    "life": 4,
    "vx_factor_2": 110,
    "vy_factor_2": 110,
    "life_2": 7
  },
  "bossTeleport": {
    "pa_min": -0.9,
    "pa_max": 0.9,
    "d_min": 160,
    "d_max": 220
  },
  "bossRealSplit": {
    "r_factor": 0.62,
    "speed_factor": 0.9,
    "dmg_factor": 0.5,
    "xp": 14,
    "burstT_min": 1.5,
    "burstT_max": 3,
    "chargeT": 99,
    "slamT": 99,
    "summonT": 99,
    "enrageAt": 0.3,
    "densMul": 0.5
  },
  "updateEnvyPower": {
    "scale_cap": 30,
    "scale_factor": 0.18
  },
  "hurtAlly": {
    "iTimer": 0.22
  },
  "repulseEnemies": {
    "radius_offset": 150,
    "radius_factor": 30,
    "distance_offset": 75,
    "distance_factor": 20,
    "damage_offset": 8,
    "damage_factor": 9,
    "damage_factor_2": 0.14,
    "r_threshold": 30,
    "steps_cap": 4
  },
  "updateAutoCards": {
    "ecoGuard_floor": 0.15
  },
  "updatePlayerMovement": {
    "dsp_factor": 3.4,
    "value_threshold": 0.5,
    "moveRamp": 0.1,
    "moveRamp_2": 0.2,
    "value": 5,
    "value_2": 2.5
  },
  "updateWeapons": {
    "novaPulse_novaPulseArg3": 1.25,
    "spin_factor": 11,
    "steps_cap": 8,
    "steps_factor": 11,
    "steps_divisor": 0.15,
    "r_offset": 8,
    "spin_factor_2": 15,
    "travel_divisor": 0.8,
    "travel_factor": -0.8,
    "sp_factor": 1.15,
    "d_threshold": 24,
    "value_10_factor": 10,
    "value_factor": 16
  },
  "updateEnemies": {
    "frozen_floor": 0.05,
    "d_factor": 0.7,
    "advanceCd_advanceCdArg3": 0.5,
    "value_factor": 0.5,
    "value_threshold": 0.4,
    "meadowCd": 2,
    "elSlow": 0.6,
    "elSlow_factor": 0.35,
    "vx_factor": 330,
    "vy_factor": 330,
    "life_threshold": 2,
    "cloneLife_threshold": 1.5,
    "want": 170,
    "dir_offset": 30,
    "navT": 0.3,
    "summonOwnT": 4,
    "summonOwnT_2": 8,
    "alive_threshold": 6,
    "value_threshold_2": 6,
    "m_threshold": 0.5,
    "want_2": 210,
    "d_threshold": 430,
    "shootT_min": 2.6,
    "shootT_max": 3.4,
    "aa_factor": 0.3,
    "aa_min": -0.04,
    "aa_max": 0.04,
    "vx_factor_2": 165,
    "vy_factor_2": 165,
    "r": 6,
    "life": 4.5,
    "shootT_max_2": 1.5,
    "aa_min_2": -0.06,
    "aa_max_2": 0.06,
    "vx_factor_3": 250,
    "vy_factor_3": 250,
    "life_2": 4,
    "navT_2": 0.24
  },
  "updatePlayerBullets": {
    "bd2_factor": 0.45,
    "bd2": 300,
    "value_factor": 14
  },
  "updateEnemyBullets": {
    "slowT": 2
  },
  "updateMeadowMob": {
    "meadowCd": 2.5
  },
  "move": {
    "dir_offset": 25,
    "navT": 0.3
  },
  "update": {
    "dt_damageFeedbackStepArg3": 0.25,
    "cardT": 50,
    "hitStopGate_offset": 0.18,
    "dt_factor": 0.88,
    "ptick": 0.5,
    "outcome_factor": 0.5,
    "slowT": 0.6,
    "slowT_2": 0.1,
    "update_refreshStatusArg3": 0.1,
    "length_threshold": 2,
    "auraPulse": 0.5,
    "R": 280,
    "update_offset": 55,
    "update_factor": 0.8,
    "bob_factor": 3,
    "update_factor_2": 40,
    "keysHeld_threshold": 3,
    "swirl_factor": 4,
    "d_min": 360,
    "d_max": 640,
    "r": 24,
    "update_factor_3": 400,
    "statueT_offset": 110,
    "life": 40,
    "bob_factor_2": 2,
    "update_factor_4": 90,
    "rot_factor": 5,
    "update_advanceCdArg3": 0.4,
    "decay": 0.7,
    "decay_2": 0.5,
    "update_factor_5": 0.4,
    "d_threshold": 2500,
    "fireT": 0.65,
    "fireT_2": 0.75,
    "vx_factor": 420,
    "vy_factor": 420,
    "r_2": 4,
    "life_2": 1.2,
    "fd_threshold": 90,
    "range_offset": 4,
    "range": 140,
    "fireT_3": 1.2,
    "dv_threshold": 160000,
    "vx_factor_2": 380,
    "vy_factor_2": 380,
    "r_3": 5,
    "life_3": 1.4,
    "frozen_floor": 0.3,
    "inside_divisor": 2,
    "update_offset_2": 7,
    "armorBreakT_floor": 0.6,
    "update_advanceCdArg3_2": 0.5,
    "update_factor_6": 0.5,
    "t": 1.5,
    "update_factor_7": 20,
    "update_factor_8": 0.12,
    "hitCd": 0.8,
    "orbT": 10,
    "orbT_min": 10,
    "orbT_max": 15,
    "half_divisor": 2,
    "r_4": 9,
    "heal": 20,
    "sp_floor": 240,
    "sp_offset": 240,
    "sp_factor": 2,
    "update_offset_3": 8,
    "update": 6,
    "length_threshold_2": 260,
    "old_offset": 260,
    "update_addCoinArg1": 4,
    "particleDrag_factor": -5,
    "vy_threshold": -20,
    "vy_cap": 0.9,
    "vy_factor_3": 1.8,
    "scale_factor": 2.8,
    "r_5": 210,
    "r_floor": 4
  },
  "hit": {
    "hit_refreshStatusArg3": 0.6,
    "hit_applyElemArg3": 2.2
  }
},
    "weapons": {
  "setWeaponElement": {
    "level_cap": 5
  },
  "weaponStat": {
    "lv_threshold": 8
  }
},
    "cards": {
  "fx": {
    "field_floor": 0.35
  }
},


    // 地图身份、流程与平衡值仅在此处定义；运行时只读引用。
    maps:{
    valley:{id:'valley',name:'罪影荒谷',get desc(){return RG.configChinese(this.bosses.length,'五',5)+'位首领 · 秘境解锁工坊 · 吞噬者终局';},firstClearGold:150,bosses:[1,2,3,4,5],times:[300,600,900,1200,1500],finalAt:1800,keyFirst:390,keyRepeat:480,hp:1,dmg:1,xp:1},
    workshop:{id:'workshop',name:'草原溪地',desc:'疏林溪流 · 苔石遗迹 · 光束躲避',firstClearGold:200,bosses:[6,7,8],times:[540,1020,1500],finalAt:1500,keyFirst:300,keyRepeat:480,hp:.9,dmg:.8,xp:1.15,mobCap:64,bossHp:[18000,42000,65000],bossDmg:[28,32,36]},
    legacy:{id:'legacy',name:'旧版荒谷现场',bosses:[1,2,3,4,5,6,7,8],times:[300,600,900,1200,1500,1800,2100,2400],finalAt:2700,keyFirst:180,keyRepeat:180,hp:1,dmg:1,xp:1},
  },
    rushDifficulties:[
    {id:1,name:"简单",get desc(){return this.hp+"生命 · "+RG.configChinese(this.weaponLv,"一",1)+"级武器 · 仅第一阶段 · 冷却较长 · "+(this.escorts?"最多"+this.escorts+"只随从":"无随从");},hp:3000,weaponLv:1,dmg:.8,attack:1.3,escorts:0},
    {id:2,name:"标准",get desc(){return this.hp+"生命 · "+RG.configChinese(this.weaponLv,"三",3)+"级武器 · 分阶段招式 · 随从逐只入场（最多"+RG.configChinese(this.escorts,"四",4)+"只）";},hp:16000,weaponLv:3,dmg:1,attack:1,escorts:4},
    {id:3,name:"极限",get desc(){return this.hp+"生命 · "+RG.configChinese(this.weaponLv,"七",7)+"级武器 · 三阶段攻势 · 随从逐只入场（最多"+RG.configChinese(this.escorts,"六",6)+"只）";},hp:65000,weaponLv:7,dmg:1.15,attack:.8,escorts:6},
  ],
    player:Object.freeze({
      maxhp:100,       // 初始生命上限；当前生命在开局取同值。
      r:14,           // 碰撞半径，逻辑像素。
      speed:222,      // 移动速度，逻辑像素/秒。
      pickup:78,      // 初始拾取半径，逻辑像素。
      critD:1.5,      // 暴击伤害倍率。
      rerolls:1,      // 每局基础重骰次数，不含局外加成。
    }),
    experience:Object.freeze({
      base:8,perLevel:5,power:1.8, // 升级经验：向下取整(base + 等级×perLevel + 等级^power)。
    }),
  });
  RG.DATA_BALANCE_VER="v12032";
})(window.RG);
