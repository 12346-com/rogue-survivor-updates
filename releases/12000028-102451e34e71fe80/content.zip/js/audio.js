// ============ 音频:原创场景配乐 + 音效加载 + 合成兜底 ============
// 素材约定:原创音效放进 assets/audio/,文件名与既有音效事件一一对应:
//   shoot / hit / kill / gem / hurt / levelup / choose / nova / boom /
//   trap / boss / over / block / freeze  (支持 .mp3 / .ogg)
//   bgm-menu/play/boss/realm.ogg = 四首原创循环，bgm.ogg = 菜单兼容曲
// 缺哪个文件就自动用内置合成音兜底,不影响运行。
(function (RG) {
  const SFX_NAMES = ["shoot", "hit", "crit", "combo", "kill", "kill-1", "kill-2", "gem", "hurt", "levelup", "choose", "nova", "boom", "trap", "boss", "over", "block", "freeze", "key", "timestop", "portal", "realm", "evaporate", "overload", "superconduct", "statue", "oath", "buy", "buypower"];
  const VOL = RG.SETTINGS_DEFAULTS.mix.volumes;
  const KILL_VARS = ["kill", "kill-1", "kill-2"];   // C-09 击杀音随机变体
  const SFX_GAIN = RG.SETTINGS_DEFAULTS.audio.sfxBus;   // 打击音与音乐分总线校准，滑条仍是用户偏好。
  // 音量设置(Z-P3 四滑条,本地持久化):主/音乐/音效/环境 0~1;旧档 {sfx,mus} 自动迁移
  RG.masterVol = RG.SETTINGS_DEFAULTS.audio.master; RG.sfxVol = RG.SETTINGS_DEFAULTS.audio.sfx; RG.musicVol = RG.SETTINGS_DEFAULTS.audio.music; RG.ambVol = RG.SETTINGS_DEFAULTS.audio.ambient;   // 默认突出打击声，保留已保存的滑条。
  try {
    const vv = JSON.parse(localStorage.getItem("rg_vol") || "null");
    if (vv) {
      if (typeof vv.sfx === "number") RG.sfxVol = vv.sfx;
      if (typeof vv.mus === "number") RG.musicVol = vv.mus;
      if (typeof vv.master === "number") RG.masterVol = vv.master;
      if (typeof vv.amb === "number") RG.ambVol = vv.amb;
    }
  } catch (err) {}
  RG.saveVol = function () { try { localStorage.setItem("rg_vol", JSON.stringify({ master: RG.masterVol, sfx: RG.sfxVol, mus: RG.musicVol, amb: RG.ambVol })); return RG.recordStorageResult ? RG.recordStorageResult("rg_vol", true) : true; } catch (err) { return RG.recordStorageResult ? RG.recordStorageResult("rg_vol", false) : false; } };
  const sv = () => SFX_GAIN * RG.sfxVol * RG.masterVol;
  const musVol = () => RG.musicVol * RG.masterVol * RG.SETTINGS_DEFAULTS.audio.musicBus;
  const EXT = ["ogg", "mp3", "wav"];
  const base = "assets/audio/";
  const SFX_REV = "11920";
  let AC = null;

  RG.muted = false;
  RG.audioInfo = { loaded: [], missing: [] };

  // 三种格式只是兼容候选，不作为三重叠播池；只播放已经确认可用的格式。
  const pools = {};
  for (const name of SFX_NAMES) {
    pools[name] = (name === "crit" || name === "combo" ? ["wav", "ogg", "mp3"] : EXT).map(ext => {
      const a = new Audio();
      a.preload = "auto";
      a._ok = null; // null=未探测 true=可用 false=缺文件
      a._ext = ext;
      a.addEventListener("ended", () => { if (a._voice) finishVoice(a._voice); });
      a.src = base + name + "." + ext + "?v=" + SFX_REV;
      a.addEventListener("error", () => { a._ok = false; markMissing(name); if (a._voice) playFallback(a._voice); });
      a.addEventListener("canplaythrough", () => {
        a._ok = true;
        if (!RG.audioInfo.loaded.includes(name)) RG.audioInfo.loaded.push(name);
        RG.audioInfo.missing = RG.audioInfo.missing.filter(n => n !== name);
      }, { once: true });
      return a;
    });
  }
  function markMissing(name) {
    if (!pools[name] || !pools[name].every(a => a._ok === false)) return;
    if (!RG.audioInfo.missing.includes(name)) RG.audioInfo.missing.push(name);
  }

  const MUSIC_REV = "11937";
  let bgm = null, bgmTried = false;
  function startOldBgm() {   // 兼容入口也使用重制后的菜单主题。
    if (bgmTried) { if (bgm && !RG.muted) { bgm.volume = musVol(); bgm.play().catch(() => {}); } return; }
    bgmTried = true;
    const a = new Audio(base + "bgm.ogg?v=" + MUSIC_REV);
    a.loop = true; a.volume = 0;
    a.addEventListener("error", () => { bgm = null; if (desiredScene === "menu" && MUS.scene !== "silent") startSynthBgm("menu"); });
    bgm = a;
    a.play().catch(() => {});
  }
  // ---------- 四首场景曲:统一主题、连续循环、淡入淡出与场景防抖 ----------
  // 缺文件回退链:场景曲 → 菜单兼容曲 → 同主题程序配乐；浏览器无音频能力则静默。
  const FILE_BGM = { menu: "bgm-menu", play: "bgm-play", boss: "bgm-boss", vault: "bgm-realm" };
  const tracks = {};
  for (const sc in FILE_BGM) {
    const a = new Audio(base + FILE_BGM[sc] + ".ogg?v=" + MUSIC_REV);
    a.loop = true; a.preload = "auto"; a.volume = 0;
    a._ok = null; a._scene = sc;
    a.addEventListener("error", () => { a._ok = false; if (bgmScene === sc) applyScene(sc); });   // 播放中才发现缺文件 → 立即走回退
    a.addEventListener("canplaythrough", () => { a._ok = true; }, { once: true });
    tracks[sc] = a;
  }
  let bgmScene = null, pendingScene = null, bgmCommitTimer = null, duckUntil = 0, desiredScene = "menu";
  let duckGain = 1;
  RG._bgmNow = null;   // 验收/探针:当前文件曲场景
  RG._bgmEl = () => (bgmScene ? tracks[bgmScene] : null);
  RG._musicFallback = null;   // 验证缺文件时仍有有效配乐路径。
  RG.musicInfo=()=>({scene:bgmScene,tracks:Object.entries(tracks).map(([scene,a])=>({scene,backend:a._source?'buffer':'media',playing:!!a._source||!a.paused,gain:a._gain||0,position:a._source?(ac().currentTime-a._started+a._offset)%a._buffer.duration:a.currentTime,duration:a._buffer?.duration||a.duration}))});
  function stopTrack(a){
    if(a._source){a._offset=(ac().currentTime-a._started+(a._offset||0))%a._buffer.duration;try{a._source.stop();}catch(err){}a._source.disconnect();a._bus.disconnect();a._source=a._bus=null;}
    if(!a.paused)a.pause();a._resume=true;
  }
  function startTrack(a){
    const context=ac();
    if(a._buffer&&context?.state==='running'){
      if(!a._source){const s=context.createBufferSource(),g=context.createGain();s.buffer=a._buffer;s.loop=true;
        g.gain.value=RG.muted?0:musVol()*duckGain*Math.sqrt(a._gain||0);s.connect(g);g.connect(context.destination);a._offset=!a.paused?a.currentTime:a._resume?(a._offset??a.currentTime??0):0;a._started=context.currentTime;a._source=s;a._bus=g;s.start(context.currentTime,a._offset%a._buffer.duration);
        if(!a.paused)a.pause();
      }
    }else if(a.paused){if(!a._resume)try{a.currentTime=0;}catch(err){}a.play().catch(()=>{});}
  }
  function pauseAllFileBgm(preservePlayhead) {
    for (const k in tracks) {
      const a = tracks[k];
      a._resume = !!(preservePlayhead && (a._resume || k === bgmScene && (!a.paused||a._source)));
      a._want = false;
      stopTrack(a);
    }
    if (bgm && !bgm.paused) bgm.pause();
  }
  function applyScene(sc) {   // 提交场景:文件曲优先,缺文件走回退链
    if (sc === "silent") {
      if (bgmCommitTimer) { clearTimeout(bgmCommitTimer); bgmCommitTimer = null; }
      pauseAllFileBgm(true);
      pendingScene = null; bgmScene = null; RG._bgmNow = null;
      MUS.scene = "silent"; MUS.pending = null;
      if (MUS.bus) MUS.bus.gain.setTargetAtTime(0.0001, ac().currentTime, 0.025);
      return;
    }
    desiredScene = sc;
    const el = tracks[sc];
    if (el && el._ok !== false) {
      // 场景首次使用才解码，避免手机开局同时常驻四首完整PCM配乐。
      const context=ac();if(!el._decodeStarted&&context&&typeof context.decodeAudioData==='function'){
        el._decodeStarted=true;readSample(context,FILE_BGM[sc],'ogg',MUSIC_REV).then(buffer=>{if(buffer)el._buffer=buffer;});
      }
      for (const k in tracks) tracks[k]._want=k===sc;
      MUS.scene = null; MUS.pending = null;   // 文件曲接管,停程序化配乐
      RG._musicFallback = null;
      if (MUS.bus) MUS.bus.gain.setTargetAtTime(0.0001, ac().currentTime, 0.04);
      bgmScene = sc; RG._bgmNow = sc;
      if (RG.muted) { stopTrack(el); if (bgm && !bgm.paused) bgm.pause(); return; }
      if (bgm && !bgm.paused) bgm.pause();
      startTrack(el);
      return;
    }
    // 菜单兼容文件也缺失时，四个场景都能回到同主题程序配乐。
    bgmScene = null; RG._bgmNow = null;
    pauseAllFileBgm(false);
    if (RG.muted) return;
    if (sc === "menu" && !(bgmTried && !bgm)) {
      MUS.scene = null; MUS.pending = null;
      if (MUS.bus) MUS.bus.gain.setTargetAtTime(0.0001, ac().currentTime, 0.04);
      RG._musicFallback = "menu-file"; startOldBgm(); return;
    }
    startSynthBgm(sc);
  }
  function startSynthBgm(sc) {
    RG._musicFallback = "synth-" + sc;
    if (RG.muted || MUS.scene === "silent" && desiredScene !== sc) return;
    const a = ac(); if (!a) return;
    ensureMusicBus(a);
    MUS.bus.gain.setTargetAtTime(0.92 * musVol() / .55 * duckGain, a.currentTime, 0.04);
    if (!MUS.timer) MUS.timer = setInterval(musStep, 40);
    if (!MUS.scene || MUS.scene === "silent") { MUS.scene = sc; MUS.pending = null; MUS.next = a.currentTime + 0.06; MUS.step = 0; }
    else MUS.pending = sc;   // 程序化:同一拍网格内换层,避免 BOSS 出现硬切/重拍
  }
  // 场景淡变独立于音量大小；危险压低快速进入、缓慢恢复，避免低音量时变成硬切。
  setInterval(() => {
    const active = bgmScene ? tracks[bgmScene] : null;
    const duckTarget = performance.now() < duckUntil ? 0.35 : 1;
    duckGain += (duckTarget - duckGain) * (duckTarget < duckGain ? .72 : .22);
    const tgt = Math.max(0, Math.min(1, RG.muted ? 0 : musVol() * duckGain));
    for (const k in tracks) {
      const a = tracks[k];
      if(a===active&&!RG.muted&&a._buffer&&!a._source)startTrack(a);
      if (a.paused&&!a._source) continue;
      if (a === active) {
        a._gain = Math.min(1, (a._gain || 0) + .04);
      } else {
        a._gain = Math.max(0, (a._gain || 0) - .04);
        if (a._gain <= 0.001)stopTrack(a);
      }
      // 等功率交叉淡变，两首曲衔接时不会掉出明显的音量空洞。
      const gain=tgt*Math.sqrt(a._gain||0);a.volume=gain;
      if(a._bus)a._bus.gain.setTargetAtTime(gain,ac().currentTime,.025);
    }
    if (bgm && !bgm.paused) bgm.volume = tgt;
    if (MUS.bus && MUS.scene && MUS.scene !== "silent") MUS.bus.gain.setTargetAtTime(RG.muted ? .0001 : .92 * musVol() / .55 * duckGain, ac().currentTime, .025);
    refreshSfx();syncSceneAmbient();
  }, 60);
  // 原创分层音床，保留独立环境滑条；单通道、场景切换销毁旧实例，不叠播。
  const FILE_AMBIENT = { valley: "amb-valley.wav", workshop: "amb-workshop.wav", vault: "amb-vault.wav" };
  const AMBIENT_REV = "12019";
  let amb=null,ambName=null,ambRun=null,ambAttempted=false,ambFailed=false,ambFocus=true,ambGain=0,ambientOverride;
  function pauseAmbient(){if(amb)amb.pause();ambGain=0;ambAttempted=false;}
  function selectAmbient(name){
    name=FILE_AMBIENT[name]?name:null;
    if(name===ambName&&ambRun===RG.run)return;
    pauseAmbient();amb=null;ambFailed=false;ambName=name;ambRun=RG.run;
  }
  function syncSceneAmbient(){
    const env=RG.readEnvironment?RG.readEnvironment():{theme:RG.realm?.active?'vault':RG.run?.mapId==='workshop'?'workshop':'valley',stage:'none',heat:0};
    if(ambRun!==RG.run)ambientOverride=undefined;
    const inRun=!!(RG.run&&RG.P),name=inRun?(ambientOverride!==undefined?ambientOverride:env.theme==='legacy'?'valley':env.theme):null;
    selectAmbient(name);
    const canPlay=!!(name&&RG.state==='play'&&!(typeof document!=='undefined'&&document.hidden)&&ambFocus&&!RG.muted&&RG.ambVol>0&&RG.masterVol>0);
    const stateGain=env.stage==='cold'?.62:env.stage==='settling'?.75:env.stage==='locked'?1.3:1+env.heat*.22;
    const target=canPlay?clampAmbient(RG.ambVol*RG.masterVol*.65*stateGain):0;
    if(!canPlay)pauseAmbient();
    else if(!ambFailed){
      if(!amb){
        const a=new Audio(base+FILE_AMBIENT[name]+'?v='+AMBIENT_REV);a.loop=true;a.preload='auto';a.volume=0;amb=a;
        a.addEventListener('error',()=>{if(amb!==a)return;ambFailed=true;pauseAmbient();const id='amb-'+name;if(!RG.audioInfo.missing.includes(id))RG.audioInfo.missing.push(id);},{once:true});
      }
      ambGain+=Math.min(.045,Math.max(-.045,target-ambGain));amb.volume=clampAmbient(ambGain);
      if(amb.paused&&!ambAttempted){ambAttempted=true;const a=amb;a.play().catch(()=>{if(amb===a)ambGain=0;});}
    }
    RG.ambientStatus={name:ambName,stage:env.stage,gain:ambGain,playing:!!amb&&!amb.paused,missing:ambFailed};
  }
  function clampAmbient(v){return Math.max(0,Math.min(1,v||0));}
  RG.setAmbient=function(name){ambRun=RG.run;ambientOverride=name==='auto'?undefined:FILE_AMBIENT[name]?name:null;syncSceneAmbient();};
  RG.syncAmbient=syncSceneAmbient;
  if(typeof window.addEventListener==='function'){
    window.addEventListener('blur',()=>{ambFocus=false;pauseAmbient();});
    window.addEventListener('focus',()=>{ambFocus=true;syncSceneAmbient();});
  }
  if(typeof document!=='undefined'&&typeof document.addEventListener==='function')document.addEventListener('visibilitychange',syncSceneAmbient);
  // 移动端浏览器会把 AudioContext 锁到第一次手势之后；由主控在点按/触摸时解锁。
  RG.unlockAudio = function () {
    const a = ac();
    if (a && a.state === "suspended") a.resume().catch(() => {});
    const el = bgmScene ? tracks[bgmScene] : null;   // 手势解锁后补播被自动播放策略拦下的场景曲
    if (el && el._want)startTrack(el);
    ambAttempted=false;syncSceneAmbient();
  };
  RG.refreshAudioMix = function () {
    refreshSfx();
    if (bgm) bgm.volume = musVol() * duckGain;
    syncSceneAmbient();
  };
  RG.startBgm = function () {
    RG.unlockAudio();
    if (MUS && MUS.bus) MUS.bus.gain.setTargetAtTime(0.92 * musVol() / .55 * duckGain, ac().currentTime, 0.04);
    applyScene(desiredScene || "menu");   // 解除静音:按最近场景恢复(文件曲优先)
  };
  RG.stopBgm = function () {
    if (RG.muted) RG.stopSfx();
    pauseAllFileBgm(true);
    if (MUS && MUS.bus) MUS.bus.gain.setTargetAtTime(0.0001, ac().currentTime, 0.025);
    syncSceneAmbient();
  };

  // ---------- 合成兜底 ----------
  function ac() { if (!AC) try { AC = new (window.AudioContext || window.webkitAudioContext)({sampleRate:44100}); } catch (e) {} return AC; }
  // 八个有上限的声部：关键提示、拾取、攻击、暴击、连击、两路击杀、技能。
  const voices = new Map(), lastSfx = {};
  const sfxBuffers={},sfxDecodes=new Map();let sfxBus=null,killChannel=0;
  function outputBus(){
    const a=ac();if(!a)return null;if(sfxBus)return sfxBus;
    sfxBus=a.createGain();sfxBus.gain.value=.8;
    if(a.createDynamicsCompressor){const c=a.createDynamicsCompressor();c.threshold.value=-12;c.knee.value=8;c.ratio.value=8;c.attack.value=.003;c.release.value=.09;sfxBus.connect(c);c.connect(a.destination);}else sfxBus.connect(a.destination);
    return sfxBus;
  }
  const stats = { played: 0, dropped: 0, peak: 0 };
  const FOCUS = RG.SETTINGS_DEFAULTS.mix.focus;
  const PICKUP = RG.SETTINGS_DEFAULTS.mix.pickup;
  const COMBAT = RG.SETTINGS_DEFAULTS.mix.combat;
  const SFX_CD = RG.SETTINGS_DEFAULTS.mix.cooldowns;
  let lastKill = -1;
  // 合成只作无文件回退；旋律全部由音频时钟排程，取消声道会连后续音符一起停止。
  const FALLBACK = {
    shoot:[[740,.048,-320]], hit:[[270,.068,-155]], crit:[[160,.105,-90,0,.3]], kill:[[185,.115,-112]],
    combo:[[240,.18,-130,0,.32],[1250,.10,-650,0,.12,"triangle"]], gem:[[1174,.078,144]], hurt:[[180,.19,-112]], block:[[620,.10,-120]],
    freeze:[[1397,.10,-350]], choose:[[587,.08,197]], nova:[[270,.20,-165]],
    boom:[[160,.24,-110]], trap:[[110,.15,80]], boss:[[125,.58,-77]],
    levelup:[[587,.16,0,0],[698,.16,0,.075],[880,.16,0,.15],[1174,.16,0,.225]],
    over:[[587,.22,0,0],[440,.22,0,.1],[349,.22,0,.2],[294,.22,0,.3]],
    key:[[587,.16,0,0],[880,.16,0,.07],[1174,.16,0,.14]],
    timestop:[[260,.38,-195]], portal:[[170,.34,250]], realm:[[145,.40,-72]],
    evaporate:[[1400,.21,-1000]], overload:[[260,.19,-184]], superconduct:[[1174,.146,394]],
    statue:[[294,.2,0,0],[440,.2,0,.08]], oath:[[440,.13,0,0],[554,.13,0,.045],[659,.13,0,.09]],
    buy:[[784,.1,0,0],[1047,.1,0,.055]], buypower:[[587,.13,0,0],[740,.13,0,.055],[988,.13,0,.11]],
  };
  function finishVoice(v) {
    if (!v || !v.live) return;
    v.live = false;
    if (voices.get(v.group) === v) voices.delete(v.group);
    if (v.timer) clearTimeout(v.timer);
    if (v.media && v.media._voice === v) { v.media._voice = null; v.media.pause(); }
    if (v.gain) { v.gain.gain.value = 0; if (v.gain.disconnect) v.gain.disconnect(); }
    for (const o of v.nodes || []) { try { o.stop(); } catch (err) {} if (o.disconnect) o.disconnect(); }
  }
  RG.stopSfx = function () { clearComboSound(); for (const v of voices.values()) finishVoice(v); };
  RG.sfxInfo = () => ({ ...stats, limit:8, decoded:Object.keys(sfxBuffers), active:Array.from(voices.values(),v=>({name:v.name,group:v.group,backend:v.backend,rate:v.rate,gain:v.gainMul||1})),combo:{recent:audioKills.length,tier:playedComboTier,pending:pendingComboTier,cues:comboCues,events:comboCueLog.slice()} });
  function sfxAllowed() { return !RG.muted && sv() > 0 && RG.state !== "pause" && !(typeof document !== "undefined" && document.hidden); }
  function refreshSfx() {
    if (!sfxAllowed()) { RG.stopSfx(); return; }
    for (const v of voices.values()) {
      const gain = (VOL[v.name] === undefined ? .5 : VOL[v.name]) * sv() * (v.gainMul || 1);
      if (v.media && v.media._voice === v) v.media.volume = Math.max(0,Math.min(1,gain));
      if (v.gain) v.gain.gain.value = gain;
    }
  }
  function reserveVoice(name, priority) {
    if (!sfxAllowed()) { stats.dropped++; return null; }
    const key = name.startsWith("kill") ? "kill" : name;
    const group = FOCUS[key] !== undefined ? "focus" : PICKUP[key] !== undefined ? "pickup" : key==='kill'?'death'+(killChannel++%2):key==='crit'?'crit':key==='combo'?'combo':['shoot','hit','tone'].includes(key)?'attack':'effect';
    const rank = priority === undefined ? (FOCUS[key] ?? PICKUP[key] ?? COMBAT[key] ?? 2) : priority;
    const now = performance.now(), cd = SFX_CD[key] || 160;
    if (now - (lastSfx[key] ?? -Infinity) < cd) { stats.dropped++; return null; }
    const focus = voices.get("focus"), old = voices.get(group);
    if ((focus?.key==='over'&&group!=='focus') || (old && old.priority >= rank)) { stats.dropped++; return null; }
    if(key==='over')RG.stopSfx();else if(old)finishVoice(old);
    const v = { name, key, group, priority:rank, created:now, live:true, nodes:[] };
    voices.set(group,v); lastSfx[key] = now;
    stats.played++; stats.peak = Math.max(stats.peak,voices.size);
    return v;
  }
  function playFallback(v) {
    if (!v.live || v.backend === "synth") return;
    if (performance.now() - v.created > 60 || !sfxAllowed()) { finishVoice(v); return; }
    if (v.timer) clearTimeout(v.timer);
    if (v.media && v.media._voice === v) { v.media._voice = null; v.media.pause(); }
    v.media = null;
    const a = ac(), notes = v.notes || FALLBACK[v.key];
    if (!a || a.state === "suspended" || !notes) { finishVoice(v); return; }
    v.backend = "synth";
    v.gain = a.createGain(); v.gain.connect(outputBus());
    const t = a.currentTime; let end = 0;
    for (const [freq,dur,slide=0,delay=0,vol=.32,type="sine"] of notes) {
      const o = a.createOscillator(), g = a.createGain(), at = t + delay;
      o.type = type; o.frequency.setValueAtTime(freq * v.rate,at);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30,(freq+slide)*v.rate),at+dur);
      g.gain.setValueAtTime(.0001,at);
      g.gain.exponentialRampToValueAtTime(Math.max(.0001,vol),at+.004);
      g.gain.exponentialRampToValueAtTime(.0001,at+dur);
      o.connect(g); g.connect(v.gain); o.start(at); o.stop(at+dur+.005); v.nodes.push(o);
      end = Math.max(end,delay+dur);
    }
    refreshSfx(); v.timer = setTimeout(()=>finishVoice(v),(end+.02)*1000);
  }

  // 已批准的短音：文件优先；file:// 入口用 XHR 解码，缺文件仍有短颗粒兜底。
  let samplePromise=null, combatSamples=null;
  let audioKills=[], playedComboTier=0, pendingComboTier=0, pendingComboAt=0, comboDebounce=null, comboQuiet=null, lastComboAt=-Infinity;
  let comboCues=0; const comboCueLog=[];
  const hasBuffers=a=>a&&typeof a.createBuffer==='function'&&typeof a.createBufferSource==='function'&&typeof a.decodeAudioData==='function';
  function pcmBuffer(a,x){const b=a.createBuffer(1,x.length,a.sampleRate||44100);b.getChannelData(0).set(x);return b;}
  function highpass(x,hz,sr){
    const w=2*Math.PI*hz/sr,c=Math.cos(w),alpha=Math.sin(w)/(2*.707),a0=1+alpha,b0=(1+c)/2/a0,b1=-(1+c)/a0,b2=b0,a1=-2*c/a0,a2=(1-alpha)/a0,out=new Float32Array(x.length);let x1=0,x2=0,y1=0,y2=0;
    for(let i=0;i<x.length;i++){const v=b0*x[i]+b1*x1+b2*x2-a1*y1-a2*y2;out[i]=v;x2=x1;x1=x[i];y2=y1;y1=v;}return out;
  }
  function shortNoise(a,seconds){
    const sr=a.sampleRate||44100,x=new Float32Array(Math.round(seconds*sr));let seed=11920,low=0;
    for(let i=0;i<x.length;i++){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;const n=(seed>>>0)/2147483648-1;low+=.25*(n-low);x[i]=low*Math.min(1,i/24)*Math.exp(-i/sr*55)*.45;}
    return highpass(x,350,sr);
  }
  function prepareHits(a,base){
    const sr=a.sampleRate||44100,bright=highpass(base,1500,sr),hits=[];
    for(let n=1;n<=20;n++){const strength=(n-1)/19,pitch=1.05+.55*strength,brightness=.10+.65*strength,x=new Float32Array(Math.round(.026*sr));
      for(let i=0;i<x.length;i++){const p=i*pitch,j=Math.floor(p),one=(base[j]||0)+(bright[j]||0)*brightness,two=(base[j+1]||0)+(bright[j+1]||0)*brightness;x[i]=(one+(two-one)*(p-j))*Math.min(1,i/16)*Math.min(1,Math.max(0,(.026-i/sr)/.015));}
      hits.push(pcmBuffer(a,x));
    }
    const tail=new Float32Array(Math.round(.07*sr));for(let i=0;i<tail.length;i++)tail[i]=(base[i+Math.round(.008*sr)]||0)*Math.min(1,i/80)*(1-i/tail.length);
    return {hits,tail:pcmBuffer(a,tail)};
  }
  function readSample(a,name,ext='wav',revision=SFX_REV){return new Promise(resolve=>{
    if(typeof XMLHttpRequest==='undefined'){resolve(null);return;}
    try{const req=new XMLHttpRequest();req.open('GET',base+name+'.'+ext+'?v='+revision,true);req.responseType='arraybuffer';req.timeout=4000;
      req.onload=()=>{if(!req.response||(req.status!==0&&req.status!==200)){resolve(null);return;}a.decodeAudioData(req.response).then(resolve,()=>resolve(null));};req.onerror=req.ontimeout=()=>resolve(null);req.send();
    }catch(err){resolve(null);}
  });}
  function prepareSfxBuffers(a){
    return Promise.all(SFX_NAMES.filter(n=>!['crit','combo'].includes(n)).map(name=>{
      if(sfxDecodes.has(name))return sfxDecodes.get(name);
      const promise=(async()=>{for(const ext of EXT){const buffer=await readSample(a,name,ext);if(!buffer)continue;
        // 去掉文件头静音，只保留2毫秒起音空间，避免按键/连杀声音落后于画面。
        const x=buffer.getChannelData(0);let first=0;while(first<x.length&&Math.abs(x[first])<.002)first++;
        const from=Math.max(0,first-Math.ceil(buffer.sampleRate*.002));
        if(from>0&&first<x.length){const trimmed=a.createBuffer(buffer.numberOfChannels,buffer.length-from,buffer.sampleRate);for(let c=0;c<buffer.numberOfChannels;c++)trimmed.getChannelData(c).set(buffer.getChannelData(c).subarray(from));sfxBuffers[name]=trimmed;}else sfxBuffers[name]=buffer;
        return true;
      }return false;})();sfxDecodes.set(name,promise);return promise;
    }));
  }
  RG.prepareCombatAudio=function(){
    const a=ac();if(!hasBuffers(a))return Promise.resolve(false);
    if(samplePromise)return samplePromise;
    prepareSfxBuffers(a);
    const fallback=shortNoise(a,.08);combatSamples={crit:pcmBuffer(a,shortNoise(a,.105)),...prepareHits(a,fallback),critBackend:'synth',comboBackend:'synth'};
    samplePromise=Promise.all([readSample(a,'crit'),readSample(a,'combo')]).then(([crit,combo])=>{
      if(crit){combatSamples.crit=crit;combatSamples.critBackend='file';}
      if(combo){Object.assign(combatSamples,prepareHits(a,combo.getChannelData(0)));combatSamples.comboBackend='file';}
      return {crit:combatSamples.critBackend,combo:combatSamples.comboBackend};
    });return samplePromise;
  };
  function sourceAt(v,buffer,at,gain){const a=ac(),s=a.createBufferSource(),g=a.createGain();s.buffer=buffer;s.playbackRate.value=v.rate||1;g.gain.value=gain;s.connect(g);g.connect(v.gain);v.nodes.push(s);s.onended=()=>{g.disconnect();s.disconnect();};s.start(at);s.stop(at+buffer.duration/(v.rate||1)+.001);return s;}
  function bufferVoice(v){const a=ac();v.rate??=1;v.gainMul??=1;v.gain=a.createGain();v.gain.connect(outputBus());refreshSfx();return a;}
  function playCritBuffer(v){const a=bufferVoice(v),at=a.currentTime+.001;v.backend=combatSamples.critBackend;v.audioEnd=at+combatSamples.crit.duration;sourceAt(v,combatSamples.crit,at,1);v.timer=setTimeout(()=>finishVoice(v),(combatSamples.crit.duration+.012)*1000);}
  function clearComboSound(){if(comboDebounce)clearTimeout(comboDebounce);if(comboQuiet)clearTimeout(comboQuiet);comboDebounce=comboQuiet=null;audioKills=[];playedComboTier=pendingComboTier=pendingComboAt=0;lastComboAt=-Infinity;}
  function fadeCombo(v){
    const a=ac();if(!v||!v.live)return;
    if(!hasBuffers(a)||!v.gain){finishVoice(v);return;}
    if(v.timer)clearTimeout(v.timer);v.live=false;if(voices.get(v.group)===v)voices.delete(v.group);
    v.gain.gain.cancelScheduledValues(a.currentTime);v.gain.gain.setValueAtTime(v.gain.gain.value,a.currentTime);v.gain.gain.linearRampToValueAtTime(0,a.currentTime+.008);
    for(const s of v.nodes)try{s.stop(a.currentTime+.008);}catch(err){}
    setTimeout(()=>{v.gain.disconnect();for(const s of v.nodes)try{s.disconnect();}catch(err){}},12);
  }
  function playComboCue(tier){
    if(!sfxAllowed()||voices.get('focus')?.key==='over')return false;
    const a=ac(),old=voices.get('combo');
    if(old)fadeCombo(old);
    if(!hasBuffers(a)||a.state==='suspended'||!combatSamples)return RG.playSfx('combo',1,5);
    const v={name:'combo',key:'combo',group:'combo',priority:5,created:performance.now(),live:true,nodes:[],backend:combatSamples.comboBackend};voices.set('combo',v);stats.played++;stats.peak=Math.max(stats.peak,voices.size);bufferVoice(v);
    const count=tier===20?5:tier===10?4:3,at=a.currentTime+.002,end=.055*(count-1)+.026+.070;
    const cue={tier,count,duration:end,start:at,latencyMs:performance.now()-pendingComboAt+2,backend:v.backend,hits:[]};
    for(let i=0;i<count;i++){const n=tier-count+1+i,params={index:n,pitch:1.05+.55*(n-1)/19,gain:1.35+1.60*(n-1)/19,brightness:.10+.65*(n-1)/19},time=.055*i;sourceAt(v,combatSamples.hits[n-1],at+time,params.gain*1.5);cue.hits.push({...params,time});}
    const finalGain=cue.hits.at(-1).gain;sourceAt(v,combatSamples.tail,at+.055*(count-1)+.026,finalGain*1.5*.18);
    v.audioEnd=at+end;v.timer=setTimeout(()=>finishVoice(v),(end+.025)*1000);
    comboCues++;comboCueLog.push(cue);if(comboCueLog.length>24)comboCueLog.shift();return true;
  }
  function flushComboCue(){
    comboDebounce=null;const tier=pendingComboTier;if(!tier)return;
    if(playComboCue(tier)){playedComboTier=tier;pendingComboTier=0;lastComboAt=performance.now()/1000;}
    else if(!comboDebounce)pendingComboTier=0;
  }
  RG.playKillFeedback=function(){
    const now=performance.now()/1000;audioKills=audioKills.filter(t=>now-t<1).slice(-19);audioKills.push(now); // 最高档只需保留最近20次，范围清怪不扩大队列。
    if(audioKills.length<5&&now-lastComboAt>=1)playedComboTier=0;
    if(comboQuiet)clearTimeout(comboQuiet);comboQuiet=setTimeout(()=>{audioKills=[];playedComboTier=0;comboQuiet=null;},1001);
    if(!sfxAllowed()||voices.get('focus')?.key==='over')return false;
    const count=audioKills.length,tier=count>=20?20:count>=10?10:count>=5?5:0;
    if(!tier){RG.playSfx('kill',1);return false;}
    if(tier<=Math.max(playedComboTier,pendingComboTier)&&(pendingComboTier||now-lastComboAt<1))return false; // 持续清怪每秒至多重响一次当前档，升档可以立即提示。
    if(!pendingComboTier){pendingComboAt=performance.now();queueMicrotask(flushComboCue);}pendingComboTier=tier;return true;
  };
  if(typeof window.addEventListener==='function')window.addEventListener('blur',()=>RG.stopSfx());
  if(typeof document!=='undefined'&&typeof document.addEventListener==='function')document.addEventListener('visibilitychange',()=>{if(document.hidden)RG.stopSfx();});

  RG.playSfxVar = function (name, base, spread) {
    // 同类音效随机音高:连续攻击不机械(Z-P3 接口,武器手感用)
    RG.playSfx(name, (base || 1) * (1 + (Math.random() * 2 - 1) * (spread === undefined ? 0.06 : spread)));
  };
  RG.duckMusic = function (dur) {
    // BOSS 大招压低背景乐(P3 混音):短促闪避而不是突然换歌(文件曲走 duckUntil,程序化走 duckT)
    MUS.duckT = dur || 1.2;
    duckUntil = performance.now() + (dur || 1.2) * 1000;
  };
  RG.playSfx = function (name, rate, priority, gainMul) {
    if (!SFX_NAMES.includes(name)) return false;
    const v = reserveVoice(name,priority); if (!v) return false;
    if(name==='crit'&&combatSamples&&hasBuffers(ac())&&ac().state!=='suspended'){playCritBuffer(v);return true;}
    if (v.key === "kill") {
      let index = Math.floor(Math.random()*KILL_VARS.length);
      if (index === lastKill) index = (index+1)%KILL_VARS.length;
      lastKill = index;
      v.name = KILL_VARS[index];
    }
    v.gainMul = Math.max(.2,Math.min(1.4,Number.isFinite(gainMul)?gainMul:1));
    v.rate = v.key === "gem" ? 1 : Math.max(v.key === "kill" ? .92 : .65,Math.min(v.key === "kill" ? 1.85 : 1.65,rate || 1));
    const pool = pools[v.name];
    if(sfxBuffers[v.name]&&hasBuffers(ac())&&ac().state!=='suspended'){
      const a=bufferVoice(v),buffer=sfxBuffers[v.name];v.backend='buffer';const duration=buffer.duration/v.rate;
      sourceAt(v,buffer,a.currentTime+.001,1);v.audioEnd=a.currentTime+duration;
      v.timer=setTimeout(()=>finishVoice(v),(duration+.012)*1000);
      if(v.group==='focus')RG.duckMusic(v.key==='boss'?1.2:.45);
      return true;
    }
    const media = pool && pool.find(a=>a._ok === true);
    if (media) {
      v.media = media; v.backend = "file"; media._voice = v;
      refreshSfx(); media.playbackRate = v.rate;
      media.preservesPitch=false;media.mozPreservesPitch=false;media.webkitPreservesPitch=false;
      try {
        media.currentTime = 0;
        // 先占声道再请求播放，同帧洪峰及尚未完成的play()都不会绕过上限。
        media.play().then(()=>{ if (!v.live && media._voice === v) media.pause(); }).catch(()=>playFallback(v));
        v.timer = setTimeout(()=>finishVoice(v),Math.max(.9,(Number.isFinite(media.duration)?media.duration:0)/v.rate+.2)*1000);
      } catch (err) { playFallback(v); }
    } else playFallback(v);
    if (v.group === "focus") RG.duckMusic(v.key === "boss" ? 1.2 : .45);
    return v.live;
  };
  RG.tone = function (freq,dur,type,vol,slide) {
    const v = reserveVoice("tone",2); if (!v) return;
    v.rate=1; v.notes=[[freq,Math.max(.01,Math.min(.5,dur)),slide||0,0,Math.min(.35,(vol||.02)*8),type||"sine"]];
    playFallback(v);
  };
  // ---------- 无文件兜底:重制主题的轻量四声部版本，保留D小调与场景节奏 ----------
  const SCENES = {
    menu: { bpm: 88, intensity: .25 },
    play: { bpm: 132 },
    boss: { bpm: 144, intensity: .85 },
    vault: { bpm: 72, intensity: .3 },
  };
  const MUSIC_ROOTS = [38,34,41,36,38,34,43,33];
  const MUSIC_CHORDS = [[50,57,60,65],[50,53,57,62],[48,53,57,64],[48,55,58,64],[50,57,60,65],[50,53,57,62],[50,55,58,65],[49,55,57,64]];
  const MUSIC_MOTIF = [[74,0,69,77,0,0,76,0],[74,0,0,0,72,0,69,0],[0,72,0,69,65,0,0,0],[67,0,0,72,0,76,0,0],[74,77,0,81,0,0,79,0],[77,0,0,0,74,0,72,0],[70,0,69,0,67,0,0,0],[69,0,0,0,73,0,76,73]];
  const musicHz = note => 440 * Math.pow(2, (note - 69) / 12);
  const MUS = { scene: null, pending: null, next: 0, step: 0, bus: null, comp: null, timer: null, intensity: 0.28 };
  // musicVol 已在上方从存档读取；不要在这里重置，否则设置页每次启动都会失效。
  function musNote(freq, t, dur, type, vol, attack) {
    const a = ac(); if (!a || !freq) return;
    const o = a.createOscillator(), g = a.createGain();
    o.type = type || "sine"; o.frequency.setValueAtTime(freq, t);
    const atk = Math.min(attack === undefined ? 0.012 : attack, dur * 0.3);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, vol), t + atk);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(MUS.bus); o.start(t); o.stop(t + dur + 0.02);
  }
  function musKick(t, vol) {
    const a = ac(); if (!a) return;
    const o = a.createOscillator(), g = a.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(118, t); o.frequency.exponentialRampToValueAtTime(47, t + 0.12);
    g.gain.setValueAtTime(Math.max(0.0001, vol), t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    o.connect(g); g.connect(MUS.bus); o.start(t); o.stop(t + 0.18);
  }
  function musicTarget() {
    if (SCENES[MUS.scene].intensity !== undefined) return SCENES[MUS.scene].intensity;
    const enemies = RG.enemies ? RG.enemies.length : 0;
    const combo = Math.min(50, RG.combo || 0);
    const hp = RG.P && RG.P.maxhp ? RG.P.hp / RG.P.maxhp : 1;
    return Math.max(0.22, Math.min(0.88, 0.25 + Math.min(0.42, enemies / 120) + combo / 250 + (hp < 0.32 ? 0.12 : 0)));
  }
  function ensureMusicBus(a) {
    if (MUS.bus) return;
    MUS.bus = a.createGain(); MUS.bus.gain.value = 0.92;
    if (a.createDynamicsCompressor) {
      MUS.comp = a.createDynamicsCompressor();
      MUS.comp.threshold.value = -20; MUS.comp.knee.value = 18; MUS.comp.ratio.value = 4;
      MUS.comp.attack.value = 0.012; MUS.comp.release.value = 0.28;
      MUS.bus.connect(MUS.comp); MUS.comp.connect(a.destination);
    } else MUS.bus.connect(a.destination);
  }
  function musStep() {
    if (!MUS.scene || MUS.scene === "silent" || RG.muted) return;
    const a = ac(); if (!a) return;
    if (MUS.next < a.currentTime - 0.3) MUS.next = a.currentTime + 0.05;   // 掉队重同步
    while (MUS.next < a.currentTime + 0.14) {
      if (MUS.pending && MUS.step % 8 === 0) { MUS.scene = MUS.pending; MUS.pending = null; }
      const sc = SCENES[MUS.scene], sp8 = 60 / sc.bpm / 2;
      MUS.duckT = Math.max(0, (MUS.duckT || 0) - sp8);
      const kv = MUS.duckT > 0 ? 0.4 : 1;
      const i = MUS.step % 8, bar = Math.floor(MUS.step / 8), tt = MUS.next;
      MUS.intensity += (musicTarget() - MUS.intensity) * 0.12;
      const inten = MUS.intensity;
      // 长音和弦把循环粘合起来；正弦波低音量，不与弹幕音效争抢中高频。
      if (i === 0) {
        MUSIC_CHORDS[bar % 8].forEach((note, n) => musNote(musicHz(note), tt, sp8 * 7.7, "sine", (0.010 - n * 0.0015) * kv, 0.16));
      }
      const sparse = MUS.scene === "menu" || MUS.scene === "vault";
      if (!sparse || i % 4 === 0) musNote(musicHz(MUSIC_ROOTS[bar % 8] + (i === 3 || i === 7 ? 12 : 0)), tt, sp8 * (sparse ? 2.8 : .88), "triangle", (0.026 + inten * 0.018) * kv, 0.018);
      if (i === 0 || (i === 4 && inten > 0.34)) musKick(tt, (0.035 + inten * 0.035) * kv);
      if (inten > 0.50 && i % 2 === 1) musNote(1450 + (i % 4) * 180, tt, 0.028, "triangle", 0.0045 * inten * kv, 0.002);
      // 与文件版共用主题问答，秘境隔小节进入；长局每八小节留出两小节呼吸。
      const note = MUSIC_MOTIF[bar % 8][i];
      if (note && bar % 8 < 6 && (MUS.scene !== "vault" || bar % 2 === 1)) musNote(musicHz(note - 12), tt, sp8 * 1.3, "triangle", (0.012 + inten * 0.009) * kv, 0.018);
      MUS.next += sp8; MUS.step++;
    }
  }
  RG.setMusicScene = function (s) {
    const target = !s ? "menu" : s;   // 菜单/结算 → menu 场景曲(v8.16 四首场景曲)
    if (target === "silent") { RG.stopSfx(); if (MUS.scene !== "silent" || bgmScene || pendingScene) applyScene("silent"); return; }   // 连尚未提交的切换一起取消，保持暂停续播位置。
    if (target !== "menu" && !SCENES[target] && !FILE_BGM[target]) return;
    if (target === pendingScene) return;                                     // 防抖:该目标已在等待
    if ((target === bgmScene && !MUS.scene) || (!bgmScene && target === MUS.scene) ||
        (target === "menu" && RG._musicFallback === "menu-file" && bgm && MUS.scene !== "silent")) {
      // 回到当前曲时取消尚未提交的切换，避免短暂经过BOSS后仍被旧定时器切走。
      if (bgmCommitTimer) { clearTimeout(bgmCommitTimer); bgmCommitTimer = null; }
      pendingScene = null; MUS.pending = null; return;
    }
    // 防抖 0.35s:场景需短暂稳定才真正切歌(结算闪跳/暂停往返不再来回横跳)
    pendingScene = target;
    if (bgmCommitTimer) clearTimeout(bgmCommitTimer);
    bgmCommitTimer = setTimeout(() => { bgmCommitTimer = null; const sc = pendingScene; pendingScene = null; applyScene(sc); }, 350);
  };
  // ---------- 打击感(v7.4):命中三档分层 / 击杀音高递进 / 手机震动 ----------
  RG.hitTier = function (tier, pitch) {
    // 暴击也经过战斗声道；不再在采样之上追加多个裸振荡器。
    RG.playSfx("hit",(pitch||1)*(tier === "crit" ? .78 : tier === "heavy" ? .9 : 1.15),tier === "crit" ? 2 : 1);
  };
  RG.killStreak = 0;
  RG.killPitchReset = function () { RG.killStreak = 0; };
  const vibCd = {};
  RG.vibrate = function (pattern, key, cd) {
    try {
      if (!navigator.vibrate) return;
      const now = performance.now();
      if (key && now - (vibCd[key] || 0) < (cd || 0)) return;
      if (key) vibCd[key] = now;
      navigator.vibrate(pattern);
    } catch (err) {}
  };
  let lastBossRoar = -9999;
  // BOSS 出场只保留一个低吼声源；防重入避免分裂、秘境与主线入口同帧叠放。
  RG.bossRoar = function () {
    if (RG.muted) return;
    const now = performance.now();
    if (now - lastBossRoar < 900) return;
    lastBossRoar = now;
    RG.playSfx("boss", 0.82);
    RG.duckMusic(1.2);   // P3:BOSS 登场压低背景乐
  };
  RG.prepareCombatAudio();
  RG.AUDIO_VER="v12027";
})(window.RG);
