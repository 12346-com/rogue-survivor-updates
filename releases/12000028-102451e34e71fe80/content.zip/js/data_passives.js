// ============ 数据:独立品质档被动卡牌与罪印 ============
// 每张卡只有一份最终定义；属性效果由该定义生成，不再覆盖历史数值。
(function (RG) {
  RG.PASSIVES_VER="v12027";
  // ponytail: 沿用轻量表和函数，不建立通用卡牌引擎。
  function proportional(def,family,field,value) {
    const card={family,value,multipliers:[field]};
    Object.defineProperties(card,Object.getOwnPropertyDescriptors(def));
    card.fx=P=>{const value=card.value;
      if(field==='maxhp'){
        if(P.hpLocked)return;
        const total=RG.passiveValue(P,family),old=P.maxhp;
        P.maxhp=Math.max(1,Math.round(old*(1+total)/(1+total-value)));
        if(!P.healBan&&!P.healBlocked)P.hp=Math.min(P.maxhp,P.hp+P.maxhp-old);
      }else{
        const now=RG.passiveValue(P,family),before=now-value;
        P[field]*=field==='cdMul'?(1+before)/(1+now):Math.max(cfgBALANCECardsFx.field_floor,1+now)/Math.max(cfgBALANCECardsFx.field_floor,1+before);
      }
    };
    return card;
  }
  RG.PASSIVE_FIELDS = ["maxhp", "speed", "regen", "dmgMul", "cdMul", "armor", "evade", "critC", "critD", "freezeC", "shieldMax", "extraShots", "bulletR", "pickup", "coinMul", "xpMul", "elemMul", "rangedMul", "visionMul", "globalCdMul", "dashCdMul", "bloodrush", "interest", "soulSuck", "deflect", "voidstep", "doomChain", "reactionMul", "giantT", "giantStacks", "r"];
  const tierCards={};
  function tiers(id,name,values,rarities,desc,options={}) {
    const suffix=['','_m','_l','_xl'];
    values.forEach((value,i)=>{
      const key=id+suffix[i];tierCards[key]={name:name+'·'+['I','II','III','IV'][i],maxLv:options.maxLv||3,
        rarity:rarities[i],get desc(){return desc(this.value)+(this.descriptionSuffix||'');},family:id,value,icon:options.icon||id,...options};
    });
  }
  // 旧卡中同张随等级改变百分比的效果拆开；重新估算后各档均可重复强化。
  tiers('ember','余烬',[.15,.25,.40],[2,3,4],v=>'命中 '+Math.round(v*100)+("% 概率附加燃烧，持续"+RG.configNumber(RG.PASSIVES.ember.rules.hurtEnemy.hurtEnemy_applyElementOutputArg3)+"秒"),{rules:{
  "hurtEnemy": {
    "hurtEnemy_applyElementOutputArg3": 3,
    "hurtEnemy_factor": 0.2
  }
}});
  for(const [id,bonus]of [['ember',.10],['ember_m',.15],['ember_l',.25]]){
    const d=tierCards[id];d.burnCritBonus=bonus;
    Object.defineProperty(d,'descriptionSuffix',{get:()=> '；燃烧目标常规暴伤+'+Math.round(d.burnCritBonus*100)+'点，同族取最高，锁暴伤无效'});
    d.detail=()=> '命中燃烧率+'+Math.round(d.value*100)+'%/级，'+RG.PASSIVES.ember.rules.hurtEnemy.hurtEnemy_applyElementOutputArg3+'秒\n燃烧目标常规暴伤+'+Math.round(d.burnCritBonus*100)+'点\n品质取最高，锁暴伤无效';
  }
  tiers('ricochet','弹射之刃',[.15,.25,.40],[2,3,4],v=>'击杀 '+Math.round(v*100)+("% 概率向"+RG.configNumber(RG.PASSIVES.ricochet.rules.killEnemy.shots_threshold)+"个敌人弹射；衍生伤害不暴击、不触发命中特效"),{rules:{
  "killEnemy": {
    "range_threshold": 0.5,
    "shots_threshold": 3,
    "range_threshold_2": 300,
    "vx_factor": 520,
    "vy_factor": 520,
    "r": 4,
    "dmg_offset": 15,
    "dmg_cap": 1800,
    "dmg_factor_2": 0.5,
    "life": 0.6
  }
}});
  tiers('petrify','石化凝视',[.06,.10,.15],[2,3,4],v=>'暴击 '+Math.round(v*100)+("% 概率石化，小怪"+RG.configNumber(cfgPASSIVESPetrifyHurtEnemy.hurtEnemy_2)+"秒、首领"+RG.configNumber(cfgPASSIVESPetrifyHurtEnemy.hurtEnemy)+"秒"),{rules:{
  "hurtEnemy": {
    "hurtEnemy": 0.6,
    "hurtEnemy_2": 3
  }
},icon:'crit'});
  tiers('thorns','荆棘反射',[.10,.20,.30],[2,3,4],v=>'护盾抵挡时向附近敌人反弹原始伤害的 '+Math.round(v*100)+'%',{rules:{
  "hurtPlayer": {
    "dv_threshold": 14400
  }
}});
  tiers('stance','磐石姿态',[.15,.25,.40],[2,3,4],v=>("静止"+RG.configNumber(RG.PASSIVES.stance.idleSeconds)+"秒后，伤害 +")+Math.round(v*100)+'%',{idleSeconds:1,});
  tiers('explosive','爆破弹头',[.10,.20,.30],[2,3,4],v=>'命中时范围溅射基础伤害的 '+Math.round(v*100)+'%',{rules:{}});
  tiers('punish','惩罚反击',[.40,.60,.85],[2,3,4],v=>("完美闪避时释放"+RG.configNumber(RG.PASSIVES.punish.rules.perfectDodge.rr)+"范围反击，反击系数 ")+Math.round(v*100)+'%',{rules:{
  "perfectDodge": {
    "rr": 110,
    "pd_offset": 40,
    "pd_factor": 3,
    "pd_factor_2": 0.22
  }
}});
  tiers('executioner','处决者印记',[.10,.15,.20],[2,3,4],v=>("对生命低于"+RG.configNumber((RG.PASSIVES.executioner.threshold*100))+"%的敌人，暴击率 +")+Math.round(v*100)+'%',{threshold:0.3,icon:'crit'});
  tiers('combostorm','连击风暴',[.10,.18],[2,3],v=>("连击达到"+RG.configNumber(RG.PASSIVES.combostorm.minCombo)+"时，攻击频率 +")+Math.round(v*100)+'%',{minCombo:25,icon:'frenzy'});
  tiers('deflect','弹幕偏转',[.08,.12,.22],[2,3,4],v=>Math.round(v*100)+'% 概率完全格挡敌方弹幕',{rules:{
  "hurtPlayer": {
    "iTimer": 0.2
  }
},icon:'barrier'});
  tiers('doom','厄运连锁',[.25,.40],[3,4],v=>'附加元素状态时，'+Math.round(v*100)+'% 概率传播到一个附近敌人',{icon:'harmony'});
  tiers('projectile_guard','弹幕装甲',[.05,.08,.12],[1,2,3],v=>'受到敌方弹幕伤害 -'+Math.round(v*100)+'%',{icon:'shell'});
  tiers('electric_guard','绝缘装甲',[.05,.08,.12],[1,2,3],v=>'受到全部雷电伤害 -'+Math.round(v*100)+'%',{icon:'shell'});
  tiers('melee_power','近程精通',[.06,.09,.14],[1,2,3],v=>'近程武器伤害 +'+Math.round(v*100)+'%',{icon:'power'});
  tiers('element_slow','元素迟滞',[.10,.20,.40],[2,3,4],v=>'元素伤害命中时 '+Math.round(v*100)+(("% 概率使敌人移速降低"+RG.configNumber(((1-RG.PASSIVES.element_slow.slowMul)*100))+"%，持续")+RG.configNumber(RG.PASSIVES.element_slow.duration)+"秒，重复触发刷新"),{slowMul:0.6,duration:3,rules:{},icon:'frost'});
  tiers('luck','幸运',[.03,.05,.08,.13],[1,2,3,5],v=>'怪兽有 '+Math.round(v*100)+'% 概率掉落双倍经验',{rules:{
  "killEnemy": {
    "double": 2
  }
},icon:'seed'});
  RG.PASSIVES = {
    boots_s:proportional({get desc(){return "移动速度 +"+RG.configNumber(RG.PASSIVES.boots_s.value*100)+"%";},"maxLv":3,"name":"疾行之靴·I","rarity":1},"boots","speed",0.08),
    boots_m:proportional({get desc(){return "移动速度 +"+RG.configNumber(RG.PASSIVES.boots_m.value*100)+"%";},"maxLv":2,"name":"疾行之靴·II","rarity":3},"boots","speed",0.15),
    hp_s:proportional({get desc(){return "生命上限 +"+RG.configNumber(RG.PASSIVES.hp_s.value*100)+"%,并回复新增生命";},"icon":"seed","maxLv":4,"name":"生命之种·I","rarity":1},"hp","maxhp",0.1),
    hp_m:proportional({get desc(){return "生命上限 +"+RG.configNumber(RG.PASSIVES.hp_m.value*100)+"%,并回复新增生命";},"icon":"seed","maxLv":2,"name":"生命之种·II","rarity":3},"hp","maxhp",0.15),
    hp_l:proportional({get desc(){return "生命上限 +"+RG.configNumber(RG.PASSIVES.hp_l.value*100)+"%,并回复新增生命";},"icon":"seed","maxLv":3,"name":"生命之种·III","rarity":4},"hp","maxhp",0.25),
    regen:{rules:{
  "fx": {
    "regen": 0.6
  }
},get desc(){return "每秒回复 +"+RG.configNumber(cfgPASSIVESRegenFx.regen)+" 生命";},"maxLv":5,"name":"再生之核","rarity":1,fx:P => { P.regen += cfgPASSIVESRegenFx.regen; }},
    pact:{rules:{
  "fx": {
    "maxhp_offset": 12,
    "dmgMul_factor": 0.13
  }
},get desc(){return "生命上限 -"+RG.configNumber(cfgPASSIVESPactFx.maxhp_offset)+",伤害 +"+RG.configNumber(cfgPASSIVESPactFx.dmgMul_factor*100)+"% (高风险高回报)";},"maxLv":5,"multipliers":["dmgMul"],"name":"血猎契约","rarity":2,fx:P=>{const n=P.passives.pact||1;P.maxhp=Math.max(1,P.maxhp-cfgPASSIVESPactFx.maxhp_offset);P.hp=Math.min(P.hp,P.maxhp);P.dmgMul*=(1+cfgPASSIVESPactFx.dmgMul_factor*n)/(1+cfgPASSIVESPactFx.dmgMul_factor*(n-1));}},
    shell:{rules:{
  "fx": {
    "armor_cap": 0.6,
    "armor_offset": 0.08
  }
},get desc(){return "受到伤害 -"+RG.configNumber(cfgPASSIVESShellFx.armor_offset*100)+"%";},"maxLv":5,"name":"铁壳护甲","rarity":1,fx:P => { P.armor = Math.min(cfgPASSIVESShellFx.armor_cap, P.armor + cfgPASSIVESShellFx.armor_offset); }},
    shieldcore:{rules:{
  "fx": {
    "shieldMax": 2,
    "shield_offset": 2
  }
},get desc(){return "获得护盾 +"+RG.configNumber(cfgPASSIVESShieldcoreFx.shieldMax)+" 层,脱战后缓慢回复";},"maxLv":5,"name":"护盾核心","rarity":3,fx:P => { P.shieldMax += cfgPASSIVESShieldcoreFx.shieldMax; P.shield = Math.min(P.shieldMax, P.shield + cfgPASSIVESShieldcoreFx.shield_offset); }},
    evade:{rules:{
  "fx": {
    "evade_cap": 0.65,
    "evade_offset": 0.08
  }
},get desc(){return RG.configNumber(cfgPASSIVESEvadeFx.evade_offset*100)+"% 几率完全闪避一次伤害；真正闪避后"+RG.configNumber(RG.PASSIVES.evade.dodgeDuration)+"秒行走+"+RG.configNumber(RG.PASSIVES.evade.dodgeSpeed*100)+"%，冲刺不加速";},maxLv:5,name:'疾影步',rarity:2,dodgeSpeed:.10,dodgeDuration:2,
      detail:()=> ("每级"+RG.configNumber(cfgPASSIVESEvadeFx.evade_offset*100)+"%概率完全闪避\n真闪避后"+RG.configNumber(RG.PASSIVES.evade.dodgeDuration)+"秒行走+"+RG.configNumber(RG.PASSIVES.evade.dodgeSpeed*100)+"%\n刷新不叠，冲刺不加速"),fx:P => { P.evade = Math.min(cfgPASSIVESEvadeFx.evade_cap, P.evade + cfgPASSIVESEvadeFx.evade_offset); }},
    power_s:proportional({get desc(){return "所有伤害 +"+RG.configNumber(RG.PASSIVES.power_s.value*100)+"%";},"icon":"power","maxLv":4,"name":"蛮力图腾·I","rarity":1},"power","dmgMul",0.08),
    power_m:proportional({get desc(){return "所有伤害 +"+RG.configNumber(RG.PASSIVES.power_m.value*100)+"%";},"icon":"power","maxLv":2,"name":"蛮力图腾·II","rarity":3},"power","dmgMul",0.15),
    power_l:proportional({get desc(){return "所有伤害 +"+RG.configNumber(RG.PASSIVES.power_l.value*100)+"%";},"icon":"power","maxLv":3,"name":"蛮力图腾·III","rarity":4},"power","dmgMul",0.2),
    frenzy:proportional({get desc(){return "攻击频率 +"+RG.configNumber(RG.PASSIVES.frenzy.value*100)+"%";},"maxLv":5,"name":"狂热节拍","rarity":2},"frenzy","cdMul",0.12),
    crit_s:{rules:{
  "fx": {
    "critC": 0.03
  }
},get desc(){return "暴击率 +"+RG.configNumber(cfgPASSIVESCrit_sFx.critC*100)+"%";},"maxLv":4,"name":"致命一击·I","rarity":1,fx:P=>{P.critC+=cfgPASSIVESCrit_sFx.critC;}},
    crit_m:{rules:{
  "fx": {
    "critC": 0.06
  }
},get desc(){return "暴击率 +"+RG.configNumber(cfgPASSIVESCrit_mFx.critC*100)+"%";},"maxLv":3,"name":"致命一击·II","rarity":2,fx:P=>{P.critC+=cfgPASSIVESCrit_mFx.critC;}},
    crit_l:{rules:{
  "fx": {
    "critC": 0.1
  }
},get desc(){return "暴击率 +"+RG.configNumber(cfgPASSIVESCrit_lFx.critC*100)+"%";},"maxLv":3,"name":"致命一击·III","rarity":3,fx:P=>{P.critC+=cfgPASSIVESCrit_lFx.critC;}},
    critd_s:{rules:{
  "fx": {
    "critD": 0.15
  }
},get desc(){return "暴击伤害 +"+RG.configNumber(cfgPASSIVESCritd_sFx.critD*100)+"%";},"maxLv":3,"name":"斩首艺术·I","rarity":2,fx:P => { P.critD += cfgPASSIVESCritd_sFx.critD; }},
    critd_m:{rules:{
  "fx": {
    "critD": 0.3
  }
},get desc(){return "暴击伤害 +"+RG.configNumber(cfgPASSIVESCritd_mFx.critD*100)+"%";},"maxLv":2,"name":"斩首艺术·II","rarity":3,fx:P => { P.critD += cfgPASSIVESCritd_mFx.critD; }},
    critd_l:{rules:{
  "fx": {
    "critD": 0.5
  }
},get desc(){return "暴击伤害 +"+RG.configNumber(cfgPASSIVESCritd_lFx.critD*100)+"%";},"maxLv":3,"name":"斩首艺术·III","rarity":4,fx:P => { P.critD += cfgPASSIVESCritd_lFx.critD; }},
    split_m:{shots:1,get desc(){return "方向类武器 弹数 +"+RG.configNumber(RG.PASSIVES.split_m.shots)+"（魔弹、追踪飞弹、霰弹、回旋镖）";},"maxLv":2,"name":"分裂弹匣·II","rarity":4,fx:P => { P.extraShots += RG.PASSIVES.split_m.shots; }},
    split_l:{rules:{
  "fx": {
    "extraShots": 2
  }
},get desc(){return "方向类武器 弹数 +"+RG.configNumber(cfgPASSIVESSplit_lFx.extraShots)+"（魔弹、追踪飞弹、霰弹、回旋镖）";},"maxLv":3,"name":"分裂弹匣·III","rarity":5,fx:P => { P.extraShots += cfgPASSIVESSplit_lFx.extraShots; }},
    magnet:proportional({get desc(){return "经验拾取范围 +"+RG.configNumber(RG.PASSIVES.magnet.value*100)+"%";},"maxLv":5,"name":"引力磁石","rarity":1},"magnet","pickup",0.35),
    bigshot:{rules:{
  "fx": {
    "bulletR_factor": 0.35,
    "dmgMul_factor": 0.08
  }
},get desc(){return "弹体尺寸 +"+RG.configNumber(cfgPASSIVESBigshotFx.bulletR_factor*100)+"%,伤害 +"+RG.configNumber(cfgPASSIVESBigshotFx.dmgMul_factor*100)+"%";},"family":"bigshot","maxLv":3,"multipliers":["bulletR","dmgMul"],"name":"巨型弹体","rarity":1,"value":0.35,fx:P=>{const n=P.passives.bigshot||1;P.bulletR*=(1+cfgPASSIVESBigshotFx.bulletR_factor*n)/(1+cfgPASSIVESBigshotFx.bulletR_factor*(n-1));P.dmgMul*=(1+cfgPASSIVESBigshotFx.dmgMul_factor*n)/(1+cfgPASSIVESBigshotFx.dmgMul_factor*(n-1));}},
    frost:{rules:{
  "fx": {
    "freezeC_cap": 0.4,
    "freezeC_offset": 0.08
  }
},get desc(){return "命中 "+RG.configNumber(cfgPASSIVESFrostFx.freezeC_offset*100)+"% 几率冻结敌人";},"maxLv":5,"name":"冰霜之触","rarity":2,fx:P => { P.freezeC = Math.min(cfgPASSIVESFrostFx.freezeC_cap, P.freezeC + cfgPASSIVESFrostFx.freezeC_offset); }},
    scout:proportional({get desc(){return "远程武器索敌距离 +"+RG.configNumber(RG.PASSIVES.scout.value*100)+"%";},"icon":"magnet","maxLv":3,"name":"鹰眼视野","rarity":1},"scout","visionMul",0.1),
    elem_s:proportional({get desc(){return "元素伤害 +"+RG.configNumber(RG.PASSIVES.elem_s.value*100)+"%";},"icon":"harmony","maxLv":3,"name":"元素增幅·I","rarity":2},"elem","elemMul",0.1),
    elem_m:proportional({get desc(){return "元素伤害 +"+RG.configNumber(RG.PASSIVES.elem_m.value*100)+"%";},"icon":"harmony","maxLv":3,"name":"元素增幅·II","rarity":3},"elem","elemMul",0.2),
    ranged:proportional({get desc(){return "远程武器伤害 +"+RG.configNumber(RG.PASSIVES.ranged.value*100)+"%";},"icon":"power","maxLv":3,"name":"远射校准","rarity":2},"ranged","rangedMul",0.1),
    dashcd_s:proportional({get desc(){return "冲刺冷却 -"+RG.configNumber(-RG.PASSIVES.dashcd_s.value*100)+("%，累计最多减少"+RG.configNumber(((1-RG.BALANCE.cards.fx.field_floor)*100))+"%");},"icon":"boots","maxLv":2,"name":"闪避回路·I","rarity":2},"dashcd","dashCdMul",-0.1),
    dashcd_m:proportional({get desc(){return "冲刺冷却 -"+RG.configNumber(-RG.PASSIVES.dashcd_m.value*100)+("%，累计最多减少"+RG.configNumber(((1-RG.BALANCE.cards.fx.field_floor)*100))+"%");},"icon":"boots","maxLv":3,"name":"闪避回路·II","rarity":5},"dashcd","dashCdMul",-0.2),
    globalcd:proportional({rules:{},get desc(){return "武器、主动与自动卡冷却 -"+RG.configNumber(-RG.PASSIVES.globalcd.value*100)+"%";},"icon":"frenzy","maxLv":3,"name":"时序压缩","rarity":3},"globalcd","globalCdMul",-0.05),
    xp_s:proportional({get desc(){return "经验获取 +"+RG.configNumber(RG.PASSIVES.xp_s.value*100)+"%";},"icon":"magnet","maxLv":3,"name":"经验解析·I","rarity":1},"xp","xpMul",0.05),
    xp_m:proportional({get desc(){return "经验获取 +"+RG.configNumber(RG.PASSIVES.xp_m.value*100)+"%";},"icon":"magnet","maxLv":2,"name":"经验解析·II","rarity":3},"xp","xpMul",0.1),
    xp_l:proportional({get desc(){return "经验获取 +"+RG.configNumber(RG.PASSIVES.xp_l.value*100)+"%";},"icon":"magnet","maxLv":3,"name":"经验解析·III","rarity":4},"xp","xpMul",0.15),
    xpwind:{rules:{
  "update": {
    "update_refreshStatusArg3": 2
  }
},name:'经验疾风',rarity:1,maxLv:3,icon:'boots',mainOnly:true,values:[0,.04,.08,.12],
      get desc(){return "拾取正经验晶石后"+RG.configNumber(RG.PASSIVES.xpwind.rules.update.update_refreshStatusArg3)+"秒行走移速+"+RG.configNumber(RG.PASSIVES.xpwind.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.xpwind.values[2]*100)+"%/"+RG.configNumber(RG.PASSIVES.xpwind.values[3]*100)+"%，刷新；不放大冲刺";},
      detail:lv=>("拾取经验晶石后"+RG.configNumber(cfgPASSIVESXpwindUpdate.update_refreshStatusArg3)+"秒\n行走移速 +")+RG.PASSIVES.xpwind.values.map(v=>RG.configNumber(v*100))[lv]+'%，刷新不叠加\n不放大冲刺；主线卡'},
    leveldash:{rules:{
  "gainXP": {
    "gainXP_refreshStatusArg3": 8
  }
},name:'升级冲刺',rarity:1,maxLv:3,icon:'frenzy',mainOnly:true,values:[0,.10,.15,.20],
      get desc(){return "持有后实际升级，"+RG.configNumber(RG.PASSIVES.leveldash.rules.gainXP.gainXP_refreshStatusArg3)+"秒攻击频率+"+RG.configNumber(RG.PASSIVES.leveldash.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.leveldash.values[2]*100)+"%/"+RG.configNumber(RG.PASSIVES.leveldash.values[3]*100)+"%；补给选牌不触发";},
      detail:lv=>("持有后实际升级，"+RG.configNumber(cfgPASSIVESLeveldashGainXP.gainXP_refreshStatusArg3)+"秒\n攻击频率 +")+RG.PASSIVES.leveldash.values.map(v=>RG.configNumber(v*100))[lv]+'%，刷新不叠加\n补给选牌不触发；主线卡'},
    openingstrike:{rules:{},name:'先发制人',rarity:1,maxLv:3,icon:'power',values:[0,.10,.20,.30],
      get desc(){return "常规攻击满血目标时伤害+"+RG.configNumber(RG.PASSIVES.openingstrike.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.openingstrike.values[2]*100)+"%/"+RG.configNumber(RG.PASSIVES.openingstrike.values[3]*100)+"%；不加成独立主动/元素/衍生伤害";},
      detail:lv=>'常规攻击满血目标时伤 +'+RG.PASSIVES.openingstrike.values.map(v=>RG.configNumber(v*100))[lv]+'%\n附魔继承本次命中基准\n独立主动、元素、衍生不加成'},
    meteor:{rules:{
  "updateAutoCards": {
    "meteor": 0.5,
    "visible_factor": 0.55,
    "length_threshold": 3,
    "autoReset_autoResetArg3": 10
  }
},get desc(){return "每 "+RG.configNumber(RG.AUTO_CARD_CDS.meteor)+" 秒预警后轰击敌群,伤害随级提升";},"icon":"explosive","maxLv":3,"name":"天坠陨星","rarity":4},
    poisontrail:{rules:{
  "updateAutoCards": {
    "length_threshold_2": 8,
    "r_offset": 62,
    "r_factor": 10,
    "t": 2,
    "dmg_offset": 12,
    "dmg_factor": 7,
    "dmg_factor_2": 0.16,
    "poisonLv_threshold": 2,
    "value": 5.8
  }
},get desc(){return "移动时每 "+RG.configNumber(RG.AUTO_CARD_CDS.poisontrail)+"/"+RG.configNumber(RG.PASSIVES.poisontrail.rules.updateAutoCards.value)+" 秒留下 "+RG.configNumber(RG.PASSIVES.poisontrail.rules.updateAutoCards.t)+" 秒毒迹";},"icon":"ash","maxLv":2,"name":"淬毒足迹","rarity":3},
    spores:{rules:{
  "killEnemy": {
    "length_threshold": 8,
    "t": 2,
    "tick": 0.4,
    "dmg_cap": 1800,
    "dmg_factor": 0.16
  }
},name:"毒爆孢子",rarity:2,maxLv:3,icon:"ash",radius:[0,60,75,90],damage:[0,14,18,22],
      get desc(){return "中毒敌人死亡留下"+RG.configNumber(RG.PASSIVES.spores.rules.killEnemy.t)+"秒毒雾，半径"+RG.configNumber(RG.PASSIVES.spores.radius[1])+"/"+RG.configNumber(RG.PASSIVES.spores.radius[2])+"/"+RG.configNumber(RG.PASSIVES.spores.radius[3])+"；每"+RG.configNumber(RG.PASSIVES.spores.rules.killEnemy.tick)+"秒基础毒伤"+RG.configNumber(RG.PASSIVES.spores.damage[1])+"/"+RG.configNumber(RG.PASSIVES.spores.damage[2])+"/"+RG.configNumber(RG.PASSIVES.spores.damage[3])+"，最多"+RG.configNumber(RG.PASSIVES.spores.rules.killEnemy.length_threshold)+"片。毒雾施毒不再生雾";},
      detail:lv=>("中毒死亡留"+RG.configNumber(cfgPASSIVESSporesKillEnemy.t)+"秒毒雾，范围")+[0,RG.PASSIVES.spores.radius["1"],RG.PASSIVES.spores.radius[(2)],RG.PASSIVES.spores.radius["3"]][lv]+("\n每"+RG.configNumber(cfgPASSIVESSporesKillEnemy.tick)+"秒基础毒伤")+[0,RG.PASSIVES.spores.damage["1"],RG.PASSIVES.spores.damage[(2)],RG.PASSIVES.spores.damage["3"]][lv]+("，随时间成长\n最多"+RG.configNumber(cfgPASSIVESSporesKillEnemy.length_threshold)+"片；毒雾施毒不再生雾")},
    earthbalance:{rules:{
  "applyElem": {
    "applyElem_refreshStatusArg3": 3
  }
},name:"地脉失衡",rarity:2,maxLv:3,icon:"crit",values:[0,.12,.18,.25],
      get desc(){return "大地元素命中使目标失衡"+RG.configNumber(RG.PASSIVES.earthbalance.rules.applyElem.applyElem_refreshStatusArg3)+"秒，受到的暴击伤害+"+RG.configNumber(RG.PASSIVES.earthbalance.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.earthbalance.values[2]*100)+"%/"+RG.configNumber(RG.PASSIVES.earthbalance.values[3]*100)+"%，刷新不叠加";},
      detail:lv=>("大地命中使目标失衡"+RG.configNumber(cfgPASSIVESEarthbalanceApplyElem.applyElem_refreshStatusArg3)+"秒\n受暴击伤害 +")+RG.PASSIVES.earthbalance.values.map(v=>RG.configNumber(v*100))[lv]+"%，刷新不叠加"},
    aftershock:{rules:{
  "elemReaction": {
    "elemReaction_refreshStatusArg3": 3
  }
},name:"反应余波",rarity:3,maxLv:3,icon:"harmony",values:[0,.06,.09,.12],
      get desc(){return "有效元素反应后"+RG.configNumber(RG.PASSIVES.aftershock.rules.elemReaction.elemReaction_refreshStatusArg3)+"秒攻击频率+"+RG.configNumber(RG.PASSIVES.aftershock.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.aftershock.values[2]*100)+"%/"+RG.configNumber(RG.PASSIVES.aftershock.values[3]*100)+"%，再次触发刷新，不叠加";},
      detail:lv=>("有效元素反应后"+RG.configNumber(cfgPASSIVESAftershockElemReaction.elemReaction_refreshStatusArg3)+"秒\n攻击频率 +")+RG.PASSIVES.aftershock.values.map(v=>RG.configNumber(v*100))[lv]+"%，刷新不叠加"},
    chargecircuit:{rules:{
  "useActive": {
    "useActive_refreshStatusArg3": 3
  }
},name:"充能回路",rarity:3,maxLv:3,icon:"frenzy",values:[0,.08,.12,.16],
      get desc(){return "成功手动释放主动技后"+RG.configNumber(RG.PASSIVES.chargecircuit.rules.useActive.useActive_refreshStatusArg3)+"秒攻击频率+"+RG.configNumber(RG.PASSIVES.chargecircuit.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.chargecircuit.values[2]*100)+"%/"+RG.configNumber(RG.PASSIVES.chargecircuit.values[3]*100)+"%，刷新不叠加";},
      detail:lv=>("成功手动释放主动后"+RG.configNumber(cfgPASSIVESChargecircuitUseActive.useActive_refreshStatusArg3)+"秒\n攻击频率 +")+RG.PASSIVES.chargecircuit.values.map(v=>RG.configNumber(v*100))[lv]+"%，刷新不叠加"},
    reactionchain:{rules:{
  "applyElem": {
    "best_factor": 160
  }
},name:'反应连锁',rarity:4,maxLv:2,icon:'harmony',values:[0,.25,.40],range:250,
      get desc(){return "有效元素反应有"+RG.configNumber(RG.PASSIVES.reactionchain.values[1]*100)+"%/"+RG.configNumber(RG.PASSIVES.reactionchain.values[2]*100)+"%概率向附近最近敌人复制一次；遵守反应冷却，不递归";},
      detail:lv=>'有效反应 '+RG.PASSIVES.reactionchain.values.map(v=>RG.configNumber(v*100))[lv]+("%概率复制一次\n"+RG.configNumber(RG.PASSIVES.reactionchain.range)+"基础范围最近可反应敌人\n同种效果；守冷却，无再次连锁")},
    elementunity:{rules:{
  "elementUnityBonus": {
    "range_threshold": 3
  }
},name:'万象归一',rarity:5,maxLv:1,icon:'harmony',perType:.12,maxTypes:4,rangeBonus:.30,
      get desc(){return "每种不同实际武器附魔，元素伤害+"+RG.configNumber(RG.PASSIVES.elementunity.perType*100)+(("%，最多"+RG.configChinese(RG.PASSIVES.elementunity.maxTypes,"四",4)+"种")+RG.configNumber(((RG.PASSIVES.elementunity.perType*RG.PASSIVES.elementunity.maxTypes)*100))+("%；"+RG.configChinese(cfgPASSIVESElementunityElementUnityBonus.range_threshold,"三",3)+"种起反应范围+"))+RG.configNumber(RG.PASSIVES.elementunity.rangeBonus*100)+"%";},
      detail:()=> ("每种不同武器附魔，元伤+"+RG.configNumber(RG.PASSIVES.elementunity.perType*100)+(("%\n最多"+RG.configChinese(RG.PASSIVES.elementunity.maxTypes,"四",4)+"种")+RG.configNumber(((RG.PASSIVES.elementunity.perType*RG.PASSIVES.elementunity.maxTypes)*100))+("%；同元素不重复\n"+RG.configChinese(cfgPASSIVESElementunityElementUnityBonus.range_threshold,"三",3)+"种起反应范围+"))+RG.configNumber(RG.PASSIVES.elementunity.rangeBonus*100)+"%")},
    weakmark:{rules:{},name:'弱点标记',rarity:2,maxLv:3,icon:'crit',hits:[0,5,4,3],cooldown:5,
      get desc(){return "每目标累计"+RG.configNumber(RG.PASSIVES.weakmark.hits[1])+"/"+RG.configNumber(RG.PASSIVES.weakmark.hits[2])+"/"+RG.configNumber(RG.PASSIVES.weakmark.hits[3])+"次常规命中，下击暴率提高至上限；同目标冷却"+RG.configNumber(RG.PASSIVES.weakmark.cooldown)+"秒，免暴优先";},
      detail:lv=>'每目标累计'+RG.PASSIVES.weakmark.hits[lv]+("次常规命中\n下击暴率升至上限，冷却"+RG.configNumber(RG.PASSIVES.weakmark.cooldown)+"秒\n免暴/零上限优先，派生不计")},
    critstreak:{rules:{},name:'连锁暴击',rarity:3,maxLv:3,icon:'critd',values:[0,.06,.10,.14],maxStacks:5,
      get desc(){return "真实常规暴击积层，后续暴伤每层+"+RG.configNumber(RG.PASSIVES.critstreak.values[1]*100)+"/"+RG.configNumber(RG.PASSIVES.critstreak.values[2]*100)+"/"+RG.configNumber(RG.PASSIVES.critstreak.values[3]*100)+"点，最多"+RG.configChinese(RG.PASSIVES.critstreak.maxStacks,"五",5)+"层；未暴常规命中清零";},
      detail:lv=>'常规真暴击积层\n后续每层暴伤+'+RG.PASSIVES.critstreak.values.map(v=>RG.configNumber(v*100))[lv]+("点，至多"+RG.configNumber(RG.PASSIVES.critstreak.maxStacks)+"层\n未暴清零；锁暴伤无效")},
    causality:{name:'因果律',rarity:5,maxLv:1,icon:'frenzy',reduction:.2,resonanceReduction:.3,cooldown:1,
      get desc(){return "真实常规暴击使已装备主动冷却-"+RG.configNumber(RG.PASSIVES.causality.reduction)+("秒，"+RG.configChinese(RG.RESONANCE_RULES.second,"五",5)+"件暴击共鸣-")+RG.configNumber(RG.PASSIVES.causality.resonanceReduction)+"秒；每秒一次，不缩短忙碌/代价";},
      detail:()=> ("常规真暴击减两槽冷却\n每秒一次-"+RG.configNumber(RG.PASSIVES.causality.reduction)+("秒，暴击"+RG.configNumber(RG.RESONANCE_RULES.second)+"件-")+RG.configNumber(RG.PASSIVES.causality.resonanceReduction)+"秒\n不缩短忙碌/代价")},
    bloodheal:{rules:{},name:'浴血续命',rarity:3,maxLv:3,icon:'heal',heals:[0,2,3,4],threshold:.30,
      get desc(){return "生命低于"+RG.configNumber(RG.PASSIVES.bloodheal.threshold*100)+"%时，有效击杀回复"+RG.configNumber(RG.PASSIVES.bloodheal.heals[1])+"/"+RG.configNumber(RG.PASSIVES.bloodheal.heals[2])+"/"+RG.configNumber(RG.PASSIVES.bloodheal.heals[3])+"生命；禁疗/生命锁无效，镜像/残影/虫洞不计";},
      detail:lv=>("生命低于"+RG.configNumber(RG.PASSIVES.bloodheal.threshold*100)+"%时\n有效击杀回复")+RG.PASSIVES.bloodheal.heals[lv]+'生命\n禁疗/生命锁无效，虚影不计'},
    pain:{rules:{},name:'痛觉',rarity:4,maxLv:2,icon:'berserk',values:[0,.25,.40],duration:2,
      get desc(){return "受伤真实扣血后"+RG.configChinese(RG.PASSIVES.pain.duration,"两",2)+"秒内攻击频率+"+RG.configNumber(RG.PASSIVES.pain.values[1]*100)+"/"+RG.configNumber(RG.PASSIVES.pain.values[2]*100)+"%，刷新不叠；抵挡/免疫/献祭不触发";},
      detail:lv=>("受伤真实扣血后"+RG.configNumber(RG.PASSIVES.pain.duration)+"秒\n攻击频率+")+RG.PASSIVES.pain.values.map(v=>RG.configNumber(v*100))[lv]+'%，刷新不叠\n抵挡/免疫/献祭不触发'},
    bloodline:{name:'血线上浮',rarity:5,maxLv:1,icon:'heart',increase:.10,cap:.80,
      get desc(){return "玩家离散残血门槛提高"+RG.configNumber(this.increase*100)+"点，上限"+RG.configNumber(this.cap*100)+"%；血怒"+RG.configNumber(Math.min(RG.PASSIVES.bloodline.cap,RG.PASSIVES.bloodrush.threshold+RG.PASSIVES.bloodline.increase)*100)+"%、"+bloodlinePair()+"、金钟"+RG.configNumber(Math.min(RG.PASSIVES.bloodline.cap,RG.PASSIVES.goldbell.rules.hurtPlayer.hurtPlayer_lowHpThresholdArg1+RG.PASSIVES.bloodline.increase)*100)+"%；不改敌人处决或连续缺血增伤";},
      detail:()=> "血怒"+RG.configNumber(Math.min(RG.PASSIVES.bloodline.cap,RG.PASSIVES.bloodrush.threshold+RG.PASSIVES.bloodline.increase)*100)+"%，"+bloodlinePair()+"\n金钟"+RG.configNumber(Math.min(RG.PASSIVES.bloodline.cap,RG.PASSIVES.goldbell.rules.hurtPlayer.hurtPlayer_lowHpThresholdArg1+RG.PASSIVES.bloodline.increase)*100)+"%；仅自身残血门槛\n上限"+RG.configNumber(RG.PASSIVES.bloodline.cap*100)+"%；处决/缺血曲线不变"},
    rally:{capacityLevel:3,capacityBonus:1,rules:{},name:'召集令',rarity:3,maxLv:3,icon:'phantom',durationPerLevel:.20,
      get desc(){return "新召有限寿命单位持续时间+"+RG.configNumber(RG.PASSIVES.rally.durationPerLevel*100)+"/"+RG.configNumber(RG.PASSIVES.rally.durationPerLevel*2*100)+"/"+RG.configNumber(RG.PASSIVES.rally.durationPerLevel*3*100)+"%；三级各类容量+"+RG.configNumber(RG.PASSIVES.rally.capacityBonus)+"，永久仆人/炮台只扩容";},
      detail:lv=>'新召有限寿命+'+[0,(RG.configNumber(RG.PASSIVES.rally.durationPerLevel*1*100)),(RG.configNumber(RG.PASSIVES.rally.durationPerLevel*2*100)),(RG.configNumber(RG.PASSIVES.rally.durationPerLevel*3*100))][lv]+("%\n三级各类容量+"+RG.configNumber(RG.PASSIVES.rally.capacityBonus)+"\n永久仆人/炮台不加寿命")},
    legion:{rules:{},name:'军团号令',rarity:4,maxLv:3,icon:'loyal',perAlly:.03,caps:[0,.09,.12,.15],
      get desc(){return "每个真实存活召唤单位，自身可增伤输出/召唤伤害+"+RG.configNumber(RG.PASSIVES.legion.perAlly*100)+"%，最多"+RG.configNumber(RG.PASSIVES.legion.caps[1]*100)+"/"+RG.configNumber(RG.PASSIVES.legion.caps[2]*100)+"/"+RG.configNumber(RG.PASSIVES.legion.caps[3]*100)+"%；固定反伤不变";},
      detail:lv=>("存活召唤每个增伤+"+RG.configNumber(RG.PASSIVES.legion.perAlly*100)+"%\n自身/召唤至多")+RG.PASSIVES.legion.caps.map(v=>RG.configNumber(v*100))[lv]+'%\n固定反伤不变'},
    dashecho:{rules:{},name:'冲刺回响',rarity:2,maxLv:3,icon:'echo',values:[0,.20,.30,.40],duration:2,
      get desc(){return "实际冲刺结束后"+RG.configChinese(RG.PASSIVES.dashecho.duration,"两",2)+"秒内，下一次有效常规命中伤害+"+RG.configNumber(RG.PASSIVES.dashecho.values[1]*100)+"/"+RG.configNumber(RG.PASSIVES.dashecho.values[2]*100)+"/"+RG.configNumber(RG.PASSIVES.dashecho.values[3]*100)+"%；空挥/免疫不消耗";},
      detail:lv=>("实际冲刺结束后"+RG.configNumber(RG.PASSIVES.dashecho.duration)+"秒内\n下次常规有效命中+")+Math.round(RG.configNumber(RG.PASSIVES.dashecho.values[lv]*100))+'%\n一次领取，空挥/免疫不耗'},
    windwalker:{rules:{},name:'风行者',rarity:3,maxLv:3,icon:'boots',values:[0,.02,.03,.04],maxStacks:5,
      get desc(){return "实际连续移动每秒一层，每层伤害+"+RG.configNumber(RG.PASSIVES.windwalker.values[1]*100)+"/"+RG.configNumber(RG.PASSIVES.windwalker.values[2]*100)+"/"+RG.configNumber(RG.PASSIVES.windwalker.values[3]*100)+"%，最多"+RG.configChinese(RG.PASSIVES.windwalker.maxStacks,"五",5)+"层；静止或传送清零";},
      detail:lv=>'实际连续移动每秒一层\n每层伤害+'+Math.round(RG.configNumber(RG.PASSIVES.windwalker.values[lv]*100))+("%，至多"+RG.configNumber(RG.PASSIVES.windwalker.maxStacks)+"层\n静止或传送清零")},
    mountain:{rules:{},name:'不动如山',rarity:4,maxLv:2,icon:'stance',recovery:[0,.5,1],reflection:.5,
      get desc(){return "实际静止时普通护盾恢复速度+"+RG.configNumber(RG.PASSIVES.mountain.recovery[1]*100)+"/"+RG.configNumber(RG.PASSIVES.mountain.recovery[2]*100)+"%；荆棘和反甲的实际反伤+"+RG.configNumber(RG.PASSIVES.mountain.reflection*100)+"%，需原盾/反伤源";},
      detail:lv=>'实际静止时普通回盾+'+Math.round(RG.PASSIVES.mountain.recovery[lv]*100)+'%\n荆棘/反甲实际反伤+'+RG.configNumber(RG.PASSIVES.mountain.reflection*100)+'%\n需原盾或反伤源，冲刺无效'},
    fullshield:{rules:{},name:'充盈壁垒',rarity:3,maxLv:3,icon:'shieldcore',values:[0,.06,.10,.14],
      get desc(){return "有普通护盾上限且全部恢复时，伤害+"+RG.configNumber(RG.PASSIVES.fullshield.values[1]*100)+"/"+RG.configNumber(RG.PASSIVES.fullshield.values[2]*100)+"/"+RG.configNumber(RG.PASSIVES.fullshield.values[3]*100)+"%；相位格挡不算普通盾";},
      detail:lv=>'普通盾全满时增伤+'+Math.round(RG.configNumber(RG.PASSIVES.fullshield.values[lv]*100))+'%\n需盾上限，相位不计'},
    shieldcounter:{rules:{},name:'壁垒反击',rarity:4,maxLv:2,icon:'ricochet',values:[0,.20,.35],duration:3,
      get desc(){return "普通护盾实际挡伤后，三秒内下一次有效常规命中伤害+"+RG.configNumber(RG.PASSIVES.shieldcounter.values[1]*100)+"/"+RG.configNumber(RG.PASSIVES.shieldcounter.values[2]*100)+"%；一次领取，刷新不叠";},
      detail:lv=>("普通盾实际挡伤后"+RG.configNumber(RG.PASSIVES.shieldcounter.duration)+"秒内\n下次常规有效命中+")+Math.round(RG.configNumber(RG.PASSIVES.shieldcounter.values[lv]*100))+'%\n一次领取，刷新不叠'},
    goldbell:{rules:{
  "hurtPlayer": {
    "hurtPlayer_lowHpThresholdArg1": 0.35,
    "goldbell_factor": 60,
    "iTimer": 5
  }
},get desc(){return "濒危受击时无敌 "+RG.configNumber(cfgPASSIVESGoldbellHurtPlayer.iTimer)+" 秒,冷却 "+RG.configNumber(cfgPASSIVESGoldbellHurtPlayer.goldbell_factor)+" 秒";},"icon":"shieldcore","maxLv":1,"name":"金钟罩","rarity":5},
    ecosystem:{rules:{
  "updateAutoCards": {
    "r_offset_2": 112,
    "r_factor_2": 8,
    "t_2": 10,
    "max": 10,
    "hps_threshold": 2,
    "hps": 8,
    "hps_2": 5,
    "ecoLv_threshold": 2,
    "value_3": 50
  }
},get desc(){return "每 "+RG.configNumber(RG.AUTO_CARD_CDS.ecosystem)+"/"+RG.configNumber(cfgPASSIVESEcosystemUpdateAutoCards.value_3)+" 秒生成 "+RG.configNumber(cfgPASSIVESEcosystemUpdateAutoCards.t_2)+" 秒回复领域";},"icon":"heart","maxLv":2,"name":"生命生态圈","rarity":4},
    pushwave:{rules:{
  "updateAutoCards": {
    "value_6": 8.5,
    "value_2": 7
  }
},get desc(){return ("每"+RG.configNumber(RG.AUTO_CARD_CDS.pushwave)+"/"+RG.configNumber(cfgPASSIVESPushwaveUpdateAutoCards.value_6)+"/"+RG.configNumber(cfgPASSIVESPushwaveUpdateAutoCards.value_2)+"秒推开附近小型怪；沿途撞墙、边界或敌人时额外承受本波基础伤害")+RG.configNumber(RG.PASSIVES.pushwave.collisionMul*100)+"%，每只每波仅一次";},"collisionMul":0.3,"icon":"barrier","maxLv":3,"name":"排斥波","rarity":3},
    scapegoat:{rules:{
  "updateAutoCards": {
    "duration_summonDurationArg1": 8,
    "r": 18,
    "hp_threshold": 2,
    "hp": 450,
    "hp_2": 300,
    "maxhp_threshold": 2,
    "scapegoatLv_threshold": 2,
    "value_7": 29,
    "scapegoat": 0.5
  }
},get desc(){return "每 "+RG.configNumber(RG.AUTO_CARD_CDS.scapegoat)+"/"+RG.configNumber(cfgPASSIVESScapegoatUpdateAutoCards.value_7)+" 秒召唤 "+RG.configNumber(cfgPASSIVESScapegoatUpdateAutoCards.hp_2)+"/"+RG.configNumber(cfgPASSIVESScapegoatUpdateAutoCards.hp)+" 生命嘲讽分身";},"icon":"phantom","maxLv":2,"name":"替罪羊","rarity":4},
    holylight:{targets:2,rules:{
  "updateAutoCards": {
    "duration_summonDurationArg1": 18,
    "hp_floor": 40,
    "hp_factor": 0.65,
    "maxhp_floor": 40,
    "maxhp_factor": 0.65,
    "dmg_floor": 16,
    "dmg_factor": 0.9,
    "fireT": 0.35,
    "autoReset_autoResetArg3": 40,
    "holylight": 0.5
  }
},get desc(){return "每 "+RG.configNumber(RG.AUTO_CARD_CDS.holylight)+" 秒将最近 "+RG.configNumber(RG.PASSIVES.holylight.targets)+" 只普通怪转为临时友军";},"icon":"harmony","maxLv":1,"name":"圣光感化","rarity":5},
    harmony:{rules:{
  "elemReaction": {
    "amp": 1.25
  },
  "applyElem": {
    "harmonize": 1.5
  }
},get desc(){return "元素状态持续 +"+RG.configNumber((RG.PASSIVES.harmony.rules.applyElem.harmonize-1)*100)+"%,反应伤害 +"+RG.configNumber((RG.PASSIVES.harmony.rules.elemReaction.amp-1)*100)+"%";},"maxLv":1,"name":"元素调和","rarity":4},
    shard:{rules:{
  "hurtEnemy": {
    "chance_threshold": 0.3,
    "t": 2,
    "r": 150,
    "dps_factor": 0.3
  }
},get desc(){return "暴击时 "+RG.configNumber(cfgPASSIVESShardHurtEnemy.chance_threshold*100)+"% 概率产生碎片风暴("+RG.configNumber(cfgPASSIVESShardHurtEnemy.t)+"秒)";},"maxLv":1,"name":"碎片风暴","rarity":5},
    crystal:{rules:{
  "killEnemy": {
    "rr_cap": 85,
    "rr_offset": 55,
    "rr_factor": 10,
    "dmg_offset": 30,
    "dmg_factor": 2.5,
    "dmg_factor_2": 1.2,
    "dmg_factor_3": 0.22,
    "killEnemy_offset": 100,
    "killEnemy_applyIceFreezeArg2": 0.8,
    "slowT": 1.2
  },
  "updateEnemies": {
    "d_threshold": 90
  }
},get desc(){return "冰冻敌人死亡时范围碎裂，半径"+RG.configNumber(cfgPASSIVESCrystalKillEnemy.rr_offset)+("/"+RG.configNumber(Math.min(cfgPASSIVESCrystalKillEnemy.rr_cap,cfgPASSIVESCrystalKillEnemy.rr_offset+cfgPASSIVESCrystalKillEnemy.rr_factor*1))+"/"+RG.configNumber(Math.min(cfgPASSIVESCrystalKillEnemy.rr_cap,cfgPASSIVESCrystalKillEnemy.rr_offset+cfgPASSIVESCrystalKillEnemy.rr_factor*2))+"/")+RG.configNumber(cfgPASSIVESCrystalKillEnemy.rr_cap)+"；寒冰冻结时近程常规命中增伤"+RG.configNumber(RG.PASSIVES.crystal.closeFrozenBonus*100)+"%，时停/硬直不算寒冰冻结";},maxLv:4,name:'凝晶碎裂',rarity:2,closeFrozenBonus:.15,
      detail:lv=>'冻敌死亡碎裂，半径'+(cfgPASSIVESCrystalKillEnemy.rr_offset+RG.configNumber((lv-1)*cfgPASSIVESCrystalKillEnemy.rr_factor))+("\n寒冰冻结近程命中增伤"+RG.configNumber(RG.PASSIVES.crystal.closeFrozenBonus*100)+"%\n时停/硬直不算寒冰冻结")},
    ash:{rules:{
  "killEnemy": {
    "rr_cap": 75,
    "rr_offset": 48,
    "rr_factor": 7,
    "dmg_offset": 26,
    "dmg_factor": 2.2,
    "dmg_factor_2": 1.1,
    "dmg_factor_3": 0.22
  }
},"desc":"燃烧的敌人死亡时爆开,范围伤害(半径随级增)","maxLv":5,"name":"灰烬爆发","rarity":2},
    combostorm:tierCards.combostorm,
    supercore:{durationPerLevel:1,arcsPerLevel:1,rules:{},get desc(){return "超导易伤持续 "+RG.configNumber(RG.BALANCE.combat.resolveReaction.value_4_offset+RG.PASSIVES.supercore.durationPerLevel)+"/"+RG.configNumber(RG.BALANCE.combat.resolveReaction.value_4_offset+RG.PASSIVES.supercore.durationPerLevel*2)+"/"+RG.configNumber(RG.BALANCE.combat.resolveReaction.value_4_offset+RG.PASSIVES.supercore.durationPerLevel*3)+" 秒,电弧 "+RG.configNumber(RG.BALANCE.combat.resolveReaction.value_3_offset+RG.PASSIVES.supercore.arcsPerLevel)+"/"+RG.configNumber(RG.BALANCE.combat.resolveReaction.value_3_offset+RG.PASSIVES.supercore.arcsPerLevel*2)+"/"+RG.configNumber(RG.BALANCE.combat.resolveReaction.value_3_offset+RG.PASSIVES.supercore.arcsPerLevel*3)+" 道";},"maxLv":3,"name":"超导核心","rarity":3},
    debt:{damageMul:1.2,hurtMul:1.15,rules:{
  "update": {
    "update_lowHpThresholdArg1": 0.3,
    "debtT": 10,
    "debtCd": 20
  }
},get desc(){return "血量<"+RG.configNumber(cfgPASSIVESDebtUpdate.update_lowHpThresholdArg1*100)+"%时触发：清除自身减速/硬直；"+RG.configNumber(cfgPASSIVESDebtUpdate.debtT)+("秒基础攻击伤害+"+RG.configNumber(((RG.PASSIVES.debt.damageMul-1)*100))+"%、承伤+"+RG.configNumber(((RG.PASSIVES.debt.hurtMul-1)*100))+"%，结束后冷却")+RG.configNumber(cfgPASSIVESDebtUpdate.debtCd)+"秒；不持续免控";},"maxLv":1,"name":"血债血偿","rarity":3,cleanseControl:true},
    echo:{rules:{
  "hurtEnemy": {
    "chance_threshold": 0.12,
    "t": 0.3,
    "dmg_factor": 0.6
  }
},get desc(){return "暴击 "+RG.configNumber(cfgPASSIVESEchoHurtEnemy.chance_threshold*100)+"% 概率 "+RG.configNumber(cfgPASSIVESEchoHurtEnemy.t)+" 秒后原地回响 "+RG.configNumber(cfgPASSIVESEchoHurtEnemy.dmg_factor*100)+"% 伤害";},"maxLv":1,"name":"回响弹头","rarity":3},
    executioner:tierCards.executioner,
    focus:{rules:{
  "rollDamage": {
    "forced_threshold": 3
  }
},get desc(){return "连续 "+RG.configNumber(cfgPASSIVESFocusRollDamage.forced_threshold)+(" 次未暴击后,第 "+RG.configNumber((cfgPASSIVESFocusRollDamage.forced_threshold+1))+" 次攻击必定暴击");},"maxLv":1,"name":"血色专注","rarity":5},
    reflect_b:{rules:{
  "fx": {
    "evade_cap": 0.65,
    "evade_offset": 0.05
  }
},get desc(){return "闪避率 +"+RG.configNumber(cfgPASSIVESReflect_bFx.evade_offset*100)+"%(与疾影步共享 "+RG.configNumber(cfgPASSIVESReflect_bFx.evade_cap*100)+"% 上限)";},"maxLv":5,"name":"反射壁垒","rarity":1,fx:P => { P.evade = Math.min(cfgPASSIVESReflect_bFx.evade_cap, P.evade + cfgPASSIVESReflect_bFx.evade_offset); }},
    ghost_img:{rules:{
  "tryDash": {
    "r": 20,
    "t": 1.5,
    "dmg_factor": 40,
    "dmg_factor_2": 0.22,
    "dmg_factor_3": 0.6
  }
},get desc(){return "冲刺留下"+RG.configNumber(cfgPASSIVESGhost_imgTryDash.t)+(("秒残像，接触敌人受创并硬直；有效受创目标"+RG.configNumber(RG.BALANCE.mobility.markDuration)+"秒常规暴率+")+RG.configNumber(cfgBALANCEMobility.criticalBonus*100)+"点，与践踏刷新一份");},maxLv:1,name:'幽影残像',rarity:4,
      detail:()=> ("冲刺留"+RG.configNumber(cfgPASSIVESGhost_imgTryDash.t)+(("秒伤敌残像\n受创目标"+RG.configNumber(RG.BALANCE.mobility.markDuration)+"秒常规暴率+")+RG.configNumber(cfgBALANCEMobility.criticalBonus*100)+"点\n与践踏共享，刷新不叠"))},
    prism:{shields:1,rules:{
  "hurtPlayer": {
    "rr": 80,
    "pd_offset": 40,
    "pd_factor": 2,
    "pd_factor_2": 0.22
  },
  "updateEnemies": {
    "prismCd": 2.4,
    "dir_threshold": 350,
    "dir_threshold_2": 260,
    "length_threshold": 2
  }
},get desc(){return "护盾 +"+RG.configNumber(RG.PASSIVES.prism.shields)+" 层;护盾破碎时产生范围冲击";},"maxLv":5,"name":"棱能护壁","rarity":2,fx:P => { P.shieldMax += RG.PASSIVES.prism.shields; P.shield = Math.min(P.shieldMax, P.shield + RG.PASSIVES.prism.shields); }},
    valhalla:{rules:{
  "onSummonExit": {
    "length_threshold": 8,
    "base_offset": 12,
    "base_factor": 1.5,
    "dmg_factor": 1.5,
    "dmg_factor_2": 0.5
  }
},name:'英灵殿',rarity:5,maxLv:1,icon:'loyal',cap:300,radius:100,bonus:.08,duration:3,
      get desc(){return "真实友军死亡或到期爆炸：最大生命"+RG.configNumber(cfgPASSIVESValhallaOnSummonExit.dmg_factor_2*100)+"%，幻影取武器基伤"+RG.configNumber(cfgPASSIVESValhallaOnSummonExit.base_factor*100)+"%，基准上限"+RG.configNumber(RG.PASSIVES.valhalla.cap)+"；"+RG.configNumber(RG.PASSIVES.valhalla.duration)+"秒可增伤输出+"+RG.configNumber(RG.PASSIVES.valhalla.bonus*100)+"%。每帧最多"+RG.configNumber(cfgPASSIVESValhallaOnSummonExit.length_threshold)+"爆，清场不触发";}},
    mirrorecho:{minimumGuards:1,name:'镜像回响',rarity:5,maxLv:1,icon:'echo',period:45,scale:.6,
      get desc(){return "每"+RG.configNumber(RG.PASSIVES.mirrorecho.period)+"秒尝试复制最近手动主动：伤害/拉距"+RG.configNumber(RG.PASSIVES.mirrorecho.scale*100)+"%，纯增益/控制时长"+RG.configNumber(RG.PASSIVES.mirrorecho.scale*100)+("%，格挡层向下取整至少"+RG.configNumber(RG.PASSIVES.mirrorecho.minimumGuards)+"；存续超频/相位跳过，不触发释放联动");}},
    resonanceheart:{name:'共鸣之心',rarity:5,maxLv:1,icon:'harmony',realmOnly:true,
      get desc(){return "仅秘境传说奖励：持有时共鸣门槛"+RG.configNumber(RG.RESONANCE_RULES.first)+"→"+RG.configNumber((RG.RESONANCE_RULES.first-RG.RESONANCE_RULES.heartReduction))+"、"+RG.configNumber(RG.RESONANCE_RULES.second)+"→"+RG.configNumber((RG.RESONANCE_RULES.second-RG.RESONANCE_RULES.heartReduction))+"，奖励数值不变；同族计数不变，移除后立即退档";}},
    scavenger:{rules:{
  "updateMeadowMob": {
    "updateMeadowMob_factor": 3,
    "updateMeadowMob_factor_2": 0.35
  }
},name:'拾荒者',rarity:1,maxLv:3,icon:'greed',chances:[0,.02,.03,.04],amount:8,
      get desc(){return "有效击杀有"+RG.configNumber(RG.PASSIVES.scavenger.chances[1]*100)+"/"+RG.configNumber(RG.PASSIVES.scavenger.chances[2]*100)+"/"+RG.configNumber(RG.PASSIVES.scavenger.chances[3]*100)+"%概率额外获得"+RG.configNumber(RG.PASSIVES.scavenger.amount)+"局内金币；虚影、虫洞与无掉钱目标不计";}},
    goldguard:{name:'黄金护体',rarity:3,maxLv:3,icon:'shell',perHundred:.005,caps:[0,.10,.15,.20],
      get desc(){return ("每持有"+RG.configNumber(RG.BALANCE.economy.wealthUnit)+"局内金币，承伤降低")+RG.configNumber(RG.PASSIVES.goldguard.perHundred*100)+("%；上限"+RG.configNumber((RG.PASSIVES.goldguard.caps["1"]*100))+"/"+RG.configNumber((RG.PASSIVES.goldguard.caps["2"]*100))+"/")+RG.configNumber(RG.PASSIVES.goldguard.caps["3"]*100)+"%，花费后立即下降";}},
    goldrain:{rules:{},name:'金雨',rarity:4,maxLv:2,icon:'meteor',rates:[0,.05,.08],period:20,minimum:20,damagePerCoin:1.5,cap:800,
      get desc(){return "每"+RG.configNumber(RG.PASSIVES.goldrain.period)+"秒消耗当前局内金币"+RG.configNumber(RG.PASSIVES.goldrain.rates[1]*100)+"/"+RG.configNumber(RG.PASSIVES.goldrain.rates[2]*100)+"%（至少"+RG.configNumber(RG.PASSIVES.goldrain.minimum)+"），对屏内敌人造成耗币×"+RG.configNumber(RG.PASSIVES.goldrain.damagePerCoin)+"直接伤害，最终基准至多"+RG.configNumber(RG.PASSIVES.goldrain.cap)+"；不足"+RG.configNumber(RG.PASSIVES.goldrain.minimum)+"或无目标不扣币";}},
    greed:{rules:{
  "receiveDamage": {
    "takenMul_factor": 0.05
  },
  "fx": {
    "coinMul": 0.1
  }
},get desc(){return "金币获取 +"+RG.configNumber(cfgPASSIVESGreedFx.coinMul*100)+"%,受到伤害 +"+RG.configNumber(RG.PASSIVES.greed.rules.receiveDamage.takenMul_factor*100)+"%/级";},"maxLv":4,"name":"贪婪之握","rarity":1,fx:P => { P.coinMul += cfgPASSIVESGreedFx.coinMul; }},
    compound:{rules:{
  "addCoin": {
    "coinAcc_threshold": 100,
    "compoundStacks_threshold": 50,
    "coinAcc": 100,
    "dmgMul": 1.01,
    "maxhp_factor": 1.01,
    "hp_factor": 1.01,
    "speed": 1.01
  }
},get desc(){return "每满"+RG.configNumber(cfgPASSIVESCompoundAddCoin.coinAcc_threshold)+"金币:伤害/生命/移速+"+RG.configNumber((cfgPASSIVESCompoundAddCoin.maxhp_factor-1)*100)+"%(至多"+RG.configNumber(cfgPASSIVESCompoundAddCoin.compoundStacks_threshold)+"层)";},"maxLv":1,"name":"复利誓约","rarity":5},
    allin:{rules:{
  "rollDamage": {
    "dmg": 1.25
  },
  "receiveDamage": {
    "takenMul": 1.2
  }
},get desc(){return "无护盾构筑时伤害 +"+RG.configNumber((RG.PASSIVES.allin.rules.rollDamage.dmg-1)*100)+"%,受伤 +"+RG.configNumber((RG.PASSIVES.allin.rules.receiveDamage.takenMul-1)*100)+"%";},"maxLv":1,"name":"孤注一掷","rarity":3},
    abyss:{rules:{
  "rollDamage": {
    "dmg_cap": 0.38,
    "dmg_factor": 0.4
  }
},get desc(){return ("生命每降 "+RG.configNumber(((1/10)*100))+"% 伤害 +"+RG.configNumber(((cfgPASSIVESAbyssRollDamage.dmg_factor/10)*100))+"%(最低血时至多 +")+RG.configNumber(cfgPASSIVESAbyssRollDamage.dmg_cap*100)+"%)";},"maxLv":1,"name":"深渊回响","rarity":4},
    slaughter:{rules:{
  "killEnemy": {
    "slaughN_threshold": 50,
    "slaughterStacks_threshold": 100,
    "slaughN": 50,
    "dmgMul": 1.01
  }
},get desc(){return "持卡每"+RG.configNumber(cfgPASSIVESSlaughterKillEnemy.slaughN_threshold)+"次有效击杀，原伤害成长+"+RG.configNumber((cfgPASSIVESSlaughterKillEnemy.dmgMul-1)*100)+"%，至多"+RG.configNumber(cfgPASSIVESSlaughterKillEnemy.slaughterStacks_threshold)+"层；"+RG.configNumber(RG.PASSIVES.slaughter.milestones.frequency.stacks)+"层攻频+"+RG.configNumber(RG.PASSIVES.slaughter.milestones.frequency.value*100)+"%、"+RG.configNumber(RG.PASSIVES.slaughter.milestones.critical.stacks)+("层暴率+"+RG.configNumber(RG.PASSIVES.slaughter.milestones.critical.value*100)+"点、")+RG.configNumber(RG.PASSIVES.slaughter.milestones.damage.stacks)+"层可增伤输出+"+RG.configNumber(RG.PASSIVES.slaughter.milestones.damage.value*100)+"%；虚影/虫洞不计";},"maxLv":1,"name":"屠戮意志","rarity":2,milestones:{frequency:{stacks:25,value:.03},critical:{stacks:50,value:.03},damage:{stacks:100,value:.05}}},
    heart:{rules:{
  "update": {
    "heartT": 120,
    "range_threshold": 10,
    "heartN_cap": 10,
    "maxhp_factor": 1.04,
    "hp_floor": 5,
    "hp_factor": 0.12
  }
},get desc(){return ("每存活 "+RG.configNumber((cfgPASSIVESHeartUpdate.heartT/60))+" 分钟:生命上限 +")+RG.configNumber((cfgPASSIVESHeartUpdate.maxhp_factor-1)*100)+"% 并恢复失血(至多 "+RG.configNumber(cfgPASSIVESHeartUpdate.heartN_cap)+" 层)";},"maxLv":1,"name":"幸存者之心","rarity":3},
    phantom:{rules:{
  "update": {
    "phantomT": 12,
    "period_floor": 28,
    "period_offset": 42,
    "period_factor": 4,
    "update_summonLimitArg1": 2,
    "phBase_offset": 12,
    "phBase_factor": 1.5,
    "duration_summonDurationArg1": 10,
    "dmg_factor": 0.75,
    "fireT": 0.45,
    "phantomT_2": 3
  }
},get desc(){return ("每 "+RG.configNumber(Math.max(cfgPASSIVESPhantomUpdate.period_floor,cfgPASSIVESPhantomUpdate.period_offset-cfgPASSIVESPhantomUpdate.period_factor*1))+"/"+RG.configNumber(Math.max(cfgPASSIVESPhantomUpdate.period_floor,cfgPASSIVESPhantomUpdate.period_offset-cfgPASSIVESPhantomUpdate.period_factor*2))+"/"+RG.configNumber(Math.max(cfgPASSIVESPhantomUpdate.period_floor,cfgPASSIVESPhantomUpdate.period_offset-cfgPASSIVESPhantomUpdate.period_factor*3))+" 秒召唤幻影(")+RG.configNumber(cfgPASSIVESPhantomUpdate.duration_summonDurationArg1)+" 秒),以初始武器 "+RG.configNumber(cfgPASSIVESPhantomUpdate.dmg_factor*100)+"% 伤害自动开火";},"maxLv":3,"name":"幻影分身","rarity":3},
    loyal:{rules:{
  "killEnemy": {
    "killEnemy_summonLimitArg1": 2,
    "chance_threshold": 0.3,
    "r_floor": 12,
    "r_factor": 0.8,
    "fireT": 0.65,
    "dmg_floor": 18,
    "dmg_factor": 0.8
  }
},get desc(){return "击败精英 "+RG.configNumber(cfgPASSIVESLoyalKillEnemy.chance_threshold*100)+"% 概率复苏为友军炮台(至多 "+RG.configNumber(cfgPASSIVESLoyalKillEnemy.killEnemy_summonLimitArg1)+")";},"maxLv":1,"name":"忠诚残兵","rarity":4},
    barrier:{period:6,duration:9,wallBaseLimit:1,rules:{},get desc(){return "每 "+RG.configNumber(RG.PASSIVES.barrier.period)+(" 秒在身后竖起临时墙,存在 "+RG.configNumber(RG.PASSIVES.barrier.duration)+(" 秒,至多 "+RG.configNumber((RG.PASSIVES.barrier.wallBaseLimit+RG.PASSIVES.barrier.maxLv))+" 面"));},"maxLv":1,"name":"临时壁垒","rarity":3},
    berserk:{rules:{
  "rollDamage": {
    "dmg_factor": 0.15
  }
},get desc(){return "按缺失生命比例增加伤害，空血时 +"+RG.configNumber(RG.PASSIVES.berserk.rules.rollDamage.dmg_factor*100)+"%";},"maxLv":3,"name":"狂血","rarity":3},
    bloodrush:{threshold:0.5,damagePerLevel:0.1,rules:{
  "fx": {
    "bloodrush_cap": 3
  }
},get desc(){return "生命低于 "+RG.configNumber((RG.PASSIVES.bloodrush.threshold*100))+"% 时,伤害 +"+RG.configNumber((RG.PASSIVES.bloodrush.damagePerLevel*100))+"%/级";},"icon":"frenzy","maxLv":3,"name":"血怒狂想","rarity":2,fx:P => { P.bloodrush = Math.min(RG.PASSIVES.bloodrush.rules.fx.bloodrush_cap, (P.bloodrush || 0) + 1); }},
    interest:{rules:{
  "fx": {
    "interest_cap": 3
  },
  "interest": {
    "period": 30,
    "cap": 25,
    "rate": 0.02
  }
},get desc(){return "每 "+RG.configNumber(cfgPASSIVESInterestInterest.period)+" 秒按持有金币 "+RG.configNumber(cfgPASSIVESInterestInterest.rate*100)+"%/级 发放利息(单次上限 "+RG.configNumber(cfgPASSIVESInterestInterest.cap)+")";},"icon":"magnet","maxLv":3,"name":"罪金利息","rarity":2,fx:P => { P.interest = Math.min(RG.PASSIVES.interest.rules.fx.interest_cap, (P.interest || 0) + 1); }},
    soul:{healBase:2,healPerLevel:2,rules:{
  "fx": {
    "soulSuck_cap": 3
  }
},get desc(){return "击杀精英回复 "+RG.configNumber((RG.PASSIVES.soul.healBase+RG.PASSIVES.soul.healPerLevel*1))+"/"+RG.configNumber((RG.PASSIVES.soul.healBase+RG.PASSIVES.soul.healPerLevel*2))+"/"+RG.configNumber((RG.PASSIVES.soul.healBase+RG.PASSIVES.soul.healPerLevel*3))+" 生命";},"icon":"heart","maxLv":3,"name":"灵魂虹吸","rarity":3,fx:P => { P.soulSuck = Math.min(RG.PASSIVES.soul.rules.fx.soulSuck_cap, (P.soulSuck || 0) + 1); }},
    voidstep:{rules:{
  "fx": {
    "voidstep_cap": 2
  }
},get desc(){return "冲刺路径敌人受创并短暂硬直；有效受创目标"+RG.configNumber(RG.BALANCE.mobility.markDuration)+("秒常规暴率+"+RG.configNumber((cfgBALANCEMobility.criticalBonus*100))+"点，与残像刷新一份");},icon:'boots',maxLv:2,name:'虚空践踏',rarity:4,
      detail:()=> ("冲刺路径伤敌并硬直\n受创目标"+RG.configNumber(RG.BALANCE.mobility.markDuration)+("秒常规暴率+"+RG.configNumber((cfgBALANCEMobility.criticalBonus*100))+"点\n与残像共享，刷新不叠")),fx:P => { P.voidstep = Math.min(cfgPASSIVESVoidstepFx.voidstep_cap, (P.voidstep || 0) + 1); }},
    ember:tierCards.ember,
    ember_m:tierCards.ember_m,
    ember_l:tierCards.ember_l,
    ricochet:tierCards.ricochet,
    ricochet_m:tierCards.ricochet_m,
    ricochet_l:tierCards.ricochet_l,
    petrify:tierCards.petrify,
    petrify_m:tierCards.petrify_m,
    petrify_l:tierCards.petrify_l,
    thorns:tierCards.thorns,
    thorns_m:tierCards.thorns_m,
    thorns_l:tierCards.thorns_l,
    stance:tierCards.stance,
    stance_m:tierCards.stance_m,
    stance_l:tierCards.stance_l,
    explosive:tierCards.explosive,
    explosive_m:tierCards.explosive_m,
    explosive_l:tierCards.explosive_l,
    punish:tierCards.punish,
    punish_m:tierCards.punish_m,
    punish_l:tierCards.punish_l,
    executioner_m:tierCards.executioner_m,
    executioner_l:tierCards.executioner_l,
    combostorm_m:tierCards.combostorm_m,
    deflect:tierCards.deflect,
    deflect_m:tierCards.deflect_m,
    deflect_l:tierCards.deflect_l,
    doom:tierCards.doom,
    doom_m:tierCards.doom_m,
    crit_xl:{rules:{
  "fx": {
    "critC": 0.15
  }
},get desc(){return "暴击率 +"+RG.configNumber(cfgPASSIVESCrit_xlFx.critC*100)+"%";},"icon":"crit","maxLv":3,"name":"致命一击·IV","rarity":5,fx:P=>{P.critC+=cfgPASSIVESCrit_xlFx.critC;}},
    insight:{rules:{
  "criticalDamageMultiplier": {
    "cb_offset": 0.4,
    "cb_factor": 2
  }
},get desc(){return "超过"+RG.configNumber(cfgPASSIVESInsightCriticalDamageMultiplier.cb_offset*100)+("%的暴击率转为暴击伤害：每1%转换为"+RG.configNumber(((cfgPASSIVESInsightCriticalDamageMultiplier.cb_factor/100)*100))+"%，不降低实际暴击率");},"icon":"critd","maxLv":1,"name":"精准直觉","rarity":3},
    projectile_guard:tierCards.projectile_guard,
    projectile_guard_m:tierCards.projectile_guard_m,
    projectile_guard_l:tierCards.projectile_guard_l,
    electric_guard:tierCards.electric_guard,
    electric_guard_m:tierCards.electric_guard_m,
    electric_guard_l:tierCards.electric_guard_l,
    melee_power:tierCards.melee_power,
    melee_power_m:tierCards.melee_power_m,
    melee_power_l:tierCards.melee_power_l,
    element_slow:tierCards.element_slow,
    element_slow_m:tierCards.element_slow_m,
    element_slow_l:tierCards.element_slow_l,
    luck:tierCards.luck,
    luck_m:tierCards.luck_m,
    luck_l:tierCards.luck_l,
    luck_xl:tierCards.luck_xl,
    reaction:{rules:{
  "fx": {
    "reactionMul_factor": 0.1
  }
},get desc(){return "元素反应伤害 +"+RG.configNumber(cfgPASSIVESReactionFx.reactionMul_factor*100)+"%，与罪印独立相乘";},"icon":"harmony","maxLv":3,"multipliers":["reactionMul"],"name":"反应催化","rarity":2,fx:P=>{const n=P.passives.reaction||1;P.reactionMul=(P.reactionMul||1)*(1+cfgPASSIVESReactionFx.reactionMul_factor*n)/(1+cfgPASSIVESReactionFx.reactionMul_factor*(n-1));}},
    elite_power:{get desc(){return "对精英和BOSS伤害 +"+RG.configNumber(RG.PASSIVES.elite_power.value*100)+"%";},"family":"elite_power","icon":"power","maxLv":3,"name":"猎首者","rarity":4,"value":0.1},
    elite_crit:{get desc(){return "对精英和BOSS暴击率 +"+RG.configNumber(RG.PASSIVES.elite_crit.value*100)+"%";},"family":"elite_crit","icon":"crit","maxLv":3,"name":"猎首直觉","rarity":4,"value":0.05},
    weakness:{get desc(){return "元素克制带来的额外伤害 +"+RG.configNumber(RG.PASSIVES.weakness.value*100)+"%";},"family":"weakness","icon":"harmony","maxLv":3,"name":"弱点洞察","rarity":3,"value":0.15},
    bloodaid:{rules:{
  "fx": {
    "dmgMul_factor": 0.05,
    "hp_offset": 50
  }
},get desc(){return "基础伤害 -"+RG.configNumber(cfgPASSIVESBloodaidFx.dmgMul_factor*100)+"%，立即回复"+RG.configNumber(cfgPASSIVESBloodaidFx.hp_offset)+"生命";},"icon":"heal","maxLv":3,"multipliers":["dmgMul"],"name":"折刃急救","rarity":3,fx:P=>{const n=P.passives.bloodaid||1;P.dmgMul*=(1-cfgPASSIVESBloodaidFx.dmgMul_factor*n)/(1-cfgPASSIVESBloodaidFx.dmgMul_factor*(n-1));if(!P.healBan&&!P.hpLocked&&!P.healBlocked)P.hp=Math.min(P.maxhp,P.hp+cfgPASSIVESBloodaidFx.hp_offset);}},
    frailheal:{rules:{
  "passiveAvailable": {
    "nextMax_factor": 0.1
  },
  "fx": {
    "maxhp_factor": 0.1,
    "hp_offset": 20
  }
},get desc(){return "生命上限 -"+RG.configNumber(RG.PASSIVES.frailheal.rules.fx.maxhp_factor*100)+"%，立即回复"+RG.configNumber(RG.PASSIVES.frailheal.rules.fx.hp_offset)+"生命";},"icon":"heal","maxLv":3,"multipliers":["maxhp"],"name":"舍血求生","rarity":1,fx:P=>{if(P.hpLocked)return;const n=P.passives.frailheal||1;P.maxhp=Math.max(1,Math.round(P.maxhp*(1-cfgPASSIVESFrailhealFx.maxhp_factor*n)/(1-cfgPASSIVESFrailhealFx.maxhp_factor*(n-1))));P.hp=Math.min(P.hp,P.maxhp);if(!P.healBan&&!P.healBlocked)P.hp=Math.min(P.maxhp,P.hp+cfgPASSIVESFrailhealFx.hp_offset);}},
    giant:{rules:{
  "fx": {
    "giantT": 60,
    "r_factor": 14,
    "r_factor_2": 0.5
  }
},get desc(){return "角色体积 +"+RG.configNumber(RG.PASSIVES.giant.rules.fx.r_factor_2*100)+"%，所有伤害 +"+RG.configNumber(RG.BALANCE.growth.playerDamageMul.playerDamageMul_factor*100)+"%，持续"+RG.configNumber(RG.PASSIVES.giant.rules.fx.giantT)+"秒；同段再次选择叠加固定加成并刷新时间";},"icon":"bigshot","maxLv":3,"name":"巨化爆发","rarity":4,fx:P=>{P.giantT=cfgPASSIVESGiantFx.giantT;P.giantStacks=(P.giantStacks||0)+1;P.r=cfgPASSIVESGiantFx.r_factor*(1+cfgPASSIVESGiantFx.r_factor_2*P.giantStacks);}},
    injury:{rules:{
  "passiveAvailable": {
    "range_threshold": 0.5
  },
  "hurtPlayer": {
    "injuryBonus_cap": 0.5,
    "injuryBonus_factor": 0.01
  }
},get desc(){return "每次实际扣血后永久增加"+RG.configNumber(cfgPASSIVESInjuryHurtPlayer.injuryBonus_factor*100)+"%伤害，最多"+RG.configNumber(cfgPASSIVESInjuryHurtPlayer.injuryBonus_cap*100)+"%；再次强化使每次再加"+RG.configNumber(cfgPASSIVESInjuryHurtPlayer.injuryBonus_factor*100)+"%，上限不变";},"icon":"berserk","maxLv":3,"name":"伤痕斗志","rarity":3},
    backpack:{rules:{
  "buildOffers": {
    "buildOffers": 4,
    "length_threshold": 3
  }
},get desc(){return ("武器携带上限"+RG.configNumber(cfgPASSIVESBackpackBuildOffers.length_threshold)+"→")+RG.configNumber(cfgPASSIVESBackpackBuildOffers.buildOffers)+"，额外武器仍需抽卡获取，仅可选择一次";},"icon":"split","maxLv":1,"name":"背包","rarity":5},
    melee_range:{rules:{},get desc(){return "近程武器攻击范围 +"+RG.configNumber(RG.PASSIVES.melee_range.value*100)+"%";},"family":"melee_range","icon":"magnet","maxLv":3,"name":"近程延展","rarity":2,"value":0.08},
    retaliation:{minimumHit:10,get desc(){return ("单次实际扣血超过"+RG.configNumber(RG.PASSIVES.retaliation.minimumHit)+"点，向本次攻击者反弹扣血量的")+RG.configNumber(RG.PASSIVES.retaliation.value*100)+"%；再次强化增加"+RG.configNumber(RG.PASSIVES.retaliation.value*100)+"%";},"family":"retaliation","icon":"thorns","maxLv":3,"name":"反甲","rarity":4,"value":0.7},
    revive:{damageMul:0.95,rules:{
  "hurtPlayer": {
    "hp_factor": 0.2,
    "iTimer": 2
  }
},get desc(){return "本局复活一次，恢复"+RG.configNumber(RG.PASSIVES.revive.rules.hurtPlayer.hp_factor*100)+("%生命；复活后所有伤害 -"+RG.configNumber(((1-RG.PASSIVES.revive.damageMul)*100))+"%，不可叠加");},"icon":"heart","maxLv":1,"name":"复生火种","rarity":5},
  };
  RG.passiveValue = function(P, family) {
    let value=0;
    for(const id in P.passives){const def=RG.PASSIVES[id];if(def?.family===family)value+=(P.passives[id]||0)*def.value;}
    return value;
  };
  RG.RARITY = [null,
    { name: "普通", color: "#4ade80" },
    { name: "进阶", color: "#60a5fa" },
    { name: "稀有", color: "#c084fc" },
    { name: "史诗", color: "#f87171" },
    { name: "传说", color: "#ffd166" },
  ];


  // 挑战契约:开局可选的风险承诺,叠加金币加成(存 meta.oaths)。
  // 原“疾风誓”按玩家反馈正式删除；七宗罪是 10 级局内唯一罪印，不再与这里混名。
  RG.OATHS = [
    {id:'blood',name:'血誓',hpMul:.65,damageMul:1.3,get desc(){return '生命上限 -'+Math.round(RG.configNumber((1-this.hpMul)*100))+'%,伤害 +'+Math.round(RG.configNumber((this.damageMul-1)*100))+'%';},coin:.25},
    {id:'healban',name:'禁疗誓',desc:'无法回复生命,治疗球变金币',coin:.30},
    {id:'swarm',name:'蜂拥誓',arrivalMul:1.35,get desc(){return '敌人到达速度 +'+Math.round(RG.configNumber((this.arrivalMul-1)*100))+'%';},coin:.35},
    {id:'glass',name:'玻璃大炮',hpMul:.5,damageMul:1.5,get desc(){return '生命上限 -'+Math.round(RG.configNumber((1-this.hpMul)*100))+'%,伤害 +'+Math.round(RG.configNumber((this.damageMul-1)*100))+'%';},coin:.40},
    {id:'fog',name:'迷雾遮目',visionMul:.7,get desc(){return '远程索敌范围 -'+Math.round(RG.configNumber((1-this.visionMul)*100))+'%';},coin:.20},
    {id:'haste',name:'急速之敌',enemySpeed:1.18,get desc(){return '敌人移动速度 +'+Math.round(RG.configNumber((this.enemySpeed-1)*100))+'%';},coin:.25},
    {id:'frail',name:'脆弱之躯',hurtMul:1.25,get desc(){return '受到伤害 +'+Math.round(RG.configNumber((this.hurtMul-1)*100))+'%';},coin:.22},
    {id:'poverty',name:'清贫之誓',coinMul:.7,get desc(){return '局内金币获取 -'+Math.round(RG.configNumber((1-this.coinMul)*100))+'%,结算加成更高';},coin:.45},
  ];

  // 罪印(v8.28):10 级从七宗罪随机三选一,当局互斥不可撤销
  RG.OATH_NODES = {
    sin_gluttony: {rules:{
  "applyOffer": {
    "maxhp_factor": 1.7,
    "armor_cap": 0.6,
    "armor_offset": 0.2,
    "speed": 0.7,
    "elemMul": 0.8
  }
}, name: "暴食", get desc(){return "生命上限 +"+RG.configNumber((cfgOATH_NODESSin_gluttonyApplyOffer.maxhp_factor-1)*100)+"%、减伤 "+RG.configNumber(cfgOATH_NODESSin_gluttonyApplyOffer.armor_offset*100)+"%，移速 -"+RG.configNumber((1-cfgOATH_NODESSin_gluttonyApplyOffer.speed)*100)+"%、元素伤害 -"+RG.configNumber((1-cfgOATH_NODESSin_gluttonyApplyOffer.elemMul)*100)+"%";}, glyph: "食", get briefGain(){return "生命 +"+RG.configNumber((cfgOATH_NODESSin_gluttonyApplyOffer.maxhp_factor-1)*100)+"% · 减伤 +"+RG.configNumber(cfgOATH_NODESSin_gluttonyApplyOffer.armor_offset*100)+"%";}, get briefCost(){return "移速 -"+RG.configNumber((1-cfgOATH_NODESSin_gluttonyApplyOffer.speed)*100)+"% · 元素伤害 -"+RG.configNumber((1-cfgOATH_NODESSin_gluttonyApplyOffer.elemMul)*100)+"%";} },
    sin_envy:     {rules:{
  "applyOffer": {
    "envyCardBonus_cap": 0.2,
    "envyCardBonus_factor": 0.01,
    "envyPower_threshold": 0.4,
    "envyPower_threshold_2": 0.7,
    "envyPower_threshold_3": 0.9,
    "envyCd": 2
  }
}, name: "嫉妒", get desc(){return "清除全部被动并随机学BOSS技；每种真实清除被动换"+RG.configNumber(cfgOATH_NODESSin_envyApplyOffer.envyCardBonus_factor*100)+"%可增伤输出，上限"+RG.configNumber(cfgOATH_NODESSin_envyApplyOffer.envyCardBonus_cap*100)+"%，不按等级多计、不重复累加";}, glyph: "妒", briefGain: "随机获得一项 BOSS 技能", briefCost: "失去全部已有被动" },
    sin_wrath:    {rules:{
  "wrathBloodBonus": {
    "wrathBloodBonus_cap": 10,
    "wrathBloodBonus_factor": 0.01
  },
  "painFrequency": {
    "painFrequency": 1.5
  },
  "applyOffer": {
    "critD": 4
  },
  "killEnemy": {
    "wrathBloodStacks_cap": 10,
    "killEnemy_refreshStatusArg3": 8
  }
}, name: "暴怒", get desc(){return "暴伤设"+RG.configNumber(cfgOATH_NODESSin_wrathApplyOffer.critD*100)+"%，永久禁疗（局外特性除外）；残血浴血击杀改为"+RG.configNumber(RG.OATH_NODES.sin_wrath.rules.killEnemy.killEnemy_refreshStatusArg3)+"秒暴伤层、至多"+RG.configNumber(RG.OATH_NODES.sin_wrath.rules.wrathBloodBonus.wrathBloodBonus_cap)+"点，痛觉效果×"+RG.configNumber(RG.OATH_NODES.sin_wrath.rules.painFrequency.painFrequency);}, glyph: "怒", get briefGain(){return "暴击伤害提升至 "+RG.configNumber(cfgOATH_NODESSin_wrathApplyOffer.critD)+" 倍";}, briefCost: "永久禁疗，局外特性除外" },
    sin_sloth:    {extraCooldown:0.1,maxDashStacks:100,rules:{
  "applyOffer": {
    "armor_cap": 0.6,
    "armor_offset": 0.3
  }
}, name: "懒惰", get desc(){return "减伤+"+RG.configNumber(cfgOATH_NODESSin_slothApplyOffer.armor_offset*100)+("%，真实停步时磐石立即生效；每次冲刺额外冷却+"+RG.configNumber(RG.OATH_NODES.sin_sloth.extraCooldown)+"秒，至多")+RG.configNumber(RG.OATH_NODES.sin_sloth.maxDashStacks)+"层";}, glyph: "惰", get briefGain(){return "减伤 +"+RG.configNumber(cfgOATH_NODESSin_slothApplyOffer.armor_offset*100)+"%";}, get briefCost(){return "冲刺越用越慢，最多额外 "+RG.configNumber((RG.OATH_NODES.sin_sloth.extraCooldown*RG.OATH_NODES.sin_sloth.maxDashStacks))+" 秒";} },
    sin_greed:    {rules:{
  "wealthGuard": {
    "wealthGuard": 1.5
  },
  "triggerGoldRain": {
    "damage": 1.3
  },
  "applyOffer": {
    "pickup": 1.8,
    "xpMul": 1.25,
    "critD": 1.3
  }
}, name: "贪婪", get desc(){return "经验拾取+"+RG.configNumber((cfgOATH_NODESSin_greedApplyOffer.pickup-1)*100)+"%、经验+"+RG.configNumber((cfgOATH_NODESSin_greedApplyOffer.xpMul-1)*100)+"%，暴伤锁"+RG.configNumber(cfgOATH_NODESSin_greedApplyOffer.critD*100)+"%；黄金护体上限×"+RG.configNumber(RG.OATH_NODES.sin_greed.rules.wealthGuard.wealthGuard)+"、金雨伤害×"+RG.configNumber(cfgOATH_NODESSin_greedTriggerGoldRain.damage)+("（仍封顶"+RG.configNumber(RG.PASSIVES.goldrain.cap)+"），复利仍"+RG.configNumber(cfgPASSIVESCompoundAddCoin.compoundStacks_threshold)+"层");}, glyph: "贪", get briefGain(){return "经验 +"+RG.configNumber((cfgOATH_NODESSin_greedApplyOffer.xpMul-1)*100)+"% · 经验拾取 +"+RG.configNumber((cfgOATH_NODESSin_greedApplyOffer.pickup-1)*100)+"%";}, get briefCost(){return "暴击伤害锁定 "+RG.configNumber(cfgOATH_NODESSin_greedApplyOffer.critD)+" 倍";} },
    sin_lust:     {rules:{
  "conversion": {
    "limit": 10,
    "bossChance": 0.1,
    "mobChance": 0.15,
    "bossHpMul": 0.5,
    "mobHpMul": 0.75,
    "damageMul": 0.75,
    "firstAttack": 0.6,
    "healthCostChance": 0.4,
    "healthFloor": 10,
    "healthCost": 10
  }
}, name: "色欲", get desc(){return "击杀 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.mobChance*100)+"% 转化仆人（BOSS "+RG.configNumber(cfgOATH_NODESSin_lustConversion.bossChance*100)+"%），最多 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.limit)+" 只。普通生命 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.mobHpMul*100)+"%、BOSS 生命 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.bossHpMul*100)+"%，伤害均为 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.damageMul*100)+"%；BOSS 仅基础技能。转化后 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.healthCostChance*100)+"% 扣 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.healthCost)+" 血，最低 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.healthFloor)+" 血";}, glyph: "欲", get briefGain(){return "击杀 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.mobChance*100)+"% 收服仆人（BOSS "+RG.configNumber(cfgOATH_NODESSin_lustConversion.bossChance*100)+"%），最多 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.limit)+" 只";}, get briefCost(){return "收服时可能扣 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.healthCost)+" 血，保底 "+RG.configNumber(cfgOATH_NODESSin_lustConversion.healthFloor)+" 血";} },
    sin_pride:    {lockedHp:1,rules:{
  "applyOffer": {
    "dmgMul": 3,
    "cdMul": 1.2,
    "critC": 0.2,
    "reactionMul_factor": 1.5
  }
}, name: "傲慢", get desc(){return "伤害 +"+RG.configNumber((cfgOATH_NODESSin_prideApplyOffer.dmgMul-1)*100)+"%、攻速 +"+RG.configNumber((cfgOATH_NODESSin_prideApplyOffer.cdMul-1)*100)+"%、暴击 +"+RG.configNumber(cfgOATH_NODESSin_prideApplyOffer.critC*100)+"%、反应伤害 +"+RG.configNumber((cfgOATH_NODESSin_prideApplyOffer.reactionMul_factor-1)*100)+("%，生命锁为 "+RG.configNumber(RG.OATH_NODES.sin_pride.lockedHp));}, glyph: "傲", get briefGain(){return "伤害 +"+RG.configNumber((cfgOATH_NODESSin_prideApplyOffer.dmgMul-1)*100)+"% · 攻速、暴击与反应增强";}, get briefCost(){return "生命锁定为 "+RG.configNumber(RG.OATH_NODES.sin_pride.lockedHp);} },
  };

  // 卡牌类别(v7.8 三选一多样性保底用):stat=纯数值 proc=机制联动 risk=风险代价 eco=经济 ally=友军
  RG.CARD_CAT = {
    ember: "proc", harmony: "proc", ricochet: "proc", shard: "proc", explosive: "proc", barrier: "proc",
    crystal: "proc", ash: "proc", echo: "proc", supercore: "proc", combostorm: "proc",
    punish: "proc", ghost_img: "proc", thorns: "proc", phantom: "ally", loyal: "ally",
    pact: "risk", berserk: "risk", debt: "risk", allin: "risk", abyss: "risk",
    magnet: "eco", greed: "eco", compound: "eco", scavenger:"eco", goldguard:"stat", goldrain:"proc", valhalla:'ally', mirrorecho:'proc', resonanceheart:'proc',
    scout: "stat", elem_s: "proc", elem_m: "proc", ranged: "stat", dashcd_s: "stat", dashcd_m: "stat", globalcd: "proc",
    xp_s: "eco", xp_m: "eco", xp_l: "eco",
    meteor:"proc", poisontrail:"proc", spores:"proc", earthbalance:"proc", aftershock:"proc", chargecircuit:"proc", goldbell:"proc", petrify:"proc", ecosystem:"proc", pushwave:"proc", scapegoat:"ally", holylight:"ally",
    insight: "stat", executioner: "stat", focus: "stat", reflect_b: "stat", prism: "stat", heart: "stat",
    dashecho:'proc', windwalker:'stat', mountain:'proc', fullshield:'stat', shieldcounter:'proc',
    bloodrush: "stat", interest: "eco", soul: "proc", deflect: "stat", voidstep: "proc", doom: "proc",
  };
  RG.AUTO_CARD_CDS = { meteor:10, poisontrail:7, goldbell:60, ecosystem:60, pushwave:10, scapegoat:35, holylight:40, goldrain:20, mirrorecho:45 };
  RG.passiveDescription=(id,lv)=>RG.PASSIVES[id]?.detail?RG.PASSIVES[id].detail(lv):RG.PASSIVES[id]?.desc||"";
  // 同族各品质与强化只计一件；五件同时保留三件收益。首批不统计近/远程武器标签。
  RG.RESONANCE_RULES=RG.freezeConfig({first:3,second:5,heartReduction:1});
  RG.RESONANCES={
    wealth:{name:'财富',color:'#fbbf24',families:['greed','interest','compound','scavenger','goldguard','goldrain'],
      at3:{coinGain:.10},at5:{wealthDamage:.005},text3:'金币获取+10%',text5:'每持100金伤害+0.5%，至多10%'},
    element:{name:'元素',color:'#7dd3fc',families:['frost','elem','crystal','ash','ember','element_slow','reaction','supercore','poisontrail','doom','weakness','harmony','spores','earthbalance','aftershock','reactionchain','elementunity'],actives:['thunder'],
      at3:{elementDamage:.10},at5:{reactionDamage:.20,reactionRange:.15},text3:'元素伤+10%',text5:'反应伤+20%/范围+15%'},
    critical:{name:'暴击',color:'#ffd166',families:['crit','critd','executioner','petrify','echo','insight','elite_crit','shard','focus','earthbalance','weakmark','critstreak','causality'],
      at3:{critRate:.05},at5:{critDamage:.25},text3:'暴击率+5点',text5:'暴伤+25点'},
    summon:{name:'召唤',color:'#4ade80',families:['phantom','scapegoat','loyal','holylight','rally','legion','valhalla'],sins:['sin_lust'],
      at3:{summonDamage:.20,summonCapacity:1},at5:{summonExitFrequency:.10},text3:'召唤伤+20%/仆人、幻影、炮台上限+1',text5:'退场后2秒攻速+10%'},
    shield:{name:'护盾',color:'#a5b4fc',families:['shieldcore','prism','thorns','retaliation','mountain','fullshield','shieldcounter'],actives:['aegis'],
      at3:{shieldRecovery:.25},at5:{shieldBreakInvul:.75,shieldBreakCooldown:10},text3:'回盾速度+25%',text5:'破盾无敌0.75秒/冷却10秒'},
  };

  // 商店永久强化(局外成长,金币购买,账号永久生效)
  RG.SHOP_PERKS = [
    {id:'p_hp',name:'强化生命',health:25,get desc(){return '开局生命上限 +'+this.health;},price:50},
    {id:'p_speed',name:'强化双腿',speedMul:1.06,get desc(){return '开局移动速度 +'+Math.round(RG.configNumber((this.speedMul-1)*100))+'%';},price:80},
    {id:'p_lv2',name:'开局进化',level:2,get desc(){return '开局'+this.level+'级，并立即获得一次三选一';},price:100,icon:'seed',group:'combat'},
    {id:'p_shield',name:'能量护盾',shields:2,get desc(){return '开局获得 '+this.shields+' 层护盾';},price:90},
    {id:'p_reroll',name:'命运重骰',rerolls:1,get desc(){return '每局重骰次数 +'+this.rerolls;},price:100},
    {id:'p_coin',name:'黄金之手',coinMul:1.2,get desc(){return '金币获取 +'+Math.round(RG.configNumber((this.coinMul-1)*100))+'%';},price:150},
    {id:'p_boltburst',name:'魔弹连发',delay:.12,get desc(){return '魔弹每次攻击间隔'+this.delay+'秒补射一轮';},price:220,icon:'bolt',group:'combat'},
    {id:'p_regen',name:'生命脉动',period:5,health:1,get desc(){return '每'+this.period+'秒回复'+this.health+'点生命，暴怒仍生效；禁疗契约或领域除外';},price:70,icon:'regen',group:'survival'},
    {id:'p_xp',name:'经验研习',xpMul:1.02,get desc(){return '全部经验获取收益 +'+Math.round(RG.configNumber((this.xpMul-1)*100))+'%';},price:80,icon:'seed',group:'income'},
  ];
  RG.perkConfig=id=>RG.SHOP_PERKS.find(p=>p.id===id);
  RG.oathConfig=id=>RG.OATHS.find(o=>o.id===id);
  const perkLook={p_hp:['heal','survival'],p_speed:['boots','survival'],p_shield:['shieldcore','survival'],p_reroll:['crit','combat'],p_coin:['greed','income']};
  for(const p of RG.SHOP_PERKS)if(perkLook[p.id]){p.icon=perkLook[p.id][0];p.group=perkLook[p.id][1];}
  for(const data of [RG.PASSIVES,RG.OATHS,RG.OATH_NODES,RG.SHOP_PERKS,RG.AUTO_CARD_CDS,RG.RESONANCES,RG.CARD_CAT])RG.freezeConfig(data);

  function bloodlinePair(){
    const debt=RG.configNumber(Math.min(RG.PASSIVES.bloodline.cap,RG.PASSIVES.debt.rules.update.update_lowHpThresholdArg1+RG.PASSIVES.bloodline.increase)*100),heal=RG.configNumber(Math.min(RG.PASSIVES.bloodline.cap,RG.PASSIVES.bloodheal.threshold+RG.PASSIVES.bloodline.increase)*100);
    return debt===heal?"血债/续命"+debt+"%":"血债"+debt+"%、续命"+heal+"%";
  }
  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgBALANCECardsFx=RG.BALANCE.cards.fx,
    cfgPASSIVESPetrifyHurtEnemy=RG.PASSIVES.petrify.rules.hurtEnemy,
    cfgPASSIVESRegenFx=RG.PASSIVES.regen.rules.fx,
    cfgPASSIVESPactFx=RG.PASSIVES.pact.rules.fx,
    cfgPASSIVESShellFx=RG.PASSIVES.shell.rules.fx,
    cfgPASSIVESShieldcoreFx=RG.PASSIVES.shieldcore.rules.fx,
    cfgPASSIVESEvadeFx=RG.PASSIVES.evade.rules.fx,
    cfgPASSIVESCrit_sFx=RG.PASSIVES.crit_s.rules.fx,
    cfgPASSIVESCrit_mFx=RG.PASSIVES.crit_m.rules.fx,
    cfgPASSIVESCrit_lFx=RG.PASSIVES.crit_l.rules.fx,
    cfgPASSIVESCritd_sFx=RG.PASSIVES.critd_s.rules.fx,
    cfgPASSIVESCritd_mFx=RG.PASSIVES.critd_m.rules.fx,
    cfgPASSIVESCritd_lFx=RG.PASSIVES.critd_l.rules.fx,
    cfgPASSIVESSplit_lFx=RG.PASSIVES.split_l.rules.fx,
    cfgPASSIVESBigshotFx=RG.PASSIVES.bigshot.rules.fx,
    cfgPASSIVESFrostFx=RG.PASSIVES.frost.rules.fx,
    cfgPASSIVESXpwindUpdate=RG.PASSIVES.xpwind.rules.update,
    cfgPASSIVESLeveldashGainXP=RG.PASSIVES.leveldash.rules.gainXP,
    cfgPASSIVESSporesKillEnemy=RG.PASSIVES.spores.rules.killEnemy,
    cfgPASSIVESEarthbalanceApplyElem=RG.PASSIVES.earthbalance.rules.applyElem,
    cfgPASSIVESAftershockElemReaction=RG.PASSIVES.aftershock.rules.elemReaction,
    cfgPASSIVESChargecircuitUseActive=RG.PASSIVES.chargecircuit.rules.useActive,
    cfgPASSIVESElementunityElementUnityBonus=RG.PASSIVES.elementunity.rules.elementUnityBonus,
    cfgPASSIVESGoldbellHurtPlayer=RG.PASSIVES.goldbell.rules.hurtPlayer,
    cfgPASSIVESEcosystemUpdateAutoCards=RG.PASSIVES.ecosystem.rules.updateAutoCards,
    cfgPASSIVESPushwaveUpdateAutoCards=RG.PASSIVES.pushwave.rules.updateAutoCards,
    cfgPASSIVESScapegoatUpdateAutoCards=RG.PASSIVES.scapegoat.rules.updateAutoCards,
    cfgPASSIVESShardHurtEnemy=RG.PASSIVES.shard.rules.hurtEnemy,
    cfgPASSIVESCrystalKillEnemy=RG.PASSIVES.crystal.rules.killEnemy,
    cfgPASSIVESDebtUpdate=RG.PASSIVES.debt.rules.update,
    cfgPASSIVESEchoHurtEnemy=RG.PASSIVES.echo.rules.hurtEnemy,
    cfgPASSIVESFocusRollDamage=RG.PASSIVES.focus.rules.rollDamage,
    cfgPASSIVESReflect_bFx=RG.PASSIVES.reflect_b.rules.fx,
    cfgPASSIVESGhost_imgTryDash=RG.PASSIVES.ghost_img.rules.tryDash,
    cfgBALANCEMobility=RG.BALANCE.mobility,
    cfgPASSIVESValhallaOnSummonExit=RG.PASSIVES.valhalla.rules.onSummonExit,
    cfgPASSIVESGreedFx=RG.PASSIVES.greed.rules.fx,
    cfgPASSIVESCompoundAddCoin=RG.PASSIVES.compound.rules.addCoin,
    cfgPASSIVESAbyssRollDamage=RG.PASSIVES.abyss.rules.rollDamage,
    cfgPASSIVESSlaughterKillEnemy=RG.PASSIVES.slaughter.rules.killEnemy,
    cfgPASSIVESHeartUpdate=RG.PASSIVES.heart.rules.update,
    cfgPASSIVESPhantomUpdate=RG.PASSIVES.phantom.rules.update,
    cfgPASSIVESLoyalKillEnemy=RG.PASSIVES.loyal.rules.killEnemy,
    cfgPASSIVESInterestInterest=RG.PASSIVES.interest.rules.interest,
    cfgPASSIVESVoidstepFx=RG.PASSIVES.voidstep.rules.fx,
    cfgPASSIVESCrit_xlFx=RG.PASSIVES.crit_xl.rules.fx,
    cfgPASSIVESInsightCriticalDamageMultiplier=RG.PASSIVES.insight.rules.criticalDamageMultiplier,
    cfgPASSIVESReactionFx=RG.PASSIVES.reaction.rules.fx,
    cfgPASSIVESBloodaidFx=RG.PASSIVES.bloodaid.rules.fx,
    cfgPASSIVESFrailhealFx=RG.PASSIVES.frailheal.rules.fx,
    cfgPASSIVESGiantFx=RG.PASSIVES.giant.rules.fx,
    cfgPASSIVESInjuryHurtPlayer=RG.PASSIVES.injury.rules.hurtPlayer,
    cfgPASSIVESBackpackBuildOffers=RG.PASSIVES.backpack.rules.buildOffers,
    cfgOATH_NODESSin_gluttonyApplyOffer=RG.OATH_NODES.sin_gluttony.rules.applyOffer,
    cfgOATH_NODESSin_envyApplyOffer=RG.OATH_NODES.sin_envy.rules.applyOffer,
    cfgOATH_NODESSin_wrathApplyOffer=RG.OATH_NODES.sin_wrath.rules.applyOffer,
    cfgOATH_NODESSin_slothApplyOffer=RG.OATH_NODES.sin_sloth.rules.applyOffer,
    cfgOATH_NODESSin_greedApplyOffer=RG.OATH_NODES.sin_greed.rules.applyOffer,
    cfgOATH_NODESSin_greedTriggerGoldRain=RG.OATH_NODES.sin_greed.rules.triggerGoldRain,
    cfgOATH_NODESSin_lustConversion=RG.OATH_NODES.sin_lust.rules.conversion,
    cfgOATH_NODESSin_prideApplyOffer=RG.OATH_NODES.sin_pride.rules.applyOffer;
})(window.RG);
