// ============ 成长与构筑:伤害掷骰 / 升级卡池 / 被动 / 进化 / 附魔 ============
(function(RG){
  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgBALANCEGrowthElementUnityBonus=RG.BALANCE.growth.elementUnityBonus,
    cfgBALANCEGrowthRefreshResonance=RG.BALANCE.growth.refreshResonance,
    cfgOATH_NODESSin_wrathWrathBloodBonus=RG.OATH_NODES.sin_wrath.rules.wrathBloodBonus,
    cfgBALANCEEconomy=RG.BALANCE.economy,
    cfgOATH_NODESSin_greedWealthGuard=RG.OATH_NODES.sin_greed.rules.wealthGuard,
    cfgOATH_NODESSin_greedTriggerGoldRain=RG.OATH_NODES.sin_greed.rules.triggerGoldRain,
    cfgPASSIVESGoldbellHurtPlayer=RG.PASSIVES.goldbell.rules.hurtPlayer,
    cfgPASSIVESDebtUpdate=RG.PASSIVES.debt.rules.update,
    cfgPASSIVESPhantomUpdate=RG.PASSIVES.phantom.rules.update,
    cfgPASSIVESScapegoatUpdateAutoCards=RG.PASSIVES.scapegoat.rules.updateAutoCards,
    cfgPASSIVESLoyalKillEnemy=RG.PASSIVES.loyal.rules.killEnemy,
    cfgPASSIVESValhallaOnSummonExit=RG.PASSIVES.valhalla.rules.onSummonExit,
    cfgBALANCEGrowthTriggerGoldRain=RG.BALANCE.growth.triggerGoldRain,
    cfgPASSIVESCompoundAddCoin=RG.PASSIVES.compound.rules.addCoin,
    cfgBALANCEGrowthTryDash=RG.BALANCE.growth.tryDash,
    cfgPASSIVESGhost_imgTryDash=RG.PASSIVES.ghost_img.rules.tryDash,
    cfgACTIVESCollapseUseActive=RG.ACTIVES.collapse.rules.useActive,
    cfgACTIVESThunderUseActive=RG.ACTIVES.thunder.rules.useActive,
    cfgBALANCEGrowthPerfectDodge=RG.BALANCE.growth.perfectDodge,
    cfgPASSIVESPunishPerfectDodge=RG.PASSIVES.punish.rules.perfectDodge,
    cfgBALANCEGrowthPassiveAvailable=RG.BALANCE.growth.passiveAvailable,
    cfgPASSIVESFrailhealPassiveAvailable=RG.PASSIVES.frailheal.rules.passiveAvailable,
    cfgBALANCEGrowthStatueSacrifice=RG.BALANCE.growth.statueSacrifice,
    cfgBALANCEGrowthPlayerDamageMul=RG.BALANCE.growth.playerDamageMul,
    cfgBALANCEGrowthCriticalDamageMultiplier=RG.BALANCE.growth.criticalDamageMultiplier,
    cfgPASSIVESInsightCriticalDamageMultiplier=RG.PASSIVES.insight.rules.criticalDamageMultiplier,
    cfgBALANCEGrowthRollDamage=RG.BALANCE.growth.rollDamage,
    cfgPASSIVESAbyssRollDamage=RG.PASSIVES.abyss.rules.rollDamage,
    cfgBALANCEGrowthSplash=RG.BALANCE.growth.splash,
    cfgBALANCEGrowthBuildOffers=RG.BALANCE.growth.buildOffers,
    cfgBALANCEGrowthCommon=RG.BALANCE.growth.common,
    cfgBALANCEGrowthOfferRarity=RG.BALANCE.growth.offerRarity,
    cfgBALANCEGrowthWeaponOfferWeight=RG.BALANCE.growth.weaponOfferWeight,
    cfgBALANCEGrowthCountPity=RG.BALANCE.growth.countPity,
    cfgBALANCEGrowthLevelUp=RG.BALANCE.growth.levelUp,
    cfgBALANCEGrowthRerollOffers=RG.BALANCE.growth.rerollOffers,
    cfgBALANCEGrowthApplyOffer=RG.BALANCE.growth.applyOffer,
    cfgOATH_NODESSin_gluttonyApplyOffer=RG.OATH_NODES.sin_gluttony.rules.applyOffer,
    cfgOATH_NODESSin_envyApplyOffer=RG.OATH_NODES.sin_envy.rules.applyOffer,
    cfgOATH_NODESSin_slothApplyOffer=RG.OATH_NODES.sin_sloth.rules.applyOffer,
    cfgOATH_NODESSin_greedApplyOffer=RG.OATH_NODES.sin_greed.rules.applyOffer,
    cfgOATH_NODESSin_prideApplyOffer=RG.OATH_NODES.sin_pride.rules.applyOffer,
    cfgBALANCEGrowthChooseOffer=RG.BALANCE.growth.chooseOffer,
    cfgBALANCEGrowthDailyChallenge=RG.BALANCE.growth.dailyChallenge,
    cfgBALANCEGrowthSettleDaily=RG.BALANCE.growth.settleDaily,
    cfgPASSIVESInterestInterest=RG.PASSIVES.interest.rules.interest,
    cfgBALANCEGrowthHitVoidstep=RG.BALANCE.growth.hitVoidstep;

  const {rand,clamp,dist2,pick,TAU}=RG;
  // 只读取实际持有武器的有效附魔；固有元素、遗留条目和同元素升级不多计。
  RG.infusedElementTypes=function(P){
    const types=new Set();for(const id of Object.keys(P.weapons||{}))if(P.weapons[id]>0&&RG.WEAPONS[id]){
      const el=RG.weaponElement(P,id);if(el&&RG.ELEMENTS[el.type]&&Number.isInteger(el.level)&&el.level>=1&&el.level<=RG.BALANCE.growth.infusedElementTypes.level_threshold)types.add(el.type);
    }return [...types];
  };
  RG.elementUnityBonus=function(P=RG.P){
    if(!P?.passives.elementunity)return {count:0,damage:0,range:0};
    const def=RG.PASSIVES.elementunity,count=Math.min(def.maxTypes,RG.infusedElementTypes(P).length);
    return {count,damage:count*def.perType,range:count>=cfgBALANCEGrowthElementUnityBonus.range_threshold?def.rangeBonus:0};
  };
  // 共鸣是持有组件的派生值，不写入永久属性或被动撤销账本。
  RG.resonanceCounts=function(P){
    const entries=Object.entries(RG.RESONANCES),sets=Object.fromEntries(entries.map(([id])=>[id,new Set()]));
    for(const [card,lv]of Object.entries(P.passives||{})){
      const def=RG.PASSIVES[card];if(!def||!(lv>0))continue;
      const family=def.family||card.replace(/_(s|m|l|xl)$/,'');
      for(const [id,r]of entries)if(r.families.includes(family))sets[id].add('被动:'+family);
    }
    for(const [card,lv]of Object.entries(P.actives||{}))if(lv>0&&RG.ACTIVES[card]&&P.activeOrder?.includes(card))for(const [id,r]of Object.entries(RG.RESONANCES))if(r.actives?.includes(card))sets[id].add('主动:'+card);
    for(const [id,r]of Object.entries(RG.RESONANCES))if(r.sins?.includes(P.sinId))sets[id].add('罪印:'+P.sinId);
    // 两把同元素武器仍是一件；升级/进化不另加，丢弃最后来源即退档。
    for(const type of RG.infusedElementTypes(P))sets.element.add('附魔:'+type);
    return Object.fromEntries(Object.entries(sets).map(([id,set])=>[id,set.size]));
  };
  RG.resonanceThreshold=(P,tier)=>tier-(P.passives.resonanceheart?RG.RESONANCE_RULES.heartReduction:0);
  RG.refreshResonance=function(P=RG.P){
    if(!P)return null;const counts=RG.resonanceCounts(P),bonuses={};
    for(const [id,r]of Object.entries(RG.RESONANCES)){if(counts[id]>=RG.resonanceThreshold(P,RG.RESONANCE_RULES.first))Object.assign(bonuses,r.at3);if(counts[id]>=RG.resonanceThreshold(P,RG.RESONANCE_RULES.second))Object.assign(bonuses,r.at5);}
    const previous=P._resonance,rallyCapacity=P.passives.rally>=RG.PASSIVES.rally.capacityLevel?RG.PASSIVES.rally.capacityBonus:0;P._resonance={counts,bonuses,rallyCapacity};
    if(P===RG.P&&previous&&((previous.bonuses.summonCapacity||0)>(bonuses.summonCapacity||0)||(previous.rallyCapacity||0)>rallyCapacity)){
      const trim=(items,match,max)=>{const alive=(items||[]).filter(a=>match(a)&&!a.dead);for(const a of alive.slice(max)){a.dead=true;a.resonanceExited=true;}};
      const extra=(bonuses.summonCapacity||0)+rallyCapacity;
      trim(RG.allies,a=>a.puppet&&a.hp>0,cfgBALANCEGrowthRefreshResonance.refreshResonance_offset+extra);trim(RG.allies,a=>a.source==='loyal'&&(a.hp==null||a.hp>0),cfgBALANCEGrowthRefreshResonance.refreshResonance_offset_2+extra);trim(RG.phantoms,a=>a.t>0,cfgBALANCEGrowthRefreshResonance.refreshResonance_offset_2+extra);
      trim(RG.decoys,a=>a.hp>0&&a.t>0,1+rallyCapacity);trim(RG.allies,a=>a.source==='holylight'&&a.hp>0&&a.t>0,cfgBALANCEGrowthRefreshResonance.refreshResonance_offset_3+rallyCapacity);
    }
    return P._resonance;
  };
  RG.resonanceBonus=(P=RG.P)=>P?(P._resonance||RG.refreshResonance(P)).bonuses:{};
  RG.playerStatusLabels=function(P=RG.P){
    if(!P)return [];const out=[];if(P.freezeT>0)out.push('冻结');else if(P.stunT>0)out.push('眩晕');if(P.poisonContactT>0)out.push('中毒');if(P.slowT>0&&!(P.freezeT>0))out.push('减速');if(P.overdriveT>0||P.debtT>0||P.bloodrush>0)out.push('狂暴');if(P.activeGuard>0||P.aegisCastT>0)out.push('霸体');if(P.dashT>0||P.iTimer>0)out.push('无敌');if(P.spaceWoundT>0)out.push('重伤');else if(P.healBan||P.healBlocked)out.push('禁疗');if(P.howlDebuffT>0)out.push('虚弱');return out;
  };
  RG.playerElementMul=(P=RG.P)=>(P.elemMul||1)*(1+(RG.resonanceBonus(P).elementDamage||0))*(1+RG.elementUnityBonus(P).damage);
  // 仅玩家卡牌离散门槛；敌人处决、连续缺血增伤、视听警告与治疗抽牌资格不使用它。
  RG.lowHpThreshold=(base,P=RG.P)=>P.passives.bloodline?Math.min(RG.PASSIVES.bloodline.cap,Math.round((base+RG.PASSIVES.bloodline.increase)*100)/100):base;
  RG.windStacks=(P=RG.P)=>P?.passives.windwalker?Math.min(RG.PASSIVES.windwalker.maxStacks,Math.floor((P.windMoveT||0)+1e-9)):0;
  RG.windDamageBonus=(P=RG.P)=>RG.windStacks(P)*RG.PASSIVES.windwalker.values[P.passives.windwalker||0];
  RG.mountainReady=(P=RG.P)=>!!(P?.passives.mountain&&!P.moving&&!(P.dashT>0));
  RG.mountainReflection=(P=RG.P)=>RG.mountainReady(P)?1+RG.PASSIVES.mountain.reflection:1;
  RG.stanceReady=P=>!(P.dashT>0)&&(P.sinId==='sin_sloth'?!P.moving:P.stillT>RG.PASSIVES.stance.idleSeconds);
  RG.wrathBloodBonus=P=>P.sinId==='sin_wrath'&&P.passives.bloodheal&&P.wrathBloodT>0&&!P.critDLocked?Math.min(cfgOATH_NODESSin_wrathWrathBloodBonus.wrathBloodBonus_cap,P.wrathBloodStacks||0)*cfgOATH_NODESSin_wrathWrathBloodBonus.wrathBloodBonus_factor:0;
  RG.painFrequency=P=>P.painT>0?RG.PASSIVES.pain.values[P.passives.pain||0]*(P.sinId==='sin_wrath'?RG.OATH_NODES.sin_wrath.rules.painFrequency.painFrequency:1):0;
  // 普通护盾真实吸收也消耗下一击；免疫、幻象、正伤害为零和独立来源不消耗。
  RG.consumeDashEcho=function(result,P=RG.P){if(P.dashEchoT>0&&result.taken>0)RG.clearStatus(P,'dashEchoT');};
  RG.fullShieldBonus=(P=RG.P)=>P?.passives.fullshield&&P.shieldMax>0&&P.shield===P.shieldMax?RG.PASSIVES.fullshield.values[P.passives.fullshield]:0;
  RG.consumeShieldCounter=function(result,P=RG.P){if(P.shieldCounterT>0&&result.taken>0)RG.clearStatus(P,'shieldCounterT');};
  // 品质取最高，不按强化或同时持有档数重复增加暴伤；沿用玩家锁定与软上限。
  RG.burningCritBonus=function(target,P=RG.P){
    if(P.critDLocked||!(P.passives.ember||P.passives.ember_m||P.passives.ember_l)||!(target.el?.fire>0)||!(target.burnDps>0))return 0;
    let bonus=0;for(const id of ['ember','ember_m','ember_l']){const n=P.passives[id],d=RG.PASSIVES[id];if(Number.isInteger(n)&&n>0&&n<=d.maxLv)bonus=Math.max(bonus,d.burnCritBonus);}return bonus;
  };
  RG.crystalCloseBonus=(target,weaponId,P=RG.P)=>P.passives.crystal&&target.frozen>0&&target.iceFreezeT>0&&weaponId&&RG.weaponIsClose(weaponId)?RG.PASSIVES.crystal.closeFrozenBonus:0;
  RG.walkSpeed=(P=RG.P)=>P.speed*(1+(P.xpWindT>0?RG.PASSIVES.xpwind.values[P.passives.xpwind||0]:0)+(P.dodgeSpeedT>0&&P.passives.evade?RG.PASSIVES.evade.dodgeSpeed:0))*(P.slowT>0?RG.BALANCE.growth.walkSpeed.walkSpeed:1);
  RG.mobilityCritBonus=(e,P=RG.P)=>e.mobilityCritT>0&&(P.passives.ghost_img||P.passives.voidstep)&&!e.isClone&&!e.workshopHole&&!e.critImmune&&P.critCap!==0?RG.BALANCE.mobility.criticalBonus:0;
  // 里程碑只由实际持卡和原击杀层数派生，不重复改写永久属性/撤销账本。
  RG.slaughterBonus=function(kind,P=RG.P){
    if(!P?.passives.slaughter)return 0;const stacks=RG.run?.slaughterStacks,m=RG.PASSIVES.slaughter.milestones[kind];
    return m&&Number.isInteger(stacks)&&stacks>=m.stacks&&stacks<=RG.BALANCE.growth.slaughterBonus.stacks_threshold?m.value:0;
  };
  RG.markMobilityHit=function(e,hit,card){if(RG.P.passives[card]&&hit?.taken>0&&!e.dead&&!e.dying&&!e.isClone&&!e.workshopHole)RG.refreshStatus(e,'mobilityCritT',RG.BALANCE.mobility.markDuration);};
  const originalPassiveDescription=RG.passiveDescription;
  RG.passiveDescription=function(id,lv){
    let desc=originalPassiveDescription(id,lv);const P=RG.P;if(!P)return desc;
    if(P.sinId==='sin_wrath'&&id==='bloodheal')return '生命低于'+Math.round(RG.lowHpThreshold(RG.PASSIVES.bloodheal.threshold,P)*100)+'%时，有效击杀改获'+lv+'层暴伤\n每层+'+RG.configNumber(RG.OATH_NODES.sin_wrath.rules.wrathBloodBonus.wrathBloodBonus_factor*100)+'点，至多'+RG.OATH_NODES.sin_wrath.rules.wrathBloodBonus.wrathBloodBonus_cap+'层，'+RG.OATH_NODES.sin_wrath.rules.killEnemy.killEnemy_refreshStatusArg3+'秒刷新；仍禁疗';
    if(P.sinId==='sin_wrath'&&id==='pain')return '实际扣血后'+RG.PASSIVES.pain.duration+'秒攻频+'+RG.configNumber(RG.PASSIVES.pain.values[lv]*RG.OATH_NODES.sin_wrath.rules.painFrequency.painFrequency*100)+'%\n暴怒联动，不改变永久禁疗';
    if(P.sinId==='sin_greed'&&id==='goldguard')return '每持'+cfgBALANCEEconomy.wealthUnit+'局内金，承伤-'+RG.configNumber(RG.PASSIVES.goldguard.perHundred*100)+'%\n贪婪上限'+RG.PASSIVES.goldguard.caps.slice(1).map(v=>RG.configNumber(v*cfgOATH_NODESSin_greedWealthGuard.wealthGuard*100)).join('/')+'%，消费即时退档';
    if(P.sinId==='sin_greed'&&id==='goldrain')return RG.PASSIVES.goldrain.period+'秒原始周期耗'+RG.PASSIVES.goldrain.rates.slice(1).map(v=>RG.configNumber(v*100)).join('/')+'%（至少'+RG.PASSIVES.goldrain.minimum+'）局内金\n耗币×'+RG.PASSIVES.goldrain.damagePerCoin+'×'+cfgOATH_NODESSin_greedTriggerGoldRain.damage+'直接伤，最终基准≤'+RG.PASSIVES.goldrain.cap+'\n不足'+RG.PASSIVES.goldrain.minimum+'或无屏内目标不扣币';
    if(P.sinId==='sin_sloth'&&RG.PASSIVES[id]?.family==='stance')return desc.replace('静止'+RG.PASSIVES.stance.idleSeconds+'秒后','真实停步后立即');
    if(P.passives.bloodline){
      if(id==='goldbell')return '预计受击后生命≤'+Math.round(RG.lowHpThreshold(cfgPASSIVESGoldbellHurtPlayer.hurtPlayer_lowHpThresholdArg1,P)*100)+'%\n免伤并无敌'+cfgPASSIVESGoldbellHurtPlayer.iTimer+'秒，冷却'+RG.AUTO_CARD_CDS.goldbell+'秒';
      if(id==='bloodrush')return desc.replace(Math.round(RG.PASSIVES.bloodrush.threshold*100)+'%',Math.round(RG.lowHpThreshold(RG.PASSIVES.bloodrush.threshold,P)*100)+'%');
      if(id==='debt'||id==='bloodheal')return desc.replace(Math.round((id==='debt'?cfgPASSIVESDebtUpdate.update_lowHpThresholdArg1:RG.PASSIVES.bloodheal.threshold)*100)+'%',Math.round(RG.lowHpThreshold(id==='debt'?cfgPASSIVESDebtUpdate.update_lowHpThresholdArg1:RG.PASSIVES.bloodheal.threshold,P)*100)+'%');
    }
    if(P.passives.rally){
      if(id==='phantom')desc=desc.replace(cfgPASSIVESPhantomUpdate.duration_summonDurationArg1+' 秒',RG.summonDuration(cfgPASSIVESPhantomUpdate.duration_summonDurationArg1,P)+' 秒');
      if(id==='scapegoat')desc='每'+RG.AUTO_CARD_CDS.scapegoat+'/'+cfgPASSIVESScapegoatUpdateAutoCards.value_7+'秒召'+cfgPASSIVESScapegoatUpdateAutoCards.hp_2+'/'+cfgPASSIVESScapegoatUpdateAutoCards.hp+'生命替身\n新召持续'+RG.summonDuration(cfgPASSIVESScapegoatUpdateAutoCards.duration_summonDurationArg1,P)+'秒，容量'+RG.decoyLimit(P);
      if(id==='holylight')desc='每'+RG.AUTO_CARD_CDS.holylight+'秒感化最多'+RG.PASSIVES.holylight.targets+'只普通怪\n新召临友'+RG.summonDuration(RG.PASSIVES.holylight.rules.updateAutoCards.duration_summonDurationArg1,P)+'秒，容量'+RG.holyLightLimit(P);
      if(id==='loyal')desc=desc.replace('至多 '+cfgPASSIVESLoyalKillEnemy.killEnemy_summonLimitArg1,'至多 '+RG.summonLimit(cfgPASSIVESLoyalKillEnemy.killEnemy_summonLimitArg1,P));
    }
    return desc;
  };
  RG.effectiveCritChance=(P=RG.P,extra=0)=>Math.min(P.critCap??1,(P.critC||0)+(RG.resonanceBonus(P).critRate||0)+RG.slaughterBonus('critical',P)+extra);
  RG.critStreakBonus=(P=RG.P)=>P.passives.critstreak&&!P.critDLocked?Math.min(RG.PASSIVES.critstreak.maxStacks,P.critStreak||0)*RG.PASSIVES.critstreak.values[P.passives.critstreak]:0;
  RG.effectiveCritDamage=(P=RG.P,streak=true)=>P.critD+(P.critDLocked?0:(RG.resonanceBonus(P).critDamage||0)+(streak?RG.critStreakBonus(P):0)+RG.wrathBloodBonus(P));
  RG.weakMarkReady=(e,P=RG.P)=>!!(P.passives.weakmark&&e!==P&&!e.isClone&&!e.workshopHole&&!e.critImmune&&P.critCap!==0&&!(e.weakmarkCd>1e-9)&&(e.weakmarkHits||0)>=RG.PASSIVES.weakmark.hits[P.passives.weakmark]);
  RG.refreshCriticalState=function(P){if((!P.passives.critstreak||P.critDLocked)&&P.critStreak!==undefined)P.critStreak=0;};
  // 在受击方真实裁决之后计数；独立主动/元素/raw和有来源的派生不进入此入口。
  RG.onCriticalCardHit=function(e,hit){
    const P=RG.P;if(!(hit.taken>0)||hit.shieldBlocked||e.isClone||e.workshopHole)return;
    if(P.passives.weakmark&&!e.critImmune&&P.critCap!==0&&!(e.weakmarkCd>1e-9)){
      if(RG.weakMarkReady(e,P)){e.weakmarkHits=0;RG.refreshStatus(e,'weakmarkCd',RG.PASSIVES.weakmark.cooldown);}
      else e.weakmarkHits=Math.min(RG.PASSIVES.weakmark.hits[P.passives.weakmark],(e.weakmarkHits||0)+1);
    }
    if(P.passives.critstreak)P.critStreak=hit.crit&&!P.critDLocked?Math.min(RG.PASSIVES.critstreak.maxStacks,(P.critStreak||0)+1):0;
    if(!hit.crit||!P.passives.causality||(P.causalityCd||0)>1e-9)return;
    const slots=[...new Set(P.activeOrder)].filter(id=>RG.ACTIVES[id]&&P.actives[id]>0&&(P.activeCd[id]||0)>0);if(!slots.length)return;
    const def=RG.PASSIVES.causality,cut=(P._resonance||RG.refreshResonance(P)).counts.critical>=RG.resonanceThreshold(P,RG.RESONANCE_RULES.second)?def.resonanceReduction:def.reduction;
    for(const id of slots)P.activeCd[id]=Math.max(0,P.activeCd[id]-cut);RG.refreshStatus(P,'causalityCd',def.cooldown);
  };
  RG.reactionRange=r=>r*(1+(RG.resonanceBonus(RG.P).reactionRange||0)+RG.elementUnityBonus().range);
  RG.summonLimit=(base,P=RG.P)=>base+(RG.resonanceBonus(P).summonCapacity||0)+(P.passives.rally>=RG.PASSIVES.rally.capacityLevel?RG.PASSIVES.rally.capacityBonus:0);
  RG.decoyLimit=(P=RG.P)=>1+(P.passives.rally>=RG.PASSIVES.rally.capacityLevel?RG.PASSIVES.rally.capacityBonus:0);
  RG.holyLightLimit=(P=RG.P)=>RG.BALANCE.growth.holyLightLimit.holyLightLimit_offset+(P.passives.rally>=RG.PASSIVES.rally.capacityLevel?RG.PASSIVES.rally.capacityBonus:0);
  RG.summonDuration=(base,P=RG.P)=>Math.round(base*(1+RG.PASSIVES.rally.durationPerLevel*(P.passives.rally||0))*100)/100;
  // 只计实体：仆人/炮台/临友、有限寿命幻影与替身；残像、弹丸和敌人分身不计。
  RG.liveSummonCount=function(limit=Infinity){
    let n=0;for(const a of RG.allies||[])if(!a.dead&&(a.puppet&&a.hp>0||a.source==='loyal'&&(a.hp==null||a.hp>0)||a.source==='holylight'&&a.hp>0&&a.t>0)){if(++n>=limit)return n;}
    for(const a of RG.phantoms||[])if(!a.dead&&a.t>0){if(++n>=limit)return n;}
    for(const a of RG.decoys||[])if(!a.dead&&a.decoy&&a.hp>0&&a.t>0){if(++n>=limit)return n;}return n;
  };
  RG.legionBonus=(P=RG.P)=>P.passives.legion?Math.min(RG.PASSIVES.legion.caps[P.passives.legion],RG.liveSummonCount(Math.round(RG.PASSIVES.legion.caps[P.passives.legion]/RG.PASSIVES.legion.perAlly))*RG.PASSIVES.legion.perAlly):0;
  RG.onSummonExit=function(a){
    if(a.resonanceExited||![RG.allies,RG.phantoms,RG.decoys].some(items=>items?.includes(a)))return;a.resonanceExited=true;const P=RG.P;
    if(P&&RG.resonanceBonus(P).summonExitFrequency){if(!(P.summonAfterT>0))RG.addText(P.x,P.y-54,'召唤共鸣','#4ade80',13);P.summonAfterT=RG.BALANCE.growth.onSummonExit.summonAfterT;}
    if(P?.passives.valhalla&&P.hp>0&&RG.state==='play'&&(RG.phantoms.includes(a)||a.puppet||a.decoy||['loyal','holylight'].includes(a.source))&&(a.dead||a.hp<=0||a.t<=0)){
      const def=RG.PASSIVES.valhalla;
      if(RG.autoFx.filter(f=>f.type==='valhalla'&&!f.done).length<cfgPASSIVESValhallaOnSummonExit.length_threshold){
        const phantom=RG.phantoms.includes(a),w=Object.keys(P.weapons)[0],base=a.baseDamage??(w&&RG.weaponStat(w,P.weapons[w],P.evolved[w]).dmg||cfgPASSIVESValhallaOnSummonExit.base_offset+P.level*cfgPASSIVESValhallaOnSummonExit.base_factor);
        const dmg=Math.min(def.cap,phantom?base*cfgPASSIVESValhallaOnSummonExit.dmg_factor:(a.maxhp||0)*cfgPASSIVESValhallaOnSummonExit.dmg_factor_2);
        if(dmg>0)RG.autoFx.push({type:'valhalla',x:a.x,y:a.y,t:0,max:0,r:def.radius,dmg});
      }
      RG.refreshStatus(P,'valhallaT',def.duration);
    }
  };
  RG.wealthGuard=(P=RG.P,coins=RG.run?.coins||0)=>P?.passives.goldguard?Math.min(RG.PASSIVES.goldguard.caps[P.passives.goldguard]*(P.sinId==='sin_greed'?cfgOATH_NODESSin_greedWealthGuard.wealthGuard:1),Math.floor(coins/cfgBALANCEEconomy.wealthUnit)*RG.PASSIVES.goldguard.perHundred):0;
  RG.wealthDamage=function(P=RG.P,coins=RG.run?.coins||0){const per=RG.resonanceBonus(P).wealthDamage;return per?Math.min(RG.BALANCE.growth.wealthDamage.wealthDamage_cap,Math.floor(coins/100)*per):0;};
  RG.onWealthKill=function(e){
    const lv=RG.P?.passives.scavenger,def=RG.PASSIVES.scavenger;
    if(lv&&!e.isClone&&!e.isEcho&&!e.noCoin&&!e.workshopHole&&!e.workshopWorm&&e.xp>0&&Math.random()<def.chances[lv])RG.addCoin(def.amount);
  };
  RG.triggerGoldRain=function(P=RG.P){
    const lv=P?.passives.goldrain,def=RG.PASSIVES.goldrain;
    if(!lv||RG.run.coins<def.minimum)return false;
    const targets=RG.enemies.filter(e=>!e.dead&&!e.dying&&!e.isClone&&!e.isEcho&&!e.workshopHole&&Math.abs(e.x-RG.cam.x)<=RG.W/cfgBALANCEGrowthTriggerGoldRain.targets_divisor+e.r&&Math.abs(e.y-RG.cam.y)<=RG.H/cfgBALANCEGrowthTriggerGoldRain.targets_divisor+e.r);
    if(!targets.length)return false;
    const cost=Math.min(RG.run.coins,Math.max(def.minimum,Math.floor(RG.run.coins*def.rates[lv])));
    RG.run.coins-=cost;
    const damage=Math.min(def.cap,cost*def.damagePerCoin*RG.playerDamageMul()*(P.sinId==='sin_greed'?cfgOATH_NODESSin_greedTriggerGoldRain.damage:1));
    for(const e of targets)RG.dealPure(e,damage,false,false,'goldrain');
    RG.rings.push({x:P.x,y:P.y,r:12,maxR:Math.max(RG.W,RG.H)/2,life:.4,maxLife:.4,color:'#ffd166'});
    RG.addText(P.x,P.y-45,'金雨 -'+cost+'金','#ffd166',15);RG.playSfx('nova');return true;
  };
  RG.resonanceOfferNote=function(P,o){
    const before=RG.resonanceCounts(P),next={...P,passives:{...P.passives},actives:{...P.actives},activeOrder:[...(P.activeOrder||[])],weapons:{...P.weapons},weaponElements:{...P.weaponElements}};
    if(o.kind==='passive')next.passives[o.id]=o.lv;
    else if(o.kind==='active'){next.actives[o.id]=o.lv;if(!next.activeOrder.includes(o.id))next.activeOrder.push(o.id);}
    else if(o.kind==='oathnode')next.sinId=o.id;
    else if(o.kind==='elementweapon')next.weaponElements[o.id]={type:o.element,level:1};
    else return '';
    const after=RG.resonanceCounts(next),notes=[];
    for(const [id,r]of Object.entries(RG.RESONANCES)){
      const def=o.kind==='passive'?RG.PASSIVES[o.id]:null,family=def&&(def.family||o.id.replace(/_(s|m|l|xl)$/,''));
      const first=RG.resonanceThreshold(P,RG.RESONANCE_RULES.first),second=RG.resonanceThreshold(P,RG.RESONANCE_RULES.second),nextFirst=RG.resonanceThreshold(next,RG.RESONANCE_RULES.first),nextSecond=RG.resonanceThreshold(next,RG.RESONANCE_RULES.second);
      const related=o.id==='resonanceheart'?after[id]>=nextFirst:family?r.families.includes(family):o.kind==='active'?r.actives?.includes(o.id):o.kind==='oathnode'?r.sins?.includes(o.id):id==='element';if(!related)continue;
      const threshold=before[id]<first?nextFirst:nextSecond,transition=before[id]>=second?second:after[id]>before[id]?before[id]+'→'+after[id]:after[id];
      const brief3={element:'元伤+10%',critical:'暴率+5点',summon:r.text3,shield:'回盾+25%',wealth:r.text3};
      const reward=before[id]<first&&after[id]>=nextFirst?brief3[id]:before[id]<second&&after[id]>=nextSecond?(id==='critical'&&P.critDLocked?'暴伤锁定':r.text5):'';
      notes.push(r.name+' '+transition+'/'+threshold+(reward?' · '+reward:''));
    }
    return notes.join(' · ')+(notes.length&&o.kind==='passive'&&Object.keys(before).every(id=>before[id]===after[id])?'（同族）':'');
  };
  // 局内商店只消费本局资金；临时赠金先花，绝不转入局外余额。
  RG.runShopBalance=()=>Math.floor((RG.run?.coins||0)+(RG.run?.openingGold||0));
  RG.recordTier=time=>Number.isFinite(time)?Math.max(0,Math.floor(time/cfgBALANCEEconomy.recordStepSeconds)):0;
  RG.recordRewardNote=()=>`生存纪录每${RG.fmtTime(cfgBALANCEEconomy.recordStepSeconds)}一档 · 新档位${cfgBALANCEEconomy.mapRecord}金`;
  RG.runItemConfig=id=>RG.RUN_SHOP_ITEMS[id]||(id==='p_boltburst'?RG.perkConfig(id):null);
  RG.runItemTargets=(P=RG.P)=>Object.keys(P.weapons).filter(id=>RG.WEAPONS[id]&&P.weapons[id]>0&&!P.evolved[id]&&P.weapons[id]<RG.WEAPONS[id].maxLv);
  RG.runItemReason=function(id,target,P=RG.P,run=RG.run){
    if(!P||!(P.hp>0)||!run||run.rushMode)return '当前不能购买';
    if(id==='p_boltburst')return P.boltDouble?'本局已购买':!P.weapons.bolt?'需要持有魔弹':'';
    const d=RG.RUN_SHOP_ITEMS[id];if(!d)return '商品不存在';
    if((run.shopCounts?.[id]||0)>=Math.min(d.limit,d.prices.length))return '本局已售罄';
    if(d.growth&&(run.shopGrowth||0)>=RG.BALANCE.economy.shopGrowthLimit)return '成长额度已用完';
    if(id==='u_heal'){
      if(P.healBan||P.hpLocked||P.healBlocked||P.spaceWoundT>0)return '当前无法治疗';
      // 入店可能正好发生在领域生效的同帧，不能只看上一帧的healBlocked。
      if((RG.domains||[]).some(dm=>dm.type==='healnull'&&!dm.dead&&dm.t>0&&!(dm.warn>0)&&!dm.playerDebuffBlocked&&!(P.workshopRuneT>0&&P.workshopRuneOwner===dm.bossOwner)&&Math.hypot(P.x-dm.x,P.y-dm.y)<dm.r))return '当前处于禁疗领域';
      if(P.hp>=P.maxhp)return '生命已满';
    }
    if(id==='u_shield'&&(!(P.shieldMax>0)||P.shield>=P.shieldMax))return '没有缺损的普通护盾';
    if(id==='u_weapon'&&(!target?!RG.runItemTargets(P).length:!RG.runItemTargets(P).includes(target)))return '没有可研磨的武器';
    return '';
  };
  RG.openRunShop=function(){
    const r=RG.run;if(!r||r.rushMode||!RG.P||RG.P.hp<=0||['over','win'].includes(RG.state))return false;
    if(r.shopRules===RG.BALANCE.economy.shopRules&&r.shopStockVisit!==r.shopVisits){
      r.shopStock=Object.keys(RG.RUN_SHOP_ITEMS).concat('p_boltburst').filter(id=>!RG.runItemReason(id)).map(item=>({
        id:r.shopVisits+'/'+item,item,price:RG.RUN_SHOP_ITEMS[item]?.prices[r.shopCounts[item]||0]??RG.perkConfig(item).price,
        targets:item==='u_weapon'?RG.runItemTargets():[],bought:false
      }));
      r.shopStockVisit=r.shopVisits;
      // 新店已没有任何有效服务时直接越过，不让后期每六级弹一次空货架。
      if(!r.shopStock.length){
        r.shopOpen=false;r.shopVisits++;if(r.shopVisits>=RG.BALANCE.economy.openingExpiresAfter)r.openingGold=0;
        RG.runShopSelection=null;RG.runShopPreview=null;RG.checkpointPending=true;return false;
      }
    }
    RG.runShopSelection=null;RG.runShopPreview=null;r.shopOpen=true;RG.state='runshop';RG.checkpointPending=true;return true;
  };
  RG.closeRunShop=function(){
    if(RG.state!=='runshop'||!RG.run.shopOpen)return false;
    RG.run.shopOpen=false;RG.run.shopVisits=(RG.run.shopVisits||0)+1;
    if(RG.run.shopVisits>=RG.BALANCE.economy.openingExpiresAfter)RG.run.openingGold=0;
    RG.runShopSelection=null;RG.runShopPreview=null;
    RG.state='play';RG.openNextLevelUp();RG.checkpointPending=true;return true;
  };
  RG.previewRunItem=function(id,target){
    const r=RG.run,P=RG.P;if(RG.state!=='runshop'||!r?.shopOpen||!P||P.hp<=0||r.rushMode)return null;
    const legacy=r.shopRules!==RG.BALANCE.economy.shopRules;
    const entry=legacy?(id==='p_boltburst'?{id,item:id,price:RG.perkConfig(id).price,bought:P.boltDouble,targets:[]}:null):r.shopStock.find(e=>e.id===id||e.item===id);
    if(!entry||entry.bought)return null;
    const item=entry.item,d=RG.runItemConfig(item);
    if(item==='u_weapon'){target=target||entry.targets.find(w=>!RG.runItemReason(item,w));if(!entry.targets.includes(target))return null;}
    const reason=legacy?'':RG.runItemReason(item,target);if(reason)return null;
    const price=entry.price,gift=Math.min(price,r.openingGold||0),coins=r.coins-(price-gift);
    const after=item==='u_heal'?Math.min(P.maxhp,P.hp+P.maxhp*d.healRatio):item==='u_shield'?Math.min(P.shieldMax,P.shield+d.amount):item==='u_reroll'?P.rerolls+d.amount:item==='u_weapon'?P.weapons[target]+1:true;
    const result=item==='u_heal'?'生命 '+RG.configNumber(P.hp)+' → '+RG.configNumber(after)+' / '+RG.configNumber(P.maxhp):item==='u_shield'?'普通护盾 '+P.shield+' → '+after+' / '+P.shieldMax:item==='u_reroll'?'选卡重骰 '+P.rerolls+' → '+after:item==='u_weapon'?RG.WEAPONS[target].name+' Lv'+P.weapons[target]+' → Lv'+after:'魔弹每次攻击补射一轮';
    return {id:entry.id,item,target:target||null,price,gift,coins,after,result,enough:coins>=0,
      stamp:JSON.stringify([r.id,r.shopVisits,item,target,price,r.coins,r.openingGold,r.shopGrowth,r.shopCounts,P.hp,P.maxhp,P.shield,P.shieldMax,P.rerolls,P.weapons,P.evolved,P.boltDouble]),
      wealth:'黄金护体 '+Math.round(RG.wealthGuard(P)*100)+'% → '+Math.round(RG.wealthGuard(P,Math.max(0,coins))*100)+'% · 财富增伤 '+Math.round(RG.wealthDamage(P)*100)+'% → '+Math.round(RG.wealthDamage(P,Math.max(0,coins))*100)+'%'};
  };
  RG.buyRunItem=function(id,target,expected){
    const p=RG.previewRunItem(id,target);if(!p||!p.enough||expected&&expected.stamp!==p.stamp)return false;
    const r=RG.run,P=RG.P,entry=r.shopStock?.find(e=>e.id===p.id),d=RG.runItemConfig(p.item);
    const before={coins:r.coins,gift:r.openingGold,hp:P.hp,shield:P.shield,rerolls:P.rerolls,weapon:p.target&&P.weapons[p.target],bolt:P.boltDouble,growth:r.shopGrowth,counts:{...r.shopCounts}};
    try{
      r.openingGold=(r.openingGold||0)-p.gift;r.coins=p.coins;
      if(p.item==='u_heal')P.hp=p.after;
      else if(p.item==='u_shield')P.shield=p.after;
      else if(p.item==='u_reroll')P.rerolls=p.after;
      else if(p.item==='u_weapon')P.weapons[p.target]=p.after;
      else P.boltDouble=true;
      if(entry){entry.bought=true;r.shopCounts[p.item]=(r.shopCounts[p.item]||0)+1;if(d.growth)r.shopGrowth++;}
    }catch(error){
      r.coins=before.coins;r.openingGold=before.gift;P.hp=before.hp;P.shield=before.shield;P.rerolls=before.rerolls;P.boltDouble=before.bolt;r.shopGrowth=before.growth;r.shopCounts=before.counts;
      if(p.target)P.weapons[p.target]=before.weapon;if(entry)entry.bought=false;return false;
    }
    RG.runShopPreview=null;RG.playSfx('buy');
    const saved=RG.saveRunCheckpoint?.()===true;RG.checkpointPending=!saved;
    if(RG.showNotice)RG.showNotice(saved?'购买完成 · '+p.result:'购买已生效，现场保存失败，请勿退出',!saved);
    return true;
  };
  RG.migrateEconomyMeta=function(meta){
    if(!meta)return false;let changed=false;
    if(meta.perks.includes('p_boltburst')){meta.perks=meta.perks.filter(id=>id!=='p_boltburst');meta.coins+=RG.perkConfig('p_boltburst').price;changed=true;}
    for(const lv of meta.bossRush?.cleared||[])for(const id of RG.BOSS_WEAPON_REWARDS[lv-1]||[])if(!meta.wUnlocked.includes(id)){meta.wUnlocked.push(id);changed=true;}
    return changed;
  };
  // ---------- 伤害 ----------
  RG.addCoin = function (n) {
    if (!RG.run||RG.run.rushMode||!Number.isFinite(n)||n<=0) return;
    const gain=n*(RG.P?RG.P.coinMul*(1+(RG.resonanceBonus().coinGain||0)):1);
    RG.run.coins += gain;
    // 复利誓约:局内每满 100 金币 → 伤害/生命/移速各 +1%，最多 50 层。
    if (RG.P && RG.P.passives && RG.P.passives.compound) {
      RG.run.coinAcc = (RG.run.coinAcc || 0) + gain;
      RG.run.compoundStacks = RG.run.compoundStacks || 0;
      while (RG.run.coinAcc >= cfgPASSIVESCompoundAddCoin.coinAcc_threshold && RG.run.compoundStacks < cfgPASSIVESCompoundAddCoin.compoundStacks_threshold) {
        RG.run.coinAcc -= cfgPASSIVESCompoundAddCoin.coinAcc;
        RG.run.compoundStacks++;
        RG.P.dmgMul *= cfgPASSIVESCompoundAddCoin.dmgMul;
        if (!RG.P.hpLocked) {
          RG.P.maxhp = Math.round(RG.P.maxhp * cfgPASSIVESCompoundAddCoin.maxhp_factor);
          if(!RG.P.healBan&&!RG.P.healBlocked)RG.P.hp = Math.min(RG.P.maxhp, RG.P.hp * cfgPASSIVESCompoundAddCoin.hp_factor);
        }
        RG.P.speed *= cfgPASSIVESCompoundAddCoin.speed;
      }
      if(RG.run.compoundStacks>=cfgPASSIVESCompoundAddCoin.compoundStacks_threshold)RG.run.coinAcc=0;
    }
  };
  RG.hasEvoReq = function (req) {
    const ps = RG.P ? RG.P.passives : {};
    if (req.endsWith("*")) { const pre = req.slice(0, -1); return Object.keys(ps).some(k => k.startsWith(pre)); }
    return !!ps[req] || Object.keys(ps).some(id=>ps[id]>0&&RG.PASSIVES[id]?.family===req);
  };
  const matchesEvoReq = (id, req) => req.endsWith("*") ? id.startsWith(req.slice(0, -1)) : id === req || RG.PASSIVES[id]?.family === req;
  function hasPlayerEvoReq(P, req) { return Object.keys(P.passives || {}).some(id => P.passives[id] > 0 && matchesEvoReq(id, req)); }
  RG.activeEvolution=(P,id)=>RG.ACTIVE_EVOLVE[id]?.branches.find(b=>b.id===P.activeEvolved?.[id])||null;
  RG.canEvolveActive=(P,id)=>!!(RG.ACTIVE_EVOLVE[id]&&P.actives?.[id]===RG.ACTIVES[id].maxLv&&P.activeOrder?.includes(id)&&!P.activeEvolved?.[id]&&hasPlayerEvoReq(P,RG.ACTIVE_EVOLVE[id].req));
  // 施法分支快照独立于刚取得的进化：旧超频到期后，下次释放才使用新分支。
  RG.overdriveCast=P=>RG.ACTIVE_EVOLVE.overdrive?.branches.find(b=>b.id===P.overdriveCastBranch)||null;
  RG.activeWait=(P,id)=>Math.max(P.activeCd?.[id]||0,id==='overdrive'&&RG.activeEvolution(P,id)?Math.max(P.overdriveT||0,P.overdriveWeakT||0):id==='aegis'&&RG.activeEvolution(P,id)?P.aegisEvoT||0:0);
  RG.aegisCast=P=>RG.ACTIVE_EVOLVE.aegis?.branches.find(b=>b.id===P.aegisCastBranch)||null;
  RG.tickAegis=function(P,dt){if(P.aegisEvoT>0){P.aegisEvoT=Math.max(0,P.aegisEvoT-dt);if(!(P.activeGuard>0))P.aegisEvoT=0;if(!P.aegisEvoT)P.activeGuard=0;}};
  RG.overdriveDamageMul=P=>P.overdriveT>0?(RG.overdriveCast(P)?.damageMul??RG.ACTIVES.overdrive.damageMul):1;
  RG.tickOverdrive=function(P,dt){
    const before=P.overdriveT||0;
    if(before>0){
      P.overdriveT=Math.max(0,before-dt);if(P.overdriveCapLeft>0)P.overdriveCapLeft=Math.max(0,P.overdriveCapLeft-dt);
      if(!P.overdriveT){const cast=RG.overdriveCast(P);P.overdriveCapLeft=0;if(cast?.weakness){P.overdriveWeakT=Math.max(0,cast.weakness-Math.max(0,dt-before));RG.addText(P.x,P.y-38,'过载虚弱','#fb923c',15);}}
    }else RG.tickStatus(P,'overdriveWeakT',dt);
  };
  RG.extendOverdrive=function(e){const P=RG.P,cast=P&&RG.overdriveCast(P);if(!cast?.extension||!(P.overdriveT>0)||!(e.xp>0)||e.noCoin||e.isClone||e.isEcho)return;P.overdriveT=Math.min(P.overdriveCapLeft,P.overdriveT+cast.extension);};
  RG.clearActiveSceneEffects=function(){
    RG.removeBattleEffects('active','collapse',['autoFx']);
    if(RG.P&&RG.overdriveCast(RG.P))for(const k of ['overdriveT','overdriveCapLeft','overdriveWeakT'])RG.clearStatus(RG.P,k);
    RG.removeBattleEffects('active','aegis',['bullets']);if(RG.P?.aegisEvoT>0){RG.P.activeGuard=0;RG.clearStatus(RG.P,'aegisEvoT');}
    RG.autoFx=RG.autoFx.filter(f=>f.type!=='valhalla');if(RG.P)RG.clearStatus(RG.P,'valhallaT');
  };
  RG.activeBuildInfo=function(P,id){
    const a=RG.ACTIVES[id],branch=RG.activeEvolution(P,id),evo=RG.ACTIVE_EVOLVE[id],lv=P.actives[id];
    const parameters=id==='collapse'?'基础'+a.damage(lv)+'，范围'+a.radius(lv)+'，':'';
    const desc=branch?branch.desc+'\n'+parameters+'冷却'+a.cooldown(lv)+'秒；前置移除仍保留':a.desc(lv)+(evo?'\n进化：Lv'+lv+'/'+a.maxLv+'，'+(hasPlayerEvoReq(P,evo.req)?'已持有':'缺')+RG.PASSIVES[evo.req].name:'');
    return {title:(branch?'★ '+branch.name:a.name)+' Lv'+lv,desc,icon:id};
  };
  function enablesEvolution(P, id) {
    return !(P.passives[id] > 0) && Object.keys(P.weapons || {}).some(w => {
      const ev = RG.EVOLVE[w];
      return ev && !P.evolved?.[w] && matchesEvoReq(id, ev.req) && !hasPlayerEvoReq(P, ev.req);
    });
  }
  // 冲刺闪避:短距高速位移 + 短暂无敌
  RG.tryDash = function () {
    const P = RG.P;
    if (!P || RG.state !== "play" || P.dashCd > 0 || (P.stunT || 0) > 0) return;
    const inp = RG.getInput();
    const a = (inp.x || inp.y) ? Math.atan2(inp.y, inp.x) : P.face;
    P.dashA = a; P.dashT = cfgBALANCEGrowthTryDash.dashT; if (P.sinId === "sin_sloth") P.slothStacks = Math.min(RG.OATH_NODES.sin_sloth.maxDashStacks, (P.slothStacks || 0) + 1);
    if(P.passives.dashecho){P.echoDashActive=true;P.echoDashMoved=false;}
    P.dashCd = cfgBALANCEGrowthTryDash.dashCd_factor * (P.dashCdMul || 1) * (P.globalCdMul || 1) + (P.slothStacks || 0) * RG.OATH_NODES.sin_sloth.extraCooldown;
    P.voidstepHits = new Set();
    P.dashCdMax = P.dashCd;
    P.dashGhost = P.dashT;   // 只有闪现位移本身可穿墙；结束后的 0.1 秒缓起必须恢复普通碰撞
    // 幽影残像:冲刺点留下 1.5 秒残像,接触的敌人受 raw 创伤并短促硬直(复用冻结表现)
    if (P.passives && P.passives.ghost_img) {
      (RG.afterimages = RG.afterimages || []).push({ x: P.x, y: P.y, r: cfgPASSIVESGhost_imgTryDash.r, t: cfgPASSIVESGhost_imgTryDash.t, dmg: cfgPASSIVESGhost_imgTryDash.dmg_factor * (1 + RG.run.t / 60 * cfgPASSIVESGhost_imgTryDash.dmg_factor_2) * RG.playerDamageMul() * cfgPASSIVESGhost_imgTryDash.dmg_factor_3, hitSet: new Set() });
      RG.rings.push({ x: P.x, y: P.y, r: 18, maxR: 18, life: 1.5, maxLife: 1.5, color: "#c4b5fd" });
    }
    P.dashGraze = cfgBALANCEGrowthTryDash.dashGraze;   // 完美闪避判定窗
    P.iTimer = Math.max(P.iTimer, cfgBALANCEGrowthTryDash.iTimer_floor);
    RG.burst(P.x, P.y, "#7c6cf0", 6, 130);
    RG.tone(320, 0.08, "triangle", 0.02, -40);
  };
  // 主动技能:最多携带 2 个。桌面 Q/E,触屏点击技能圆钮。
  RG.useActive = function (slotOrId,copy=false) {
    const P = RG.P;
    if (!P || RG.state !== "play") return false;
    const id = typeof slotOrId === "number" ? P.activeOrder[slotOrId] : slotOrId;
    const def = RG.ACTIVES && RG.ACTIVES[id], lv = (P.actives && P.actives[id]) || 0;
    if (!def || lv <= 0 || (!copy&&RG.activeWait(P,id)>0)) return false;
    if(copy&&(!P.activeOrder.includes(id)||!P.passives.mirrorecho||id==='overdrive'&&(P.overdriveT>0||P.overdriveWeakT>0)||id==='aegis'&&(P.activeGuard>0||P.aegisEvoT>0)))return false;
    const scale=copy?RG.PASSIVES.mirrorecho.scale:1;
    if (id === "collapse") {
      const branch=RG.activeEvolution(P,id);
      const rr = def.radius(lv);
      const dmg = def.damage(lv) * (1 + RG.run.t / 60 * cfgACTIVESCollapseUseActive.dmg_factor) * RG.playerDamageMul()*scale;
      for (const e of RG.enemies) {
        if (e.dead || e.dying) continue;
        const dx = P.x - e.x, dy = P.y - e.y, d = Math.hypot(dx, dy);
        if (d > rr + e.r) continue;
        const pull = (e.boss ? cfgACTIVESCollapseUseActive.pull : Math.min(cfgACTIVESCollapseUseActive.pull_cap, cfgACTIVESCollapseUseActive.pull_offset + (rr - d) * cfgACTIVESCollapseUseActive.pull_factor))*scale;
        if (d > 1&&!e.workshopHole) { e.x += dx / d * pull; e.y += dy / d * pull; }
        if(branch?.id!=='starburst')RG.dealPure(e,dmg,false,false,'active:collapse');
      }
      if(branch){
        const fields=RG.autoFx.filter(f=>f.active==='collapse'&&!f.done);
        if(fields.length>=cfgACTIVESCollapseUseActive.length_threshold)fields[0].done=true;
        RG.autoFx.push({type:branch.id==='horizon'?'collapseWell':'collapseBurst',active:'collapse',branch:branch.id,x:P.x,y:P.y,r:rr,t:branch.duration,max:branch.duration,tick:branch.period||0,dmg,damageSource:'active:collapse',copyScale:scale});
      }
      RG.rings.push({ x: P.x, y: P.y, r: 12, maxR: rr, life: 0.42, maxLife: 0.42, color: def.color });
      RG.burst(P.x, P.y, def.color, 18, 240); RG.cam.shake = Math.max(RG.cam.shake, 7);
      RG.playSfx("nova"); RG.vibrate([18, 25, 30], "active", 120);
    } else if (id === "overdrive") {
      const branch=RG.activeEvolution(P,id);P.overdriveT=(branch?.duration||def.duration(lv))*scale;P.overdriveCastBranch=branch?.id||'base';P.overdriveCapLeft=(branch?.total||0)*scale;P.overdriveWeakT=0;
      RG.addText(P.x, P.y - 38, (branch?.name||'超频')+'启动!', def.color, 18);
      RG.rings.push({ x: P.x, y: P.y, r: 12, maxR: 82, life: 0.35, maxLife: 0.35, color: def.color });
      RG.playSfx("buypower"); RG.vibrate(24, "active", 120);
    } else if (id === "aegis") {
      const branch=RG.activeEvolution(P,id);P.aegisCastBranch=branch?.id||'base';P.aegisEvoT=(branch?.duration||0)*scale;P.aegisCleared=0;P.aegisReflected=0;
      P.activeGuard = Math.max(P.activeGuard || 0, Math.max(copy?RG.PASSIVES.mirrorecho.minimumGuards:1,Math.floor(def.guards(lv)*scale)));
      P.iTimer = Math.max(P.iTimer, def.invul(lv)*scale);
      RG.addText(P.x, P.y - 38, (branch?.name||'相位壁垒')+' ×'+P.activeGuard, def.color, 18);
      RG.rings.push({ x: P.x, y: P.y, r: 12, maxR: 64, life: 0.4, maxLife: 0.4, color: def.color });
      RG.playSfx("block"); RG.vibrate(20, "active", 120);
    } else if (id === "thunder") {
      // 落雷只有元素伤害层，不先结算普通攻击再重复附魔；每次重新筛选存活目标。
      const damage=def.damage(lv)*(1+Math.min(RG.run.t,cfgACTIVESThunderUseActive.damage_cap)/60*cfgACTIVESThunderUseActive.damage_factor)*RG.playerDamageMul()*RG.playerElementMul(P)*scale;
      const marked=new Set();
      RG.withDamageSource('active:thunder',()=>{
        for(let n=0;n<def.strikes(lv);n++){
          const targets=RG.enemies.filter(e=>!e.dead&&!e.dying&&!e.isClone&&dist2(P.x,P.y,e.x,e.y)<=def.range*def.range);
          if(!targets.length)break;
          const e=pick(targets),accepted=RG.dealElement(e,damage,'elec');
          if(!e.dead&&!e.dying)RG.applyElem(e,'elec',cfgACTIVESThunderUseActive.useActive_applyElemArg3,accepted,damage);
          if(!marked.has(e)){marked.add(e);RG.autoFx.push({type:'thunder',x:e.x,y:e.y,t:.3,max:.3});}
        }
      });
      RG.playSfx('overload');RG.vibrate(24,'active',120);
    } else if (id === "chrono") {
      // 局部控制只暂停敌人行动；已经离体的弹丸、场地和导演继续更新。
      for(const e of RG.enemies)if(!e.dead&&!e.dying&&!e.isClone&&!e.workshopHole&&dist2(P.x,P.y,e.x,e.y)<=def.range*def.range)
        RG.refreshStatus(e,'chronoT',(e.boss?def.bossDuration(lv):def.duration(lv))*scale);
      RG.rings.push({x:P.x,y:P.y,r:12,maxR:100,life:.4,maxLife:.4,color:def.color});
      RG.addText(P.x,P.y-38,'时间静止',def.color,18);RG.playSfx('superconduct');RG.vibrate(20,'active',120);
    }
    if(!copy){P.activeCd[id] = Math.max(1, def.cooldown(lv) * (P.globalCdMul || 1));if(P.activeOrder.includes(id))P.lastActiveId=id;if(P.passives.chargecircuit)RG.refreshStatus(P,'chargeAfterT',RG.PASSIVES.chargecircuit.rules.useActive.useActive_refreshStatusArg3);}
    return true;
  };
  // 完美闪避:冲刺判定窗内擦弹 → 子弹时间 + 短暂增伤
  RG.perfectDodge = function () {
    const P = RG.P;
    RG.timeStop = Math.max(RG.timeStop, cfgBALANCEGrowthPerfectDodge.timeStop_floor);
    P.pdBuff = cfgBALANCEGrowthPerfectDodge.pdBuff;
    P.iTimer = Math.max(P.iTimer, cfgBALANCEGrowthPerfectDodge.iTimer_floor);
    RG.addText(P.x, P.y - 34, "完美闪避!", "#c4b5fd", 15);
    RG.vibrate(25);
    RG.rings.push({ x: P.x, y: P.y, r: 10, maxR: 70, life: 0.3, maxLife: 0.3, color: "#c4b5fd" });
    RG.tone(660, 0.12, "triangle", 0.03, -30);
    // 惩罚反击:完美闪避触发范围反击(raw 基准)
    const pn = RG.passiveValue(P,"punish");
    if (pn) {
      const rr = cfgPASSIVESPunishPerfectDodge.rr, pd = (cfgPASSIVESPunishPerfectDodge.pd_offset + RG.P.level * cfgPASSIVESPunishPerfectDodge.pd_factor) * (1 + RG.run.t / 60 * cfgPASSIVESPunishPerfectDodge.pd_factor_2) * pn;
      RG.rings.push({ x: P.x, y: P.y, r: 12, maxR: rr, life: 0.25, maxLife: 0.25, color: "#c4b5fd" });
      for (const e of RG.enemies) { if (!e.dead && Math.hypot(e.x - P.x, e.y - P.y) < rr + e.r) RG.dealPure(e, pd); }
      RG.addText(P.x, P.y - 26, "惩罚反击!", "#c4b5fd", 14);
    }
  };
  RG.passiveAvailable = function (P, id, source) {
    const def = RG.PASSIVES[id];
    if(def?.realmOnly&&source!=='realmreward')return false;
    if(def?.mainOnly&&RG.run?.rushMode)return false;
    if (!def || (P.passives[id] || 0) >= def.maxLv || (id==="revive" && P.reviveSpent) || (id==="injury"&&(P.injuryBonus||0)>=RG.PASSIVES.injury.rules.passiveAvailable.range_threshold) ||
      (["bloodaid","frailheal"].includes(id) && (P.healBan||P.hpLocked||P.healBlocked||P.hp>=P.maxhp)) ||
      ((P.healBan || P.hpLocked) && (id.startsWith("hp_") || ["regen", "heart"].includes(id))) ||
      ((P.healBan || P.hpLocked) && id==='bloodheal') ||
      (P.hpLocked && id === "pact") || (id === "allin" && P.shieldMax > 0) ||
      (P.passives.allin && (["shieldcore", "prism"].includes(id)||def.family==="thorns")) || (P.critCap && id === "focus")) return false;
    // 只过滤明确封顶的纯属性卡；首次取得当前武器所缺前置仍有进化价值。
    const caps = { shell:["armor",cfgBALANCEGrowthPassiveAvailable.shell], evade:["evade",cfgBALANCEGrowthPassiveAvailable.evade], reflect_b:["evade",cfgBALANCEGrowthPassiveAvailable.reflect_b], frost:["freezeC",cfgBALANCEGrowthPassiveAvailable.frost] };
    const familyCaps={ember:1,ricochet:1,petrify:1,deflect:1,doom:1,element_slow:1,luck:1,projectile_guard:cfgBALANCEGrowthPassiveAvailable.projectile_guard,electric_guard:cfgBALANCEGrowthPassiveAvailable.electric_guard};
    if(familyCaps[def.family] && RG.passiveValue(P,def.family)>=familyCaps[def.family]-1e-8)return false;
    if(id==='frailheal'){
      const old=P.passives.frailheal||0,nextMax=Math.max(1,Math.round(P.maxhp*(1-cfgPASSIVESFrailhealPassiveAvailable.nextMax_factor*(old+1))/(1-cfgPASSIVESFrailhealPassiveAvailable.nextMax_factor*old)));
      if(P.hp>=nextMax)return false;   // 缩减上限后没有治疗空间，不提供净亏的零收益选项。
    }
    const limit = caps[id], noGain = (limit && (P[limit[0]] || 0) >= limit[1] - 1e-8) ||
      (id === "globalcd" && (P.globalCdMul || 1) <= RG.BALANCE.cards.fx.field_floor + 1e-8) ||
      (id.startsWith("crit_") && RG.effectiveCritChance(P) >= (P.critCap ?? 1) - 1e-8 && !(P.passives.insight&&!P.critDLocked)) ||
      (id==='weakmark'&&RG.effectiveCritChance(P)>=(P.critCap??1)-1e-8) ||
      (P.critDLocked && (id.startsWith("critd_") || id === "insight" || id==='critstreak'));
    return !noGain || enablesEvolution(P, id);
  };
  // 神秘雕像:献祭25%当前生命；少量概率扣除本局金币。
  RG.statueSacrifice = function () {
    const P = RG.P, st = P.statueNear;
    if (!st || st.used) return;
    if (P.hp <= cfgBALANCEGrowthStatueSacrifice.hp_threshold) { RG.addText(P.x, P.y - 30, "血量不足,无法献祭", "#ff5470", 13); return; }
    P.hp -= Math.min(P.hp * cfgBALANCEGrowthStatueSacrifice.hp_factor, P.hp - cfgBALANCEGrowthStatueSacrifice.hp_offset);
    P.iTimer = cfgBALANCEGrowthStatueSacrifice.iTimer;
    RG.statues = RG.statues.filter(s => s !== st);
    const roll = Math.random();
    if (roll < cfgBALANCEGrowthStatueSacrifice.roll_threshold) {
      const pool = Object.keys(RG.PASSIVES).filter(id => RG.PASSIVES[id].rarity >= cfgBALANCEGrowthStatueSacrifice.pool_threshold && RG.passiveAvailable(P, id));
      const picks = [], cp = pool.slice();
      while (picks.length < cfgBALANCEGrowthStatueSacrifice.length_threshold && cp.length) picks.push(cp.splice(Math.floor(Math.random() * cp.length), 1)[0]);
      RG.offers = picks.map(id => ({ kind: "passive", id, lv: (P.passives[id] || 0) + 1 }));
      if (!RG.offers.length) RG.offers = [{ kind: "coins", amount: cfgBALANCEGrowthStatueSacrifice.amount }];
      RG.offerKind = "normal"; RG.selectedOffer = null;
      RG.addText(P.x, P.y - 44, "雕像回应了你!", "#c084fc", 16);
      RG.state = "levelup";
    } else if (roll < cfgBALANCEGrowthStatueSacrifice.roll_threshold_2) {
      RG.addCoin(cfgBALANCEGrowthStatueSacrifice.statueSacrifice_addCoinArg1);
      RG.addText(P.x, P.y - 40, "金 +80", "#ffd166", 16);
    } else if(roll>=cfgBALANCEGrowthStatueSacrifice.roll_threshold_3){
      const lost=RG.run.coins*cfgBALANCEGrowthStatueSacrifice.lost_factor;RG.run.coins-=lost;RG.addText(P.x,P.y-40,"石碑偷走20%金币 · -"+Math.round(lost),"#ff5470",16);
    } else {
      RG.addText(P.x, P.y - 40, "雕像毫无反应...", "#565a70", 14);
    }
    RG.playSfx("statue");
  };
  RG.playerDamageMul = (legion=true) => RG.P.dmgMul * (1+(RG.P.injuryBonus||0)) * (RG.P.giantT>0?1+cfgBALANCEGrowthPlayerDamageMul.playerDamageMul_factor*(RG.P.giantStacks||1):1) * (RG.P.reviveSpent?RG.PASSIVES.revive.damageMul:1) * (RG.P.howlDebuffT > 0 ? cfgBALANCEGrowthPlayerDamageMul.playerDamageMul_2 : 1) * (RG.P.workshopRuneT>0&&RG.P.workshopRuneOwner&&!RG.P.workshopRuneOwner.dead&&!RG.P.workshopRuneOwner.dying?cfgBALANCEGrowthPlayerDamageMul.playerDamageMul_3:1) * (1+RG.fullShieldBonus()) * (1+RG.windDamageBonus()) * (legion?1+RG.legionBonus():1) * (1+RG.slaughterBonus('damage')) * (1+RG.wealthDamage()) * (RG.P.passives.valhalla&&RG.P.valhallaT>0?1+RG.PASSIVES.valhalla.bonus:1) * (RG.P.sinId==='sin_envy'?1+(RG.P.envyCardBonus||0):1);
  RG.criticalDamageMultiplier=function(P,streak=true,extra=0){const cb=RG.effectiveCritDamage(P,streak)-cfgBALANCEGrowthCriticalDamageMultiplier.cb_offset+(P.critDLocked?0:extra)+(P.passives.insight&&!P.critDLocked?Math.max(0,P.critC+(RG.resonanceBonus(P).critRate||0)+RG.slaughterBonus('critical',P)-cfgPASSIVESInsightCriticalDamageMultiplier.cb_offset)*cfgPASSIVESInsightCriticalDamageMultiplier.cb_factor:0);return cfgBALANCEGrowthCriticalDamageMultiplier.criticalDamageMultiplier_offset+(cb>cfgBALANCEGrowthCriticalDamageMultiplier.cb_threshold?cfgBALANCEGrowthCriticalDamageMultiplier.criticalDamageMultiplier_offset_2+(cb-cfgBALANCEGrowthCriticalDamageMultiplier.criticalDamageMultiplier_offset_2)*cfgBALANCEGrowthCriticalDamageMultiplier.criticalDamageMultiplier_factor:cb);};
  RG.rollDamage = function (base, critCBonus,primary=true,critExtra=0) {
    const P = RG.P;
    const raw = base * RG.playerDamageMul();                     // 衍生伤害(风暴等二段效果)基准:只吃基础×伤害倍率,不再继承后续增伤链
    let dmg = raw;
    dmg *= 1 + Math.min(cfgBALANCEGrowthRollDamage.dmg_cap, RG.combo || 0) * cfgBALANCEGrowthRollDamage.dmg_factor;   // 击杀连击:每层 +1%,封顶 50%
    if (P.bloodrush && P.hp / Math.max(1, P.maxhp) < RG.lowHpThreshold(RG.PASSIVES.bloodrush.threshold,P)) dmg *= 1 + RG.PASSIVES.bloodrush.damagePerLevel * P.bloodrush;   // v11.7 血怒
    dmg *= RG.overdriveDamageMul(P);   // 施法快照分支决定临时输出，不写入基础属性。
    if (P.pdBuff > 0) dmg *= cfgBALANCEGrowthRollDamage.dmg;                     // 完美闪避增伤
    if ((P.debtT || 0) > 0) dmg *= RG.PASSIVES.debt.damageMul;               // 血债血偿:常规输出链+20%(raw 基准不含它,衍生伤害天然不吃)
    if (RG.stanceReady(P)) dmg *= 1 + RG.passiveValue(P,"stance");   // 各档磐石固定加成累计为一个独立倍率。
    if (P.passives.berserk) { const miss = 1 - clamp(P.hp / P.maxhp, 0, 1); if (miss > 0) dmg *= 1 + miss * RG.PASSIVES.berserk.rules.rollDamage.dmg_factor * P.passives.berserk; }
    if (P.passives.abyss) { const lost = 1 - clamp(P.hp / P.maxhp, 0, 1); dmg *= 1 + Math.min(cfgPASSIVESAbyssRollDamage.dmg_cap, lost * cfgPASSIVESAbyssRollDamage.dmg_factor); }   // 深渊回响:生命每降10%伤+4%,封顶+38%
    if (P.passives.allin && (P.shieldMax || 0) === 0) dmg *= RG.PASSIVES.allin.rules.rollDamage.dmg;   // 孤注一掷:无护盾构筑时+25%
    const normal=dmg;   // 保存未暴击输出，目标禁止暴击时直接采用，不重新计算角色属性。
    let crit = false;
    const cc = RG.effectiveCritChance(P,critCBonus||0);   // 处决者与共鸣都遵守同一上限。
    const forced = P.critCap==null && P.passives.focus && (P.noCrit || 0) >= RG.PASSIVES.focus.rules.rollDamage.forced_threshold;
    if (forced || (cc > 0 && Math.random() < cc)) {
      crit = true; P.noCrit = 0;
      dmg *= RG.criticalDamageMultiplier(P,primary,critExtra);   // 目标暴伤也先通过原软上限。
    } else { P.noCrit = (P.noCrit || 0) + 1; }
    return { dmg, crit, raw, normal };
  };
  // 攻击方只生成输出：卡牌/临时增益及其适用条件在这里计算，不修改受击对象。
  RG.outgoingDamage = function(base,target,direct=false,exact=false,attacker=RG.P,primary=true,weaponId=null) {
    // 怪物与场地已在发招时生成数值，不能再套入玩家的增伤/暴击。
    if(attacker!==RG.P)return {dmg:base,normal:base,raw:base,crit:false,elementBase:base,elementNormal:base};
    const P=RG.P;
    let bonus=0;
    if(!direct){if(target.maxhp&&target.hp/target.maxhp<RG.PASSIVES.executioner.threshold)bonus+=RG.passiveValue(P,'executioner');if(target.elite||target.boss)bonus+=RG.passiveValue(P,'elite_crit');}
    if(!direct&&primary&&RG.weakMarkReady(target,P))bonus+=1;
    if(!direct&&primary)bonus+=RG.mobilityCritBonus(target,P);
    const hit=direct?{dmg:base,normal:base,raw:base,crit:false}:RG.rollDamage(base,bonus,primary,primary?RG.burningCritBonus(target,P):0);
    if(!direct&&primary&&P.passives.crystal){const mul=1+RG.crystalCloseBonus(target,weaponId,P);hit.dmg*=mul;hit.normal*=mul;}
    if(!direct&&!exact&&primary&&P.passives.openingstrike&&target.maxhp>0&&target.hp>=target.maxhp){const mul=1+RG.PASSIVES.openingstrike.values[P.passives.openingstrike];hit.dmg*=mul;hit.normal*=mul;}
    if(!direct&&primary&&P.passives.dashecho&&P.dashEchoT>0){const mul=1+RG.PASSIVES.dashecho.values[P.passives.dashecho];hit.dmg*=mul;hit.normal*=mul;}
    if(!direct&&primary&&P.passives.shieldcounter&&P.shieldCounterT>0){const mul=1+RG.PASSIVES.shieldcounter.values[P.passives.shieldcounter];hit.dmg*=mul;hit.normal*=mul;}
    hit.elementBase=hit.dmg;hit.elementNormal=hit.normal;
    if(!exact&&(target.elite||target.boss)){const mul=1+RG.passiveValue(P,'elite_power');hit.dmg*=mul;hit.normal*=mul;}
    return hit;
  };
  // 爆破弹头溅射(火源:溅射附加燃烧)
  RG.splash = function (x, y, baseDmg, primary) {
    const value=RG.passiveValue(RG.P,"explosive");if(!value)return;
    const r = cfgBALANCEGrowthSplash.r;
    RG.rings.push({ x, y, r: 8, maxR: r, life: 0.22, maxLife: 0.22, color: "#fb923c" });
    for (const e of RG.enemies) {
      if (e.dead || e.dying || e===primary) continue;
      if (Math.hypot(e.x - x, e.y - y) < r + e.r) {
        RG.dealPure(e, baseDmg * RG.playerDamageMul() * value);
        RG.applyElementOutput(e,"fire",cfgBALANCEGrowthSplash.splash_applyElementOutputArg3,baseDmg*cfgBALANCEGrowthSplash.splash_factor,baseDmg,true,false);
      }
    }
  };

  // ---------- 升级/选卡 ----------
  RG.gainXP = function (n) {
    const P = RG.P;
    if(!P||P.hp<=0||RG.state==='over'||RG.state==='win')return;
    P.xp += n * (P.xpMul || 1);
    P.levelQueue = P.levelQueue || [];
    while (P.xp >= P.xpNext) {
      P.xp -= P.xpNext;
      P.level++;
      if(P.passives.leveldash){if(!(P.levelHasteT>0))RG.addText(P.x,P.y-48,'升级冲刺','#4ade80',14);RG.refreshStatus(P,'levelHasteT',RG.PASSIVES.leveldash.rules.gainXP.gainXP_refreshStatusArg3);}
      P.xpNext = RG.xpFor(P.level);
      P.levelQueue.push(P.level);
    }
    RG.openNextLevelUp();
  };
  // 大额经验逐级排队，避免覆盖三选一，并确保十级七罪节点不会跳过。
  RG.openNextLevelUp = function () {
    const P = RG.P;
    if (!P || P.hp<=0 || RG.battleUpdating || RG.state !== "play" || !P.levelQueue || !P.levelQueue.length) return false;
    const next = P.levelQueue[0];
    if(Number.isInteger(next)&&next%RG.BALANCE.economy.shopEvery===0&&next>(RG.run.shopThrough||0)&&!RG.run.rushMode){RG.run.shopThrough=next;RG.openRunShop();return true;}
    P.levelQueue.shift();
    if (next === "realmreward") RG.legendaryOffer(); else RG.levelUp(next);
    return true;
  };
  function upgradeableWeapons(P) {
    return Object.keys(P.weapons || {}).filter(id => RG.WEAPONS[id] && !P.evolved?.[id] && P.weapons[id] < RG.WEAPONS[id].maxLv);
  }
  RG.buildOffers = function (kind) {
    if (kind === "realmreward") {
      const ids=Object.keys(RG.PASSIVES).filter(id=>RG.PASSIVES[id].rarity===cfgBALANCEGrowthBuildOffers.ids&&RG.passiveAvailable(RG.P,id,'realmreward')),out=[];
      while(out.length<cfgBALANCEGrowthBuildOffers.length_threshold&&ids.length){const id=ids.splice(Math.floor(Math.random()*ids.length),1)[0];out.push({kind:"passive",id,lv:(RG.P.passives[id]||0)+1,rarity:cfgBALANCEGrowthBuildOffers.rarity});}
      // 全部传说满级时显示明确金币兜底，绝不重新引入职业或无效卡。
      if(!out.length)out.push({kind:"coins",amount:cfgBALANCEGrowthBuildOffers.amount,rarity:cfgBALANCEGrowthBuildOffers.rarity});return out;
    }
    if (kind === "active") {
      const P = RG.P;
      return Object.keys(RG.ACTIVES)
        .filter(id => (P.actives[id] || 0) < RG.ACTIVES[id].maxLv && ((P.actives[id] || 0) > 0 || P.activeOrder.length < cfgBALANCEGrowthBuildOffers.length_threshold_2))
        .map(id => ({ kind: "active", id, lv: (P.actives[id] || 0) + 1 }));
    }
    const P = RG.P, pool = [];
    // 进化是一次明确的构筑抉择：只要有满级武器满足条件，直接把它的两个分支并列展示，
    // 不再让其中一个分支被普通卡随机挤掉。
    for(const id of RG.WEAPON_ORDER){
      const ev=RG.EVOLVE[id],lv=P.weapons[id]||0;
      if(ev&&lv>=RG.WEAPONS[id].maxLv&&!P.evolved[id]&&RG.hasEvoReq(ev.req))return ev.branches.map(branch=>({kind:"evolve",id,branch:branch.id}));
    }
    for(const id of Object.keys(RG.ACTIVE_EVOLVE))if(RG.canEvolveActive(P,id))return RG.ACTIVE_EVOLVE[id].branches.map(branch=>({kind:'activeevolve',id,branch:branch.id}));
    for (const id in RG.WEAPONS) {
      const lv = P.weapons[id] || 0;
      // 解锁条件只限制获取新武器；已经持有的武器始终允许升级。
      if (lv === 0 && !RG.weaponUnlocked(id)) continue;
      if (lv === 0 && Object.keys(P.weapons).length >= (P.passives.backpack?RG.PASSIVES.backpack.rules.buildOffers.buildOffers:cfgBALANCEGrowthBuildOffers.buildOffers)) continue;   // 基础三槽，背包仅增加一次机会。
      if (lv >= RG.WEAPONS[id].maxLv) {
        // 满级武器:满足条件时把两个互斥分支都放入池中；每局三把武器均可进化。
        continue;
      }
      pool.push({ kind: "weapon", id, lv: lv + 1, rarity: lv===0?cfgBALANCEGrowthBuildOffers.rarity_2:cfgBALANCEGrowthBuildOffers.rarity_3 });
    }
    // 主动技能独立槽位；统一按史诗品质随机出现，最多携带两种。
    for (const id in RG.ACTIVES) {
      const lv = P.actives[id] || 0;
      if (lv >= RG.ACTIVES[id].maxLv) continue;
      if (lv === 0 && P.activeOrder.length >= cfgBALANCEGrowthBuildOffers.length_threshold_2) continue;
      pool.push({ kind: "active", id, lv: lv + 1, rarity:cfgBALANCEGrowthBuildOffers.rarity_2 });
    }
    // 元素卡按史诗品质进入普通池，不再补偿；无有效武器时不入池。
    for(const element of RG.ELEMENT_ORDER){
      const targets=Object.keys(P.weapons).filter(id=>{
        const el=RG.weaponElement(P,id);
        return !el||(el.type===element&&el.level<cfgBALANCEGrowthBuildOffers.targets_threshold);
      });
      if(!targets.length)continue;
      pool.push({kind:"element",element,rarity:cfgBALANCEGrowthBuildOffers.rarity_2});
    }
    for (const id in RG.PASSIVES) {
      const lv = P.passives[id] || 0;
      if (!RG.passiveAvailable(P, id)) continue;
      pool.push({ kind: "passive", id, lv: lv + 1, rarity:RG.PASSIVES[id].rarity });
    }
    if(Object.keys(P.weapons).length)pool.push({kind:"discard",rarity:cfgBALANCEGrowthBuildOffers.rarity_3});
    // 治疗分档:血量健康时不占卡池;禁疗誓排除
    if (P.hp < P.maxhp * cfgBALANCEGrowthBuildOffers.buildOffers_factor && !P.healBan) {
      pool.push({ kind: "heal", heal: cfgBALANCEGrowthBuildOffers.heal, rarity: 1, w: cfgBALANCEGrowthBuildOffers.w });
      pool.push({ kind: "heal", heal: cfgBALANCEGrowthBuildOffers.heal_2, rarity: cfgBALANCEGrowthBuildOffers.rarity_4, w: cfgBALANCEGrowthBuildOffers.w_2 });
      pool.push({ kind: "heal", heal: cfgBALANCEGrowthBuildOffers.heal_3, rarity: cfgBALANCEGrowthBuildOffers.rarity, w: cfgBALANCEGrowthBuildOffers.w_3 });
    }
    // 卡池变薄时:金币补充包(后期全满也不空选)
    if (pool.length < cfgBALANCEGrowthBuildOffers.length_threshold_3) pool.push({ kind: "coins", amount: cfgBALANCEGrowthBuildOffers.amount_2, w: cfgBALANCEGrowthBuildOffers.w_4 });
    if (pool.length < cfgBALANCEGrowthBuildOffers.length_threshold) { pool.push({ kind: "coins", amount: cfgBALANCEGrowthBuildOffers.amount_3, w: cfgBALANCEGrowthBuildOffers.w_4 }); pool.push({ kind: "coins", amount: cfgBALANCEGrowthBuildOffers.amount, w: cfgBALANCEGrowthBuildOffers.w_5 }); }
    const out=[],cp=pool.slice();
    const weighted=(items,weight)=>{
      let roll=Math.random()*items.reduce((sum,o)=>sum+weight(o),0);
      for(const o of items){roll-=weight(o);if(roll<=0)return o;}return items.at(-1);
    };
    while(out.length<cfgBALANCEGrowthBuildOffers.length_threshold&&cp.length){
      const available=[1,cfgBALANCEGrowthBuildOffers.available,cfgBALANCEGrowthBuildOffers.available_2,cfgBALANCEGrowthBuildOffers.available_3,cfgBALANCEGrowthBuildOffers.available_4].filter(q=>cp.some(o=>RG.offerRarity(o)===q));
      const guaranteed=out.length===0&&P.highOfferGuaranteed;
      const high=available.filter(q=>q>=cfgBALANCEGrowthBuildOffers.high_threshold),grades=guaranteed&&high.length?high:available;
      const rarity=weighted(grades,q=>RG.CARD_RARITY_WEIGHTS[q]);
      const candidates=cp.filter(o=>RG.offerRarity(o)===rarity);
      const choice=weighted(candidates,o=>o.kind==='weapon'&&(P.weapons[o.id]||0)>0?RG.weaponOfferWeight(P,o.id):1);
      out.push(choice);cp.splice(cp.indexOf(choice),1);
    }
    if(!out.length)out.push({kind:'heal',heal:cfgBALANCEGrowthBuildOffers.heal_2,rarity:cfgBALANCEGrowthBuildOffers.rarity_4});
    return out;
  };
  RG.CARD_RARITY_WEIGHTS={1:cfgBALANCEGrowthCommon.value_1,2:cfgBALANCEGrowthCommon.value_2,3:cfgBALANCEGrowthCommon.value_3,4:1,5:cfgBALANCEGrowthCommon.value_5};
  RG.offerRarity=function(o){
    if(o.rarity)return o.rarity;
    if(o.kind==='passive')return RG.PASSIVES[o.id]?.rarity||1;
    if(['active','element'].includes(o.kind))return cfgBALANCEGrowthOfferRarity.offerRarity;
    if(['evolve','oathnode'].includes(o.kind))return cfgBALANCEGrowthOfferRarity.offerRarity_2;
    if(o.kind==='weapon')return o.lv===1?cfgBALANCEGrowthOfferRarity.offerRarity:cfgBALANCEGrowthOfferRarity.offerRarity_3;
    return 1;
  };
  // 只补偿每把武器未被展示的轮数；不读取选择历史，也不强塞任何武器。
  RG.weaponOfferWeight=(P,id)=>(1+Math.min(cfgBALANCEGrowthWeaponOfferWeight.weaponOfferWeight_cap,P.weaponOfferMisses?.[id]||0))**cfgBALANCEGrowthWeaponOfferWeight.weaponOfferWeight;
  function normalCardRound(){return RG.offerKind==='normal'&&!RG.offers.some(o=>['evolve','activeevolve'].includes(o.kind));}
  RG.countPity=function(reroll=false){
    if(!normalCardRound())return;
    const P=RG.P,high=RG.offers.some(o=>RG.offerRarity(o)>=cfgBALANCEGrowthCountPity.high_threshold);
    if(high){P.highOfferMisses=0;P.cardRoundHighSeen=true;}
    else if(!reroll)P.highOfferMisses=Math.min(cfgBALANCEGrowthCountPity.highOfferMisses_cap,(P.highOfferMisses||0)+1);
  };
  RG.countElementPity=function(){};
  RG.countWeaponPity=function(reroll=false){
    if(!normalCardRound())return;
    const P=RG.P,ids=upgradeableWeapons(P);P.weaponOfferMisses=P.weaponOfferMisses||{};
    const seen=new Set(P.cardRoundWeaponSeen||[]);
    for(const id of ids){
      if(RG.offers.some(o=>o.kind==='weapon'&&o.id===id)){P.weaponOfferMisses[id]=0;seen.add(id);}
      else if(!reroll)P.weaponOfferMisses[id]=Math.min(RG.BALANCE.growth.countWeaponPity.id_cap,(P.weaponOfferMisses[id]||0)+1);
    }
    for(const id of Object.keys(P.weaponOfferMisses))if(!ids.includes(id))delete P.weaponOfferMisses[id];
    P.cardRoundWeaponSeen=[...seen];
  };
  RG.levelUp = function (reachedLevel) {
    if(!RG.P||RG.P.hp<=0||!['play','levelup','runshop'].includes(RG.state))return;
    const milestone = reachedLevel === undefined ? RG.P.level : reachedLevel;
    if (RG.battleUpdating || RG.state === "levelup" || RG.state==='runshop') { RG.P.levelQueue.push(milestone); return; }
    RG.playSfx("levelup");
    RG.P.weaponOfferGuaranteed=false;
    RG.P.weaponOfferMissed=false;
    RG.P.highOfferGuaranteed=false;
    RG.P.cardRoundWeaponSeen=[];RG.P.cardRoundHighSeen=false;
    if (milestone === cfgBALANCEGrowthLevelUp.levelUp && !RG.P.sinLocked) {
      // 十级展示全部七项，玩家自行选择唯一罪印。
      RG.offers = Object.keys(RG.OATH_NODES).map(id => ({ kind: "oathnode", id }));
      if (RG.uiPages) RG.uiPages.sinchoices = 0;
      RG.offerKind = "oathnode";
      RG.addText(RG.P.x, RG.P.y - 64, "☷ 罪印觉醒:选择一项,当局不可撤销!", "#c084fc", 16);
    } else {
      RG.P.highOfferGuaranteed=(RG.P.highOfferMisses||0)>=cfgBALANCEGrowthLevelUp.highOfferGuaranteed_threshold;
      RG.offers = RG.buildOffers("normal");
      RG.offerKind = "normal";
    }
    if (!RG.offers.length) RG.offers = [{ kind: "heal", heal: cfgBALANCEGrowthLevelUp.heal, rarity: cfgBALANCEGrowthLevelUp.rarity }];
    RG.countPity();
    RG.countElementPity();
    RG.countWeaponPity();
    RG.selectedOffer=null;
    RG.state = "levelup";
  };
  RG.legendaryOffer = function () {
    if(!RG.P||RG.P.hp<=0||!['play','levelup','runshop'].includes(RG.state))return;
    if (RG.battleUpdating || RG.state === "levelup" || RG.state==='runshop') { RG.P.levelQueue.push("realmreward"); return; }
    RG.playSfx("levelup");
    RG.offers = RG.buildOffers("realmreward");
    RG.P.weaponOfferGuaranteed=false;
    RG.P.weaponOfferMissed=false;
    RG.offerKind = "realmreward";
    RG.selectedOffer=null;
    RG.state = "levelup";
  };
  RG.rerollOffers = function () {
    const P = RG.P;
    if (RG.state !== "levelup" || !P || P.rerolls <= 0) return;
    if(RG.offers.some(o=>o.kind==='evolve'||o.kind==='activeevolve'))return;
    if (RG.offerKind === "active" || RG.offerKind === "oathnode" || RG.offerKind === "elementweapon" || RG.offerKind === "discardweapon") return;   // 固定成长节点/武器绑定不消耗重骰
    P.rerolls--;
    RG.offers = RG.buildOffers(RG.offerKind || "normal");
    if (!RG.offers.length) RG.offers = [{ kind: "heal", heal: cfgBALANCEGrowthRerollOffers.heal, rarity: cfgBALANCEGrowthRerollOffers.rarity }];
    RG.countPity(true);RG.countWeaponPity(true);RG.selectedOffer=null;
    RG.playSfx("choose");
  };
  // 进化提示(HUD 用):返回满级未进化武器的提示文案数组
  RG.evoHints = function () {
    const P = RG.P, out = [];
    if (!P) return out;
    for (const id in P.weapons) {
      const lv = P.weapons[id], ev = RG.EVOLVE[id];
      if (!ev || lv < RG.WEAPONS[id].maxLv || P.evolved[id]) continue;
      const reqName = ev.req.endsWith("*")
        ? (RG.PASSIVES[Object.keys(P.passives).find(k => k.startsWith(ev.req.slice(0, -1)))] || {}).name || ev.req.slice(0, -1) + "系"
        : (RG.PASSIVES[ev.req] || {}).name || ev.req;
      out.push(RG.WEAPONS[id].name + " → " + (RG.hasEvoReq(ev.req) ? "★可选择分支!" : "缺 " + reqName));
    }
    return out;
  };
  const conciseNumber = n => String(Math.round((n + Number.EPSILON) * 100) / 100);
  const asPercent = n => conciseNumber(n * 100) + "%";
  const asMultiplier = n => "×" + conciseNumber(n);
  const changedValue = (name, a, b, format = conciseNumber) => name + format(a) + "→" + format(b);
  function reqName(req) {
    if (req === "crit*") return "暴击或暴伤卡";
    const id = Object.keys(RG.PASSIVES).find(k => matchesEvoReq(k, req)), name = RG.PASSIVES[id]?.name || req;
    return name.split("·")[0] + (req.endsWith("*") ? "任一档" : "");
  }
  function evolutionNote(P, id) {
    const ev = RG.EVOLVE[id];
    if (!ev || P.evolved?.[id]) return "";
    const lv = P.weapons[id] || 0, ready = hasPlayerEvoReq(P, ev.req);
    return "进化：Lv" + lv + "/" + RG.WEAPONS[id].maxLv + " · " + (ready ? "已获" : "缺") + reqName(ev.req);
  }
  function passiveEvolutionNote(P, id) {
    const names = Object.keys(P.weapons || {}).filter(w => {
      const ev = RG.EVOLVE[w];
      return ev && !P.evolved?.[w] && matchesEvoReq(id, ev.req);
    }).map(w => RG.WEAPONS[w].name);
    return names.length ? "进化前置：" + names.join("、") : "";
  }
  // 武器详情与选牌共用基础参数，避免把临时增伤或攻速当成武器自身升级。
  const WEAPON_STATS = [
    ["dmg","基础伤害"], ["dot","持续伤害"], ["cd","间隔",n=>conciseNumber(n)+"秒"],
    ["shotCd","射击间隔",n=>conciseNumber(n)+"秒"], ["count","弹数"], ["blades","刀刃"],
    ["pulses","脉冲"], ["jumps","跳链"], ["max","气珠"], ["radius","半径"],
    ["range","射程"], ["charge","蓄力",n=>conciseNumber(n)+"秒"], ["width","宽度"],
    ["duration","驻场",n=>conciseNumber(n)+"秒"], ["pierce","穿透"], ["spawnCd","凝聚间隔",n=>conciseNumber(n)+"秒"],
    ["reflections","反射次数"], ["length","重砸距离"], ["burstDelay","补射延迟",n=>conciseNumber(n)+"秒"], ["pelletSize","弹体尺寸",asMultiplier],
    ["hitCd","命中间隔",n=>conciseNumber(n)+"秒"], ["spin","转速"], ["size","尺寸",asMultiplier], ["speed","弹速"],
  ];
  function weaponStatText(id, lv, beforeLv, branch) {
    const after = RG.weaponStat(id, lv, branch), before = beforeLv ? RG.weaponStat(id, beforeLv, branch) : null;
    const values = WEAPON_STATS.filter(([key]) => typeof after[key] === "number" && (!before || after[key] !== before[key]));
    return values.slice(0, 3).map(([key,name,format=conciseNumber]) => before
      ? changedValue(name, before[key] || 0, after[key], format) : name + format(after[key])).join(" · ");
  }
  RG.weaponBuildInfo = function (P, id) {
    const w = RG.WEAPONS[id], lv = P?.weapons?.[id];
    if (!w || !lv) return null;
    const branch = RG.EVOLVE[id]?.branches.find(b => b.id === P.evolved?.[id]), el = RG.weaponElement(P, id);
    const element = el ? RG.ELEMENTS[el.type]?.name + " Lv" + el.level + " · 额外元素伤害" + asPercent(RG.BALANCE.combat.weaponElementHit.directFactor) : "尚未附魔";
    return { title:(branch?.name || w.name) + " Lv" + lv,
      desc:[branch ? w.name + " · " + branch.desc : w.desc, weaponStatText(id, lv, 0, P.evolved?.[id]),
        element, evolutionNote(P, id)].filter(Boolean).join("\n") };
  };
  RG.sinBuildInfo = function (P) {
    const n = P && RG.OATH_NODES[P.sinId];
    if (!n) return null;
    let status = "";
    if (P.sinId === "sin_sloth") status = "冲刺 " + (P.slothStacks || 0) + "/"+RG.OATH_NODES.sin_sloth.maxDashStacks+" 层 · 额外冷却 " + conciseNumber((P.slothStacks || 0) * RG.OATH_NODES.sin_sloth.extraCooldown) + "秒";
    if (P.sinId === "sin_envy") status = "窃取：" + ({golem:"地震",homing:"追踪弹",eye:"激光",barrage:"密集弹幕"}[P.envyPower] || "等待觉醒")+' · 重建伤害+'+Math.round((P.envyCardBonus||0)*100)+'%';
    if (P.sinId === "sin_wrath") status='浴血暴伤+'+Math.round(RG.wrathBloodBonus(P)*100)+'点 · 剩余'+Math.ceil(P.wrathBloodT||0)+'秒';
    if (P.sinId === "sin_lust") status = "存活仆人 " + (RG.allies || []).filter(a => a.puppet && !a.dead && a.hp > 0).length + "/"+RG.summonLimit(10,P);
    return { title:n.name + " · 唯一罪印", desc:["获得：" + n.briefGain, "代价：" + n.briefCost, status].filter(Boolean).join("\n") };
  };
  function baseOfferText(o) {
    if(o.kind==='activeevolve'){
      const branch=RG.ACTIVE_EVOLVE[o.id].branches.find(b=>b.id===o.branch);
      return {title:'★ '+branch.name,desc:branch.desc+'\n二选一；前置移除仍保留',color:RG.RARITY[5].color,q:5,lv:'Lv'+RG.P.actives[o.id],rn:'主动进化 · 传说',icon:o.id};
    }
    if (o.kind === "heal") {
      const names = { 30: "应急包扎", 70: "医疗包", 150: "战地急救" };
      const rc = RG.RARITY[o.rarity || 1];
      return { title: names[o.heal] || "应急治疗", desc: "立即回复 " + o.heal + " 生命", color: rc.color, lv: "", rn: rc.name, icon: o.heal >= 150 ? "healbig" : "heal" };
    }
    if (o.kind === "evolve") {
      const w = RG.WEAPONS[o.id], branch = RG.EVOLVE[o.id].branches.find(b=>b.id===o.branch) || RG.EVOLVE[o.id].branches[0];
      return { title: "★ " + branch.name, desc: w.name + " 分支: " + branch.desc, color: RG.RARITY[5].color, q: 5, lv: "", rn: "分支进化 · 传说", icon: o.id };
    }
    if (o.kind === "element") {
      const def=RG.ELEMENTS[o.element],targets=Object.keys(RG.P.weapons).filter(id=>{const el=RG.weaponElement(RG.P,id);return !el||(el.type===o.element&&el.level<5);});
      const upgrades=targets.filter(id=>RG.weaponElement(RG.P,id)).length;
      return {title:"◆ "+def.name+"元素",desc:upgrades?"选择武器提升该元素等级":"选择一把已有武器进行附魔",color:def.color,q:4,lv:"",rn:"元素卡",glyph:def.glyph};
    }
    if (o.kind === "elementweapon") {
      const def=RG.ELEMENTS[o.element],el=RG.weaponElement(RG.P,o.id),next=el?el.level+1:1;
      return {title:RG.WEAPONS[o.id].name,desc:(el?"强化":"附加")+def.name+"元素至 Lv"+next+"\n额外元素伤害"+asPercent(RG.BALANCE.combat.weaponElementHit.directFactor)+" · "+asPercent(RG.BALANCE.combat.weaponElementHit.chance_threshold)+"概率附加状态",color:def.color,q:4,lv:"Lv"+next,rn:"选择目标武器",glyph:def.glyph,icon:o.id};
    }
    if (o.kind === "coins") return { title: "金币补给", desc: "立即获得 " + o.amount + " 金币", color: "#ffd166", lv: "", rn: "补给" };
    if(o.kind==="discard"||o.kind==="discardweapon")return {title:o.id?RG.WEAPONS[o.id].name:"弃械重构",desc:o.id?"丢弃此武器及其等级、进化和附魔，不返还资源":"选择丢弃一把当前武器，之后可以重新获取",color:RG.RARITY[2].color,q:2,lv:"",rn:"进阶",icon:o.id||"split"};
    if (o.kind === "oathnode") {
      const n = RG.OATH_NODES[o.id];
      return { title: "☷ " + n.name, desc: n.desc, color: "#c084fc", q: 5, lv: "", rn: "七宗罪 · 唯一罪印", glyph: n.glyph };
    }
    if (o.kind === "active") {
      const a=RG.ACTIVES[o.id];return {title:a.name,desc:a.desc(o.lv),color:a.color,q:4,lv:"Lv"+o.lv,rn:"主动技能",glyph:a.glyph,icon:o.id};
    }
    if (o.kind === "weapon") {
      const w = RG.WEAPONS[o.id], rc = o.lv === 1 ? RG.RARITY[4] : RG.RARITY[2];
      return {title:(o.lv===1?"解锁武器 · ":"")+w.name,desc:w.desc,color:rc.color,q:0,lv:"Lv"+o.lv,rn:rc.name,icon:o.id};
    }
    const p = RG.PASSIVES[o.id], rc = RG.RARITY[p.rarity];
    let desc=RG.passiveDescription(o.id,o.lv);
    const P=RG.P,previous=P.passives[o.id]||0;
    if(p.values&&previous)desc+='\n强化：'+asPercent(p.values[previous])+'→'+asPercent(p.values[o.lv]);
    if(o.id==='spores'){
      desc='中毒死亡留'+p.rules.killEnemy.t+'秒毒雾\n范围'+(previous?p.radius[previous]+'→':'')+p.radius[o.lv]+'；基础毒伤'+(previous?p.damage[previous]+'→':'')+p.damage[o.lv]+'/'+p.rules.killEnemy.tick+'秒\n至多'+p.rules.killEnemy.length_threshold+'片，无连锁';
      if(!P.passives.poisontrail&&!Object.keys(P.weapons).some(id=>RG.weaponElement(P,id)?.type==='poison'))desc+='；需毒源';
    }
    if(o.id==='earthbalance'&&!Object.keys(P.weapons).some(id=>RG.weaponElement(P,id)?.type==='earth'))desc+='\n当前缺大地附魔';
    if(o.id==='chargecircuit')desc+='\n已持有主动 '+P.activeOrder.length+'/2';
    if(o.id==='causality')desc+='\n已持有主动 '+P.activeOrder.length+'/2';
    if(o.id==='windwalker')desc+='\n当前'+RG.windStacks(P)+'/'+p.maxStacks+'层';
    if(o.id==='fullshield')desc+='\n当前普通盾 '+(P.shield||0)+'/'+(P.shieldMax||0);
    if(o.id==='legion'){const count=RG.liveSummonCount();desc='存活召唤每个增伤+'+Math.round(p.perAlly*100)+'%\n自身/召唤至多'+Math.round(p.caps[o.lv]*100)+'%\n固定反伤不变；当前'+count+'个';}
    if(o.id==='critstreak')desc='常规真暴击积层\n后续每层暴伤+'+(previous?Math.round(p.values[previous]*100)+'→':'')+Math.round(p.values[o.lv]*100)+'点\n至多'+p.maxStacks+'层，未暴命中清零\n锁暴伤无效；当前'+Math.min(p.maxStacks,P.critStreak||0)+'/'+p.maxStacks+'层';
    if(o.id==='elementunity'){
      const def=RG.PASSIVES.elementunity,n=Math.min(def.maxTypes,RG.infusedElementTypes(P).length);
      desc='每种不同武器附魔，元伤+'+Math.round(def.perType*100)+'%\n最多'+RG.configChinese(def.maxTypes,'四',4)+'种'+Math.round(def.maxTypes*def.perType*100)+'%；'+RG.configChinese(cfgBALANCEGrowthElementUnityBonus.range_threshold,'三',3)+'种起反应范围+'+Math.round(def.rangeBonus*100)+'%\n当前'+n+'种：元伤+'+Math.round(n*def.perType*100)+'%';
    }
    return { title: p.name, desc, color: rc.color, q: p.rarity, lv: "Lv" + o.lv, rn: rc.name, icon: p.icon || o.id };
  };
  const PASSIVE_TRACK = RG.PASSIVE_FIELDS;
  RG.offerText=function(o){
    const info=baseOfferText(o);
    if(RG.state==='levelup'&&RG.selectedOffer!=null&&RG.offers[RG.selectedOffer]===o&&!['oathnode','element'].includes(o.kind)){
      const note=RG.resonanceOfferNote(RG.P,o);if(note){info.desc+='\n'+note;info.resonanceNote=note;}
    }
    return info;
  };
  function passiveSnapshot(P) { const s = {}; for (const k of PASSIVE_TRACK) s[k] = Number.isFinite(P[k]) ? P[k] : 0; return s; }
  function rememberPassive(P, id, before) {
    const mulKeys = RG.PASSIVES[id]?.multipliers || [], mul = {}, add = {};
    for (const k of PASSIVE_TRACK) {
      const value = Number.isFinite(P[k]) ? P[k] : 0;
      if (value === before[k]) continue;
      if (mulKeys.includes(k) && before[k]) mul[k] = value / before[k];
      else add[k] = value - before[k];
    }
    P.passiveHistory.push({ id, mul, add });
  }
  RG.clearPassivesForEnvy = function (P) {
    const removed=Object.entries(P.passives).filter(([id,lv])=>RG.PASSIVES[id]&&Number.isInteger(lv)&&lv>0&&lv<=RG.PASSIVES[id].maxLv).length;
    const hist = P.passiveHistory || [];
    for (let i = hist.length - 1; i >= 0; i--) {
      const h = hist[i];
      for (const k in h.mul) P[k] /= h.mul[k];
      for (const k in h.add) P[k] -= h.add[k];
    }
    P.passives = {}; P.passiveHistory = []; P.injuryBonus=0;RG.clearStatus(P,'giantT');
    P.autoCd = {};
    if(P.wrathBloodT!==undefined){RG.clearStatus(P,'wrathBloodT');P.wrathBloodStacks=0;}
    delete P.lastActiveId;if(P.valhallaT!==undefined)RG.clearStatus(P,'valhallaT');
    RG.autoFx=(RG.autoFx||[]).filter(f=>f.active==='collapse');RG.clearBattleCollections(['healFields']);
    RG.vials = (RG.vials || []).filter(v=>!v.poisonTrail&&!v.poisonSpore);
    if(P.reactionAfterT!==undefined)RG.clearStatus(P,'reactionAfterT');
    if(P.chargeAfterT!==undefined)RG.clearStatus(P,'chargeAfterT');
    for(const k of ['xpWindT','levelHasteT'])if(P[k]!==undefined)RG.clearStatus(P,k);
    if(P.painT!==undefined)RG.clearStatus(P,'painT');
    if(P.windMoveT!==undefined)P.windMoveT=0;
    if(P.dashEchoT!==undefined)RG.clearStatus(P,'dashEchoT');
    if(P.shieldCounterT!==undefined)RG.clearStatus(P,'shieldCounterT');
    if(P.dodgeSpeedT!==undefined)RG.clearStatus(P,'dodgeSpeedT');
    for(const e of RG.enemies||[])if(e.mobilityCritT!==undefined)RG.clearStatus(e,'mobilityCritT');
    if(P.echoDashActive!==undefined)P.echoDashActive=false;
    if(P.echoDashMoved!==undefined)P.echoDashMoved=false;
    for(const k of ['critStreak','causalityCd'])if(P[k]!==undefined)P[k]=0;
    for(const e of RG.enemies){RG.clearStatus(e,'earthImbalanceT');if(e.weakmarkHits!==undefined)e.weakmarkHits=0;if(e.weakmarkCd!==undefined)RG.clearStatus(e,'weakmarkCd');}
    P.maxhp = Math.max(1, Math.round(P.maxhp));
    P.hp = Math.min(P.hp, P.maxhp); P.shield = Math.min(P.shield, P.shieldMax);
    P.debtT = P.debtCd = P.phantomT = P.heartT = P.heartN = 0;
    RG.clearBattleCollections(['phantoms','afterimages','allies','decoys']);
    if(P.summonAfterT!==undefined)RG.clearStatus(P,'summonAfterT');
    RG.refreshResonance(P);
    return removed;
  };
  function applyOffer(o) {
    const P = RG.P;
    if(o.kind==='activeevolve'){
      const branch=RG.ACTIVE_EVOLVE[o.id]?.branches.find(b=>b.id===o.branch);
      if(!branch||!RG.canEvolveActive(P,o.id))return false;
      (P.activeEvolved||(P.activeEvolved={}))[o.id]=branch.id;
      RG.addText(P.x,P.y-44,'★ '+branch.name,'#ffd166',22,{pop:true,life:1.2});RG.playSfx('levelup');return true;
    }
    if (o.kind === "heal") {
      if (P.healBan || P.hpLocked || P.healBlocked) { RG.addText(P.x, P.y - 30, "禁疗:治疗无效!", "#ff5470", 13); return; }
      P.hp = Math.min(P.maxhp, P.hp + (o.heal || cfgBALANCEGrowthApplyOffer.hp)); return;
    }
    if (o.kind === "coins") { RG.addCoin(o.amount); RG.addText(P.x, P.y - 30, "金 +" + o.amount, "#ffd166", 15); return; }
    if (o.kind === "evolve") {
      const branch = RG.EVOLVE[o.id].branches.find(b=>b.id===o.branch) || RG.EVOLVE[o.id].branches[0];
      P.weapons[o.id] = cfgBALANCEGrowthApplyOffer.id; P.evolved[o.id] = branch.id; P.evoCount++;
      if (RG.unlockAchievement) RG.unlockAchievement("evolve_1");
      RG.addText(P.x, P.y - 44, "★ " + branch.name + "!", "#ffd166", 22, { pop: true, life: 1.2 });
      RG.flashes = RG.flashes || [];
      RG.flashes.push({ t: 0.45, max: 0.45, color: "#FFC247", title: branch.name });
      RG.rings.push({ x: P.x, y: P.y, r: 20, maxR: 180, life: 0.4, maxLife: 0.4, color: "#FFC247" });
      RG.requestHitStop(0.08);
      RG.playSfx("levelup");
      return;
    }
    if (o.kind === "elementweapon") {
      if(!RG.setWeaponElement(P,o.id,o.element))return;
      const def=RG.ELEMENTS[o.element],el=RG.weaponElement(P,o.id);
      RG.addText(P.x,P.y-44,"◆ "+RG.WEAPONS[o.id].name+" · "+def.name+" Lv"+el.level+"!",def.color,18);
      RG.playSfx("levelup");return;
    }
    if (o.kind === "oathnode") {
      P.sinLocked = true; P.sinId = o.id; P.oathLocked = true; P.oathNode = o.id;
      if (RG.unlockAchievement) RG.unlockAchievement("sin_taker");
      if (o.id === "sin_gluttony") { const old = P.maxhp; P.maxhp = Math.round(P.maxhp * cfgOATH_NODESSin_gluttonyApplyOffer.maxhp_factor); if(!P.healBan&&!P.healBlocked&&!P.hpLocked)P.hp = Math.min(P.maxhp, P.hp + P.maxhp - old); P.armor = Math.min(cfgOATH_NODESSin_gluttonyApplyOffer.armor_cap, P.armor + cfgOATH_NODESSin_gluttonyApplyOffer.armor_offset); P.speed *= cfgOATH_NODESSin_gluttonyApplyOffer.speed; P.elemMul *= cfgOATH_NODESSin_gluttonyApplyOffer.elemMul; }
      if (o.id === "sin_envy") { const removed=RG.clearPassivesForEnvy(P);if(P.envyCardBonus===undefined)P.envyCardBonus=Math.min(cfgOATH_NODESSin_envyApplyOffer.envyCardBonus_cap,removed*cfgOATH_NODESSin_envyApplyOffer.envyCardBonus_factor);const roll = Math.random(); P.envyPower = roll < cfgOATH_NODESSin_envyApplyOffer.envyPower_threshold ? "golem" : roll < cfgOATH_NODESSin_envyApplyOffer.envyPower_threshold_2 ? "homing" : roll < cfgOATH_NODESSin_envyApplyOffer.envyPower_threshold_3 ? "eye" : "barrage"; P.envyCd = cfgOATH_NODESSin_envyApplyOffer.envyCd; }
      if (o.id === "sin_wrath") { P.critD = RG.OATH_NODES.sin_wrath.rules.applyOffer.critD; P.wrathMetaHeal = !P.healBan; P.healBan = true; P.regen = 0; }
      if (o.id === "sin_sloth") { P.armor = Math.min(cfgOATH_NODESSin_slothApplyOffer.armor_cap, P.armor + cfgOATH_NODESSin_slothApplyOffer.armor_offset); P.slothStacks = 0; }
      if (o.id === "sin_greed") { P.pickup *= cfgOATH_NODESSin_greedApplyOffer.pickup; P.xpMul *= cfgOATH_NODESSin_greedApplyOffer.xpMul; P.critD = cfgOATH_NODESSin_greedApplyOffer.critD; P.critDLocked = true; }
      if (o.id === "sin_lust") { P.lustPuppets = true; }
      if (o.id === "sin_pride") { P.dmgMul *= cfgOATH_NODESSin_prideApplyOffer.dmgMul; P.cdMul /= cfgOATH_NODESSin_prideApplyOffer.cdMul; P.critC += cfgOATH_NODESSin_prideApplyOffer.critC; P.reactionMul = (P.reactionMul||1)*cfgOATH_NODESSin_prideApplyOffer.reactionMul_factor; P.maxhp = P.hp = RG.OATH_NODES.sin_pride.lockedHp; P.regen = 0; P.hpLocked = true; }
      const sinName = RG.OATH_NODES[o.id].name;
      RG.addText(P.x, P.y - 44, sinName + " 罪印已烙下!", "#c084fc", 18, { pop: true, life: 1.2 });
      RG.flashes = RG.flashes || [];
      RG.flashes.push({ t: 0.5, max: 0.5, color: "#c084fc", title: sinName });
      RG.rings.push({ x: P.x, y: P.y, r: 16, maxR: 200, life: 0.45, maxLife: 0.45, color: "#c084fc" });
      RG.requestHitStop(0.1);
      if (P.envyPower) RG.addText(P.x, P.y - 68, "窃取权能 · " + ({ golem:"地震", eye:"激光", homing:"追踪弹", barrage:"密集弹幕" }[P.envyPower]), "#ffd166", 15, { pop: true });
      RG.playSfx("oath");
      return;
    }
    if (o.kind === "active") {
      const isNew = !P.actives[o.id];
      P.actives[o.id] = o.lv;
      if (isNew && P.activeOrder.length < cfgBALANCEGrowthApplyOffer.length_threshold) P.activeOrder.push(o.id);
      if (P.activeCd[o.id] == null) P.activeCd[o.id] = 0;
      const slot = Math.max(0,P.activeOrder.indexOf(o.id)), key = RG.controls?.bindings?.[slot ? "active2" : "active1"] || RG.DEFAULT_KEYS[slot ? "active2" : "active1"];
      const hint = isNew ? (RG.touchMode ? " · 点击技能键" : " · 按 " + RG.keyLabel(key) + " 释放") : "";
      RG.addText(P.x, P.y - 42, (isNew ? "获得 " : "强化 ") + RG.ACTIVES[o.id].name + hint, RG.ACTIVES[o.id].color, 17);
      return;
    }
    if(o.kind==="discardweapon"){if(P.evolved[o.id])P.evoCount=Math.max(0,(P.evoCount||0)-1);delete P.weapons[o.id];delete P.evolved[o.id];delete P.weaponElements[o.id];delete P.weaponCd[o.id];delete P.weaponOfferMisses[o.id];
      RG.removeBattleEffects('weapon',o.id,['bullets','booms','vials','spinners']);
      if(o.id==="nova")P.novaQueue=[];if(o.id==="beam"){P.beamTgt=null;P.beamLock=P.beamOver=P.beamTick=0;}
      if(o.id==="hammer")P.hammerQueue=[];if(o.id==="bolt")P.boltBurstQueue=[];if(o.id==="seeker")P.seekerBurstQueue=[];if(o.id==="kiwave")RG.qiOrbs=[];return;}
    if (o.kind === "weapon") { P.weapons[o.id] = o.lv; return; }
    const before = passiveSnapshot(P);
    P.passives[o.id] = o.lv;
    const def = RG.PASSIVES[o.id], fx = def && def.fx;
    if (fx) { fx(P); if(P.critDLocked)P.critD=cfgBALANCEGrowthApplyOffer.critD; rememberPassive(P, o.id, before); }
    if (RG.AUTO_CARD_CDS && RG.AUTO_CARD_CDS[o.id] && P.autoCd[o.id] == null) P.autoCd[o.id] = o.id === "goldbell" ? 0 : RG.AUTO_CARD_CDS[o.id] * (['goldrain','mirrorecho'].includes(o.id)?1:cfgBALANCEGrowthApplyOffer.id_2);
  };
  RG.applyOffer=function(o){const result=applyOffer(o);RG.refreshCriticalState(RG.P);RG.refreshResonance(RG.P);return result;};
  RG.chooseOffer = function (i) {
    if (!RG.P||RG.P.hp<=0||RG.state==='over'||RG.state==='win'||!RG.offers[i]) return;
    const o = RG.offers[i];
    if(o.kind==='activeevolve'&&(!RG.canEvolveActive(RG.P,o.id)||!RG.ACTIVE_EVOLVE[o.id]?.branches.some(b=>b.id===o.branch)))return;
    if(o.kind==="element"){RG.openElementWeaponOffer(o.element);return;}
    if(o.kind==="discard"){RG.offers=Object.keys(RG.P.weapons).map(id=>({kind:"discardweapon",id,rarity:cfgBALANCEGrowthChooseOffer.rarity}));RG.offerKind="discardweapon";RG.selectedOffer=null;if(RG.uiPages)RG.uiPages.weaponchoices=0;return;}
    RG.applyOffer(o);
    const cat = o.kind === "passive" ? (RG.CARD_CAT[o.id] || "stat") : o.kind === "oathnode" ? "oath" : o.kind === "active" ? "active" : "other";
    RG.P.pickCats = (RG.P.pickCats || []).slice(cfgBALANCEGrowthChooseOffer.pickCats_sliceArg1); RG.P.pickCats.push(cat);
    RG.offers = []; RG.offerRects = [];
    RG.P.weaponOfferGuaranteed=false;
    RG.P.weaponOfferMissed=false;
    RG.state = "play";
    RG.playSfx("choose");
    RG.openNextLevelUp();
  };
  RG.openElementWeaponOffer = function (element) {
    RG.offers=Object.keys(RG.P.weapons).filter(id=>{const el=RG.weaponElement(RG.P,id);return !el||(el.type===element&&el.level<RG.BALANCE.growth.openElementWeaponOffer.offers_threshold);}).map(id=>({kind:"elementweapon",id,element}));
    if(!RG.offers.length){RG.state="play";RG.openNextLevelUp();return;}
    RG.offerKind="elementweapon";RG.selectedOffer=null;RG.state="levelup";if(RG.uiPages)RG.uiPages.weaponchoices=0;
    RG.addText(RG.P.x,RG.P.y-66,"◆ 选择要附魔的武器","#67e8f9",16);
  };
  // 双步确认:第一次仅选中,再点一次/Enter/确定按钮才应用(v11.7 回滚一键选卡)
  RG.selectOffer=function(i){if(RG.state==="levelup"&&RG.offers[i]){RG.selectedOffer=i;if(RG.uiPages&&RG.offers.length>3&&RG.offerKind!=='oathnode')RG.uiPages.weaponchoices=Math.floor(i/2);RG.playSfx("choose");}};
  RG.cancelOfferSelection=function(){if(RG.state==="levelup")RG.selectedOffer=null;};
  RG.confirmOffer=function(){if(RG.state!=="levelup"||RG.selectedOffer==null)return;const i=RG.selectedOffer;RG.selectedOffer=null;RG.chooseOffer(i);};

  // v11.2 构筑流派标签:结算/暂停展示本局辨识度
  RG.buildTags = function (P) {
    if (!P) return [];
    const tags = [];
    const ws = Object.keys(P.weapons || {});
    const pass = P.passives || {};
    const els = Object.keys(P.weaponElements || {}).length;
    if (els || pass.harmony || pass.ember || pass.elem_s || pass.elem_m || pass.supercore) tags.push({ n: "元素", c: "#7dd3fc" });
    if ((P.critC || 0) >= 0.22 || pass.focus || pass.executioner || P.sinId === "sin_wrath") tags.push({ n: "暴击", c: "#ffd166" });
    if (P.sinId === "sin_lust" || pass.phantom || pass.loyal || pass.scapegoat || pass.holylight || pass.rally || pass.legion || (RG.allies || []).length) tags.push({ n: "召唤", c: "#4ade80" });
    if (ws.some(RG.weaponIsClose)) tags.push({ n: "近程", c: "#fb923c" });
    if (ws.some(RG.weaponIsRanged)) tags.push({ n: "远程", c: "#7ecbff" });
    if (pass.magnet || pass.greed || pass.compound || pass.xp_s || pass.xp_m || pass.xp_l) tags.push({ n: "经济", c: "#fbbf24" });
    if ((P.armor || 0) >= 0.18 || pass.shell || pass.barrier || pass.goldbell || pass.mountain || pass.fullshield || pass.shieldcounter || P.sinId === "sin_gluttony" || P.sinId === "sin_sloth") tags.push({ n: "壁垒", c: "#a5b4fc" });
    if (P.sinId === "sin_wrath" || P.sinId === "sin_pride" || pass.pact || pass.berserk || pass.allin || pass.debt) tags.push({ n: "罪契", c: "#F04A66" });
    return tags.slice(0, 5);
  };
  // ===== v11.4 成就 / 图鉴 / 今日挑战 / 局内日志 =====
  RG.ACHIEVEMENTS = [
    { id: "first_blood", name: "初染罪孽", desc: "击杀第一只敌人" },
    { id: "combo_50", name: "杀意连绵", desc: "达成 50 连击" },
    { id: "multikill_5", name: "瞬灭成群", desc: "一次多杀 ×5 以上" },
    { id: "evolve_1", name: "武器蜕变", desc: "完成一次武器进化" },
    { id: "sin_taker", name: "罪印烙下", desc: "选择一枚七宗罪" },
    { id: "boss_slayer", name: "弑主者", desc: "击破首个 BOSS" },
    { id: "cycle_2", name: "四首领试炼", desc: "主线击破前四个首领" },
    { id: "survivor_10", name: "十分坚守", desc: "单局存活 10 分钟" },
    { id: "survivor_20", name: "二十分坚守", desc: "单局存活 20 分钟" },
    { id: "rich", name: "罪金成堆", desc: "单局获得 500 金币" },
    { id: "win_final", name: "终焉陨落", desc: "击败终焉·吞噬者" },
    { id: "rush_clear", name: "连战破关", desc: "通关任一 BOSS 连战" },
    { id: "contract_3", name: "三重罪契", desc: "同时启用 3 项挑战契约开局" },
    { id: "daily_done", name: "今日已偿", desc: "完成一次今日挑战" },
    { id: "lib_mob", name: "图鉴初开", desc: "见过 8 种敌人" },
    { id: "lib_full", name: "万相皆录", desc: "见过全部敌人种类" },
  ];
  RG.unlockAchievement = function (id) {
    try { if (!RG.meta || !RG.ACHIEVEMENTS || !RG.ACHIEVEMENTS.some(a => a.id === id)) return; } catch (err) { return; }
    RG.meta.achievements = RG.meta.achievements || {};
    if (RG.meta.achievements[id]) return;
    RG.meta.achievements[id] = Date.now();
    RG.saveMeta();
    const def = RG.ACHIEVEMENTS.find(a => a.id === id);
    const msg = "成就解锁 · " + def.name;
    if (RG.P && RG.state === "play") RG.addText(RG.P.x, RG.P.y - 70, msg, "#ffd166", 16, { pop: true, life: 1.4 });
    else RG.menuNotice = { text: msg, until: Date.now() + 5000 };
    RG.playSfx("levelup");
  };
  RG.seenMob = function (type) {
    if (!RG.meta || !type) return;
    RG.meta.seenMobs = RG.meta.seenMobs || [];
    if (!RG.meta.seenMobs.includes(type)) {
      RG.meta.seenMobs.push(type);
      const mobN = Object.keys(RG.ETYPES || {}).length;
      const seenCount=RG.meta.seenMobs.filter(id=>RG.ETYPES[id]).length;
      if (seenCount >= 8) RG.unlockAchievement("lib_mob");
      if (seenCount >= mobN) RG.unlockAchievement("lib_full");
    }
  };
  RG.pushRunLog = function (win) {
    if (!RG.meta || !RG.run || !RG.P) return;
    const tags = (RG.buildTags && RG.buildTags(RG.P).map(t => t.n)) || [];
    const weapon = (Object.keys(RG.P.weapons || {})[0]) || RG.lastWeapon || "bolt";
    RG.meta.runLog = [{experiment:RG.run.experiment||null,mapId:RG.run.rushMode?'rush':RG.run.mapId||'legacy',t: Math.round(RG.run.t), kills: RG.run.kills | 0, lv: RG.P.level | 0, tags, weapon, win: !!win, ts: Date.now() }, ...(RG.meta.runLog || [])].slice(0, 8);
  };
  RG.dailyChallenge = function () {
    const d = new Date();
    const key = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
    let seed = 0;
    for (let i = 0; i < key.length; i++) seed = (seed * cfgBALANCEGrowthDailyChallenge.seed_factor + key.charCodeAt(i)) >>> 0;
    const all = (RG.OATHS || []).map(o => o.id);
    const weapons = (RG.WEAPON_ORDER || ["bolt"]).filter(id => RG.weaponUnlocked(id));
    if (!RG.meta) return { key, contracts: [], weapon: "bolt", bonus: 0 };
    const c1 = all[seed % all.length];
    let c2 = all[(seed >>> cfgBALANCEGrowthDailyChallenge.c2) % all.length];
    if (c2 === c1) c2 = all[(seed + 1) % all.length];
    const weapon = weapons[seed % weapons.length] || "bolt";
    if (RG.meta.daily && RG.meta.daily.key === key) {
      const current = RG.meta.daily;
      // 旧日期算法曾生成缺失契约；修复当日条件时保留已领金币和战绩。
      if (!Array.isArray(current.contracts) || current.contracts.length !== cfgBALANCEGrowthDailyChallenge.dailyChallenge || current.contracts[0] === current.contracts[1] || current.contracts.some(id => !all.includes(id))) {
        current.contracts = [c1,c2]; RG.saveMeta();
      }
      normalizeDailyRewards(current);
      return { ...current, bonus: current.rewardWon ? 0 : cfgBALANCEGrowthDailyChallenge.bonus };
    }
    RG.meta.daily = { key, done: false, best: 0, contracts: [c1, c2], weapon, rewardPaid:0, rewardWon:false };
    RG.saveMeta();
    return { ...RG.meta.daily, bonus: cfgBALANCEGrowthDailyChallenge.bonus };
  };
  RG.startDailyRun = function () {
    const dc = RG.dailyChallenge();
    RG.startRun(dc.weapon, [...new Set([...(RG.meta.oaths || []), ...dc.contracts])],1,'main','valley');
    RG.run.daily = true;
    RG.run.dailyKey = dc.key;
    RG.addText(RG.P.x, RG.P.y - 56, "今日挑战 · 罪契已强制叠加", "#ffd166", 15, { pop: true });
  };
  function normalizeDailyRewards(d) {
    // 旧存档无法区分已领失败还是通关档，保守视为已领完，杜绝迁移重复发奖。
    if (!Number.isFinite(d.rewardPaid) || d.rewardPaid < 0) { d.rewardPaid=0; d.rewardWon=!!d.done; }
    if (typeof d.rewardWon !== "boolean") d.rewardWon=!!d.done;
  }
  // 失败先领基础档；当日首次通关只补两档差额，重复结算只更新纪录。
  RG.settleDaily = function (win) {
    const d = RG.meta && RG.meta.daily, r = RG.run;
    if (!r || !r.daily || !d || d.key !== r.dailyKey) return 0;
    normalizeDailyRewards(d);
    d.best = Math.max(d.best || 0, r.t || 0);
    const target = Math.round((win ? cfgBALANCEGrowthSettleDaily.target : cfgBALANCEGrowthSettleDaily.target_2) + (r.t || 0) * (win ? cfgBALANCEGrowthSettleDaily.target_3 : cfgBALANCEGrowthSettleDaily.target_4));
    const bonus = win ? (d.rewardWon ? 0 : Math.max(0,target-d.rewardPaid)) : (d.done ? 0 : target);
    d.rewardPaid += bonus;
    if (win) d.rewardWon = true;
    d.done = true;
    RG.meta.coins += bonus;
    r.earnedCoins=(r.earnedCoins||0)+bonus;
    RG.unlockAchievement("daily_done");
    RG.saveMeta();
    RG.menuNotice = { text: bonus ? (win ? "今日首次通关 · 补领奖励 +" : "今日基础奖励 +") + bonus :
      d.rewardWon ? "今日奖励已领完" : "今日基础奖励已领 · 首次通关仍可补奖", until: Date.now() + cfgBALANCEGrowthSettleDaily.until_offset };
    return bonus;
  };
  RG.tickInterest = function (dt) {
    const P = RG.P;
    if (!P || !P.interest || !RG.run) return;
    RG.run.interestT = (RG.run.interestT == null ? cfgPASSIVESInterestInterest.period : RG.run.interestT) - dt;
    if (RG.run.interestT <= 1e-8) {
      RG.run.interestT += cfgPASSIVESInterestInterest.period;
      const gain = Math.min(cfgPASSIVESInterestInterest.cap, Math.floor((RG.run.coins || 0) * cfgPASSIVESInterestInterest.rate * P.interest));
      if (gain > 0) { RG.addCoin(gain); RG.addText(P.x, P.y - 34, "利息 +" + gain, "#ffd166", 13, { pop: true }); }
    }
  };
  // 检测本帧实际冲刺线段，每次冲刺对每个敌人只命中一次。
  RG.hitVoidstep = function (x, y) {
    const P = RG.P;
    if (!P.voidstep) return;
    const dx = P.x - x, dy = P.y - y, len = dx * dx + dy * dy;
    const hits = P.voidstepHits || (P.voidstepHits = new Set());
    for (const e of RG.enemies) {
      if (e.dead || e.dying || hits.has(e)) continue;
      const t = len ? clamp(((e.x - x) * dx + (e.y - y) * dy) / len, 0, 1) : 0;
      if (dist2(e.x, e.y, x + dx * t, y + dy * t) > (P.r + e.r) ** 2) continue;
      hits.add(e);
      const hit=RG.dealPure(e, cfgBALANCEGrowthHitVoidstep.hit_offset + cfgBALANCEGrowthHitVoidstep.hit_factor * P.voidstep + (P.level || 1) * cfgBALANCEGrowthHitVoidstep.hit_factor_2);
      RG.markMobilityHit(e,hit,'voidstep');
      if (!e.boss) e.frozen = Math.max(e.frozen || 0, cfgBALANCEGrowthHitVoidstep.frozen_floor);
    }
  };
  RG.SYSTEM_GROWTH_VER="v12033";
})(window.RG);
