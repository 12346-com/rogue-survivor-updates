// ============ 持久化:版本迁移 / 校验 / 双副本恢复 ============
"use strict";
(function (RG) {
  RG.PERSISTENCE_VER="v12032";
  if(!RG.BATTLE_ARRAYS)return;   // 旧工具缓存由main加载守卫提示刷新，避免加载时展开空清单。
  const SCHEMA = 2;
  const storageFailures = new Set();
  RG.recordClaimedTime=map=>Math.max(map?.recordRewardTime||0,map?.bestTime||0);
  RG.recordStorageResult = function (key, ok) {
    const failed = storageFailures.size > 0;
    if (ok) storageFailures.delete(key); else storageFailures.add(key);
    RG.storageStatus = { ok: !storageFailures.size, message: storageFailures.size ? "保存失败，请导出备份保留当前进度" : "存档已保存" };
    if (!ok && (!failed || Date.now() - (RG.storageNoticeAt || 0) > 15000)) {
      RG.storageNoticeAt = Date.now();
      if (RG.showNotice) RG.showNotice(RG.storageStatus.message, true);
    } else if (failed && !storageFailures.size && RG.showNotice) RG.showNotice("存档已恢复正常");
    return ok;
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function checksum(text) {
    // FNV-1a 32 位；用于识别截断、半写入和被意外改坏的存档，不承担加密用途。
    let hash = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 0x01000193);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function decode(raw, normalize) {
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      let data = parsed;
      if (parsed && parsed.schema !== undefined) {
        if (parsed.schema !== SCHEMA || !parsed.data || typeof parsed.check !== "string") return null;
        const body = JSON.stringify(parsed.data);
        if (checksum(body) !== parsed.check) return null;
        data = parsed.data;
      }
      return normalize ? normalize(data) : data;
    } catch (err) { return null; }
  }

  RG.loadSafe = function (key, defaults, normalize) {
    const fallback = clone(defaults);
    let primary = null, backup = null;
    try { if (typeof localStorage === "undefined") return fallback; primary = localStorage.getItem(key); backup = localStorage.getItem(key + "_backup"); } catch (err) { RG.recordStorageResult(key, false); return fallback; }
    const direct = decode(primary, normalize);
    if (direct) return direct;
    const recovered = decode(backup, normalize);
    if (recovered) {
      RG.saveRecovered = true;
      RG.saveRecoveryKey = key;
      RG.saveRecoveryMode = "backup";
      return recovered;
    }
    if (primary || backup) {
      RG.saveRecovered = true;
      RG.saveRecoveryKey = key;
      RG.saveRecoveryMode = "default";
    }
    return fallback;
  };

  RG.saveSafe = function (key, value, normalize) {
    try {
      if (typeof localStorage === "undefined") return RG.recordStorageResult(key, false);
      const clean = normalize ? normalize(value) : value;
      if (!clean) return RG.recordStorageResult(key, false);
      const old = localStorage.getItem(key);
      if (decode(old, normalize)) localStorage.setItem(key + "_backup", old);
      const body = JSON.stringify(clean);
      localStorage.setItem(key, JSON.stringify({ schema: SCHEMA, data: clean, check: checksum(body) }));
      return RG.recordStorageResult(key, true);
    } catch (err) { return RG.recordStorageResult(key, false); }
  };

  RG.persistenceChecksum = checksum;

  // 备份局外成长、纪录、键位及音量；战场检查点只在原设备和对应版本恢复。
  const BACKUP_KIND = "RG-save-backup", BACKUP_LIMIT = 300000;
  function safeBackupTree(value, depth = 0) {
    if (depth > 12) return false;
    if (value === null || typeof value !== "object") return typeof value !== "number" || Number.isFinite(value);
    return Object.keys(value).every(k => !["__proto__", "constructor", "prototype"].includes(k) && safeBackupTree(value[k], depth + 1));
  }
  function normalizeBackup(data) {
    if (!data || !safeBackupTree(data) || Object.keys(data).some(k => !["meta", "best", "controls", "volume", "touch"].includes(k))) return null;
    if (!data.meta || !data.best || !data.controls || !data.volume || !RG.normalizeMeta || !RG.normalizeBest) return null;
    const meta = RG.normalizeMeta(data.meta), best = RG.normalizeBest(data.best), volume = {};
    for (const key of ["master", "sfx", "mus", "amb"]) {
      if (!Number.isFinite(data.volume[key]) || data.volume[key] < 0 || data.volume[key] > 1) return null;
      volume[key] = data.volume[key];
    }
    const touch = data.touch || { dead: 14, sens: 1.1 };
    if (touch.analog != null && typeof touch.analog !== "boolean") return null;
    if (!Number.isFinite(touch.dead) || touch.dead < 2 || touch.dead > 30 || !Number.isFinite(touch.sens) || touch.sens < .7 || touch.sens > 1.4) return null;
    return meta && best ? { meta, best, controls: RG.normalizeControls(data.controls), volume, touch: { dead: touch.dead, sens: touch.sens, analog: touch.analog === true } } : null;
  }
  RG.exportSaveBackup = function () {
    try {
      const data = normalizeBackup({ meta: RG.meta, best: RG.best, controls: RG.controls, volume: { master: RG.masterVol, sfx: RG.sfxVol, mus: RG.musicVol, amb: RG.ambVol }, touch: { dead: RG.joyDead ?? 14, sens: RG.joySens ?? 1.1, analog: RG.joyAnalog === true } });
      if (!data) return null;
      return JSON.stringify({ kind: BACKUP_KIND, schema: 1, version: RG.VERSION, createdAt: new Date().toISOString(), data, check: checksum(JSON.stringify(data)) }, null, 2);
    } catch (err) { return null; }
  };
  RG.readSaveBackup = function (raw) {
    try {
      if (typeof raw !== "string" || raw.length > BACKUP_LIMIT) return null;
      const file = JSON.parse(raw);
      if (!file || file.kind !== BACKUP_KIND || file.schema !== 1 || !file.data || file.check !== checksum(JSON.stringify(file.data))) return null;
      return normalizeBackup(file.data);
    } catch (err) { return null; }
  };
  RG.importSaveBackup = function (raw) {
    if (RG.state !== "settings" || RG.returnState !== "menu") return false;
    const data = RG.readSaveBackup(raw); if (!data) return false;
    // 导入可恢复构筑和余额，但本安装已经领取的单次奖励不能回滚后再领。
    for(const id of ['valley','workshop'])if(RG.meta?.maps?.[id]?.firstClearPaid||RG.meta?.maps?.[id]?.wins>0)data.meta.maps[id].firstClearPaid=true;
    for(const id of ['valley','workshop'])data.meta.maps[id].recordRewardTime=Math.max(RG.recordClaimedTime(RG.meta?.maps?.[id]),RG.recordClaimedTime(data.meta.maps[id]));
    const br=data.meta.bossRush,currentBr=RG.meta?.bossRush;
    if(currentBr){br.cleared=[...new Set([...br.cleared,...(currentBr.cleared||[])])];br.unlocked=Math.max(br.unlocked,currentBr.unlocked||1);}
    const currentDaily=RG.meta?.daily,incomingDaily=data.meta.daily;
    const dayOrder=d=>{const [y,m,day]=String(d?.key||'').split('-').map(Number);return y*372+m*31+day;};
    if(currentDaily&&(!incomingDaily||!Number.isFinite(dayOrder(incomingDaily))||dayOrder(currentDaily)>dayOrder(incomingDaily)))data.meta.daily={...currentDaily};
    else if(currentDaily&&incomingDaily&&dayOrder(currentDaily)===dayOrder(incomingDaily)){incomingDaily.key=currentDaily.key;incomingDaily.done||=!!currentDaily.done;incomingDaily.rewardWon||=!!currentDaily.rewardWon;incomingDaily.rewardPaid=Math.max(incomingDaily.rewardPaid||0,currentDaily.rewardPaid||0);incomingDaily.best=Math.max(incomingDaily.best||0,currentDaily.best||0);}
    const encode = value => JSON.stringify({ schema: SCHEMA, data: value, check: checksum(JSON.stringify(value)) });
    const writes = { rogue_meta: encode(data.meta), rogue_best: encode(data.best), rg_controls: encode(data.controls), rg_vol: JSON.stringify(data.volume), rg_touch: JSON.stringify(data.touch) };
    const old = new Map();
    try {
      for (const key of Object.keys(writes)) { old.set(key, localStorage.getItem(key)); old.set(key + "_backup", localStorage.getItem(key + "_backup")); }
      for (const [key, value] of Object.entries(writes)) {
        const previous = old.get(key); if (previous !== null) localStorage.setItem(key + "_backup", previous);
        localStorage.setItem(key, value);
      }
    } catch (err) {
      // 写入未全部成功前不应用到内存，尽力撤回已写入键，保留当前进度供导出。
      for (const [key, value] of old) try { if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value); } catch (ignored) {}
      RG.recordStorageResult("backup-import", false); return false;
    }
    if (RG.clearRunCheckpoint) RG.clearRunCheckpoint();
    RG.meta = data.meta; RG.best = data.best; RG.controls = data.controls;
    RG.masterVol = data.volume.master; RG.sfxVol = data.volume.sfx; RG.musicVol = data.volume.mus; RG.ambVol = data.volume.amb;
    RG.joyDead = data.touch.dead; RG.joySens = data.touch.sens; RG.joyAnalog=data.touch.analog;
    RG.fxQuality = data.meta.fxQuality; RG.fxAuto = data.meta.fxAuto; RG.fxAutoReduced = false;
    if (RG.applyDisplaySettings) RG.applyDisplaySettings();
    RG.P = null; RG.run = null; RG.backupPreview = null;
    for (const key of ["rogue_meta", "rogue_best", "rg_controls", "rg_vol", "rg_touch", "backup-import"]) RG.recordStorageResult(key, true);
    return true;
  };

  // 检查点保存整个战场对象图：穿透命中集合、首领引用、召唤物与秘境地图不能拆开复制。
  const RUN_KEY = "rogue_run_checkpoint", RUN_SLOT = RUN_KEY + "_generation";
  const RUN_VERSION = "v12.0.32", RUN_COMPATIBLE=[RUN_VERSION,"v12.0.31","v12.0.30","v12.0.29","v12.0.28","v12.0.27","v12.0.26","v12.0.25","v12.0.24","v12.0.23","v12.0.22","v12.0.21","v12.0.20","v12.0.19","v12.0.18","v12.0.17","v12.0.16","v12.0.15","v12.0.14","v12.0.13","v12.0.12","v12.0.11","v12.0.10","v12.0.9","v12.0.8","v12.0.7","v12.0.6","v12.0.5","v12.0.4","v12.0.3","v12.0.2","v12.0.1","v12.0.0","v11.9.52","v11.9.51","v11.9.50","v11.9.49","v11.9.48","v11.9.47","v11.9.46","v11.9.45","v11.9.44","v11.9.43","v11.9.42","v11.9.41","v11.9.40","v11.9.39","v11.9.38","v11.9.37","v11.9.36","v11.9.35","v11.9.34","v11.9.33","v11.9.32","v11.9.31","v11.9.30","v11.9.29","v11.9.28","v11.9.27","v11.9.26","v11.9.25"], RUN_SCHEMA = 1, MAX_BYTES = 2000000, MAX_NODES = 20000;
  const RUN_ARRAYS = RG.BATTLE_ARRAYS;
  const RESUME_STATES=['play','levelup','runshop'];
  const validResume=(state,battle)=>RESUME_STATES.includes(state)&&(state!=='levelup'||battle.offers.length>0)&&(state==='runshop'?battle.run.shopOpen===true:battle.run.shopOpen!==true);
  const RUN_FIELDS = ["P", "run", "walls", "boundary", "realm", "cam", "portal", "keysHeld", "timeStop", "auraT", "auraPulse", "bossIntro", "bossIntroName", "tempWalls", "spinnerSeq", "lastWeapon", "oathSw", "oathSwarm", "oathFrail", "runMetaDaily", "ricLast", "combo", "comboT", "killStreak", "killTimes", "comboKills", "multiKillN", "offerKind", ...RUN_ARRAYS];
  const CACHE_FIELDS = new Set(["_spr", "_sprDpr", "_ruin", "_ruinSource", "_ruinW", "_ruinH","_resonance"]);
  const BAD_KEYS = new Set(["__proto__", "prototype", "constructor"]);
  const PROGRESS_FIELDS = ["coins", "runs", "won", "wUnlocked", "perks", "bossRush", "achievements", "runLog", "daily"];
  let checkpointCache, checkpointSequence = 0;

  function stable(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return "[" + value.map(v => stable(v) || "null").join(",") + "]";
    return "{" + Object.keys(value).sort().filter(k => value[k] !== undefined).map(k => JSON.stringify(k) + ":" + stable(value[k])).join(",") + "}";
  }
  function progressStamp(meta, best, legacy=false) {
    const data = {};
    for (const key of PROGRESS_FIELDS) data[key] = meta && meta[key] != null ? meta[key] : null;
    if(!legacy)data.maps=meta?.maps||null;
    data.best = best || null;
    return checksum(stable(data));
  }
  function graphEncode(root) {
    const seen = new Map(), nodes = [];
    function value(v) {
      if (v === undefined) return { u: 1 };
      if (typeof v === "number" && !Number.isFinite(v)) {
        if (Number.isNaN(v)) throw new Error("检查点含无效数字");
        return { n: v > 0 ? "+inf" : "-inf" };
      }
      if (v === null || ["string", "boolean", "number"].includes(typeof v)) return v;
      if (typeof v !== "object") throw new Error("检查点含不可保存类型");
      if (seen.has(v)) return { r: seen.get(v) };
      if (nodes.length >= MAX_NODES) throw new Error("检查点实体过多");
      const id = nodes.length, node = {}; seen.set(v, id); nodes.push(node);
      if (Array.isArray(v)) { node.t = "a"; node.v = v.map(value); }
      else if (v instanceof Set) { node.t = "s"; node.v = [...v].map(value); }
      else if (v instanceof Map) { node.t = "m"; node.v = [...v].map(([k, item]) => [value(k), value(item)]); }
      else {
        const proto = Object.getPrototypeOf(v);
        if (proto !== Object.prototype && proto !== null) throw new Error("检查点含运行时对象");
        node.t = "o"; node.v = [];
        for (const key of Object.keys(v)) {
          if (CACHE_FIELDS.has(key)) continue;
          if (BAD_KEYS.has(key)) throw new Error("检查点字段不合法");
          node.v.push([key, value(v[key])]);
        }
      }
      return { r: id };
    }
    const entry = value(root);
    return { root: entry, nodes };
  }
  function graphDecode(graph) {
    if (!graph || Object.keys(graph).some(k => !["root", "nodes"].includes(k)) || !Array.isArray(graph.nodes) || !graph.nodes.length || graph.nodes.length > MAX_NODES) throw new Error("检查点对象图不合法");
    const objects = graph.nodes.map(node => {
      if (!node || Object.keys(node).some(k => !["t", "v"].includes(k)) || !Array.isArray(node.v) || node.v.length > MAX_NODES) throw new Error("检查点节点不合法");
      if (node.t === "a") return [];
      if (node.t === "s") return new Set();
      if (node.t === "m") return new Map();
      if (node.t === "o") return {};
      throw new Error("检查点节点类型不合法");
    });
    let edges = 0;
    function value(v) {
      if (++edges > MAX_NODES * 12) throw new Error("检查点引用过多");
      if (typeof v === "number" && !Number.isFinite(v)) throw new Error("检查点数字不合法");
      if (v === null || ["string", "boolean", "number"].includes(typeof v)) return v;
      if (!v || typeof v !== "object" || Array.isArray(v) || Object.keys(v).length !== 1) throw new Error("检查点值不合法");
      if (v.u === 1) return undefined;
      if (v.n === "+inf") return Infinity;
      if (v.n === "-inf") return -Infinity;
      if (Number.isInteger(v.r) && v.r >= 0 && v.r < objects.length) return objects[v.r];
      throw new Error("检查点引用不合法");
    }
    for (let i = 0; i < graph.nodes.length; i++) {
      const node = graph.nodes[i], out = objects[i];
      for (const item of node.v) {
        if (node.t === "a") out.push(value(item));
        else if (node.t === "s") out.add(value(item));
        else {
          if (!Array.isArray(item) || item.length !== 2) throw new Error("检查点条目不合法");
          if (node.t === "m") out.set(value(item[0]), value(item[1]));
          else {
            if (typeof item[0] !== "string" || BAD_KEYS.has(item[0]) || Object.hasOwn(out, item[0])) throw new Error("检查点字段不合法");
            out[item[0]] = value(item[1]);
          }
        }
      }
    }
    return value(graph.root);
  }
  // 现行时长读取配置；旧上界仅作历史现场兼容底线，不回写玩法配置。
  const checkpointStateBounds={
    "wrathBloodT":()=>Math.max(RG.OATH_NODES.sin_wrath.rules.killEnemy.killEnemy_refreshStatusArg3),
    "reactionAfterT":()=>Math.max(RG.PASSIVES.aftershock.rules.elemReaction.elemReaction_refreshStatusArg3),
    "dodgeSpeedT":()=>Math.max(RG.PASSIVES.evade.dodgeDuration),
    "shieldCounterT":()=>Math.max(RG.PASSIVES.shieldcounter.duration),
    "painT":()=>Math.max(RG.PASSIVES.pain.duration),
    "dashEchoT":()=>Math.max(RG.PASSIVES.dashecho.duration),
    "slowT":()=>Math.max(RG.BALANCE.combat.update.update_refreshStatusArg3),
    "xpWindT":()=>Math.max(RG.PASSIVES.xpwind.rules.update.update_refreshStatusArg3),
    "chargeAfterT":()=>Math.max(RG.PASSIVES.chargecircuit.rules.useActive.useActive_refreshStatusArg3),
    "levelHasteT":()=>Math.max(RG.PASSIVES.leveldash.rules.gainXP.gainXP_refreshStatusArg3)
  };
  const configuredStateLimit=(key,legacy)=>Math.max(legacy,checkpointStateBounds[key]?.()||0);
  function validBattle(battle) {
    if (!battle || typeof battle !== "object" || Object.keys(battle).some(k => !RUN_FIELDS.includes(k))) return false;
    const p = battle.P, r = battle.run;
    const finite = (v, lo, hi) => Number.isFinite(v) && v >= lo && v <= hi;
    const position = o => o && finite(o.x, -1e7, 1e7) && finite(o.y, -1e7, 1e7);
    if (!p || !r || !finite(p.hp, .000001, 1e12) || !finite(p.maxhp, .000001, 1e12) || !position(p) || !finite(p.r, .000001, 10000) || !finite(p.speed, 0, 100000) || !Number.isInteger(p.level) || p.level < 1 || p.level > 1e6 || !p.weapons || !p.passives || !Array.isArray(p.levelQueue) || p.levelQueue.length > 128) return false;
    if(!Object.keys(p.weapons).every(id=>RG.WEAPONS[id]&&Number.isInteger(p.weapons[id])&&p.weapons[id]>=1&&p.weapons[id]<=8))return false;
    if(!['reactionAfterT','chargeAfterT','tetherGuardT'].every(k=>p[k]===undefined||finite(p[k],0,configuredStateLimit(k,3))))return false;
    if(p.summonAfterT!==undefined&&!finite(p.summonAfterT,0,Math.max(2,RG.BALANCE.growth.onSummonExit.summonAfterT))||p.resonanceShieldCd!==undefined&&!finite(p.resonanceShieldCd,0,10))return false;
    if(p.xpWindT!==undefined&&!finite(p.xpWindT,0,configuredStateLimit("xpWindT",2))||p.levelHasteT!==undefined&&!finite(p.levelHasteT,0,configuredStateLimit("levelHasteT",8)))return false;
    if(!['xpwind','leveldash','openingstrike'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(!['reactionchain','elementunity'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(!['weakmark','critstreak','causality'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(p.critStreak!==undefined&&(!Number.isInteger(p.critStreak)||!finite(p.critStreak,0,RG.PASSIVES.critstreak.maxStacks)||p.critStreak>0&&(!p.passives.critstreak||p.critDLocked)))return false;
    if(p.causalityCd!==undefined&&!finite(p.causalityCd,0,RG.PASSIVES.causality.cooldown))return false;
    if(!['bloodheal','pain','bloodline'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(p.painT!==undefined&&(!finite(p.painT,0,configuredStateLimit("painT",2))||p.painT>0&&!p.passives.pain))return false;
    if(!['rally','legion'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(!['dashecho','windwalker','mountain'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(p.windMoveT!==undefined&&(!finite(p.windMoveT,0,RG.PASSIVES.windwalker.maxStacks)||p.windMoveT>0&&!p.passives.windwalker))return false;
    if(p.dashEchoT!==undefined&&(!finite(p.dashEchoT,0,configuredStateLimit("dashEchoT",2))||p.dashEchoT>0&&!p.passives.dashecho))return false;
    if(p.echoDashActive!==undefined&&typeof p.echoDashActive!=='boolean'||p.echoDashMoved!==undefined&&typeof p.echoDashMoved!=='boolean')return false;
    if(p.echoDashActive&&(!(p.dashT>0)||!p.passives.dashecho)||p.echoDashMoved&&!p.echoDashActive)return false;
    if(!['fullshield','shieldcounter'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(p.shieldCounterT!==undefined&&(!finite(p.shieldCounterT,0,configuredStateLimit("shieldCounterT",3))||p.shieldCounterT>0&&!p.passives.shieldcounter))return false;
    if(p.dodgeSpeedT!==undefined&&(!finite(p.dodgeSpeedT,0,configuredStateLimit("dodgeSpeedT",2))||p.dodgeSpeedT>0&&!p.passives.evade))return false;
    if(!['slaughter','debt'].every(k=>p.passives[k]===undefined||p.passives[k]===1))return false;
    if(!['scavenger','goldguard','goldrain'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(p.autoCd?.goldrain!==undefined&&!finite(p.autoCd.goldrain,0,RG.PASSIVES.goldrain.period))return false;
    if(r.compoundStacks!==undefined&&(!Number.isInteger(r.compoundStacks)||!finite(r.compoundStacks,0,RG.PASSIVES.compound.rules.addCoin.compoundStacks_threshold))||r.coinAcc!==undefined&&!finite(r.coinAcc,0,1e12))return false;
    if(!['valhalla','mirrorecho','resonanceheart'].every(k=>p.passives[k]===undefined||p.passives[k]===1))return false;
    if(p.autoCd?.mirrorecho!==undefined&&!finite(p.autoCd.mirrorecho,0,RG.PASSIVES.mirrorecho.period)||p.valhallaT!==undefined&&(!finite(p.valhallaT,0,Math.max(3,RG.PASSIVES.valhalla.duration))||p.valhallaT>0&&!p.passives.valhalla))return false;
    if(p.lastActiveId!==undefined&&(!RG.ACTIVES[p.lastActiveId]||!p.actives[p.lastActiveId]||!p.activeOrder.includes(p.lastActiveId)))return false;
    if(p.envyCardBonus!==undefined&&(!finite(p.envyCardBonus,0,RG.OATH_NODES.sin_envy.rules.applyOffer.envyCardBonus_cap)||p.envyCardBonus>0&&p.sinId!=='sin_envy'))return false;
    if(p.wrathBloodT!==undefined&&(!finite(p.wrathBloodT,0,configuredStateLimit("wrathBloodT",8))||p.wrathBloodT>0&&(p.sinId!=='sin_wrath'||!p.passives.bloodheal||!p.healBan)))return false;
    if(p.wrathBloodStacks!==undefined&&(!Number.isInteger(p.wrathBloodStacks)||!finite(p.wrathBloodStacks,0,RG.OATH_NODES.sin_wrath.rules.wrathBloodBonus.wrathBloodBonus_cap)||p.wrathBloodStacks>0&&!(p.wrathBloodT>0)))return false;
    if(p.activeEvolved!==undefined&&(!p.activeEvolved||Array.isArray(p.activeEvolved)||!Object.entries(p.activeEvolved).every(([id,branch])=>p.actives?.[id]===RG.ACTIVES[id]?.maxLv&&p.activeOrder?.includes(id)&&RG.ACTIVE_EVOLVE[id]?.branches.some(b=>b.id===branch))))return false;
    const overdrive=RG.ACTIVE_EVOLVE.overdrive.branches,overload=overdrive.find(b=>b.id==='overload'),perpetual=overdrive.find(b=>b.id==='perpetual');
    if(p.overdriveCastBranch!==undefined&&!['base','overload','perpetual'].includes(p.overdriveCastBranch)||p.overdriveWeakT!==undefined&&!finite(p.overdriveWeakT,0,overload.weakness)||p.overdriveCapLeft!==undefined&&!finite(p.overdriveCapLeft,0,perpetual.total))return false;
    if(p.overdriveCastBranch&&p.overdriveCastBranch!=='base'&&(p.activeEvolved?.overdrive!==p.overdriveCastBranch||!finite(p.overdriveT,0,p.overdriveCastBranch==='overload'?overload.duration:perpetual.total)))return false;
    if(p.overdriveCastBranch==='perpetual'&&p.overdriveT>0&&(!finite(p.overdriveCapLeft,p.overdriveT-1e-7,perpetual.total)||p.overdriveWeakT>0))return false;
    if(p.overdriveWeakT>0&&(p.overdriveCastBranch!=='overload'||p.overdriveT>0)||p.overdriveCapLeft>0&&(p.overdriveCastBranch!=='perpetual'||!(p.overdriveT>0)))return false;
    if(p.aegisCastBranch!==undefined&&!['base','void','mirror'].includes(p.aegisCastBranch)||p.aegisEvoT!==undefined&&!finite(p.aegisEvoT,0,Math.max(...RG.ACTIVE_EVOLVE.aegis.branches.map(b=>b.duration)))||p.aegisCleared!==undefined&&(!Number.isInteger(p.aegisCleared)||!finite(p.aegisCleared,0,999))||p.aegisReflected!==undefined&&(!Number.isInteger(p.aegisReflected)||!finite(p.aegisReflected,0,RG.ACTIVES.aegis.guards(RG.ACTIVES.aegis.maxLv))))return false;
    if(p.aegisCastBranch&&p.aegisCastBranch!=='base'&&p.activeEvolved?.aegis!==p.aegisCastBranch||p.aegisEvoT>0&&(!['void','mirror'].includes(p.aegisCastBranch)||!Number.isInteger(p.activeGuard)||!finite(p.activeGuard,1,RG.ACTIVES.aegis.guards(RG.ACTIVES.aegis.maxLv))))return false;
    if(!['spores','earthbalance','aftershock','chargecircuit'].every(k=>p.passives[k]===undefined||Number.isInteger(p.passives[k])&&finite(p.passives[k],1,RG.PASSIVES[k].maxLv)))return false;
    if(!['thunder','chrono'].every(k=>p.actives?.[k]===undefined||Number.isInteger(p.actives[k])&&finite(p.actives[k],1,RG.ACTIVES[k].maxLv)&&finite(p.activeCd?.[k]??0,0,32)))return false;
    for(const key of ['hammerQueue','novaQueue','boltBurstQueue','seekerBurstQueue']){
      if(!Array.isArray(p[key])||p[key].length>64||!p[key].every(item=>item&&finite(item.t,-1,60)&&item.st&&
        finite(item.st.dmg,0,1e12)&&(key!=='hammerQueue'||position(item.attack)&&finite(item.attack.length,0,1e6)&&finite(item.attack.width,0,1e6))))return false;
    }
    if(r.openingGold!==undefined&&!finite(r.openingGold,0,RG.BALANCE.economy.openingGold)||r.shopVisits!==undefined&&(!Number.isInteger(r.shopVisits)||!finite(r.shopVisits,0,1e6))||r.shopThrough!==undefined&&(!Number.isInteger(r.shopThrough)||!finite(r.shopThrough,0,1e6))||r.shopOpen!==undefined&&typeof r.shopOpen!=='boolean')return false;
    if(p.shieldRecoverExtra!==undefined&&!finite(p.shieldRecoverExtra,0,RG.BALANCE.combat.hurtPlayer.missingRecovery*RG.BALANCE.combat.hurtPlayer.tripleCost))return false;
    if (!finite(r.t, 0, 1e9) || !finite(r.coins, 0, 1e12) || !finite(r.kills, 0, 1e12) || r.rushEndT > 0) return false;
    if(r.slaughterStacks!==undefined&&(!Number.isInteger(r.slaughterStacks)||!finite(r.slaughterStacks,0,RG.PASSIVES.slaughter.rules.killEnemy.slaughterStacks_threshold))||r.slaughN!==undefined&&(!Number.isInteger(r.slaughN)||!finite(r.slaughN,0,1e12)))return false;
    if(r.firstClearBonus!==undefined&&(![0,...Object.values(RG.MAPS).map(m=>m.firstClearGold).filter(Number.isFinite)].includes(r.firstClearBonus)||r.firstClearBonus>0&&(r.rushMode||!r.won||r.firstClearBonus!==RG.mapConfig(r.mapId).firstClearGold)))return false;
    if(r.mapId!==undefined&&!['legacy','valley','workshop'].includes(r.mapId))return false;
    if(r.mapId&&(!Number.isInteger(r.bossNum)||r.bossNum<0||r.bossNum>RG.mapConfig(r.mapId).bosses.length))return false;
    if (!Array.isArray(battle.walls) || battle.walls.length > 1024 || !battle.boundary || !Array.isArray(battle.boundary.pts) || battle.boundary.pts.length < 3 || battle.boundary.pts.length > 128 || !battle.boundary.pts.every(position) || !battle.realm || !position(battle.cam)) return false;
    const spaceConfig=RG.BOSS_SKILLS.domain.space;
    for(const e of battle.enemies||[])if(e.space){const s=e.space;
      if(e.bossKind!=='domain'||![1,2].includes(s.phase)||!Array.isArray(s.gates)||s.gates.length>64||!s.gates.every(g=>position(g)&&g.owner===e&&['pair','hole','small','ultimate'].includes(g.kind)&&finite(g.life,0,Math.max(spaceConfig.ultimate.life,spaceConfig.hole.life,spaceConfig.small.life,spaceConfig.pair.life))&&finite(g.warn,0,Math.max(spaceConfig.pair.warn,spaceConfig.ultimate.warn))&&finite(g.length,1,Math.max(300,...[spaceConfig.pair,spaceConfig.small,spaceConfig.hole,spaceConfig.ultimate].map(c=>c.length)))&&finite(g.a,-1e6,1e6)&&finite(g.shotT,-1,Math.max(10,spaceConfig.small.shotEvery,...spaceConfig.ultimate.interval))&&(!g.mate||s.gates.includes(g.mate)&&g.mate.mate===g)))return false;
      if(s.sequence&&(!position(s.sequence.center)||!Number.isInteger(s.sequence.count)||!finite(s.sequence.count,...spaceConfig.small.count)||!finite(s.sequence.left,1,s.sequence.count)))return false;
    }
    if(p.spaceWoundT!==undefined&&!finite(p.spaceWoundT,0,spaceConfig.hole.wound)||p.freezeT!==undefined&&!finite(p.freezeT,0,Math.max(10,RG.FROST_BOSS.field.freeze))||p.poisonContactT!==undefined&&!finite(p.poisonContactT,0,Math.max(10,RG.BALANCE.combat.update.ptick)))return false;
    // 新寒冰现场也须完整且有界；坏冰墙/尸体不能在恢复后触发绘制异常。
    for(const e of battle.enemies||[])if(e.frost){
      const s=e.frost;
      if(![1,2].includes(s.phase)||!['shieldT','fieldT','breathT','slowT','wallT'].every(k=>finite(s[k],-1,1e5))||!finite(e.shieldHp||0,0,1e12))return false;
      if(!Array.isArray(s.walls)||s.walls.length>Math.max(12,RG.FROST_BOSS.wall.count)||!s.walls.every(w=>position(w)&&finite(w.r,1,1e4)&&finite(w.width,1,1e3)&&finite(w.a,-100,100)&&finite(w.warn,0,Math.max(1,RG.FROST_BOSS.wall.warn))&&finite(w.t,-1,RG.FROST_BOSS.wall.life)&&typeof w.full==='boolean'))return false;
      if(!Array.isArray(s.wallQueue)||s.wallQueue.length>2||!s.wallQueue.every(w=>position(w)&&finite(w.r,1,1e4)&&finite(w.width,1,1e3)&&finite(w.a,-100,100)&&finite(w.warn,0,Math.max(1,RG.FROST_BOSS.wall.warn))&&finite(w.t,0,RG.FROST_BOSS.wall.life)&&finite(w.delay,0,Math.max(4,RG.FROST_BOSS.wall.gap*(RG.FROST_BOSS.wall.count-1)))&&typeof w.full==='boolean'))return false;
      if(!Array.isArray(s.corpses)||s.corpses.length>512||!s.corpses.every(c=>position(c)&&finite(c.r,1,1e4)&&finite(c.xp,0,1e12)&&[0,1,2].includes(c.tier)&&RG.ETYPES[c.type]&&(c.animClock===undefined||finite(c.animClock,0,1e9))&&(c.faceA===undefined||finite(c.faceA,-100,100))&&(c.faceDir===undefined||[0,1,2,3].includes(c.faceDir))))return false;
      if(s.breath&&(![0,1].includes(s.breath.phase)||!Number.isInteger(s.breath.index)||s.breath.index<0||s.breath.index>Math.max(...RG.FROST_BOSS.breath.count)-1||!finite(s.breath.next,-1,1)))return false;
    }
    if (!RUN_ARRAYS.every(k => Array.isArray(battle[k]) && battle[k].length <= (["bullets", "ebullets"].includes(k) ? 8192 : k === "enemies" ? 1024 : k === "offers" ? 64 : 2048))) return false;
    if(r.experiment!=null&&(r.experiment!=='crossfire'||r.mapId!=='workshop'||r.rushMode||r.daily))return false;
    if(r.crossfireSquadNext!==undefined&&(!Number.isInteger(r.crossfireSquadNext)||!finite(r.crossfireSquadNext,0,1e9)))return false;
    if(r.crossfireStats&&!['hits','kills','damage'].every(k=>finite(r.crossfireStats[k],0,1e15)))return false;
    for(const a of [...battle.hbeams,...battle.rings])if(a.crossfireKind!==undefined){
      if(r.experiment!=='crossfire'||!['prism','smasher'].includes(a.crossfireKind)||a.crossfireSource!=='enemyCrossfire'||!position(a.crossfireOwner)||!(a.crossfireHit instanceof Set)||a.crossfireHit.size>1024||![...a.crossfireHit].every(position))return false;
    }
    const rallyExtra=p.passives.rally>=RG.PASSIVES.rally.capacityLevel?RG.PASSIVES.rally.capacityBonus:0,extra=(RG.resonanceCounts(p).summon>=RG.resonanceThreshold(p,RG.RESONANCE_RULES.first)?1:0)+rallyExtra;
    const exits=battle.autoFx.filter(f=>f.type==='valhalla');if(exits.length>RG.PASSIVES.valhalla.rules.onSummonExit.length_threshold||!exits.every(f=>p.passives.valhalla&&position(f)&&f.r===RG.PASSIVES.valhalla.radius&&finite(f.dmg,.000001,RG.PASSIVES.valhalla.cap)&&f.t===0&&f.max===0))return false;
    if(!battle.autoFx.filter(f=>f.active==='collapse').every(f=>f.copyScale===undefined||[1,RG.PASSIVES.mirrorecho.scale].includes(f.copyScale)))return false;
    if(!battle.phantoms.every(a=>a.baseDamage===undefined||finite(a.baseDamage,.000001,1e12)))return false;
    const fields=battle.autoFx.filter(f=>f.active==='collapse');if(fields.filter(f=>!f.done).length>RG.ACTIVES.collapse.rules.useActive.length_threshold||!fields.every(f=>position(f)&&finite(f.r,1,RG.ACTIVES.collapse.radius(RG.ACTIVES.collapse.maxLv))&&finite(f.dmg,0,1e12)&&f.damageSource==='active:collapse'&&['horizon','starburst'].includes(f.branch)&&f.type===(f.branch==='horizon'?'collapseWell':'collapseBurst')&&finite(f.t,0,RG.ACTIVE_EVOLVE.collapse.branches.find(b=>b.id===f.branch).duration)&&f.max===(RG.ACTIVE_EVOLVE.collapse.branches.find(b=>b.id===f.branch).duration)&&finite(f.tick,0,RG.ACTIVE_EVOLVE.collapse.branches.find(b=>b.id==='horizon').period)))return false;
    if(!battle.bullets.filter(b=>b.active==='aegis').every(b=>b.raw===true&&b.phaseReflected===true&&b.damageSource==='active:aegis:mirror'&&finite(b.dmg,0,1e12)&&finite(b.life,0,2)&&finite(b.r,.01,8)&&b.pierce===0&&!b.summon))return false;
    if(battle.phantoms.filter(a=>!a.dead&&a.t>0).length>RG.summonLimit(RG.PASSIVES.phantom.rules.update.update_summonLimitArg1,p)||battle.allies.filter(a=>a.puppet&&!a.dead&&a.hp>0).length>RG.summonLimit(RG.OATH_NODES.sin_lust.rules.conversion.limit,p)||battle.allies.filter(a=>a.source==='loyal'&&!a.dead).length>RG.summonLimit(RG.PASSIVES.loyal.rules.killEnemy.killEnemy_summonLimitArg1,p))return false;
    if(battle.decoys.filter(a=>!a.dead&&a.hp>0&&a.t>0).length>RG.decoyLimit(p)||battle.allies.filter(a=>a.source==='holylight'&&!a.dead&&a.hp>0&&a.t>0).length>RG.holyLightLimit(p))return false;
    const validSummonTime=(a,base)=>{const lv=a.rallyLv??0,max=Math.round(base*(1+RG.PASSIVES.rally.durationPerLevel*lv)*100)/100;return Number.isInteger(lv)&&finite(lv,0,RG.PASSIVES.rally.maxLv)&&(a.dead||finite(a.t,0,max))&&(a.max===undefined||a.max===max);};
    if(!battle.phantoms.every(a=>validSummonTime(a,RG.PASSIVES.phantom.rules.update.duration_summonDurationArg1))||!battle.decoys.every(a=>validSummonTime(a,RG.PASSIVES.scapegoat.rules.updateAutoCards.duration_summonDurationArg1))||!battle.allies.filter(a=>a.source==='holylight').every(a=>validSummonTime(a,RG.PASSIVES.holylight.rules.updateAutoCards.duration_summonDurationArg1)))return false;
    for(const e of battle.enemies){
      if(e.meadowAge!==undefined&&!finite(e.meadowAge,0,1e9)||e.meadowCd!==undefined&&!finite(e.meadowCd,-1e9,10)||e.meadowWind!==undefined&&!finite(e.meadowWind,0,1))return false;
      if(e.type==='tether'&&e.meadowWind>0&&(!finite(e.tetherX,-1e7,1e7)||!finite(e.tetherY,-1e7,1e7)))return false;
      if(e.mobilityCritT!==undefined&&(!finite(e.mobilityCritT,0,RG.BALANCE.mobility.markDuration)||e.mobilityCritT>0&&(!p.passives.ghost_img&&!p.passives.voidstep||e.isClone||e.workshopHole)))return false;
      if(e.iceFreezeT!==undefined&&(!finite(e.iceFreezeT,0,1.2)||e.iceFreezeT>0&&(!(e.frozen>0)||e.iceFreezeT>e.frozen+1e-7)))return false;
      if(e.weakmarkHits!==undefined&&(!Number.isInteger(e.weakmarkHits)||!finite(e.weakmarkHits,0,Math.max(...RG.PASSIVES.weakmark.hits))||e.weakmarkHits>0&&!p.passives.weakmark)||e.weakmarkCd!==undefined&&!finite(e.weakmarkCd,0,RG.PASSIVES.weakmark.cooldown))return false;
      if(e.chronoT!==undefined&&!finite(e.chronoT,0,e.boss?RG.ACTIVES.chrono.bossDuration(RG.ACTIVES.chrono.maxLv):RG.ACTIVES.chrono.duration(RG.ACTIVES.chrono.maxLv))||e.earthImbalanceT!==undefined&&!finite(e.earthImbalanceT,0,RG.PASSIVES.earthbalance.rules.applyElem.applyElem_refreshStatusArg3)||e.poisonSpore!==undefined&&typeof e.poisonSpore!=='boolean')return false;
      if(e.workshopRunes&&(!Array.isArray(e.workshopRunes)||e.workshopRunes.length>RG.BOSS_SKILLS.shared.updateWorkshopRunes.length_threshold||!e.workshopRunes.every(r=>position(r)&&finite(r.r,1,100)&&finite(r.t,0,RG.BOSS_SKILLS.shared.updateWorkshopRunes.t)&&finite(r.hold,0,RG.BOSS_SKILLS.shared.updateWorkshopRunes.hold_threshold))))return false;
      if(e.workshopValves&&(!Array.isArray(e.workshopValves)||e.workshopValves.length>RG.BOSS_SKILLS.shared.updateWorkshopValves.length_threshold||!e.workshopValves.every(v=>position(v)&&finite(v.r,1,100)&&finite(v.hold,0,RG.BOSS_SKILLS.shared.updateWorkshopValves.hold_threshold)&&typeof v.active==='boolean')||e.workshopValves.filter(v=>v.active).length>RG.BOSS_SKILLS.shared.updateWorkshopValves.available_sliceArg2))return false;
      if(e.valveCooldown!==undefined&&!finite(e.valveCooldown,0,RG.BOSS_SKILLS.shared.updateWorkshopValves.valveCooldown)||e.workshopColdT!==undefined&&!finite(e.workshopColdT,0,RG.BOSS_SKILLS.shared.updateWorkshopValves.workshopColdT))return false;
      if(e.workshopRiftT!==undefined&&!finite(e.workshopRiftT,0,RG.BOSS_SKILLS.shared.closeWorkshopHole.workshopRiftT))return false;
      if(e.workshopHole&&!e.dead&&(!battle.wormholes.includes(e)||!battle.enemies.includes(e.bossOwner)||e.bossOwner.bossKind!=='void'||!e.bossOwner.boss||e.bossOwner.dead||e.bossOwner.dying||r.mapId!=='workshop'||r.rushMode||!finite(e.hp,0,RG.BOSS_SKILLS.shared.spawnWorkshopHoles.hp)||e.maxhp!==RG.BOSS_SKILLS.shared.spawnWorkshopHoles.maxhp||!finite(e.t,0,RG.BOSS_SKILLS.shared.spawnWorkshopHoles.t)||!finite(e.warn,0,RG.BOSS_SKILLS.shared.spawnWorkshopHoles.warn)||!finite(e.wormCd,-1,RG.BOSS_SKILLS.shared.spawnWorkshopHoles.wormCd)))return false;
      if(e.workshopWorm&&!e.dead&&(!battle.enemies.includes(e.bossOwner)||e.bossOwner.bossKind!=='void'||e.bossOwner.dead||e.bossOwner.dying||!finite(e.life,-1,RG.BOSS_SKILLS.shared.updateWorkshopHoles.life)||e.maxhp!==RG.BOSS_SKILLS.shared.updateWorkshopHoles.maxhp||e.speed!==RG.BOSS_SKILLS.shared.updateWorkshopHoles.speed||r.mapId!=='workshop'||r.rushMode))return false;
      if(e.workshopWarp&&(!position(e.workshopWarp)||!finite(e.workshopWarp.aim,-100,100)||!finite(e.workshopWarp.t,0,Math.max(1,RG.BOSS_SKILLS.shared.updateWorkshopWarp.t))||!['warn','recover'].includes(e.workshopWarp.stage)))return false;
      if(e.workshopWarp?.hole&&!battle.wormholes.includes(e.workshopWarp.hole))return false;
      if(e.overOrigin&&(!position(e.overOrigin)||!finite(e.overOrigin.r,1,10000)||!finite(e.overT,0,RG.BOSS_SKILLS.shared.updateWorkshopHeat.overT)))return false;
    }
    if(p.workshopRuneT!==undefined&&(!finite(p.workshopRuneT,0,RG.BOSS_SKILLS.shared.updateWorkshopRunes.workshopRuneT)||p.workshopRuneT>0&&(!battle.enemies.includes(p.workshopRuneOwner)||p.workshopRuneOwner.bossKind!=='domain'||!p.workshopRuneOwner.boss||p.workshopRuneOwner.dead||p.workshopRuneOwner.dying||r.mapId!=='workshop'||r.rushMode)))return false;
    if(p.workshopCoolT!==undefined&&(!finite(p.workshopCoolT,0,RG.BOSS_SKILLS.shared.updateWorkshopValves.workshopCoolT)||p.workshopCoolT>0&&(!battle.enemies.includes(p.workshopCoolOwner)||p.workshopCoolOwner.bossKind!=='furnace'||!p.workshopCoolOwner.boss||p.workshopCoolOwner.dead||p.workshopCoolOwner.dying||r.mapId!=='workshop'||r.rushMode)))return false;
    if(battle.wormholes.filter(w=>w.workshopHole).length>Math.max(RG.BOSS_SKILLS.shared.spawnWorkshopHoles.limit,RG.BOSS_SKILLS.shared.spawnWorkshopHoles.limit_2)||battle.enemies.filter(e=>e.workshopWorm&&!e.dead&&!e.dying).length>RG.BOSS_SKILLS.shared.updateWorkshopHoles.length_threshold||!battle.wormholes.every(w=>!w.workshopHole||battle.enemies.includes(w)&&!w.dead))return false;
    const spores=battle.vials.filter(v=>v.poisonSpore);
    if(spores.length>RG.PASSIVES.spores.rules.killEnemy.length_threshold||!spores.every(v=>position(v)&&RG.PASSIVES.spores.radius.slice(1).includes(v.r)&&finite(v.t,0,RG.PASSIVES.spores.rules.killEnemy.t)&&finite(v.tick,-1,RG.PASSIVES.spores.rules.killEnemy.tick)&&finite(v.dmg,0,1e9)&&v.poison===true&&v.noSlow===true))return false;
    if(!battle.offers.every(o=>o&&(!["weapon","evolve","elementweapon"].includes(o.kind)||RG.WEAPONS[o.id])))return false;
    if(!battle.offers.every(o=>o.kind!=='activeevolve'||RG.canEvolveActive(p,o.id)&&RG.ACTIVE_EVOLVE[o.id]?.branches.some(b=>b.id===o.branch)))return false;
    if (r.boss && !battle.enemies.includes(r.boss) && !r.boss.dead || r.finalBoss && !battle.enemies.includes(r.finalBoss) && !r.finalBoss.dead) return false;
    if (battle.realm.active && (!Array.isArray(battle.realm.mainWalls) || !battle.realm.mainBoundary || !battle.realm.mainPos)) return false;
    return battle.walls.every(w => position(w) && finite(w.w, .000001, 1e6) && finite(w.h, .000001, 1e6) && (!w.meadowTree || w.w===26 && w.h===18 && Number.isInteger(w.treeCell) && w.treeCell>=0 && w.treeCell<=3 && finite(w.treeSize,90,185))) && battle.enemies.every(e => position(e) && finite(e.hp, -1e12, 1e12) && finite(e.r, .000001, 10000) && e.hitCds && typeof e.hitCds === "object") && battle.bullets.every(b => position(b) && finite(b.vx, -1e6, 1e6) && finite(b.vy, -1e6, 1e6) && b.hitSet instanceof Set) && battle.ebullets.every(b => position(b) && finite(b.vx, -1e6, 1e6) && finite(b.vy, -1e6, 1e6));
  }
  // 只迁移审计基线的现场：保留既有局外进度与武器，转换旧延迟字段。
  function migrateBattle(battle,version){
    if(battle.P?.freezeT>0&&!(battle.P.stunT>0))battle.P.freezeT=0;
    if(version!==RUN_VERSION&&version!=="v12.0.31"&&version!=="v12.0.30"&&version!=="v12.0.29"&&battle.run){
      battle.run.openingGold=0;battle.run.shopVisits=RG.BALANCE.economy.openingExpiresAfter;battle.run.shopThrough=battle.P.level;battle.run.shopOpen=false;
      for(const e of battle.enemies||[])if(e.bossKind==='domain')delete e.space;
      battle.domains=(battle.domains||[]).filter(d=>d.bossOwner?.bossKind!=='domain');
    }
    // 旧草原现场保留存量实体、生命与拾取物，只换后续导演，不再补入旧怪。
    if(battle.run?.mapId==='workshop'&&!battle.run.rushMode&&battle.run.roster?.revision!==25){
      battle.run.roster=RG.makeEncounterRoster('workshop');battle.run.squad=null;battle.run.outgoingSquad=null;battle.run.packPending=0;battle.run.squadRestT=0;battle.run.spawnT=Math.max(2,battle.run.spawnT||0);
    }
    // 旧草原现场补齐确定树干，避开现有实体；秘境现场只更新暂存的主地图。
    if(version!==RUN_VERSION&&version!=="v12.0.31"&&version!=="v12.0.30"&&version!=="v12.0.29"&&version!=="v12.0.28"&&version!=="v12.0.27"&&version!=="v12.0.26"&&version!=="v12.0.25"&&battle.run?.mapId==='workshop'&&!battle.run.rushMode){
      const realm=battle.realm?.active,walls=realm?battle.realm.mainWalls:battle.walls;
      if(Array.isArray(walls))walls.push(...RG.makeMeadowTrees(walls,realm?[battle.realm.mainPos]:[battle.P,...battle.enemies]));
    }
    // 里程碑读取原层数，续局不重触发血债；近期现场直接保留战斗数据。
    if(version===RUN_VERSION||version==="v12.0.31"||version==="v12.0.30"||version==="v12.0.29"||version==="v12.0.28"||version==="v12.0.27"||version==="v12.0.26"||version==="v12.0.25"||version==="v12.0.24"||version==="v12.0.23"||version==="v12.0.22"||version==="v12.0.21"||version==="v12.0.20"||version==="v12.0.19"||version==="v12.0.18"||version==="v12.0.17"||version==="v12.0.16"||version==="v12.0.15"||version==="v12.0.14"||version==="v12.0.13"||version==="v12.0.12"||version==="v12.0.11"||version==="v12.0.10"||version==="v12.0.9"||version==="v12.0.8")return battle;
    // 地图缺省视为旧现场；迁移不重排进行中的首领，也不改变地图归属。
    battle.run.mapId??='legacy';
    // 工坊旧版无限寿命传送圈退场；下一轮生成有生命和寿命的新虫洞，不重算首领耐久。
    if(version!==RUN_VERSION&&battle.run.mapId==='workshop'&&!battle.run.rushMode)battle.wormholes=battle.wormholes.filter(w=>!w.bossOwner||w.workshopHole);
    if(version==='v11.9.37'||version==='v11.9.38'||version==='v11.9.39'||version==='v11.9.40'||version==='v11.9.41'||version==='v11.9.42'||version==='v11.9.43'||version==='v11.9.44'||version==='v11.9.45'||version==='v11.9.46'||version==='v11.9.47'||version==='v11.9.48'||version==='v11.9.49'||version==='v11.9.50'||version==='v11.9.51'||version==='v11.9.52'||version==='v12.0.0'||version==='v12.0.1'||version==='v12.0.2'||version==='v12.0.3'||version==='v12.0.4'||version==='v12.0.5'||version==='v12.0.6'||version==='v12.0.7')return battle;
    battle=migrateLegacyBattle(battle,version);
    if(version!==RUN_VERSION){
      // 新耐久按剩余比例迁移，盾与分身一起同步；当前版本续局不再重复乘算。
      if(battle.run?.rushMode){
        const r=battle.run,b=battle.enemies.find(e=>e.rushBoss&&!e.splitChild&&!e.isClone);
        if(b){const ratio=RG.rushBossHp(r.rushLv,r.rushDifficulty||1)/b.maxhp;
          for(const e of battle.enemies)if(e===b||e.splitChild){
            e.hp*=ratio;e.maxhp*=ratio;if(e.shieldHp)e.shieldHp*=ratio;e.cycle=1;
            const limit=r.rushDifficulty===1?1:r.rushDifficulty===3?3:2;
            e.mechanicPhase=Math.min(limit,Math.max(e.mechanicPhase||1,e.frost?.phase||1,e.hp/e.maxhp<=.35?3:e.hp/e.maxhp<=.7?2:1));
            e.fightElapsed=e.mechanicPhase>=3?28:e.mechanicPhase>=2?12:0;
          }
        }
      }
      if(battle.run?.squad)battle.run.squad.entryRate=RG.spawnArrivalRate(battle.run.t)*(battle.run.squad.batchMul||1);
    }
    return battle;
  }
  function migrateLegacyBattle(battle,version){
    if(version==='v11.9.36')return battle;
    if(version==='v11.9.35'||version==='v11.9.34'||version==='v11.9.33'||version==='v11.9.32'||version==='v11.9.31')return battle;   // 刷怪与结构升级不重做已完成的首领/队列迁移。
    if(version!==RUN_VERSION){
      if(version!=="v11.9.30"&&battle.run?.rushMode){
        const r=battle.run,b=battle.enemies.find(e=>e.rushBoss&&!e.splitChild&&!e.isClone);
        if(b){
          const hp=RG.rushBossHp(r.rushLv,r.rushDifficulty||1),ratio=hp/b.maxhp;
          // 旧连战按血量比例缩放，盾与分身也保持比例；不回滚玩家进度。
          for(const e of battle.enemies)if(e===b||e.splitChild){e.hp*=ratio;e.maxhp*=ratio;if(e.shieldHp)e.shieldHp*=ratio;}
          b.attackMul=RG.rushDifficulty(r.rushDifficulty||1).attack;
          for(const e of battle.enemies)if(e.splitChild)e.attackMul=b.attackMul;
          if(b.frost)for(const key of ['field','breath','slow','wall'])b.frost[key+'T']=Math.min(b.frost[key+'T'],RG.FROST_BOSS[key].cd*(b.attackMul||1));
        }
        const p=battle.P,id=battle.lastWeapon;
        if(id&&p.weapons[id]){
          p.weapons[id]=Math.max(p.weapons[id],RG.rushDifficulty(r.rushDifficulty||1).weaponLv);
          for(let i=0;i<battle.offers.length;i++){const o=battle.offers[i];if(o.kind==='weapon'&&o.id===id&&o.lv<=p.weapons[id]){
            if(p.weapons[id]<RG.WEAPONS[id].maxLv)o.lv=p.weapons[id]+1;
            else battle.offers[i]={kind:'heal',heal:70,rarity:3};
          }}
        }
      }else if(version!=="v11.9.30"){
        for(const e of battle.enemies)if(e.bossKind==='gluttony'&&!e.splitChild&&!e.isClone&&!e.realmBoss&&!e.final){const ratio=(e.maxhp+300)/e.maxhp;e.hp*=ratio;e.maxhp+=300;}
      }
      // 第五首领旧镜像现场就地转为寒冰首领，生命与玩家构筑保留。
      for(const e of battle.enemies||[])if(e.bossKind==='mirror'&&!e.isClone&&!e.frost)RG.initFrostBoss(e);
      battle.enemies=(battle.enemies||[]).filter(e=>!e.isMirror);
      for(const e of battle.enemies||[])if(e.frost){
        e.escortKeys=['brute','flamer'];e.frost.wallQueue??=[];
        for(const c of e.frost.corpses){c.frozen=1;c.animClock??=0;c.faceDir??=0;}
        // 已发出的旧高伤害技能也降为当前数值，避免恢复瞬间继续吃旧伤害。
        for(const h of battle.hbeams||[])if(h.frostOwner===e&&h.frostField){h.dmg=e.dmg*RG.FROST_BOSS.field.damage;h.w=RG.FROST_BOSS.field.width*(e.frost.phase===2?RG.FROST_BOSS.field.grow:1);h.len=RG.FROST_BOSS.field.length*(e.frost.phase===2?RG.FROST_BOSS.field.grow:1);}
        for(const b of battle.ebullets||[])if(b.frostOwner===e)b.dmg=e.dmg*RG.FROST_BOSS.breath.damage;
      }
      if(battle.run?.rushMode&&(battle.enemies||[]).some(e=>e.frost&&!e.dead))for(const e of battle.enemies)if(e.rushEscort&&e.type==='howler'){
        // 旧连战现场中的哀嚎随从换为喷火兽，保留已有生命比例与击杀数量。
        const from=RG.ETYPES.howler,to=RG.ETYPES.flamer,ratio=e.hp/e.maxhp;
        e.type='flamer';e.maxhp*=to.hp/from.hp;e.hp=e.maxhp*ratio;e.dmg*=to.dmg/from.dmg;e.xp*=to.xp/from.xp;e.r=to.r;e.speed*=to.speed/from.speed;
      }
    }
    if(version!==RUN_VERSION&&battle.run?.rushMode&&battle.run.rushDifficulty===1){
      // 旧简单现场解除低血量强化，已发出的二阶段招式清理，不改玩家生命与奖励。
      for(const e of battle.enemies)if(e.rushBoss||e.splitChild){
        if(e.enraged&&!e.frost)e.speed/=1.25;
        e.enraged=false;e.mechanicPhase=1;e.cycle=1;e.spdMul=1;
        e.s1=e.s2=e.s3=false;e.stoneT=0;
        if(e.frost){e.frost.phase=1;e.frost.walls=[];e.frost.wallQueue=[];e.frost.breath=null;
          for(const key of ['hbeams','ebullets','domains'])battle[key]=battle[key].filter(v=>v.frostOwner!==e);
        }
      }
      battle.wormholes=[];
    }
    if(version===RUN_VERSION||version==='v11.9.30'||version==='v11.9.29'||version==='v11.9.28'||version==='v11.9.27'||version==='v11.9.26')return battle;
    const p=battle.P;if(!p||!p.weapons||!p.passives)throw Error('旧现场缺少玩家数据');
    p.hammerQueue=p.hammerAfter&&p.weapons.hammer?[p.hammerAfter]:[];
    p.novaQueue=[];
    if(p.weapons.nova&&p.novaLeft>0){
      const st={...RG.weaponStat('nova',p.weapons.nova,p.evolved?.nova)},range=1+RG.passiveValue(p,'melee_range');
      st.dmg*=1+RG.passiveValue(p,'melee_power');st.radius*=range;
      for(let i=0;i<Math.min(3,p.novaLeft);i++)p.novaQueue.push({t:Math.max(0,p.novaNext||0)+i*.16,st:{...st}});
    }
    delete p.hammerAfter;delete p.novaLeft;delete p.novaNext;delete p.kiBalls;
    p.boltBurstQueue=p.boltBurstQueue||[];p.seekerBurstQueue=p.seekerBurstQueue||[];
    for(const event of p.seekerBurstQueue){event.st.life=event.st.range/(p.visionMul||1);delete event.st.range;event.st.targetRange=620*(p.visionMul||1);}
    p.reactionMul=(1+.1*(p.passives.reaction||0))*(p.sinId==='sin_pride'?1.5:1);
    let level=0;
    for(const h of p.passiveHistory||[])if(h.id==='reaction'){
      level++;delete h.add.reactionMul;h.mul.reactionMul=(1+.1*level)/(1+.1*(level-1));
    }
    if(!p.weapons.kiwave)battle.qiOrbs=[];
    for(const al of battle.allies||[])al.source=al.puppet?'lust':al.converted?'holylight':'loyal';
    for(const e of battle.enemies||[])for(const type of RG.ELEMENT_ORDER)if(!(e.el?.[type]>0)){
      if(e.el)e.el[type]=0;if(e.elDmg)e.elDmg[type]=0;if(type==='fire'){e.burnDps=0;e.burnTick=0;}
    }
    for(const b of battle.bullets||[])if(b.weapon==='seeker')b.targetRange=620*(p.visionMul||1);
    return battle;
  }
  function readCheckpoint() {
    let incompatible=false;
    try {
      if (typeof localStorage === "undefined" || RG.mixedVer || RG.VERSION !== RUN_VERSION) return null;
      const generation = localStorage.getItem(RUN_SLOT);
      if (!generation || generation === "cleared") return null;
      for (const key of [RUN_KEY, RUN_KEY + "_backup"]) {
        const raw = localStorage.getItem(key);
        if (!raw || raw.length > MAX_BYTES) continue;
        const data = decode(raw);
        if(data&&!RUN_COMPATIBLE.includes(data.version)){incompatible=true;continue;}
        if (!data || data.checkpointSchema !== RUN_SCHEMA || !RUN_COMPATIBLE.includes(data.version) || data.generation !== generation || !RESUME_STATES.includes(data.resumeState)) continue;
        if(data.metaStamp!==progressStamp(RG.meta,RG.best)&&(data.version===RUN_VERSION||data.metaStamp!==progressStamp(RG.meta,RG.best,true))&&!(data.version!==RUN_VERSION&&RG.economyPreviousMeta&&[progressStamp(RG.economyPreviousMeta,RG.best),progressStamp(RG.economyPreviousMeta,RG.best,true)].includes(data.metaStamp)))continue;
        try {
          const battle = migrateBattle(graphDecode(data.graph),data.version);
          if (validBattle(battle) && validResume(data.resumeState,battle)) return { data:{...data,version:RUN_VERSION,metaStamp:progressStamp(RG.meta,RG.best),graph:graphEncode(battle)}, battle };
          incompatible=true;
        } catch (err) {}
      }
    } catch (err) {}
    if(incompatible&&!RG.checkpointIncompatibleNoticed){RG.checkpointIncompatibleNoticed=true;if(RG.showNotice)RG.showNotice("上局现场不兼容，请重新开局",true);}
    return null;
  }
  RG.hasRunCheckpoint = function () {
    if (checkpointCache === undefined) checkpointCache = readCheckpoint();
    // 菜单每帧只核对小型进度指纹；购买或领奖后立即隐藏旧续局入口，不再读取战场图。
    if (checkpointCache && (RG.mixedVer || RG.VERSION !== RUN_VERSION || checkpointCache.data.metaStamp !== progressStamp(RG.meta, RG.best))) checkpointCache = null;
    return !!checkpointCache;
  };
  RG.clearRunCheckpoint = function () {
    checkpointCache = null;
    try { if (typeof localStorage === "undefined") return false; } catch (err) { return false; }
    let invalidated = false, removed = 0;
    try { localStorage.setItem(RUN_SLOT, "cleared"); invalidated = true; } catch (err) {}
    for (const key of [RUN_KEY, RUN_KEY + "_backup"]) try { localStorage.removeItem(key); removed++; } catch (err) {}
    return invalidated || removed === 2;
  };
  RG.saveRunCheckpoint = function () {
    try {
      const paused = RG.state === "pause" || RG.state === "settings" && RG.returnState === "pause";
      if (typeof localStorage === "undefined" || RG.mixedVer || RG.VERSION !== RUN_VERSION || !paused && !["play", "levelup", "runshop", "countdown"].includes(RG.state)) return false;
      const battle = {};
      for (const key of RUN_FIELDS) battle[key] = RG[key];
      if (!validBattle(battle)) { RG.clearRunCheckpoint(); return false; }
      const resumeState = RG.state==='runshop'||RG.state==='countdown'&&RG.runCountdown?.resumeState==='runshop'||paused&&RG.checkpointResumeState==='runshop'&&RG.run.shopOpen?'runshop':RG.state === "levelup" || RG.state==="countdown"&&RG.runCountdown?.resumeState==="levelup" || paused && RG.checkpointResumeState === "levelup" ? "levelup" : "play";
      if (!validResume(resumeState,battle)) return false;
      // 先落盘已得到的局外奖励，检查点不回滚金币、成就、解锁和纪录。
      if (RG.saveMeta && RG.saveMeta() === false) return false;
      const storedMeta = decode(localStorage.getItem("rogue_meta"));
      if (!storedMeta || progressStamp(storedMeta, RG.best) !== progressStamp(RG.meta, RG.best)) return false;
      const data = { checkpointSchema: RUN_SCHEMA, version: RUN_VERSION, generation: Date.now().toString(36) + "-" + (++checkpointSequence), metaStamp: progressStamp(RG.meta, RG.best), resumeState, graph: graphEncode(battle) };
      const body = JSON.stringify(data), raw = JSON.stringify({ schema: SCHEMA, data, check: checksum(body) });
      if (raw.length > MAX_BYTES) return false;
      // 两份均属于同一代；最后提交有效代号，任何中途失败都不会复活上一局备份。
      localStorage.setItem(RUN_KEY + "_backup", raw);
      localStorage.setItem(RUN_KEY, raw);
      localStorage.setItem(RUN_SLOT, data.generation);
      checkpointCache = { data };
      return RG.recordStorageResult(RUN_KEY, true);
    } catch (err) { return RG.recordStorageResult(RUN_KEY, false); }
  };
  RG.restoreRunCheckpoint = function () {
    const saved = readCheckpoint();
    if (!saved) { checkpointCache = null; return false; }
    // 消费成功才能应用：第二次调用与旧备份都不能再次恢复并重复领奖。
    if (!RG.clearRunCheckpoint()) return false;
    for (const key of RUN_FIELDS) RG[key] = saved.battle[key];
    if(!RG.run.id)RG.run.id="legacy-"+saved.data.generation;
    if(!RG.run.rushMode)RG.selectedMap=RG.run.mapId||'legacy';
    RG.selectedExperiment=RG.run.experiment||null;
    RG.checkpointResumeState = saved.data.resumeState;
    RG.state = "pause"; RG.checkpointPending = false;
    RG.refreshResonance(RG.P);
    RG.clearBattleFeedback();
    RG.cam.shake = 0; RG.fatalErr = null;
    if (RG.releaseRunInput) RG.releaseRunInput();
    else { if (RG.joy) Object.assign(RG.joy, { active: false, id: null, vx: 0, vy: 0 }); RG.volDrag = null; RG.pageDrag = null; }
    if (RG.stopSfx) RG.stopSfx();
    if (RG.setMusicScene) RG.setMusicScene("silent");
    if (RG.rebuildWallGrid) RG.rebuildWallGrid(RG.walls);
    if (RG.clearEnemyGrid) RG.clearEnemyGrid();
    RG._tempWalls = RG.walls.filter(w => w.temp);
    RG.beginRunCountdown();
    return true;
  };

  RG.beginRunCountdown=function(){
    RG.runCountdown={remaining:3,last:performance.now(),resumeState:RG.checkpointResumeState||"play"};
    RG.state="countdown";
  };
  RG.tickRunCountdown=function(){
    const countdown=RG.runCountdown;if(!countdown||RG.state!=="countdown")return;
    const now=performance.now(),elapsed=Math.max(0,(now-countdown.last)/1000);countdown.last=now;
    countdown.remaining=Math.max(0,countdown.remaining-elapsed);
    if(countdown.remaining===0){RG.state=countdown.resumeState;RG.checkpointResumeState=null;RG.runCountdown=null;RG.checkpointPending=true;if(RG.releaseRunInput)RG.releaseRunInput();}
  };
  const NAMED_INDEX="rogue_named_runs",NAMED_PREFIX="rogue_named_run_";
  function namedIndex(){
    const index=RG.loadSafe(NAMED_INDEX,[],value=>Array.isArray(value)&&value.every(o=>o&&typeof o.id==="string"&&/^[a-z0-9-]+$/.test(o.id)&&typeof o.name==="string"&&o.name.length<=32&&Number.isFinite(o.time)&&Number.isFinite(o.level))?value:null);
    return index;
  }
  RG.listNamedRuns=()=>namedIndex();
  RG.saveNamedRun=function(name,overwrite=false){
    name=String(name||"").trim();if(!name||name.length>32)return {ok:false,error:"请输入 1—32 字的存档名字"};
    if(!RG.P||!RG.run||!(RG.state==="pause"||RG.state==="settings"&&RG.returnState==="pause"||RG.state==="saves"&&RG.saveListReturn==="pause"))return {ok:false,error:"请在本局暂停后保存"};
    const index=namedIndex(),old=index.find(o=>o.name===name);if(old&&!overwrite)return {ok:false,exists:true};
    RG.run.named=true;
    const originalState=RG.state;RG.state="pause";
    const saved=RG.saveRunCheckpoint();RG.state=originalState;
    if(!saved)return {ok:false,error:"存档写入失败，请保留当前页面"};
    try{
      const raw=localStorage.getItem(RUN_KEY),data=decode(raw);if(!data)return {ok:false,error:"现场校验失败"};
      const id=Date.now().toString(36)+"-"+(++checkpointSequence),key=NAMED_PREFIX+id;
      localStorage.setItem(key,raw);
      const item={id,name,time:RG.run.t,level:RG.P.level,createdAt:Date.now(),version:RUN_VERSION};
      const next=[item,...index.filter(o=>o!==old)];
      if(!RG.saveSafe(NAMED_INDEX,next)){localStorage.removeItem(key);return {ok:false,error:"目录保存失败，旧存档已保留"};}
      if(old)try{localStorage.removeItem(NAMED_PREFIX+old.id);}catch(err){}
      RG.recordStorageResult(NAMED_INDEX,true);return {ok:true};
    }catch(err){RG.recordStorageResult(NAMED_INDEX,false);return {ok:false,error:"存档空间不足或不可写入"};}
  };
  RG.deleteNamedRun=function(id){
    const index=namedIndex();if(!index.some(o=>o.id===id))return false;
    if(!RG.saveSafe(NAMED_INDEX,index.filter(o=>o.id!==id)))return false;
    try{localStorage.removeItem(NAMED_PREFIX+id);}catch(err){}return true;
  };
  RG.restoreNamedRun=function(id){
    if(!namedIndex().some(o=>o.id===id))return false;
    try{
      const raw=localStorage.getItem(NAMED_PREFIX+id);if(!raw||raw.length>MAX_BYTES)return false;
      const data=decode(raw);if(!data||data.checkpointSchema!==RUN_SCHEMA||!RUN_COMPATIBLE.includes(data.version)||!RESUME_STATES.includes(data.resumeState)){if(RG.showNotice)RG.showNotice('存档现场不兼容，请重新开局',true);return false;}
      const battle=migrateBattle(graphDecode(data.graph),data.version);if(!validBattle(battle)||!validResume(data.resumeState,battle))return false;
      // 命名现场不回滚局外进度，也不因死亡、通关或读取而消耗。
      const migrated={...data,version:RUN_VERSION,graph:graphEncode(battle),metaStamp:progressStamp(RG.meta,RG.best)};
      const body=JSON.stringify(migrated),current=JSON.stringify({schema:SCHEMA,data:migrated,check:checksum(body)});
      localStorage.setItem(RUN_KEY+"_backup",current);localStorage.setItem(RUN_KEY,current);localStorage.setItem(RUN_SLOT,migrated.generation);
      checkpointCache=undefined;return RG.restoreRunCheckpoint();
    }catch(err){return false;}
  };
})(window.RG);
