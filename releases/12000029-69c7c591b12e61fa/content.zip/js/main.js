// ============ 主控:画布/输入/状态机/主循环 ============
(function (RG) {
  const { clamp, TAU } = RG;
  const cv = document.getElementById("cv");
  const COARSE = !!(window.matchMedia && window.matchMedia("(pointer:coarse)").matches);

  RG.VERSION = "v12.0.29";
  console.log("[RG] 罪恶之下 " + RG.VERSION);
  // !️ 改 data_passives.js 的 PASSIVES_VER 时,必须同步改这里的期望值(上次漏改导致全员开局被拦)
  if (RG.DATA_BALANCE_VER !== "v12029" || RG.DATA_ACTIVES_VER !== "v12027" || RG.WALLS_VER !== "v12029" || RG.UTIL_VER !== "v12027" || RG.PERSISTENCE_VER !== "v12029" || RG.DATA_WEAPONS_VER !== "v12029" || RG.DATA_ENEMIES_VER !== "v12029" || RG.PASSIVES_VER !== "v12029" || RG.SYSTEM_RUN_VER !== "v12029" || RG.SYSTEM_GROWTH_VER !== "v12029" || RG.SYSTEM_SPAWNING_VER !== "v12029" || RG.SYSTEM_BOSSES_VER !== "v12029" || RG.SYSTEM_ENTITIES_VER !== "v12029" || RG.DRAW_WORLD_VER !== "v12029" || RG.DRAW_MENUS_VER !== "v12029" || RG.AUDIO_VER !== "v12029") {
    RG.mixedVer = true;
    console.error("[RG] 资源版本不一致,请按 Ctrl+F5 强制刷新!",{balance:RG.DATA_BALANCE_VER,actives:RG.DATA_ACTIVES_VER,walls:RG.WALLS_VER,util:RG.UTIL_VER,persistence:RG.PERSISTENCE_VER,weapons:RG.DATA_WEAPONS_VER,enemies:RG.DATA_ENEMIES_VER,passives:RG.PASSIVES_VER,run:RG.SYSTEM_RUN_VER,growth:RG.SYSTEM_GROWTH_VER,spawning:RG.SYSTEM_SPAWNING_VER,bosses:RG.SYSTEM_BOSSES_VER,entities:RG.SYSTEM_ENTITIES_VER,world:RG.DRAW_WORLD_VER,menus:RG.DRAW_MENUS_VER,audio:RG.AUDIO_VER});
    const notice=document.getElementById("system-notice");
    if(notice){notice.textContent="资源版本不一致，请刷新页面（电脑按 Ctrl+F5）";notice.hidden=false;notice.classList.add("error");}
    return;
  }
  let noticeTimer, backupRaw = null;
  RG.showNotice = function (message, error = false) {
    const element = document.getElementById("system-notice");
    if (!element || !element.classList) return;
    element.textContent = message; element.classList.toggle("error", error); element.hidden = false;
    clearTimeout(noticeTimer); noticeTimer = setTimeout(() => { element.hidden = true; }, error ? 9000 : 4500);
  };
  // Android内容更新：原生层负责网络/签名/快照，页面只展示状态及用户动作。
  RG.androidUpdateSupported=!!(window.AndroidUpdate&&typeof window.AndroidUpdate.status==='function');
  RG.androidUpdateActivating=false;
  const updateStates=new Set(['idle','unconfigured','unavailable','checking','available','downloading','ready','applying','current','error','shellRequired']);
  RG.onAndroidUpdateStatus=function(raw){
    try{
      const data=typeof raw==='string'?JSON.parse(raw):raw;
      if(!data||!updateStates.has(data.state))throw Error('状态无效');
      if(['error','shellRequired','unavailable'].includes(data.state))RG.androidUpdateActivating=false;
      const number=v=>Number.isFinite(v)&&v>=0?Math.min(v,128*1024*1024):0;
      RG.androidUpdateInfo={state:data.state,message:String(data.message||'').slice(0,240),version:String(data.version||RG.VERSION).slice(0,30),availableVersion:String(data.availableVersion||'').slice(0,30),notes:String(data.notes||'').slice(0,1200),bytes:number(data.bytes),total:number(data.total),configured:data.configured===true};
    }catch(error){RG.androidUpdateActivating=false;RG.androidUpdateInfo={state:'error',message:'更新状态暂不可用，当前游戏可继续运行',version:RG.VERSION,bytes:0,total:0};}
  };
  RG.canApplyAndroidUpdate=()=>!RG.mixedVer&&!RG.fatalErr&&(RG.state==='menu'||RG.state==='settings'&&RG.returnState==='menu');
  RG.requestAndroidUpdate=function(action){
    if(!RG.androidUpdateSupported||RG.androidUpdateActivating||!['check','download','apply','configure'].includes(action))return false;
    if(!RG.canApplyAndroidUpdate()){RG.showNotice('请先回到主菜单，再进行更新');return false;}
    const state=RG.androidUpdateInfo?.state;
    if(['checking','downloading','applying'].includes(state)||action==='apply'&&state!=='ready'||action==='download'&&state!=='available')return false;
    try{if(action==='apply'){RG.androidUpdateActivating=true;RG.androidUpdateInfo={...RG.androidUpdateInfo,state:'applying',message:'正在重启游戏并验证新版本'};}window.AndroidUpdate[action]();return true;}catch(error){RG.onAndroidUpdateStatus({state:'error',message:'更新器暂不可用，当前游戏可继续运行'});return false;}
  };
  let androidReadySent=false;
  RG.androidContentReady=function(){
    if(!RG.androidUpdateSupported||androidReadySent||RG.mixedVer||RG.fatalErr)return;
    try{window.AndroidUpdate.contentReady(RG.VERSION);androidReadySent=true;}catch(error){RG.onAndroidUpdateStatus({state:'error',message:'更新器暂不可用，当前游戏可继续运行'});}
  };
  if(RG.androidUpdateSupported)try{RG.onAndroidUpdateStatus(window.AndroidUpdate.status());}catch(error){RG.onAndroidUpdateStatus(null);}
  // Android内容更新结束。
  const runDialog=document.getElementById("run-save-dialog"),runName=document.getElementById("run-save-name"),runTitle=document.getElementById("run-save-title"),runError=document.getElementById("run-save-error"),runConfirm=document.getElementById("run-save-confirm");
  let runDialogMode="save",runDeleteId=null;
  RG.closeRunSaveDialog=function(){if(runDialog)runDialog.hidden=true;runDialogMode="save";};
  RG.openRunSaveDialog=function(mode="save",id=null){
    if(!runDialog)return;
    runDialogMode=mode;runDeleteId=id;runDialog.hidden=false;runError.textContent="";
    runName.hidden=mode==="delete";runName.disabled=mode==="delete";runConfirm.textContent=mode==="delete"?"确认删除":"保存";
    runTitle.textContent=mode==="delete"?"删除此存档？此操作无法恢复。":"保存本局 · 输入名字";
    if(mode!=="delete"){runName.value="";runName.focus();}else runConfirm.focus();
  };
  const runForm=document.getElementById("run-save-form"),runCancel=document.getElementById("run-save-cancel");
  runForm?.addEventListener("submit",e=>{
    e.preventDefault();
    if(runDialogMode==="delete"){if(RG.deleteNamedRun(runDeleteId)){RG.closeRunSaveDialog();RG.showNotice("存档已删除");}else runError.textContent="删除失败，原存档已保留";return;}
    const result=RG.saveNamedRun(runName.value,runDialogMode==="overwrite");
    if(result.exists){runDialogMode="overwrite";runName.disabled=true;runTitle.textContent="同名存档已存在，是否覆盖？";runConfirm.textContent="确认覆盖";runConfirm.focus();}
    else if(result.ok){runName.disabled=false;RG.closeRunSaveDialog();RG.showNotice("本局存档已保存");}
    else runError.textContent=result.error;
  });
  runCancel?.addEventListener("click",()=>{
    if(runDialogMode==="overwrite"){runDialogMode="save";runName.disabled=false;runTitle.textContent="请重新输入存档名字";runConfirm.textContent="保存";runName.focus();runName.select();}
    else RG.closeRunSaveDialog();
  });
  RG.prepareBackupImport = function (raw) {
    if (RG.state !== "settings" || RG.returnState !== "menu") { RG.showNotice("先结算本局，再导入备份", true); return false; }
    const data = RG.readSaveBackup(raw);
    if (!data) { RG.showNotice("备份格式或校验不正确，当前进度未改动", true); return false; }
    backupRaw = raw; RG.backupPreview = { coins: data.meta.coins, runs: data.meta.runs, won: data.meta.won };
    return true;
  };
  RG.cancelBackupImport = function () { backupRaw = null; RG.backupPreview = null; };
  RG.confirmBackupImport = function () {
    if (!backupRaw || !RG.importSaveBackup(backupRaw)) return false;
    RG.cancelBackupImport(); RG.showNotice("备份已导入，局外进度和设置已恢复"); return true;
  };
  RG.downloadSaveBackup = function () {
    const raw = RG.exportSaveBackup();
    if (!raw) { RG.showNotice("备份生成失败，请保留当前页面", true); return false; }
    const filename = "罪恶之下-存档-" + new Date().toISOString().slice(0, 10) + ".json";
    if (window.AndroidStore && window.AndroidStore.exportBackup) { window.AndroidStore.exportBackup(raw, filename); return true; }
    const url = URL.createObjectURL(new Blob([raw], { type: "application/json" })), link = document.createElement("a");
    link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000); RG.showNotice("备份已生成，请保留下载的JSON文件"); return true;
  };
  const backupFile = document.getElementById("backup-file");
  if (backupFile) backupFile.addEventListener("change", async () => {
    const file = backupFile.files && backupFile.files[0]; backupFile.value = "";
    if (!file) return;
    if (file.size > 300000) { RG.showNotice("备份文件过大，当前进度未改动", true); return; }
    try { RG.prepareBackupImport(await file.text()); } catch (err) { RG.showNotice("无法读取备份文件，当前进度未改动", true); }
  });
  RG.offlineStatus = { text: location.protocol === "file:" ? "本地资源已内置" : "离线资源尚未就绪", state: "pending" };
  const offlineRegistrations = new WeakSet();
  RG.connectOfflineWorker = function (registration) {
    const ask = () => [...new Set([registration.installing, registration.waiting, registration.active, navigator.serviceWorker.controller])].filter(Boolean).forEach(worker => worker.postMessage({ type: "RG_OFFLINE_STATUS" }));
    ask(); if (offlineRegistrations.has(registration)) return;
    offlineRegistrations.add(registration);
    if (registration.installing) registration.installing.addEventListener("statechange", ask);
    registration.addEventListener("updatefound", () => { ask(); if (registration.installing) registration.installing.addEventListener("statechange", ask); });
  };
  if (navigator.serviceWorker) {
    window.addEventListener("online", () => {
      if (RG.offlineStatus.state !== "failed") return;
      navigator.serviceWorker.controller?.postMessage({ type: "RG_OFFLINE_RETRY" });
      // 旧版worker可能不认识修复消息；重新注册也恢复首次安装失败的情况。
      navigator.serviceWorker.register("sw.js", { updateViaCache: "none" }).then(registration => { RG.connectOfflineWorker(registration); return registration.update(); }).catch(() => {});
    });
    navigator.serviceWorker.addEventListener("message", event => {
      const data = event.data;
      if (!data || data.type !== "RG_OFFLINE_STATUS" || data.version !== RG.VERSION) return;
      const previous = RG.offlineStatus.state;
      const text = data.state === "ready" ? "离线资源已就绪" : data.state === "failed" ? "离线下载失败，联网后重试" : "离线资源下载 " + Math.round(100 * (data.completed || 0) / Math.max(1, data.total)) + "%";
      RG.offlineStatus = { ...data, text };
      if (data.state === "ready" && previous !== "ready") RG.showNotice(text);
      if (data.state === "failed" && previous !== "failed") RG.showNotice(text, true);
    });
    navigator.serviceWorker.addEventListener("controllerchange", () => navigator.serviceWorker.controller?.postMessage({ type: "RG_OFFLINE_STATUS" }));
  }
  // 局外成长存档:金币 / 已解锁武器 / 永久强化；旧难度字段仅为存档兼容保留
  const META_DEFAULT = { coins: 0, wUnlocked: [], perks: [], oaths: [], diff: 1, rushDifficulty:1, won: 0, runs: 0, tutorialSeen: false, ...RG.SETTINGS_DEFAULTS.display, bossRush: { unlocked: 1, cleared: [], best: {},bestByDifficulty:{} }, achievements: {}, seenMobs: [], runLog: [], daily: null };
  const BEST_DEFAULT = { time: 0, kills: 0, level: 1 };
  const finite = (v, fallback, lo, hi) => Number.isFinite(+v) ? clamp(+v, lo, hi) : fallback;
  const stringList = (v, allowed) => Array.isArray(v) ? [...new Set(v.filter(x => typeof x === "string" && (!allowed || allowed[x])))] : [];
  function normalizeMeta(raw) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    const br = raw.bossRush && typeof raw.bossRush === "object" ? raw.bossRush : {};
    const best = {};
    if (br.best && typeof br.best === "object") for (const key of Object.keys(br.best)) {
      const lv = +key, t = +br.best[key]; if (lv >= 1 && lv <= 8 && Number.isFinite(t) && t >= 0) best[lv] = Math.min(t, 86400);
    }
    const bestByDifficulty={};
    for(const diff of [1,2,3]){const source=br.bestByDifficulty?.[diff],table={};if(source&&typeof source==="object")for(const lv of [1,2,3,4,5,6,7,8]){const t=source[lv];if(Number.isFinite(t)&&t>=0)table[lv]=Math.min(t,86400);}if(Object.keys(table).length)bestByDifficulty[diff]=table;}
    const namedReceipts={};
    for(const [id,receipt]of Object.entries(raw.namedReceipts||{}))if(/^[a-z0-9-]{1,96}$/.test(id)&&receipt&&Number.isFinite(receipt.coins))namedReceipts[id]={coins:finite(receipt.coins,0,0,1e12),counted:!!receipt.counted,mapCounted:!!receipt.mapCounted,mapWonCounted:!!receipt.mapWonCounted,recordPaid:!!receipt.recordPaid};
    const maps={};
    for(const id of ['valley','workshop']){const m=raw.maps?.[id]||{};maps[id]={unlocked:id==='valley'||m.unlocked===true,runs:Math.round(finite(m.runs,0,0,1e7)),wins:Math.round(finite(m.wins,0,0,1e7)),firstClearPaid:m.firstClearPaid===true||m.wins>0,bestTime:finite(m.bestTime,0,0,86400),bestKills:Math.round(finite(m.bestKills,0,0,1e9)),bestLevel:Math.round(finite(m.bestLevel,1,1,9999))};}
    return {
      namedReceipts,maps,
      coins: finite(raw.coins, 0, 0, 1e9), wUnlocked: stringList(raw.wUnlocked, RG.WEAPONS), perks: stringList(raw.perks),
      oaths: stringList(raw.oaths).filter(id => id !== "swift"), diff: Math.round(finite(raw.diff, 1, 1, 3)),
      rushDifficulty:Math.round(finite(raw.rushDifficulty,1,1,3)),
      won: Math.round(finite(raw.won, 0, 0, 9999)), runs: Math.round(finite(raw.runs, 0, 0, 1e7)),
      tutorialSeen: !!raw.tutorialSeen, ...RG.normalizeDisplaySettings(raw),
      bossRush: { unlocked: Math.round(finite(br.unlocked, 1, 1, 8)), cleared: [...new Set((Array.isArray(br.cleared) ? br.cleared : []).map(Number).filter(n => n >= 1 && n <= 8))], best,bestByDifficulty },
      achievements: raw.achievements && typeof raw.achievements === "object" && !Array.isArray(raw.achievements) ? { ...raw.achievements } : {},
      seenMobs: stringList(raw.seenMobs),
      runLog: Array.isArray(raw.runLog) ? raw.runLog.slice(0, 8).filter(r => r && typeof r === "object").map(r => ({
        ...(['valley','workshop','legacy','rush'].includes(r.mapId)?{mapId:r.mapId}:{}),t: finite(r.t, 0, 0, 86400), kills: Math.round(finite(r.kills, 0, 0, 1e9)), lv: Math.round(finite(r.lv, 1, 1, 9999)),
        tags: Array.isArray(r.tags) ? r.tags.slice(0, 5).map(String) : [], weapon: typeof r.weapon === "string" ? r.weapon : "", win: !!r.win, ts: finite(r.ts, 0, 0, 1e15),
      })) : [],
      daily: raw.daily && typeof raw.daily === "object" ? {
        key: String(raw.daily.key || ""), done: !!raw.daily.done, best: finite(raw.daily.best, 0, 0, 86400),
        rewardPaid: finite(raw.daily.rewardPaid, 0, 0, 1e9), rewardWon: raw.daily.rewardWon === undefined ? !!raw.daily.done : !!raw.daily.rewardWon,
        contracts: stringList(raw.daily.contracts), weapon: typeof raw.daily.weapon === "string" ? raw.daily.weapon : "bolt",
      } : null,
    };
  }
  function normalizeBest(raw) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    return { time: finite(raw.time, 0, 0, 86400), kills: Math.round(finite(raw.kills, 0, 0, 1e9)), level: Math.round(finite(raw.level, 1, 1, 9999)) };
  }
  RG.normalizeMeta = normalizeMeta; RG.normalizeBest = normalizeBest;
  RG.meta = RG.loadSafe("rogue_meta", normalizeMeta(META_DEFAULT), normalizeMeta);
  const economyBefore=JSON.parse(JSON.stringify(RG.meta));
  if(RG.migrateEconomyMeta(RG.meta)){RG.economyPreviousMeta=economyBefore;RG.saveSafe('rogue_meta',RG.meta,normalizeMeta);}
  RG.selectedMap='valley';
  RG.namedRunReceipt=function(){
    if(!RG.run?.named||!RG.run.id)return null;
    const receipts=RG.meta.namedReceipts||(RG.meta.namedReceipts={});
    return receipts[RG.run.id]||(receipts[RG.run.id]={coins:RG.run.earnedCoins||0,counted:!!RG.run.counted});
  };
  // 已通关的旧存档补发武器，既有购买记录保留。
  let rewardMigration=false;
  for(const lv of RG.meta.bossRush.cleared)if(RG.unlockBossWeapons(lv).length)rewardMigration=true;
  if(RG.meta.daily&&!RG.weaponUnlocked(RG.meta.daily.weapon)){RG.meta.daily.weapon='bolt';rewardMigration=true;}
  RG.saveMeta = function () { return RG.saveSafe("rogue_meta", RG.meta, normalizeMeta); };
  if(rewardMigration)RG.saveMeta();

  RG.TEST_MOB = location.search.includes("testmobs");
  RG.state = "menu";
  RG.lastWeapon = "bolt";
  RG.resetBattleState();
  RG.best = RG.loadSafe("rogue_best", BEST_DEFAULT, normalizeBest);
  RG.saveBest = function () { return RG.saveSafe("rogue_best", RG.best, normalizeBest); };
  if (RG.saveRecovered) RG.menuNotice = { text: RG.saveRecoveryMode === "backup" ? "检测到存档异常，已从备份恢复" : "检测到存档损坏，已安全重建", until: Date.now() + 9000 };

  // ---------- 自适应画布 ----------
  function resize() {
    RG.W = window.innerWidth; RG.H = window.innerHeight;
    const css = getComputedStyle(document.documentElement), readSafe = name => Math.max(0, parseFloat(css.getPropertyValue(name)) || 0);
    RG.safe = { top: readSafe("--safe-top"), right: readSafe("--safe-right"), bottom: readSafe("--safe-bottom"), left: readSafe("--safe-left") };
    // debug safe=t,r,b,l 可在桌面复现刘海/圆角屏，不影响正式地址。
    const debugSafe = new URLSearchParams(location.search).get("safe");
    if (debugSafe) { const p = debugSafe.split(",").map(Number); if (p.length === 4 && p.every(Number.isFinite)) RG.safe = { top: p[0], right: p[1], bottom: p[2], left: p[3] }; }
    RG.safe.top = Math.min(RG.safe.top, RG.H * .22); RG.safe.bottom = Math.min(RG.safe.bottom, RG.H * .22);
    RG.safe.left = Math.min(RG.safe.left, RG.W * .22); RG.safe.right = Math.min(RG.safe.right, RG.W * .22);
    RG.UIS = clamp(Math.min(RG.W / 960, RG.H / 600), 0.78, 1.5);
    const DPR = RG.canvasPixelRatio(window.devicePixelRatio, COARSE, RG.renderQuality); RG.renderDpr = DPR;
    cv.width = Math.round(RG.W * DPR); cv.height = Math.round(RG.H * DPR);
    cv.style.width = RG.W + "px"; cv.style.height = RG.H + "px";
    RG.ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    RG.ctx.imageSmoothingEnabled = false;   // 像素素材始终硬边缩放，避免移动端发糊
  }
  window.addEventListener("resize", resize);
  if (window.visualViewport) window.visualViewport.addEventListener("resize", resize);
  RG.resizeCanvas = resize;
  RG.applyDisplaySettings = function () {
    Object.assign(RG, RG.normalizeDisplaySettings(RG.meta)); RG.resetFramePacing(); RG.resetFxMonitor(); resize();
  };
  RG.applyDisplaySettings();

  // ---------- 输入 ----------
  const keys = {};
  RG.touchMode = COARSE || (navigator.maxTouchPoints || 0) > 0;
  RG.fxScale = function () {
    const base = { low: .38, medium: .68, high: 1 }[RG.fxQuality] || .68;
    return base * (RG.fxAutoReduced ? .58 : 1);
  };
  RG.setFxQuality = function (quality) {
    if (!["low", "medium", "high"].includes(quality)) return;
    RG.fxQuality = RG.meta.fxQuality = quality; RG.resetFxMonitor(); RG.saveMeta();
  };
  RG.toggleFxAuto = function () { RG.fxAuto = RG.meta.fxAuto = !RG.fxAuto; RG.resetFxMonitor(); RG.saveMeta(); };
  RG.setFrameRate = function (rate) {
    if (!["30", "60", "120", "auto"].includes(rate)) return;
    RG.frameRate = RG.meta.frameRate = rate; RG.resetFramePacing(); RG.resetFxMonitor(); RG.saveMeta();
  };
  RG.setRenderQuality = function (quality) {
    if (!["low", "medium", "high"].includes(quality)) return;
    RG.renderQuality = RG.meta.renderQuality = quality; resize(); RG.saveMeta();
  };
  RG.controls=RG.loadSafe('rg_controls',RG.normalizeControls(),RG.normalizeControls);
  RG.saveControls=()=>RG.saveSafe('rg_controls',RG.controls,RG.normalizeControls);
  RG.resetControls=function(){RG.controls=RG.normalizeControls();RG.bindingPending=null;RG.saveControls();};
  // 各输入只负责命中/按键判断，对局动作统一在这里执行。
  RG.performRunAction=function(action,id){
    if(action==='start')RG.startRun(id);
    else if(action==='retry')RG.retryRun();
    else if(action==='pause')RG.pauseAndCheckpoint();
    else if(action==='resume')RG.resumeRun();
    else if(action==='abandon')RG.abandonRun();
    else if(action==='menu'){RG.resetBattleState();RG.state='menu';}
    else return false;
    return true;
  };
  window.addEventListener("keydown", e => {
    if(RG.androidUpdateActivating){e.preventDefault();return;}
    if(runDialog&&!runDialog.hidden){if(e.key==="Escape"){e.preventDefault();runCancel.click();}return;}
    if(RG.bindingPending){e.preventDefault();if(e.repeat)return;if(e.key==='Escape')RG.bindingPending=null;else if(!e.ctrlKey&&!e.altKey&&!e.metaKey&&RG.bindKey(RG.bindingPending,e.key))RG.bindingPending=null;return;}
    if(RG.controlEditing){if(e.key==='Escape'){controlEnd(true);RG.controlEditing=false;}return;}
    const key=e.key.toLowerCase(),b=RG.controls.bindings;
    keys[e.key.toLowerCase()] = true;
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
    if (e.repeat) return;   // 移动键保持按下，功能键每次按压只触发一次。
    if (key===b.mute) { RG.muted = !RG.muted; if (RG.muted && RG.stopBgm) RG.stopBgm(); else if (RG.startBgm && RG.state !== "menu") RG.startBgm(); }
    if (key===b.dash && RG.state === "play") RG.tryDash();
    if (key===b.active1 && RG.state === "play") RG.useActive(0);
    if (key===b.active2 && RG.state === "play") RG.useActive(1);
    if (key===b.interact && RG.state === "play" && RG.P && RG.P.statueNear) RG.statueSacrifice();
    if (key===b.pause && (RG.state === "play" || RG.state === "pause")) RG.performRunAction(RG.state==='play'?'pause':'resume');
    // 直接测试怪兽:T = 立刻在身边刷三只新怪(?testmobs=1 时开局自动刷)
    if (RG.TEST_MOB && e.key.toLowerCase() === "t" && RG.state === "play" && RG.spawnTestMobs) RG.spawnTestMobs();
    if (e.key === "Escape") RG.handleBack();
    if (key===b.reroll) {
      if (RG.state === "over") RG.performRunAction('retry');
      else if (RG.state === "levelup") RG.rerollOffers();
    }
    if (RG.state === "levelup" && ["1", "2", "3", "4", "5", "6", "7"].includes(e.key)) RG.selectOffer(+e.key - 1);
    if (RG.state === "levelup" && e.key === "Enter") RG.confirmOffer();
    if (RG.state === "loadout" && ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"].includes(e.key)) {
      const wi = e.key === "0" ? 9 : +e.key - 1, wid = RG.WEAPON_ORDER[wi];
      if (wid && (RG.weaponUnlocked(wid) || RG.DEBUG)) RG.performRunAction('start',wid);
    }
  });
  window.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);
  function releaseInput(save=true) {
    controlEnd(true);RG.bindingPending=null;
    for (const key in keys) delete keys[key];
    if (RG.joy) { RG.joy.active = false; RG.joy.id = null; RG.joy.vx = 0; RG.joy.vy = 0; }
    RG.volDrag = null; RG.pageDrag = null;RG.shopMouseDrag=null;RG.buildMouseDrag=null;
    if (save && (RG.state === "play" || RG.state==="countdown")) RG.state = "pause";
    if(save&&RG.saveRunCheckpoint&&(['pause','levelup','runshop'].includes(RG.state)||RG.state==='settings'&&RG.returnState==='pause'))RG.saveRunCheckpoint();
  }
  RG.releaseRunInput=()=>releaseInput(false);
  RG.pauseAndCheckpoint=()=>releaseInput();
  RG.resumeRun=function(){if(RG.runCountdown){RG.runCountdown.last=performance.now();RG.state="countdown";return;}RG.state=RG.checkpointResumeState==='runshop'&&RG.run.shopOpen?'runshop':RG.checkpointResumeState==='levelup'&&RG.offers.length?'levelup':'play';RG.checkpointResumeState=null;};
  // 键盘与Android系统返回共享层级，暂停设置退出后保留当前战场。
  RG.handleBack=function(){
    if(RG.androidUpdateActivating)return true;
    if(runDialog&&!runDialog.hidden){runCancel.click();return true;}
    if(RG.state==='saves'){RG.state='settings';return true;}
    if(RG.backupPreview){RG.cancelBackupImport();return true;}
    if(RG.bindingPending){RG.bindingPending=null;return true;}
    if(RG.controlEditing){controlEnd(true);RG.controlEditing=false;RG.saveControls();return true;}
    if(RG.state==='runshop'){RG.closeRunShop();return true;}
    if(RG.state==='achievements'&&RG.codexSelection){RG.codexSelection=null;return true;}
    if(RG.state==='levelup'){RG.cancelOfferSelection();return true;}
    if(['shop','oaths','settings','achievements'].includes(RG.state)){RG.state=RG.returnState||'menu';return true;}
    if(RG.state==='loadout'){RG.state='maps';return true;}
    if(['maps','growth','guide','rush'].includes(RG.state)){RG.state='menu';return true;}
    if(RG.state==='rushweapon'){RG.state='rush';return true;}
    if(RG.state==='play'||RG.state==='countdown')return RG.performRunAction('pause');
    if(RG.state==='pause')return RG.performRunAction('resume');
    if(['win','over'].includes(RG.state))return RG.performRunAction('menu');
    return false;
  };
  const chooseWithCheckpoint=RG.chooseOffer;
  RG.chooseOffer=function(i){const result=chooseWithCheckpoint(i);if(RG.P&&['play','levelup','runshop'].includes(RG.state))RG.checkpointPending=true;return result;};
  window.addEventListener("blur", ()=>releaseInput());
  window.addEventListener('pagehide',()=>releaseInput());
  // 切到后台清理输入并暂停，避免丢失松键事件后持续移动。
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) releaseInput();
  });

  // 虚拟摇杆(触屏)+ P2 死区/灵敏度(设置页可调,本地持久化)
  RG.joy = { active: false, id: null, sx: 0, sy: 0, vx: 0, vy: 0 };
  RG.joyDead = RG.SETTINGS_DEFAULTS.touch.dead; RG.joySens = RG.SETTINGS_DEFAULTS.touch.sens; RG.joyAnalog = RG.SETTINGS_DEFAULTS.touch.analog;
  try {
    const tc = JSON.parse(localStorage.getItem("rg_touch") || "null");
    if (tc) { RG.joyAnalog=tc.analog===true; if (typeof tc.dead === "number") RG.joyDead = tc.dead; if (typeof tc.sens === "number") RG.joySens = tc.sens; }
  } catch (err) {}
  RG.saveTouch = function () { try { localStorage.setItem("rg_touch", JSON.stringify({ dead: RG.joyDead, sens: RG.joySens, analog: RG.joyAnalog })); return RG.recordStorageResult("rg_touch", true); } catch (err) { return RG.recordStorageResult("rg_touch", false); } };
  function canvasPos(cx, cy) {
    const r = cv.getBoundingClientRect();
    return { x: (cx - r.left) / r.width * RG.W, y: (cy - r.top) / r.height * RG.H };
  }
  function pagePos(p) { return { x:p.x, y:p.y+RG.pageScrollOffset(RG.state) }; }
  // 默认轻推即全速；开启轻推轻跑后恢复模拟摇杆的渐进速度。
  RG.joystickVector=function(dx,dy){const d=Math.hypot(dx,dy),dead=RG.joyDead||RG.SETTINGS_DEFAULTS.touch.dead;if(d<=dead)return {x:0,y:0};const speed=RG.joyAnalog?Math.min(1,Math.pow(Math.min(1,(d-dead)/Math.max(20,56-dead)),.85)*(RG.joySens||1)):1;return {x:dx/d*speed,y:dy/d*speed};};
  function controlDown(p,id){if(!RG.controlEditing)return false;if(RG.controlDrag)return true;const r=(RG.controlRects||[]).find(r=>r.id&&p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h);if(r)RG.controlDrag={id,key:r.id,old:RG.controls.touch[r.id]&&{...RG.controls.touch[r.id]}};else handleClick(p.x,p.y);return true;}
  function controlMove(p){if(RG.controlDrag)RG.setControlPosition(RG.controlDrag.key,p.x,p.y);}
  function controlEnd(cancel){if(!RG.controlDrag)return;const d=RG.controlDrag;if(cancel){if(d.old)RG.controls.touch[d.key]=d.old;else delete RG.controls.touch[d.key];}else RG.saveControls();RG.controlDrag=null;}
  cv.addEventListener("mousemove", e => { const p = canvasPos(e.clientX, e.clientY); RG.mouse = p;if(RG.controlDrag?.id==='mouse')controlMove(p);if (RG.volDrag) setVolFromX(p.x);const build=RG.buildMouseDrag;if(build&&RG.state==='pause'){if(Math.hypot(p.x-build.startX,p.y-build.startY)>7)build.moved=true;if(build.moved)RG.scrollBuildBy(build.lastY-p.y,{x:build.startX,y:build.startY},build.lastX-p.x);build.lastX=p.x;build.lastY=p.y;}const d=RG.shopMouseDrag;if(d&&['shop','achievements'].includes(RG.state)){if(Math.abs(p.y-d.startY)>7)d.moved=true;if(d.moved)RG.scrollShopBy(d.lastY-p.y,{x:d.startX,y:d.startY});d.lastY=p.y;} });
  window.addEventListener("mouseup", e => { RG.volDrag = null;controlEnd(false);const build=RG.buildMouseDrag;RG.buildMouseDrag=null;if(build&&!build.moved&&RG.state==='pause'){const p=canvasPos(e.clientX,e.clientY);handleClick(p.x,p.y);}const d=RG.shopMouseDrag;RG.shopMouseDrag=null;if(d&&!d.moved&&['shop','achievements'].includes(RG.state)){const p=canvasPos(e.clientX,e.clientY);handleClick(p.x,p.y);} });
  cv.addEventListener("mousedown", e => { if (RG.unlockAudio) RG.unlockAudio(); const p = pagePos(canvasPos(e.clientX, e.clientY));if(controlDown(p,'mouse'))return; if (volPointerDown(p.x, p.y)) return;if(RG.buildScrollHit(p)){RG.buildMouseDrag={startX:p.x,startY:p.y,lastX:p.x,lastY:p.y,moved:false};return;}if(RG.shopScrollHit(p)){RG.shopMouseDrag={startX:p.x,startY:p.y,lastY:p.y,moved:false};return;} handleClick(p.x, p.y); });
  cv.addEventListener("wheel",e=>{const moved=RG.state==='pause'?RG.scrollBuildBy(e.deltaY,canvasPos(e.clientX,e.clientY),e.deltaX):['shop','achievements'].includes(RG.state)?RG.scrollShopBy(e.deltaY,canvasPos(e.clientX,e.clientY)):RG.scrollPageBy(RG.state,e.deltaY);if(moved)e.preventDefault();}, {passive:false});
  cv.addEventListener("touchstart", e => {
    if (RG.unlockAudio) RG.unlockAudio();
    RG.touchMode = true;
    for (const t of e.changedTouches) {
      const p = canvasPos(t.clientX, t.clientY), pp=pagePos(p);
      if(controlDown(p,t.identifier))continue;
      const actionRects = RG.state === "play" ? (RG.btnRects || []).concat(RG.activeRects || [], RG.statueRect ? [RG.statueRect] : []) : [];
      const onAction = actionRects.some(r => p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h);
      const inJoyZone = RG.state === "play" && !onAction && t.clientX < window.innerWidth * 0.55;
      if (inJoyZone && RG.joy.id === null) {
        RG.joy.id = t.identifier; RG.joy.active = true;
        RG.joy.sx = p.x; RG.joy.sy = p.y; RG.joy.vx = 0; RG.joy.vy = 0;
      } else if(RG.state==='pause'||RG.scrollablePage(RG.state)){
        if(RG.state==="settings"&&volPointerDown(pp.x,pp.y)){if(RG.volDrag)RG.volDragId=t.identifier;}
        else RG.pageDrag={id:t.identifier,state:RG.state,startX:p.x,startY:p.y,lastX:p.x,lastY:p.y,x:p.x,y:p.y,moved:false};
      } else {
        if (!(RG.state === "settings" && volPointerDown(pp.x, pp.y))) handleClick(pp.x, pp.y);
        if (RG.volDrag) RG.volDragId = t.identifier;
      }
    }
    e.preventDefault();
  }, { passive: false });
  cv.addEventListener("touchmove", e => {
    for (const t of e.changedTouches) {
      if(RG.controlDrag&&RG.controlDrag.id===t.identifier){controlMove(canvasPos(t.clientX,t.clientY));continue;}
      if(RG.pageDrag&&RG.pageDrag.id===t.identifier){const p=canvasPos(t.clientX,t.clientY),d=RG.pageDrag,dy=p.y-d.lastY,dx=p.x-d.lastX;d.lastX=p.x;d.lastY=p.y;d.x=p.x;d.y=p.y;if(Math.hypot(p.x-d.startX,p.y-d.startY)>7)d.moved=true;if(d.state==='pause'){if(d.moved&&RG.state==='pause')RG.scrollBuildBy(-dy,{x:d.startX,y:d.startY},-dx);}else if(['shop','achievements'].includes(d.state)){if(d.moved)RG.scrollShopBy(-dy,{x:d.startX,y:d.startY});}else RG.scrollPageBy(d.state,-dy);}
      else if (RG.volDrag && RG.volDragId === t.identifier) { const p = canvasPos(t.clientX, t.clientY); setVolFromX(p.x); }
      else if (t.identifier === RG.joy.id) {
        const p = canvasPos(t.clientX, t.clientY);
        let dx = p.x - RG.joy.sx, dy = p.y - RG.joy.sy;
        const vector=RG.joystickVector(dx,dy);RG.joy.vx=vector.x;RG.joy.vy=vector.y;
      }
    }
    e.preventDefault();
  }, { passive: false });
  function endTouch(e) {
    for (const t of e.changedTouches) {
      if(RG.controlDrag&&RG.controlDrag.id===t.identifier)controlEnd(e.type==='touchcancel');
      if(RG.pageDrag&&t.identifier===RG.pageDrag.id){const d=RG.pageDrag;RG.pageDrag=null;if(e.type!=="touchcancel"&&!d.moved&&RG.state===d.state)handleClick(d.x,d.y+RG.pageScrollOffset(d.state));}
      if (t.identifier === RG.joy.id) { RG.joy.id = null; RG.joy.active = false; RG.joy.vx = 0; RG.joy.vy = 0; }
      if (RG.volDragId === t.identifier) { RG.volDrag = null; RG.volDragId = null; }
    }
  }
  cv.addEventListener("touchend", endTouch);
  cv.addEventListener("touchcancel", endTouch);

  RG.getInput = function () {
    const b=RG.controls.bindings,held=(id,alias)=>keys[b[id]]||(!Object.values(b).includes(alias)&&keys[alias]);
    let x = (held('right','arrowright')?1:0)-(held('left','arrowleft')?1:0);
    let y = (held('down','arrowdown')?1:0)-(held('up','arrowup')?1:0);
    x += RG.joy.vx; y += RG.joy.vy;
    const l = Math.hypot(x, y);
    if (l > 1) { x /= l; y /= l; }
    return { x, y };
  };

  // 设置界面:音量滑条(点按轨道/拖动手柄均可,触屏同源)
  function volRowAt(x, y) {
    if (RG.state !== "settings" || !RG.setRects) return null;
    for (const r of RG.setRects) {
      if (r.action.startsWith("vol:") && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return r.action.slice(4);
    }
    return null;
  }
  function setVolFromX(x) {
    const r = (RG.setRects || []).find(rr => rr.action === "vol:" + RG.volDrag);
    if (!r) return;
    const sw = r.trackW || Math.min(420, RG.W - 120), sx0 = r.trackX == null ? RG.W / 2 - sw / 2 : r.trackX;
    const v = Math.max(0, Math.min(1, (x - sx0) / sw));
    if (RG.volDrag === "jdead") { RG.joyDead = Math.round(2 + v * 28); RG.saveTouch(); return; }
    if (RG.volDrag === "jsens") { RG.joySens = 0.7 + v * 0.7; RG.saveTouch(); return; }
    const prop = { master: "masterVol", mus: "musicVol", sfx: "sfxVol", amb: "ambVol" }[RG.volDrag];
    if (prop) RG[prop] = v;
    if (RG.refreshAudioMix) RG.refreshAudioMix();
    RG.saveVol();
  }
  function volPointerDown(x, y) {
    const key = volRowAt(x, y);
    if (!key) return false;
    RG.volDrag = key; setVolFromX(x);
    return true;
  }
  function handleClick(x, y) {
    if(RG.androidUpdateActivating)return;
    if(runDialog&&!runDialog.hidden||RG.state==="countdown")return;
    if(RG.state==="over"&&RG.deathFx)return;
    if(RG.bindingPending)RG.bindingPending=null;
    if(RG.controlEditing){for(const r of RG.controlRects||[])if(!r.id&&x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==='done'){RG.controlEditing=false;RG.saveControls();}else if(r.action==='reset'){RG.controls.touch={};RG.controls.scale=1;RG.saveControls();}else{RG.controls.scale=clamp(RG.controls.scale+(r.action==='larger'?.05:-.05),.8,1.25);RG.saveControls();}return;}return;}
    if(RG.uiNavState===RG.state)for(const r of RG.uiNav||[]){if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==='tab'){RG.uiTabs[r.key]=r.id;RG.uiPages[r.key]=0;}else RG.uiPages[r.key]=Math.max(0,(RG.uiPages[r.key]||0)+r.delta);RG.playSfx("choose");return;}}
    if(RG.state==="saves"){
      for(const r of RG.saveRects||[])if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){
        if(r.action==="back")RG.handleBack();
        else if(r.action==="delete-named")RG.openRunSaveDialog("delete",r.id);
        else if(r.action==="load-named"){if(RG.restoreNamedRun(r.id))RG.releaseRunInput();else RG.showNotice("此现场不兼容或已损坏，请重新开局；原存档仍保留",true);}
        return;
      }
      return;
    }
    if (RG.state === "play" && RG.activeRects) {
      for (const r of RG.activeRects) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) { RG.useActive(r.slot); return; }
      }
    }
    // 游戏中:右上角触屏按钮(暂停/静音/冲刺)
    if (RG.state === "play" && RG.btnRects) {
      for (const r of RG.btnRects) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
          if (r.action === "pause") RG.performRunAction('pause');
          else if (r.action === "dash") RG.tryDash();
          else { RG.muted = !RG.muted; if (RG.muted) RG.stopBgm(); else RG.startBgm(); }
          return;
        }
      }
    }
    if(RG.state==='maps'&&RG.mapRects){
      for(const r of RG.mapRects)if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==='back')RG.handleBack();else RG.selectMap(r.id);return;}
      return;
    }
    if(RG.state==="loadout"&&RG.loadoutRects){
      for(const r of RG.loadoutRects)if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==="back")RG.handleBack();else if(r.action==="start")RG.performRunAction('start',r.id);return;}
      return;
    }
    if(RG.state==="achievements"&&RG.achRects){
      for(const r of RG.achRects)if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==="back")RG.handleBack();else if(r.action==='codex')RG.codexSelection=r.id;else if(r.action==='codexclose')RG.codexSelection=null;return;}
    }
    if(RG.state==="growth"&&RG.growthRects){
      for(const r of RG.growthRects)if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){
        if(r.action==="back"){RG.handleBack();return;}
        if(r.action==="daily"){RG.startDailyRun();return;}
        RG.returnState="growth";RG.state=r.action;return;
      }
      return;
    }
    if(RG.state==="guide"&&RG.guideRects){
      for(const r of RG.guideRects)if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){RG.meta.tutorialSeen=true;RG.saveMeta();RG.state=r.action==="practice"?"maps":"menu";return;}
      return;
    }
    if(RG.state==='runshop'){
      for(const r of RG.runShopRects||[])if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==='runbuy')RG.buyRunItem(r.id);else RG.closeRunShop();return;}return;
    }
    // 商店
    if (RG.state === "shop" && RG.shopRects) {
      for (const r of RG.shopRects) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
          if (r.action === "back") RG.handleBack();
          else if (r.action === "inspect-shop") { RG.shopSelection={category:RG.uiTabs.shop,id:r.id}; RG.uiPages.shopDetail=0; RG.playSfx("choose"); }
          else if (r.action === "buy") RG.buyShopItem(r.id);
          else if (r.action === "prev") RG.shopPage = Math.max(0, (RG.shopPage || 0) - 1);
          else if (r.action === "next") RG.shopPage = (RG.shopPage || 0) + 1;
          return;
        }
      }
      return;
    }
    // 设置
    if (RG.state === "settings" && RG.setRects) {
      for (const r of RG.setRects) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
          if (r.action === "back") RG.handleBack();
          else if (r.action === "prev") RG.setPage = Math.max(0, (RG.setPage || 0) - 1);   // v8.15 设置页分页
          else if (r.action === "next") RG.setPage = (RG.setPage || 0) + 1;
          else if (r.action.startsWith("fx:")) RG.setFxQuality(r.action.slice(3));
          else if (r.action.startsWith("fps:")) RG.setFrameRate(r.action.slice(4));
          else if (r.action.startsWith("resolution:")) RG.setRenderQuality(r.action.slice(11));
          else if (r.action === "fxauto") RG.toggleFxAuto();
          else if (r.action === "janalog") {RG.joyAnalog=!RG.joyAnalog;RG.saveTouch();}
          else if (r.action === "mute") { RG.muted = !RG.muted; if (RG.muted) RG.stopBgm(); else RG.startBgm(); }
          else if(r.action==='touchlayout'){RG.controlEditing=true;RG.bindingPending=null;}
          else if(r.action==='resetkeys')RG.resetControls();
          else if(r.action==='export-save')RG.downloadSaveBackup();
          else if(r.action==='save-run')RG.openRunSaveDialog();
          else if(r.action==='named-saves'){RG.saveListReturn=RG.returnState;RG.state='saves';}
          else if(r.action==='import-save'&&RG.returnState==='menu'&&backupFile)backupFile.click();
          else if(r.action==='confirm-import')RG.confirmBackupImport();
          else if(r.action==='cancel-import')RG.cancelBackupImport();
          else if(r.action.startsWith('android-update:'))RG.requestAndroidUpdate(r.action.slice(15));
          else if(r.action.startsWith('bind:'))RG.bindingPending=r.action.slice(5);
          return;
        }
      }
      return;
    }
    // 誓约
    if (RG.state === "oaths" && RG.oathRects) {
      for (const r of RG.oathRects) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
          if (r.action === "back") RG.handleBack();
          else if (r.action === "oath") {
            const oaths = RG.meta.oaths = RG.meta.oaths || [];
            const i = oaths.indexOf(r.id);
            if (i >= 0) oaths.splice(i, 1); else oaths.push(r.id);
            RG.saveMeta(); RG.playSfx("oath");
          }
          return;
        }
      }
      return;
    }
    // 雕像献祭按钮
    if (RG.state === "play" && RG.statueRect) {
      const sr = RG.statueRect;
      if (x >= sr.x && x <= sr.x + sr.w && y >= sr.y && y <= sr.y + sr.h) { RG.statueSacrifice(); return; }
    }
    // 升级:重骰按钮
    if (RG.state === "levelup" && RG.rerollRect) {
      const rr = RG.rerollRect;
      if (x >= rr.x && x <= rr.x + rr.w && y >= rr.y && y <= rr.y + rr.h) { RG.rerollOffers(); return; }
    }
    // † BOSS 连战选关
    if (RG.state === "rush" && RG.rushRects) {
      for (const r of RG.rushRects) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
          if (r.action === "back") RG.handleBack();
          else if (r.action === "rushstart") { RG.rushPendingLv=r.id; RG.state="rushweapon"; }
          return;
        }
      }
      return;
    }
    if(RG.state==="rushweapon"&&RG.rushWeaponRects){
      for(const r of RG.rushWeaponRects)if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){if(r.action==="back")RG.handleBack();else if(r.action==="difficulty"){RG.meta.rushDifficulty=r.id;RG.saveMeta();}else if(r.action==="weapon")RG.startRush(RG.rushPendingLv||1,r.id);return;}
      return;
    }
    const rects = RG.state === "levelup" || RG.state === "over" || RG.state === "win" || RG.state === "pause" ? RG.offerRects : RG.state === "menu" ? RG.menuRects : [];
    for (const r of rects) {
      if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
        if (RG.performRunAction(r.action,r.id)) return;
        if (r.action === "restore") {if(RG.restoreRunCheckpoint&&RG.restoreRunCheckpoint())RG.releaseRunInput();else RG.menuNotice={text:'上局记录不兼容或已损坏，请重新开局',until:Date.now()+6000};}
        else if (r.action === "shop") { RG.returnState="menu"; RG.state = "shop"; }
        else if (r.action === "oaths") { RG.returnState="menu"; RG.state = "oaths"; }
        else if (r.action === "achievements") { RG.returnState="menu"; RG.state = "achievements"; }
        else if (r.action === "daily") RG.startDailyRun();
        else if (r.action === "settings") { RG.returnState=RG.state==='pause'?'pause':'menu'; RG.state = "settings"; }
        else if (r.action === "inspect-build") { RG.buildSelection=r.key; RG.buildFocusDetail=!!RG.buildLayout?.portrait; RG.uiPages.buildDetail=0; if(RG.buildScroll.detail)RG.buildScroll.detail.y=0; RG.playSfx("choose"); }
        else if (r.action === "pause-stats") { RG.buildSelection='stats';RG.buildFocusDetail=!!RG.buildLayout?.portrait;RG.uiTabs.pause='overview';if(RG.buildScroll.detail)RG.buildScroll.detail.y=0;if(RG.buildLayout?.portrait&&RG.buildScroll.page)RG.buildScroll.page.y=RG.buildScroll.page.max; }
        else if (r.action === "save-run") RG.openRunSaveDialog();
        else if (r.action === "loadout") RG.state = "maps";
        else if (r.action === "growth") RG.state = "growth";
        else if (r.action === "guide") RG.state = "guide";
        else if (r.action === "continue") RG.continueRun();
        else if (r.action === "rush") RG.state = "rush";
        else if (r.action === "back") RG.handleBack();
        else if(r.action==="confirm")RG.confirmOffer();
        else if(r.action==="cancel")RG.cancelOfferSelection();
        else RG.selectOffer(r.i);
        return;
      }
    }
  }

  // 商店购买:武器 / 永久强化
  RG.buyShopItem = function (id) {
    const w = RG.WEAPONS[id];
    if (w && RG.SHOP_WEAPONS.includes(id) && w.price && !RG.meta.wUnlocked.includes(id)) {
      if (RG.meta.coins >= w.price) {
        RG.meta.coins -= w.price; RG.meta.wUnlocked.push(id); RG.saveMeta(); RG.playSfx("buy");
      }
      return;
    }
    const perk = RG.SHOP_PERKS.find(p => p.id === id);
    if (perk && !perk.runOnly && !RG.meta.perks.includes(id)) {
      if (RG.meta.coins >= perk.price) {
        RG.meta.coins -= perk.price; RG.meta.perks.push(id); RG.saveMeta(); RG.playSfx("buypower");
      }
    }
  };

  // ---------- 主循环 ----------
  // 低帧率最多追100ms，仍按50ms以内推进；升级或暂停立即停止剩余子步。
  RG.advanceFrame = function (elapsed) {
    if (!Number.isFinite(elapsed) || elapsed <= 0) return 0;
    if(RG.state==="over"&&RG.deathFx){RG.updateDeathFeedback(Math.min(.1,elapsed));return 1;}
    if(RG.state!=="play")return 0;
    let remaining = Math.min(.1, elapsed), steps = 0;
    while (remaining > 1e-8 && RG.state === "play") {
      const step = Math.min(.05, remaining); RG.update(step); remaining -= step; steps++;
    }
    return steps;
  };
  if (RG.DEBUG) window.__rogue = {
    startRun: s => RG.startRun(s),
    update: d => RG.update(d),
    draw: () => RG.draw(),
    gainXP: n => RG.gainXP(n),
    hurtPlayer: n => RG.hurtPlayer(n),
    chooseOffer: i => RG.chooseOffer(i),
    useActive: i => RG.useActive(i),
    state: () => RG.state, run: () => RG.run, player: () => RG.P,
    enemies: () => RG.enemies, hazards: () => RG.hazards, walls: () => RG.walls,
    keys,
  };
  function loop(t) {
    requestAnimationFrame(loop);   // 先续帧:任何异常都不再冻结游戏
    const elapsed = RG.takeDisplayFrame(t);
    if (elapsed == null) return;
    RG.monitorDisplayFrame(elapsed);
    try {
      if(RG.state==="countdown")RG.tickRunCountdown();
      else if (RG.state === "play" || RG.state === "over" && RG.deathFx) RG.advanceFrame(elapsed);
      if(RG.checkpointPending){RG.checkpointPending=false;if(RG.saveRunCheckpoint)RG.saveRunCheckpoint();}
    // 暂停与局内设置继续当前场景曲；切后台才暂停音频并保留播放位置。
    if (document.hidden) RG.setMusicScene("silent");
    else if ((['play','levelup','runshop','pause','countdown'].includes(RG.state)||RG.state==='settings'&&RG.returnState==='pause') && RG.run && RG.P) RG.setMusicScene(RG.realm.active ? "vault" : (RG.run.boss||RG.run.finalBoss ? "boss" : "play"));
    else RG.setMusicScene(null);
      RG.draw();
      RG.androidContentReady();
    } catch (err) {
      if (!loop.errLogged) {
        loop.errLogged = true;
        console.error("[RG] 帧异常已拦截:", err);
        const stk = (String((err && err.stack) || "").split("\n").find(l => l.trim().startsWith("at ")) || "").trim().replace(/\(.*js\//, "(js/").slice(0, 110);
        RG.fatalErr = (String((err && err.message) || err).slice(0, 80) + "  @" + stk).slice(0, 190);
      }
    }
    if (RG.DEBUG && RG.P) {
      RG.ctx.textAlign = "left"; RG.ctx.fillStyle = "#0f0"; RG.ctx.font = "12px monospace";
      RG.ctx.fillText("FPS " + Math.round(RG.displayFps) + "  enemies " + RG.enemies.length + "  walls " + RG.walls.length + "  t=" + (RG.run ? RG.run.t.toFixed(1) : 0), 18, RG.H - 14);
    }
    // 拦截到的异常直接显示在屏幕上,便于玩家截图反馈
    if (RG.fatalErr) {
      RG.ctx.textAlign = "left"; RG.ctx.fillStyle = "#ff5470"; RG.ctx.font = "bold 13px monospace";
      RG.ctx.fillText("! 已拦截异常,请截图反馈: " + RG.fatalErr, 18, 22);
    }
  }
  requestAnimationFrame(loop);

  // 混版本加载守卫:Service Worker / HTTP 缓存更新过渡期可能半新半旧 js 混跑,检测到就提示强刷
})(window.RG);
