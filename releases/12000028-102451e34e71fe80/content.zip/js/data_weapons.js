// ============ 数据:武器定义(4 初始 + 10 商店/连战解锁)+ 进化表 ============
(function (RG) {
  // 每个武器单独配置一至七级的实际基础伤害，弹丸/跳链/持续伤害按一次结算计。
  RG.WEAPON_DAMAGE_CURVES = {
    bolt:[12,18,28,42,58,76,98],
    seeker:[18,28,42,62,86,114,148],
    laser:[26,44,70,104,146,194,248],
    orbit:[9.5,16,26,39,55,74,96],
    nova:[17,28,44,66,94,128,166],
    boomer:[14.4,24,38,56,78,104,134],
    scythe:[24,44,74,114,166,228,300],
    spinner:[7.2,13,22,34,48,65,84],
    kiwave:[4.5,8,13,20,29,40,54],
    chain:[21,34,52,76,106,142,184],
    scatter:[16.2,22,30,40,52,66,82],
    beam:[5.3,8,12,17,23,30,38],
    vial:[6.1,10,16,24,34,46,60],
    hammer:[32,60,104,166,248,346,460],
  };
  const damage=(id,lv)=>RG.WEAPON_DAMAGE_CURVES[id][Math.min(7,Math.max(1,lv))-1];
  RG.WEAPONS = {
    bolt: {rules:{
  "stat": {
    "lv_threshold": 8,
    "dmg": 202,
    "cd": 0.26,
    "count": 3,
    "pierce": 2,
    "speed": 700,
    "range": 640,
    "cd_floor": 0.26,
    "cd_offset": 0.62,
    "cd_factor": 0.045,
    "count_threshold": 2,
    "count_threshold_2": 5,
    "speed_2": 640,
    "range_2": 560
  }
},
      name: "魔弹", desc: "自动射向最近的敌人", color: "#7ecbff",
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSBoltStat.lv_threshold) return { dmg: cfgWEAPONSBoltStat.dmg, cd: cfgWEAPONSBoltStat.cd, count: cfgWEAPONSBoltStat.count, pierce: cfgWEAPONSBoltStat.pierce, speed: cfgWEAPONSBoltStat.speed, range: cfgWEAPONSBoltStat.range, evo: true };
        return { dmg: damage("bolt",lv), cd: Math.max(cfgWEAPONSBoltStat.cd_floor, cfgWEAPONSBoltStat.cd_offset - lv * cfgWEAPONSBoltStat.cd_factor), count: 1 + (lv >= cfgWEAPONSBoltStat.count_threshold ? 1 : 0) + (lv >= cfgWEAPONSBoltStat.count_threshold_2 ? 1 : 0), pierce: 0, speed: cfgWEAPONSBoltStat.speed_2, range: cfgWEAPONSBoltStat.range_2 };   // v8.24:lv2 双发、lv5 三发(与分裂弹匣叠加)
      },
    },
    seeker: {rules:{
  "stat": {
    "lv_threshold": 8,
    "dmg": 238,
    "cd": 0.6,
    "count": 4,
    "speed": 330,
    "turn": 4.5,
    "range": 9,
    "cd_floor": 0.6,
    "cd_offset": 1.25,
    "cd_factor": 0.08,
    "count_threshold": 4,
    "count_threshold_2": 7,
    "speed_offset": 280,
    "speed_factor": 12,
    "turn_2": 3.4,
    "range_offset": 5,
    "range_factor": 0.35
  },
  "weaponStat": {
    "lv_threshold": 3,
    "burstDelay": 0.2,
    "targetRange": 620
  }
},
      name: "追踪飞弹", desc: "发射会拐弯追敌的飞弹", color: "#c084fc",
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSSeekerStat.lv_threshold) return { dmg: cfgWEAPONSSeekerStat.dmg, cd: cfgWEAPONSSeekerStat.cd, count: cfgWEAPONSSeekerStat.count, speed: cfgWEAPONSSeekerStat.speed, turn: cfgWEAPONSSeekerStat.turn, range: cfgWEAPONSSeekerStat.range, evo: true };
        return { dmg: damage("seeker",lv), cd: Math.max(cfgWEAPONSSeekerStat.cd_floor, cfgWEAPONSSeekerStat.cd_offset - lv * cfgWEAPONSSeekerStat.cd_factor), count: 1 + (lv >= cfgWEAPONSSeekerStat.count_threshold ? 1 : 0) + (lv >= cfgWEAPONSSeekerStat.count_threshold_2 ? 1 : 0), speed: cfgWEAPONSSeekerStat.speed_offset + lv * cfgWEAPONSSeekerStat.speed_factor, turn: cfgWEAPONSSeekerStat.turn_2, range: cfgWEAPONSSeekerStat.range_offset + lv * cfgWEAPONSSeekerStat.range_factor };   // v8.24:速度逐级+连发节点
      },
    },
    laser: {rules:{
  "updateWeapons": {
    "shots": 2,
    "width_divisor": 2
  },
  "stat": {
    "lv_threshold": 8,
    "dmg": 272,
    "cd": 0.5,
    "range": 820,
    "width": 30,
    "cd_floor": 0.9,
    "cd_offset": 1.6,
    "cd_factor": 0.09,
    "range_offset": 700,
    "range_factor": 15,
    "width_offset": 7
  },
  "weaponStat": {
    "reflections_cap": 5
  }
},
      name: "激光", get desc(){return "贯穿射线，遇墙、地图边界与盾面反射，最多"+RG.configChinese(RG.WEAPONS.laser.rules.weaponStat.reflections_cap,"五",5)+"次";}, color: "#ff5470", price: 300,
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSLaserStat.lv_threshold) return { dmg: cfgWEAPONSLaserStat.dmg, cd: cfgWEAPONSLaserStat.cd, range: cfgWEAPONSLaserStat.range, width: cfgWEAPONSLaserStat.width, twin: true, evo: true };
        return { dmg: damage("laser",lv), cd: Math.max(cfgWEAPONSLaserStat.cd_floor, cfgWEAPONSLaserStat.cd_offset - lv * cfgWEAPONSLaserStat.cd_factor), range: cfgWEAPONSLaserStat.range_offset + lv * cfgWEAPONSLaserStat.range_factor, width: cfgWEAPONSLaserStat.width_offset + lv };   // v8.24:射程逐级+15
      },
    },
    orbit: {rules:{
  "updateWeapons": {
    "sweep_floor": 0.2,
    "body_factor": 11,
    "half_factor": 2,
    "value_factor": 26
  },
  "stat": {
    "lv_threshold": 8,
    "dmg": 96,
    "blades": 10,
    "radius": 150,
    "spin": 4.2,
    "hitCd": 0.3,
    "size": 1.5,
    "blades_cap": 7,
    "blades_offset": 2,
    "blades_divisor": 1.5,
    "radius_offset": 84,
    "radius_factor": 6,
    "spin_offset": 2.7,
    "spin_factor": 0.18,
    "hitCd_2": 0.38,
    "size_factor": 0.06
  },
  "weaponStat": {
    "lv_threshold": 3,
    "spin": 1.1,
    "size": 1.15,
    "radius": 1.1
  }
},
      name: "环刃", desc: "旋转刀刃环绕自身,接触伤害", color: "#ffd166",
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSOrbitStat.lv_threshold) return { dmg: cfgWEAPONSOrbitStat.dmg, blades: cfgWEAPONSOrbitStat.blades, radius: cfgWEAPONSOrbitStat.radius, spin: cfgWEAPONSOrbitStat.spin, hitCd: cfgWEAPONSOrbitStat.hitCd, size: cfgWEAPONSOrbitStat.size, evo: true };
        return { dmg: damage("orbit",lv), blades: Math.min(cfgWEAPONSOrbitStat.blades_cap, cfgWEAPONSOrbitStat.blades_offset + Math.floor(lv / cfgWEAPONSOrbitStat.blades_divisor)), radius: cfgWEAPONSOrbitStat.radius_offset + lv * cfgWEAPONSOrbitStat.radius_factor, spin: cfgWEAPONSOrbitStat.spin_offset + lv * cfgWEAPONSOrbitStat.spin_factor, hitCd: cfgWEAPONSOrbitStat.hitCd_2, size: 1 + lv * cfgWEAPONSOrbitStat.size_factor };   // v8.23:范围/转速/体积全面上调(用户反馈)
      },
    },
    nova: {rules:{
  "updateWeapons": {
    "id_threshold": 0.2,
    "value": 0.5,
    "t_factor": 0.16
  },
  "stat": {
    "lv_threshold": 8,
    "dmg": 212,
    "radius": 330,
    "knock": 340,
    "pulses": 4,
    "cd_offset": 2.2,
    "cd_factor": 0.13,
    "radius_offset": 115,
    "radius_factor": 18,
    "knock_offset": 130,
    "knock_factor": 22,
    "pulses_threshold": 4,
    "pulses_threshold_2": 7
  }
},
      name: "冲击波", desc: "周期性范围冲击,击退敌人", color: "#ff8fa3",
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSNovaStat.lv_threshold) return { dmg: cfgWEAPONSNovaStat.dmg, cd: 1.0, radius: cfgWEAPONSNovaStat.radius, knock: cfgWEAPONSNovaStat.knock, pull: true, pulses: cfgWEAPONSNovaStat.pulses, evo: true };
        return { dmg: damage("nova",lv), cd: Math.max(1.0, cfgWEAPONSNovaStat.cd_offset - lv * cfgWEAPONSNovaStat.cd_factor), radius: cfgWEAPONSNovaStat.radius_offset + lv * cfgWEAPONSNovaStat.radius_factor, knock: cfgWEAPONSNovaStat.knock_offset + lv * cfgWEAPONSNovaStat.knock_factor, pulses: 1 + (lv >= cfgWEAPONSNovaStat.pulses_threshold ? 1 : 0) + (lv >= cfgWEAPONSNovaStat.pulses_threshold_2 ? 1 : 0) };   // v8.24:连冲 2~3 次(进化 4 次),后续脉冲弱击退
      },
    },
    boomer: {rules:{
  "updateWeapons": {
    "hitCd": 0.45
  },
  "stat": {
    "lv_threshold": 8,
    "dmg": 144,
    "count": 3,
    "speed": 620,
    "range": 400,
    "cd": 0.8,
    "hitCd": 0.4,
    "size": 1.6,
    "count_threshold": 2,
    "count_threshold_2": 5,
    "speed_offset": 430,
    "speed_factor": 24,
    "range_offset": 235,
    "range_factor": 15,
    "cd_floor": 0.85,
    "cd_offset": 1.6,
    "cd_factor": 0.09,
    "hitCd_2": 0.45,
    "size_factor": 0.08
  },
  "weaponStat": {
    "lv_threshold": 3,
    "size": 1.2
  }
},
      name: "回旋镖", desc: "掷出后飞回,去回都能伤敌,可越过墙体", color: "#a3e635",
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSBoomerStat.lv_threshold) return { dmg: cfgWEAPONSBoomerStat.dmg, count: cfgWEAPONSBoomerStat.count, speed: cfgWEAPONSBoomerStat.speed, range: cfgWEAPONSBoomerStat.range, cd: cfgWEAPONSBoomerStat.cd, hitCd: cfgWEAPONSBoomerStat.hitCd, size: cfgWEAPONSBoomerStat.size, evo: true };
        return { dmg: damage("boomer",lv), count: 1 + (lv >= cfgWEAPONSBoomerStat.count_threshold ? 1 : 0) + (lv >= cfgWEAPONSBoomerStat.count_threshold_2 ? 1 : 0), speed: cfgWEAPONSBoomerStat.speed_offset + lv * cfgWEAPONSBoomerStat.speed_factor, range: cfgWEAPONSBoomerStat.range_offset + lv * cfgWEAPONSBoomerStat.range_factor, cd: Math.max(cfgWEAPONSBoomerStat.cd_floor, cfgWEAPONSBoomerStat.cd_offset - lv * cfgWEAPONSBoomerStat.cd_factor), hitCd: cfgWEAPONSBoomerStat.hitCd_2, size: 1 + lv * cfgWEAPONSBoomerStat.size_factor };
      },
    },
    // ---- v9.0 新武器:四套完全不同的攻击循环 ----
    scythe: {rules:{
  "hurtEnemy": {
    "hurtEnemy_offset": 4
  },
  "updateWeapons": {
    "tgt_offset": 36,
    "arc_divisor": 2,
    "executeMul": 2,
    "value_factor": 34,
    "id": 0.18
  },
  "stat": {
    "cd_offset": 1.18,
    "cd_factor": 0.06,
    "radius_offset": 92,
    "radius_factor": 8,
    "arc_offset": 1.18,
    "arc_factor": 0.08
  },
  "weaponStat": {
    "arc_factor": 1.2,
    "radius": 1.15
  }
},
      name: "月蚀镰刀", desc: "敌人靠近时自动朝目标扇形斩击", color: "#f472b6",
      maxLv: 7,
      stat: lv => ({ dmg: damage("scythe",lv), cd: cfgWEAPONSScytheStat.cd_offset - lv * cfgWEAPONSScytheStat.cd_factor, radius: cfgWEAPONSScytheStat.radius_offset + lv * cfgWEAPONSScytheStat.radius_factor, arc: cfgWEAPONSScytheStat.arc_offset + lv * cfgWEAPONSScytheStat.arc_factor }),
    },
    spinner: {rules:{
  "updateWeapons": {
    "value_threshold": 6,
    "sa_divisor": 2,
    "sa_factor": 0.14,
    "travel_cap": 0.42,
    "id": 0.25
  },
  "stat": {
    "cd_offset": 4.5,
    "cd_factor": 0.22,
    "radius_offset": 30,
    "radius_factor": 5,
    "duration_offset": 2.5,
    "duration_factor": 0.12,
    "speed": 560,
    "hitCd": 0.34
  },
  "weaponStat": {
    "targetRange": 620
  }
},
      name: "旋转连棍", desc: "掷出旋棍,驻场高速旋转持续切割", color: "#fb923c", price: 350,
      maxLv: 7,
      stat: lv => ({ dmg: damage("spinner",lv), cd: cfgWEAPONSSpinnerStat.cd_offset - lv * cfgWEAPONSSpinnerStat.cd_factor, radius: cfgWEAPONSSpinnerStat.radius_offset + lv * cfgWEAPONSSpinnerStat.radius_factor, duration: cfgWEAPONSSpinnerStat.duration_offset + (lv - 1) * cfgWEAPONSSpinnerStat.duration_factor, speed: cfgWEAPONSSpinnerStat.speed, hitCd: cfgWEAPONSSpinnerStat.hitCd }),
    },
    kiwave: {rules:{
  "updateWeapons": {
    "shot_min": 0.05,
    "shot_max": 0.35,
    "shot": 0.16,
    "r": 6,
    "r_2": 3.5
  },
  "stat": {
    "spawnCd": 5,
    "max_cap": 10,
    "max_offset": 3,
    "shotCd_offset": 1.04,
    "shotCd_factor": 0.06,
    "radius_offset": 66,
    "radius_factor": 4,
    "range": 560,
    "speed": 760
  },
  "weaponStat": {
    "aimSpread": 0.07
  }
},
      name: "元气波", get desc(){return "每"+RG.configNumber(cfgWEAPONSKiwaveStat.spawnCd)+"秒凝聚气珠,环绕并自动高速齐射";}, color: "#67e8f9", price: 400,
      maxLv: 7,
      stat: lv => ({ dmg: damage("kiwave",lv), spawnCd: cfgWEAPONSKiwaveStat.spawnCd, max: Math.min(cfgWEAPONSKiwaveStat.max_cap, cfgWEAPONSKiwaveStat.max_offset + lv), shotCd: cfgWEAPONSKiwaveStat.shotCd_offset - lv * cfgWEAPONSKiwaveStat.shotCd_factor, radius: cfgWEAPONSKiwaveStat.radius_offset + lv * cfgWEAPONSKiwaveStat.radius_factor, range: cfgWEAPONSKiwaveStat.range, speed: cfgWEAPONSKiwaveStat.speed }),
    },
    // ---- 商店解锁 ----
    chain: {rules:{
  "stat": {
    "cd_floor": 0.5,
    "cd_offset": 1.1,
    "cd_factor": 0.07,
    "jumps_offset": 2,
    "jumps_divisor": 2,
    "range": 420,
    "hop": 260
  }
},
      name: "闪电链", desc: "闪电在敌人之间跳跃传导", color: "#7dd3fc", price: 350,
      maxLv: 7,
      stat: lv => ({ dmg: damage("chain",lv), cd: Math.max(cfgWEAPONSChainStat.cd_floor, cfgWEAPONSChainStat.cd_offset - lv * cfgWEAPONSChainStat.cd_factor), jumps: cfgWEAPONSChainStat.jumps_offset + Math.floor(lv / cfgWEAPONSChainStat.jumps_divisor), range: cfgWEAPONSChainStat.range, hop: cfgWEAPONSChainStat.hop }),
    },
    scatter: {rules:{
  "updateWeapons": {
    "r": 10,
    "r_2": 4
  },
  "stat": {
    "cd_floor": 0.55,
    "cd_offset": 1.05,
    "cd_factor": 0.06,
    "count_offset": 4,
    "count_factor": 0.7,
    "spread": 0.55,
    "speed": 520,
    "range": 300,
    "pierce": 2
  },
  "weaponStat": {
    "pelletSize": 1.5
  }
},
      name: "霰弹", desc: "朝面朝方向扇形喷射弹丸,可穿透,越远伤害越低", color: "#fbbf24", price: 250,
      maxLv: 7,
      stat: lv => ({ dmg: damage("scatter",lv), cd: Math.max(cfgWEAPONSScatterStat.cd_floor, cfgWEAPONSScatterStat.cd_offset - lv * cfgWEAPONSScatterStat.cd_factor), count: cfgWEAPONSScatterStat.count_offset + Math.floor(lv * cfgWEAPONSScatterStat.count_factor), spread: cfgWEAPONSScatterStat.spread, speed: cfgWEAPONSScatterStat.speed, range: cfgWEAPONSScatterStat.range, pierce: cfgWEAPONSScatterStat.pierce }),   // v8.23:穿透 2 + 距离衰减(用户反馈)
    },
    // ---- 内容扩展(v7.5):持续光束 / 区域压制 / 近身重击 ----
    beam: {overheatCooldown:1,rules:{
  "updateWeapons": {
    "beamStep_floor": 0.2,
    "beamLock_threshold": 5,
    "beamLock_cap": 5,
    "ramp_threshold": 1.5,
    "ramp": 1.8,
    "ramp_threshold_2": 0.5,
    "ramp_2": 1.4,
    "beamOver_floor": 0.5,
    "value_threshold": 0.5
  },
  "stat": {
    "lv_threshold": 8,
    "dmg": 47,
    "cd": 0.08,
    "range": 560,
    "width": 26,
    "cd_floor": 0.06,
    "cd_offset": 0.15,
    "cd_factor": 0.011,
    "range_offset": 460,
    "range_factor": 12,
    "width_offset": 12,
    "width_factor": 2
  }
},
      name: "熔断射线", get desc(){return "锁定最近敌人持续灼烧,同一目标超 "+RG.configNumber(RG.WEAPONS.beam.rules.updateWeapons.beamLock_threshold)+(" 秒过热 "+RG.configNumber(RG.WEAPONS.beam.overheatCooldown)+" 秒");}, color: "#ff9d5c",
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSBeamStat.lv_threshold) return { dmg: cfgWEAPONSBeamStat.dmg, cd: cfgWEAPONSBeamStat.cd, range: cfgWEAPONSBeamStat.range, width: cfgWEAPONSBeamStat.width, evo: true };
        return { dmg: damage("beam",lv), cd: Math.max(cfgWEAPONSBeamStat.cd_floor, cfgWEAPONSBeamStat.cd_offset - lv * cfgWEAPONSBeamStat.cd_factor), range: cfgWEAPONSBeamStat.range_offset + lv * cfgWEAPONSBeamStat.range_factor, width: cfgWEAPONSBeamStat.width_offset + lv * cfgWEAPONSBeamStat.width_factor };   // 高频持续伤害采用较缓的独立成长，冷却逐级递减。
      },
    },
    vial: {slowMul:.6,rules:{
  "updateWeapons": {
    "value_90000_factor": 90000,
    "t": 4,
    "arm": 0.4,
    "id": 0.5
  },
  "stat": {
    "cd_floor": 1.8,
    "cd_offset": 3.2,
    "cd_factor": 0.16,
    "radius_offset": 66,
    "radius_factor": 6
  },
  "weaponStat": {
    "lv_threshold": 3,
    "radius": 1.2
  }
},
      name: "腐蚀瓶", desc: "抛出酸蚀瓶,留下持续腐蚀并减速的酸液地面", color: "#a3e635", price: 300,
      maxLv: 7,
      stat: lv => ({ dot: damage("vial",lv), cd: Math.max(cfgWEAPONSVialStat.cd_floor, cfgWEAPONSVialStat.cd_offset - lv * cfgWEAPONSVialStat.cd_factor), radius: cfgWEAPONSVialStat.radius_offset + lv * cfgWEAPONSVialStat.radius_factor }),   // v8.24:半径 +4→+6/级
    },
    hammer: {rules:{
  "updateWeapons": {
    "t_offset": 0.22,
    "length_factor": 1.25,
    "width_factor": 1.25,
    "dmg_factor": 0.65
  },
  "stat": {
    "lv_threshold": 8,
    "dmg": 502,
    "cd": 0.85,
    "radius": 96,
    "cd_floor": 0.85,
    "cd_offset": 1.15,
    "cd_factor": 0.035,
    "radius_offset": 50,
    "radius_factor": 5
  },
  "weaponStat": {
    "length_factor": 2
  }
},
      name: "震地之锤", desc: "近敌触发，朝最近敌人砸出前方长方形重击", color: "#fbbf24", price: 400,
      maxLv: 7,
      stat: lv => {
        if (lv >= cfgWEAPONSHammerStat.lv_threshold) return { dmg: cfgWEAPONSHammerStat.dmg, cd: cfgWEAPONSHammerStat.cd, radius: cfgWEAPONSHammerStat.radius, evo: true };
        return { dmg: damage("hammer",lv), cd: Math.max(cfgWEAPONSHammerStat.cd_floor, cfgWEAPONSHammerStat.cd_offset - lv * cfgWEAPONSHammerStat.cd_factor), radius: cfgWEAPONSHammerStat.radius_offset + lv * cfgWEAPONSHammerStat.radius_factor };
      },
    },
  };
  RG.WEAPON_ORDER = ["beam", "bolt", "seeker", "orbit", "nova", "boomer", "scythe", "spinner", "kiwave", "hammer", "vial", "laser", "chain", "scatter"];
  // “远程伤害”与盾兽正面格挡共同使用同一分类，避免新增武器只接到其中一半。
  RG.CLOSE_WEAPONS = ["vial", "orbit", "hammer", "scythe", "scatter", "nova"];
  RG.RANGED_WEAPONS = ["bolt", "laser", "seeker", "boomer", "chain", "spinner", "beam", "kiwave"];
  RG.weaponIsClose = id => RG.CLOSE_WEAPONS.includes(id);
  RG.weaponRangeLabel = id => RG.weaponIsClose(id) ? "近程" : RG.weaponIsRanged(id) ? "远程" : "";
  RG.weaponIsRanged = id => RG.RANGED_WEAPONS.includes(id);
  // 四把默认武器；其余按覆盖能力、操作成本与单体爆发分档出售。
  RG.BASE_WEAPONS = ["bolt", "orbit", "boomer", "spinner"];
  const prices={seeker:160,scatter:180,nova:220,scythe:240,beam:300,laser:300,vial:320,hammer:340,chain:380,kiwave:440};
  for(const id of RG.WEAPON_ORDER){if(RG.BASE_WEAPONS.includes(id))delete RG.WEAPONS[id].price;else{RG.WEAPONS[id].price=prices[id];RG.WEAPONS[id].shopTier=prices[id]<=240?'初阶':prices[id]<=340?'进阶':'高阶';}}
  RG.BOSS_WEAPON_REWARDS=[['seeker'],['scatter'],['nova'],['scythe'],['laser','beam'],['vial','hammer'],['chain'],['kiwave']];
  RG.unlockBossWeapons=function(lv){const earned=[];if(!RG.meta)return earned;for(const id of RG.BOSS_WEAPON_REWARDS[lv-1]||[]){if(!RG.meta.wUnlocked.includes(id)){RG.meta.wUnlocked.push(id);earned.push(id);}}return earned;};
  RG.SHOP_WEAPONS = RG.WEAPON_ORDER.filter(id => !RG.BASE_WEAPONS.includes(id));
  RG.weaponUnlocked = id => RG.BASE_WEAPONS.includes(id) || !!(RG.meta && RG.meta.wUnlocked.includes(id));

  // v10.1 元素档案：元素等级属于具体武器，与武器等级和进化分支互相独立。
  RG.ELEMENT_ORDER = ["fire", "ice", "elec", "poison", "earth"];
  RG.ELEMENTS = {
    fire:   { name:"烈火", glyph:"火", color:"#fb923c", efficiency:[0,.20,.30,.40,.50,.65] },
    ice:    { name:"寒冰", glyph:"冰", color:"#7dd3fc", efficiency:[0,.20,.30,.40,.50,.65] },
    elec:   { name:"雷电", glyph:"电", color:"#fde047", efficiency:[0,.20,.30,.40,.50,.65] },
    poison: { name:"剧毒", glyph:"毒", color:"#84cc16", efficiency:[0,.20,.30,.40,.50,.65] },
    earth:  { name:"大地", glyph:"地", color:"#d6a85f", efficiency:[0,.20,.30,.40,.50,.65] },
  };
  // 兼容 v9.4 的字符串结构，P2 起正式结构为 {type,level}。
  RG.weaponElement = function(P,id){
    const raw=P&&P.weaponElements&&P.weaponElements[id];
    if(!raw)return null;
    return typeof raw==="string"?{type:raw,level:1}:raw;
  };
  RG.setWeaponElement = function(P,id,type){
    if(!P||!P.weapons[id]||!RG.ELEMENTS[type])return false;
    const old=RG.weaponElement(P,id);
    if(old&&old.type!==type)return false;
    P.weaponElements[id]={type,level:Math.min(RG.BALANCE.weapons.setWeaponElement.level_cap,old?old.level+1:1)};
    return true;
  };
  RG.elementEfficiency = function(P,id){
    const el=RG.weaponElement(P,id),def=el&&RG.ELEMENTS[el.type];
    return def?(def.efficiency[Math.min(5,Math.max(1,el.level||1))]||0):0;
  };

  // ---- H3 分支进化:武器满级 + 指定被动(* 为前缀匹配) → 二选一行为分支 ----
  RG.EVOLVE = {
    bolt:   { req:"frenzy", branches:[{id:"annihilate",name:"湮灭魔弹",get desc(){return RG.configChinese(RG.EVOLVE.bolt.branches.find(b=>b.id==="annihilate").stats.count,"三",3)+"发高伤魔弹,穿透 +"+RG.configNumber(RG.EVOLVE.bolt.branches.find(b=>b.id==="annihilate").stats.pierce);},stats:{dmg:202,cd:.26,count:3,pierce:2,speed:700,range:640}},{id:"starfall",name:"星雨弹幕",get desc(){return RG.configChinese(RG.EVOLVE.bolt.branches.find(b=>b.id==="starfall").stats.count,"七",7)+"发宽散魔弹覆盖正面";},stats:{dmg:120,cd:.23,count:7,pierce:0,speed:720,range:620,spread:.2}}] },
    seeker: { req:"magnet", branches:[{id:"judgment",name:"天罚导弹",get desc(){return RG.configChinese(RG.EVOLVE.seeker.branches.find(b=>b.id==="judgment").stats.count,"四",4)+"枚重型飞弹,追踪强化";},stats:{dmg:238,cd:.6,count:4,speed:330,turn:4.5,range:9}},{id:"swarm",name:"蜂群协议",get desc(){return RG.configChinese(RG.EVOLVE.seeker.branches.find(b=>b.id==="swarm").stats.count,"八",8)+"枚高速轻弹持续换目标";},stats:{dmg:123,cd:.48,count:8,speed:390,turn:5.5,range:8}}] },
    laser:  { req:"power*", branches:[{id:"twin",name:"歼星射线",desc:"双射线同时贯穿战场",stats:{dmg:272,cd:.5,range:820,width:30,twin:true}},{id:"lance",name:"天穹长枪",get desc(){return (this.stats.twin?"双":"单")+"道超宽射线造成重击";},stats:{dmg:510,cd:.82,range:940,width:46,twin:false}}] },
    orbit:  { req:"boots*", branches:[{id:"wheel",name:"风火车轮",get desc(){return RG.configChinese(RG.EVOLVE.orbit.branches.find(b=>b.id==="wheel").stats.blades,"十",10)+"刃高速环绕,扩大覆盖";},stats:{dmg:96,blades:10,radius:150,spin:4.2,hitCd:.3,size:1.5}},{id:"breaker",name:"断空巨轮",get desc(){return RG.configChinese(RG.EVOLVE.orbit.branches.find(b=>b.id==="breaker").stats.blades,"四",4)+"枚超大重刃高频切割";},stats:{dmg:232,blades:4,radius:175,spin:2.9,hitCd:.18,size:2.8}}] },
    nova:   { req:"shell", branches:[{id:"singularity",name:"引力奇点",get desc(){return RG.configChinese(RG.EVOLVE.nova.branches.find(b=>b.id==="singularity").stats.pulses,"四",4)+"连脉冲先吸聚再爆发";},stats:{dmg:212,cd:1,radius:330,knock:340,pull:true,pulses:4}},{id:"repulse",name:"斥灭脉冲",get desc(){return RG.configChinese(this.stats.pulses,"双",2)+"连高伤脉冲强力击退";},stats:{dmg:325,cd:.75,radius:280,knock:480,pulses:2}}] },
    boomer: { req:"split*", branches:[{id:"twins",name:"双生回旋镖",get desc(){return RG.configChinese(RG.EVOLVE.boomer.branches.find(b=>b.id==="twins").stats.count,"三",3)+"枚回旋镖同时往返";},stats:{dmg:144,count:3,speed:620,range:400,cd:.8,hitCd:.4,size:1.6}},{id:"giant",name:"回天巨刃",desc:"巨刃远距多段切割，保留已获得的投掷数量",stats:{dmg:327,count:3,speed:520,range:520,cd:1.05,hitCd:.22,size:3}}] },
    beam:   { req:"power*", branches:[{id:"split",name:"灼穿光束",desc:"维持单体锁定,提高灼烧伤害与射程",stats:{dmg:47,cd:.08,range:580,width:18}},{id:"cold",name:"冷核射线",desc:"单体稳定高频射线,永不过热",stats:{dmg:38,cd:.05,range:620,width:20,noOverheat:true}}] },
    vial:   { req:"magnet", branches:[{id:"miasma",name:"瘴气领域",desc:"超大酸池长时间压制区域",stats:{dot:72,cd:1.7,radius:165,duration:8}},{id:"toxic",name:"剧毒坩埚",desc:"小范围高伤毒池持续侵蚀",stats:{dot:151,cd:1.35,radius:95,duration:5,forcedElement:"poison"}}] },
    hammer: { req:"shell", branches:[{id:"aftershock",name:"天崩地裂",desc:"重锤落地后追加延迟震波",stats:{dmg:502,cd:.85,radius:120,aftershock:true}},{id:"mountain",name:"镇岳重锤",desc:"单次超重击与极强击退",stats:{dmg:606,cd:1.05,radius:138,heavyKnock:true}}] },
    scythe: { req:"crit*", branches:[{id:"fullmoon",name:"满月收割",desc:"挥出整圈镰光清扫近身",stats:{dmg:333,cd:.82,radius:165,arc:6.283,fullCircle:true}},{id:"execute",name:"断头新月",desc:"远距扇斩,残血敌人承伤翻倍",stats:{dmg:315,cd:.72,radius:210,arc:1.8,execute:.35}}] },
    spinner:{ req:"boots*", branches:[{id:"twins",name:"双龙绞",desc:"同时投出两根旋棍驻场",stats:{dmg:93,cd:2.8,radius:75,duration:4,speed:600,hitCd:.28,count:2}},{id:"pillar",name:"定海神针",get desc(){return RG.configChinese(RG.EVOLVE.spinner.branches.find(b=>b.id==="pillar").stats.count,"单",1)+"根超长重棍持续碾压";},stats:{dmg:109,cd:3.2,radius:140,duration:5,speed:520,hitCd:.22,count:1}}] },
    kiwave: { req:"harmony", branches:[{id:"myriad",name:"万气归宗",get desc(){return RG.configChinese(RG.EVOLVE.kiwave.branches.find(b=>b.id==="myriad").stats.max,"十",10)+"颗气珠高速齐射";},stats:{dmg:104,spawnCd:3.8,max:10,shotCd:.28,radius:100,range:640,speed:820,pierce:0}},{id:"siege",name:"破城气核",get desc(){return RG.configChinese(RG.EVOLVE.kiwave.branches.find(b=>b.id==="siege").stats.max,"五",5)+"颗重型气弹贯穿敌阵";},stats:{dmg:228,spawnCd:4.2,max:5,shotCd:.55,radius:115,range:680,speed:720,pierce:2}}] },
    chain:  { req:"elem*", branches:[{id:"thunder",name:"万雷天引",get desc(){return "闪电在"+RG.configChinese(RG.EVOLVE.chain.branches.find(b=>b.id==="thunder").stats.jumps,"十二",12)+"个目标间远距传导";},stats:{dmg:222,cd:.42,jumps:12,range:560,hop:360}},{id:"judgment",name:"雷罚烙印",desc:"缩短跳链,大幅提升单体伤害",stats:{dmg:403,cd:.58,jumps:6,range:600,hop:300}}] },
    scatter:{ req:"split*", branches:[{id:"storm",name:"金属风暴",get desc(){return RG.configChinese(RG.EVOLVE.scatter.branches.find(b=>b.id==="storm").stats.count,"十六",16)+"发宽扇弹幕贯穿敌群";},stats:{dmg:59,cd:.48,count:16,spread:.7,speed:600,range:400,pierce:4}},{id:"slug",name:"破城独头弹",get desc(){return RG.configChinese(RG.EVOLVE.scatter.branches.find(b=>b.id==="slug").stats.count,"单",1)+"发重弹高伤高穿透";},stats:{dmg:447,cd:.72,count:1,spread:0,speed:760,range:620,pierce:12,slug:true}}] },
  };
  RG.weaponStat = function(id, lv, branchId) {
    const base = RG.WEAPONS[id].stat(lv);
    let st = Object.assign({}, base);
    if (lv >= RG.BALANCE.weapons.weaponStat.lv_threshold && RG.EVOLVE[id]) {
      const branches = RG.EVOLVE[id].branches;
      const branch = branches.find(b => b.id === branchId) || branches[0];
      Object.assign(st, branch.stats, { evo:true, evoBranch:branch.id, evoName:branch.name });
    }
    // 伤害调整已计入基础曲线与进化表；等级节点的行为收益永久保留。
    if (id === "seeker" && lv >= cfgWEAPONSSeekerWeaponStat.lv_threshold) st.burstDelay = cfgWEAPONSSeekerWeaponStat.burstDelay;
    // 飞弹的旧range单位为秒，转换为明确寿命；鹰眼只提高索敌距离。
    if(id==='seeker'){st.life=st.range;delete st.range;st.targetRange=cfgWEAPONSSeekerWeaponStat.targetRange;}
    if(id==='spinner'||id==='boomer')st.targetRange=RG.WEAPONS.spinner.rules.weaponStat.targetRange;
    if (id === "kiwave") { st.aimSpread = RG.WEAPONS.kiwave.rules.weaponStat.aimSpread; }
    if (id === "scatter") { st.pelletSize = RG.WEAPONS.scatter.rules.weaponStat.pelletSize; }
    if (id === "laser") st.reflections = Math.min(RG.WEAPONS.laser.rules.weaponStat.reflections_cap, lv);
    if (id === "orbit" && lv >= cfgWEAPONSOrbitWeaponStat.lv_threshold) { st.spin *= cfgWEAPONSOrbitWeaponStat.spin; st.size *= cfgWEAPONSOrbitWeaponStat.size; st.radius *= cfgWEAPONSOrbitWeaponStat.radius; }
    if (id === "vial" && lv >= cfgWEAPONSVialWeaponStat.lv_threshold) st.radius *= cfgWEAPONSVialWeaponStat.radius;
    if (id === "scythe") { st.arc = Math.min(Math.PI * 2, st.arc * cfgWEAPONSScytheWeaponStat.arc_factor); st.radius *= cfgWEAPONSScytheWeaponStat.radius; }
    if (id === "boomer" && lv >= cfgWEAPONSBoomerWeaponStat.lv_threshold) st.size *= cfgWEAPONSBoomerWeaponStat.size;
    if (id === "hammer") { st.length = st.radius * RG.WEAPONS.hammer.rules.weaponStat.length_factor; st.width = st.radius; }
    return st;
  };
  RG.DATA_WEAPONS_VER="v12027";
  for(const data of [RG.WEAPONS,RG.EVOLVE,RG.ELEMENTS,RG.WEAPON_DAMAGE_CURVES])RG.freezeConfig(data);

  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgWEAPONSBoltStat=RG.WEAPONS.bolt.rules.stat,
    cfgWEAPONSSeekerStat=RG.WEAPONS.seeker.rules.stat,
    cfgWEAPONSLaserStat=RG.WEAPONS.laser.rules.stat,
    cfgWEAPONSOrbitStat=RG.WEAPONS.orbit.rules.stat,
    cfgWEAPONSNovaStat=RG.WEAPONS.nova.rules.stat,
    cfgWEAPONSBoomerStat=RG.WEAPONS.boomer.rules.stat,
    cfgWEAPONSScytheStat=RG.WEAPONS.scythe.rules.stat,
    cfgWEAPONSSpinnerStat=RG.WEAPONS.spinner.rules.stat,
    cfgWEAPONSKiwaveStat=RG.WEAPONS.kiwave.rules.stat,
    cfgWEAPONSChainStat=RG.WEAPONS.chain.rules.stat,
    cfgWEAPONSScatterStat=RG.WEAPONS.scatter.rules.stat,
    cfgWEAPONSBeamStat=RG.WEAPONS.beam.rules.stat,
    cfgWEAPONSVialStat=RG.WEAPONS.vial.rules.stat,
    cfgWEAPONSHammerStat=RG.WEAPONS.hammer.rules.stat,
    cfgWEAPONSSeekerWeaponStat=RG.WEAPONS.seeker.rules.weaponStat,
    cfgWEAPONSOrbitWeaponStat=RG.WEAPONS.orbit.rules.weaponStat,
    cfgWEAPONSVialWeaponStat=RG.WEAPONS.vial.rules.weaponStat,
    cfgWEAPONSScytheWeaponStat=RG.WEAPONS.scythe.rules.weaponStat,
    cfgWEAPONSBoomerWeaponStat=RG.WEAPONS.boomer.rules.weaponStat;
})(window.RG);
