// 自动生成：node scripts/build-release-assets.js；禁止手改。
(function (root) {
  const manifest = {
  "schema": 1,
  "version": "v12.0.28",
  "scriptVersion": "12028",
  "cache": "rogue-v12-0-28",
  "revision": "bd4cd4d84e5ba52979056886095608ce6dce5ad0949f062ae82fa693ae6b276f",
  "totalBytes": 17231858,
  "files": [
    {
      "path": "assets/apple-touch-icon.png",
      "url": "./assets/apple-touch-icon.png",
      "kind": "interface",
      "source": "index.html",
      "bytes": 25810,
      "sha256": "624f9f86aa5ad1fa7ad39a916801915fd3c410b6cd1f31b5c0326adc16d27a0e"
    },
    {
      "path": "assets/art/arena-floor-pixel-v1.png",
      "url": "./assets/art/arena-floor-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.realmfloor",
      "bytes": 1068194,
      "sha256": "667679ac880ae514f3937275b629560d8fb4033621ed19e52645665388dd35ea"
    },
    {
      "path": "assets/art/arena-floor-pixel-v3.png",
      "url": "./assets/art/arena-floor-pixel-v3.png",
      "kind": "art",
      "source": "RG.ART.floor",
      "bytes": 265855,
      "sha256": "db343ae7d41e5334bd06f21e963aec9a02b5c4b6c319ed494304341f910532b5"
    },
    {
      "path": "assets/art/boss-anim-pixel-v1.png",
      "url": "./assets/art/boss-anim-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.bossanim",
      "bytes": 187267,
      "sha256": "0fe2ec3303a18e368f1eca75295fe2062a86630fd52490262a2fc69d44233479"
    },
    {
      "path": "assets/art/boss-atlas-pixel-v1.png",
      "url": "./assets/art/boss-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.boss",
      "bytes": 1782164,
      "sha256": "70ff81fcd8d26cd303efc02e824c2d256f8dc7957cedd49b1fef92ef8fa57b47"
    },
    {
      "path": "assets/art/card-atlas-pixel-v1.png",
      "url": "./assets/art/card-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.card",
      "bytes": 1200496,
      "sha256": "8447894c177cc44cae803a44289d3090f4f59e2f395362b22157ebe65f4ebc92"
    },
    {
      "path": "assets/art/character-atlas-pixel-v2.png",
      "url": "./assets/art/character-atlas-pixel-v2.png",
      "kind": "art",
      "source": "RG.ART.atlas",
      "bytes": 1592416,
      "sha256": "e7c504e1f1681e16e5646884c31df22f251438dbdf9145ecd8e5e7557a9fd2f3"
    },
    {
      "path": "assets/art/element-marks-atlas-pixel-v1.png",
      "url": "./assets/art/element-marks-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.element_marks",
      "bytes": 5567,
      "sha256": "dc466cb5177c8f51e97f3384d383f12cc4532dcbd1157a73286ef1cd9c28d18f"
    },
    {
      "path": "assets/art/environment-detail-atlas-pixel-v1.png",
      "url": "./assets/art/environment-detail-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.env_detail",
      "bytes": 137868,
      "sha256": "bdb6fc527555d20a18f2e7b7bbf0d44ba7837a2aeb9d54b183e2e3c5b64102df"
    },
    {
      "path": "assets/art/environment-valley-atlas-pixel-v1.png",
      "url": "./assets/art/environment-valley-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.env_valley",
      "bytes": 108528,
      "sha256": "deaea25a925d434583bbe36ce3a757f5fa787f377eebcfbeb1c69099d72e3e23"
    },
    {
      "path": "assets/art/environment-workshop-atlas-pixel-v1.png",
      "url": "./assets/art/environment-workshop-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.env_workshop",
      "bytes": 113760,
      "sha256": "341f53a3512e057a5d58b227161ecbdce8a5008343b50e73594641f45fb1de80"
    },
    {
      "path": "assets/art/ground-earth-moss-pixel-v1.png",
      "url": "./assets/art/ground-earth-moss-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.ground_earth",
      "bytes": 257176,
      "sha256": "335aac67071c85382a098abafb821877e326f8d7994df1500b4ffa4ea4997298"
    },
    {
      "path": "assets/art/ground-valley-stone-pixel-v1.png",
      "url": "./assets/art/ground-valley-stone-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.ground_valley",
      "bytes": 251723,
      "sha256": "670f5e5d70fb68be599f9551e2087f8ae2dcc2fab72270a4b51f3c329a9d9813"
    },
    {
      "path": "assets/art/ground-workshop-stone-pixel-v1.png",
      "url": "./assets/art/ground-workshop-stone-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.ground_workshop",
      "bytes": 249015,
      "sha256": "ff91feecf50a332195096e1b75dbdd06490d08a9e05aaa99923ea804b3f66dbe"
    },
    {
      "path": "assets/art/hud-bar-fill.png",
      "url": "./assets/art/hud-bar-fill.png",
      "kind": "art",
      "source": "RG.ART.hudfill",
      "bytes": 220,
      "sha256": "9eb17283e5e339860fbf9cd68b373833f7d8844449bfa8b34c3632c65e1f2589"
    },
    {
      "path": "assets/art/hud-bar-frame.png",
      "url": "./assets/art/hud-bar-frame.png",
      "kind": "art",
      "source": "RG.ART.hudframe",
      "bytes": 310,
      "sha256": "260e627431e36bc7e6bdd3ce1c206c31763e7786e3d5bb159d20fc176112f2d9"
    },
    {
      "path": "assets/art/hud-dash-btn.png",
      "url": "./assets/art/hud-dash-btn.png",
      "kind": "art",
      "source": "RG.ART.dashbtn",
      "bytes": 1273,
      "sha256": "279092cbb7f188f7ae2ee5633a26901585f743de6f6e7c478ea55b6c71bfea65"
    },
    {
      "path": "assets/art/meadow-banks-atlas-pixel-v1.png",
      "url": "./assets/art/meadow-banks-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.meadow_banks",
      "bytes": 8418,
      "sha256": "563128b3df297dbaf3ccdcd28d722a5afb94bbd85a223182195b60072836e989"
    },
    {
      "path": "assets/art/meadow-ground-pixel-v1.png",
      "url": "./assets/art/meadow-ground-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.meadow_grass",
      "bytes": 6407,
      "sha256": "c2aacebfe0257673124f169088907e2064a984c3f63fe46d904e7344028fecdb"
    },
    {
      "path": "assets/art/meadow-trees-atlas-pixel-v1.png",
      "url": "./assets/art/meadow-trees-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.meadow_trees",
      "bytes": 10883,
      "sha256": "f3f4a376e88a0770336b7424d10239b7666ea9b931857524e3b7843f371671c7"
    },
    {
      "path": "assets/art/meadow-wall-horizontal-pixel-v1.png",
      "url": "./assets/art/meadow-wall-horizontal-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.meadow_wall_h",
      "bytes": 41936,
      "sha256": "43beb6e799e76f91c3ff141a77e48428289310e3fe56167c6c443f85a977b501"
    },
    {
      "path": "assets/art/meadow-wall-vertical-pixel-v1.png",
      "url": "./assets/art/meadow-wall-vertical-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.meadow_wall_v",
      "bytes": 18809,
      "sha256": "c771d5277953ad571f580748fca15b8ab73fc3bdcf566012172a2c3f8c8e4a89"
    },
    {
      "path": "assets/art/menu-arena-pixel-v1.png",
      "url": "./assets/art/menu-arena-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.menu",
      "bytes": 1607937,
      "sha256": "2fcf92783af72a21880ea815ca156c133ba5c0c677dcf05a1efaf4744e577675"
    },
    {
      "path": "assets/art/menu-book-v1.png",
      "url": "./assets/art/menu-book-v1.png",
      "kind": "art",
      "source": "RG.ART.menubook",
      "bytes": 25661,
      "sha256": "c2ba55fa9afdc18c352d8bd17acecd3c6b1d5c1f36871843d8bd3699b4cbcc00"
    },
    {
      "path": "assets/art/menu-primary-frame-v1.png",
      "url": "./assets/art/menu-primary-frame-v1.png",
      "kind": "art",
      "source": "RG.ART.menuframe",
      "bytes": 50907,
      "sha256": "55b8610402268f2d9e43d7090c4407e7faec455b8455be4a2ea080ba0cf935e1"
    },
    {
      "path": "assets/art/menu-settings-v1.png",
      "url": "./assets/art/menu-settings-v1.png",
      "kind": "art",
      "source": "RG.ART.menusettings",
      "bytes": 20837,
      "sha256": "adf4b8f96e73706170e377bdbfa0c647b2e9ee3794835930c6d44f7992f00909"
    },
    {
      "path": "assets/art/menu-valley-pixel-v2.png",
      "url": "./assets/art/menu-valley-pixel-v2.png",
      "kind": "art",
      "source": "RG.ART.menuvalley",
      "bytes": 32887,
      "sha256": "9372115107eddf0522887895ceb54db3d5fb3160f32f07e1315a4644ca010c15"
    },
    {
      "path": "assets/art/mob-anim-pixel-v1.png",
      "url": "./assets/art/mob-anim-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.mobanim",
      "bytes": 190415,
      "sha256": "632058ef46c0cef02112dfb927e3c07ac02d6cd4418ea07427ad77377cd2bd9f"
    },
    {
      "path": "assets/art/mob-anim-pixel-v2.png",
      "url": "./assets/art/mob-anim-pixel-v2.png",
      "kind": "art",
      "source": "RG.ART.mobanim2",
      "bytes": 251394,
      "sha256": "7e30ac9bdef18827cf3057aab768e44b51912e8bdf16850883fcefebc34f8a50"
    },
    {
      "path": "assets/art/mob-crucible-move-v2.png",
      "url": "./assets/art/mob-crucible-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_crucible_anim",
      "bytes": 16228,
      "sha256": "876f741d2437b4a5776f7944add3a0aff44a8071328cbc377e41165f381dd190"
    },
    {
      "path": "assets/art/mob-crystal-anim-v3.png",
      "url": "./assets/art/mob-crystal-anim-v3.png",
      "kind": "art",
      "source": "RG.ART.mob_crystal_anim",
      "bytes": 19280,
      "sha256": "c2a65e30d11a10f0a70b412df021bd863e6f2318efbb4d19de599ea23448f49f"
    },
    {
      "path": "assets/art/mob-crystal-pixel-v1-cut.png",
      "url": "./assets/art/mob-crystal-pixel-v1-cut.png",
      "kind": "art",
      "source": "RG.ART.mob_crystal",
      "bytes": 11618,
      "sha256": "9c0afc3d5f1e12f2f7b4c1ccaf40f4f2cb3797816de4c6c71f470000d138a702"
    },
    {
      "path": "assets/art/mob-howler-anim-v2.png",
      "url": "./assets/art/mob-howler-anim-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_howler_anim",
      "bytes": 29356,
      "sha256": "5fc8ea8459cd975ae20b5acecb67b601122948a6c0bb9100d6596ca6e064e843"
    },
    {
      "path": "assets/art/mob-howler-pixel-v1-cut.png",
      "url": "./assets/art/mob-howler-pixel-v1-cut.png",
      "kind": "art",
      "source": "RG.ART.mob_howler",
      "bytes": 5135,
      "sha256": "850fc5234ea4d1c00d76049ebcf80a4c651e35373968ff470382a09ff8b709d2"
    },
    {
      "path": "assets/art/mob-mortar-move-v2.png",
      "url": "./assets/art/mob-mortar-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_mortar_anim",
      "bytes": 15713,
      "sha256": "8963757e62330feb106b8ed2af8d1c6aa1aea37132c43644052a693927b3d0f8"
    },
    {
      "path": "assets/art/mob-phantasm-move-v2.png",
      "url": "./assets/art/mob-phantasm-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_phantasm_anim",
      "bytes": 7458,
      "sha256": "4091bbbd30c2bbaff227bc15e7da487d63f0d3f513521848afafa934dcfe5854"
    },
    {
      "path": "assets/art/mob-scavenger-move-v2.png",
      "url": "./assets/art/mob-scavenger-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_scavenger_anim",
      "bytes": 11002,
      "sha256": "d00ebe251f10d33477d7a2480eab9b6971ff30e550b3edbf2e74320ba5c891c4"
    },
    {
      "path": "assets/art/mob-sporepod-move-v2.png",
      "url": "./assets/art/mob-sporepod-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_sporepod_anim",
      "bytes": 15311,
      "sha256": "3769ca5ed71bcfe3d5a27ac4f24b28c66f717f62100e999f0c535491f320f50f"
    },
    {
      "path": "assets/art/mob-stalker-anim-v2.png",
      "url": "./assets/art/mob-stalker-anim-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_stalker_anim",
      "bytes": 18198,
      "sha256": "329b42b4b87a6f1804c42856d81608499505cd9f18daac7a9b506dab849d4caf"
    },
    {
      "path": "assets/art/mob-stalker-pixel-v1-cut.png",
      "url": "./assets/art/mob-stalker-pixel-v1-cut.png",
      "kind": "art",
      "source": "RG.ART.mob_stalker",
      "bytes": 6890,
      "sha256": "847f40a6f600818a6c43524670e5dc3cb87272a31ae64b6ac58b7821fb6572a3"
    },
    {
      "path": "assets/art/mob-tether-move-v2.png",
      "url": "./assets/art/mob-tether-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_tether_anim",
      "bytes": 9093,
      "sha256": "5d2846d79d3f249356c92e9cb1fbbe9796bd89a3eba696c987db85dfe11ead8c"
    },
    {
      "path": "assets/art/mob-warder-move-v2.png",
      "url": "./assets/art/mob-warder-move-v2.png",
      "kind": "art",
      "source": "RG.ART.mob_warder_anim",
      "bytes": 13324,
      "sha256": "12496dcfc02d272458f6698f427497eb141d4270933232e7617670e1fe153b8c"
    },
    {
      "path": "assets/art/player-atlas-pixel-v1.png",
      "url": "./assets/art/player-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.player",
      "bytes": 47067,
      "sha256": "d8bef607566dcef5cf2713c279637f71bfd5723751b6bd804da5914062defa95"
    },
    {
      "path": "assets/art/ruin-barrier-horizontal-pixel-v1.png",
      "url": "./assets/art/ruin-barrier-horizontal-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.wall_temp_h",
      "bytes": 20977,
      "sha256": "b8b3ed5105d2cce581fdafa8ce83fcc598f7a099753744031eec9dc795cc3feb"
    },
    {
      "path": "assets/art/ruin-barrier-vertical-pixel-v1.png",
      "url": "./assets/art/ruin-barrier-vertical-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.wall_temp_v",
      "bytes": 27726,
      "sha256": "33f0b5876b4b8c63eeb3b404a9cbf0d52772fb1ba2ea425ba8589d2e0dbea306"
    },
    {
      "path": "assets/art/ruin-wall-horizontal-pixel-v1.png",
      "url": "./assets/art/ruin-wall-horizontal-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.wall_h",
      "bytes": 18980,
      "sha256": "4a92f3d267d3e250d5b754072f1c706b49971fe784d8004e93b4d3bc22517fb9"
    },
    {
      "path": "assets/art/ruin-wall-vertical-pixel-v1.png",
      "url": "./assets/art/ruin-wall-vertical-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.wall_v",
      "bytes": 31113,
      "sha256": "d60d030c5abcc423b9b7a3388766a355af27948f05692fbf3138e43227388ec2"
    },
    {
      "path": "assets/art/stele-base-pixel-v1.png",
      "url": "./assets/art/stele-base-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.stele_base",
      "bytes": 8135,
      "sha256": "cf3fe2ba9fcb3081d782e4ccc7d8acf8e5567385f14bdd1fabef60cf81bcd7be"
    },
    {
      "path": "assets/art/stele-idle-atlas-pixel-v1.png",
      "url": "./assets/art/stele-idle-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.stele_idle",
      "bytes": 18495,
      "sha256": "769a2be118af6d7a00b7dedb6d68844b64ae1e22b924326ad7152f008034eca8"
    },
    {
      "path": "assets/art/ui-aux-atlas-pixel-v1.png",
      "url": "./assets/art/ui-aux-atlas-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.uiaux",
      "bytes": 55990,
      "sha256": "47d422bd6e16cd131c29ba02dd4859ffbda26992102bd17607218e2e36490245"
    },
    {
      "path": "assets/art/ui-coin-pixel-v1.png",
      "url": "./assets/art/ui-coin-pixel-v1.png",
      "kind": "art",
      "source": "RG.ART.uicoin",
      "bytes": 7771,
      "sha256": "c41e755b9a4aef736deae1a3cc14eb58ef5686154459df593340b43255d7fdc1"
    },
    {
      "path": "assets/audio/amb-valley.wav",
      "url": "./assets/audio/amb-valley.wav?v=12019",
      "kind": "ambient",
      "source": "FILE_AMBIENT",
      "bytes": 705644,
      "sha256": "75bf1fd4f4248c2b8387ecd226c3094afe7d7c763c273e381eb05ef34c0c863c"
    },
    {
      "path": "assets/audio/amb-vault.wav",
      "url": "./assets/audio/amb-vault.wav?v=12019",
      "kind": "ambient",
      "source": "FILE_AMBIENT",
      "bytes": 705644,
      "sha256": "597179938b7e5a5974e988733fa026c94e099143ce46fc7d6af9306437fa2cef"
    },
    {
      "path": "assets/audio/amb-workshop.wav",
      "url": "./assets/audio/amb-workshop.wav?v=12019",
      "kind": "ambient",
      "source": "FILE_AMBIENT",
      "bytes": 705644,
      "sha256": "dd4d31e73dc404c338a869ef6ae942c3139622075fafd985dc2fa1182e72d36e"
    },
    {
      "path": "assets/audio/bgm-boss.ogg",
      "url": "./assets/audio/bgm-boss.ogg?v=11937",
      "kind": "music",
      "source": "FILE_BGM/兼容配乐",
      "bytes": 613024,
      "sha256": "653b60bfd537b9cbe137d7d591c00e62ad311294a1e28d694b37ef540933c7af"
    },
    {
      "path": "assets/audio/bgm-menu.ogg",
      "url": "./assets/audio/bgm-menu.ogg?v=11937",
      "kind": "music",
      "source": "FILE_BGM/兼容配乐",
      "bytes": 357522,
      "sha256": "64e426e6736591b44f5bf2bbb3067968afe1217124e0844cbdb6ae7cb5b32b00"
    },
    {
      "path": "assets/audio/bgm-play.ogg",
      "url": "./assets/audio/bgm-play.ogg?v=11937",
      "kind": "music",
      "source": "FILE_BGM/兼容配乐",
      "bytes": 686172,
      "sha256": "3ddaafb4ea0b9d4c669cb9b38a6a00cdcbbada0b65a1f2ac3dd6eff5984898ac"
    },
    {
      "path": "assets/audio/bgm-realm.ogg",
      "url": "./assets/audio/bgm-realm.ogg?v=11937",
      "kind": "music",
      "source": "FILE_BGM/兼容配乐",
      "bytes": 367999,
      "sha256": "ffa2927725508ac409b26931c57fc78d32bc9683a7687ac12f61d4edc8ce8ab4"
    },
    {
      "path": "assets/audio/bgm.ogg",
      "url": "./assets/audio/bgm.ogg?v=11937",
      "kind": "music",
      "source": "FILE_BGM/兼容配乐",
      "bytes": 357522,
      "sha256": "64e426e6736591b44f5bf2bbb3067968afe1217124e0844cbdb6ae7cb5b32b00"
    },
    {
      "path": "assets/audio/block.ogg",
      "url": "./assets/audio/block.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.block",
      "bytes": 4047,
      "sha256": "dc4227ba6eaba006d0ad9d8ca988b27aeb4a141ed68c72e22e75e5bf276d3749"
    },
    {
      "path": "assets/audio/boom.ogg",
      "url": "./assets/audio/boom.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.boom",
      "bytes": 5297,
      "sha256": "4641200d8c5f3b47f33feeddad48cefa2954546e74a75c552b96fc1ab861e0f0"
    },
    {
      "path": "assets/audio/boss.ogg",
      "url": "./assets/audio/boss.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.boss",
      "bytes": 6476,
      "sha256": "858426e684ff4cfe0e476025bb0ce2aec85834e850f882d04061600079a00ebf"
    },
    {
      "path": "assets/audio/buy.ogg",
      "url": "./assets/audio/buy.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.buy",
      "bytes": 4250,
      "sha256": "d7c93063047389cde1097a0420fd82eb6852bc0a339ae33c7abe5bcaae0838ba"
    },
    {
      "path": "assets/audio/buypower.ogg",
      "url": "./assets/audio/buypower.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.buypower",
      "bytes": 4493,
      "sha256": "26bcc2da0ab55d28fa5e0b5af5a388d5c0a96e44a1402c885512f1289c21001d"
    },
    {
      "path": "assets/audio/choose.ogg",
      "url": "./assets/audio/choose.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.choose",
      "bytes": 3976,
      "sha256": "ef6a0077bfd29804d8ddb2508f6f21635131cd15460da876589f397ef7e09312"
    },
    {
      "path": "assets/audio/combo.ogg",
      "url": "./assets/audio/combo.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.combo",
      "bytes": 5682,
      "sha256": "0015e97dfb4db79f4e3d0cd19e890d726b857636e4faf8f1e36d4a1286c6cb09"
    },
    {
      "path": "assets/audio/combo.wav",
      "url": "./assets/audio/combo.wav?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.combo",
      "bytes": 7100,
      "sha256": "31807e5f5303a363ba5d0c23393b76eb2d6f103e24f4b38b0b2a4ca0f5f25ac1"
    },
    {
      "path": "assets/audio/crit.ogg",
      "url": "./assets/audio/crit.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.crit",
      "bytes": 5124,
      "sha256": "e68d09043eda3488b8dbc04deec44971042214acc4184b8cb8357d5b6618c825"
    },
    {
      "path": "assets/audio/crit.wav",
      "url": "./assets/audio/crit.wav?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.crit",
      "bytes": 9306,
      "sha256": "f678879cafdac962f48eb9adf579b43ab6805b76402e637ac170ec581da56aac"
    },
    {
      "path": "assets/audio/evaporate.ogg",
      "url": "./assets/audio/evaporate.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.evaporate",
      "bytes": 5555,
      "sha256": "8076af6f1a426d462727571f02a163ba39cb645e524e74077cab2d58772d640b"
    },
    {
      "path": "assets/audio/freeze.ogg",
      "url": "./assets/audio/freeze.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.freeze",
      "bytes": 4165,
      "sha256": "4c96c5f1c2d7644e434e736d9ea19fd772fafa69201a60bcd52a9f72371110be"
    },
    {
      "path": "assets/audio/gem.ogg",
      "url": "./assets/audio/gem.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.gem",
      "bytes": 3966,
      "sha256": "fb509382ce2a2a78fd3acdca7bc39d58b093d72f7a1ba4f43ab8069dba4dc3ab"
    },
    {
      "path": "assets/audio/hit.ogg",
      "url": "./assets/audio/hit.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.hit",
      "bytes": 4212,
      "sha256": "3d29ae5179054b838a5aea7d29111ed09a4b6f9b6d66dec4b82e6f973450188d"
    },
    {
      "path": "assets/audio/hurt.ogg",
      "url": "./assets/audio/hurt.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.hurt",
      "bytes": 4939,
      "sha256": "a926ffc15e870fe9c1796e30590296f819cd5d4a7f03399c02bb48aed65fec7f"
    },
    {
      "path": "assets/audio/key.ogg",
      "url": "./assets/audio/key.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.key",
      "bytes": 4770,
      "sha256": "7fa2adf311881634ea35e4c6543e392a15e1b1ff66a127567580d11a9b532c7a"
    },
    {
      "path": "assets/audio/kill-1.ogg",
      "url": "./assets/audio/kill-1.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.kill-1",
      "bytes": 4657,
      "sha256": "05ddbab2d5fd0d222b4a738c92c714b4fbbcd95fbbafb9bc849b917d4123ee2f"
    },
    {
      "path": "assets/audio/kill-2.ogg",
      "url": "./assets/audio/kill-2.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.kill-2",
      "bytes": 4783,
      "sha256": "6385ab4b63be812830cea1b1f84f201f60b72c7b6bee18fbcedc1ce54f1f7bfc"
    },
    {
      "path": "assets/audio/kill.ogg",
      "url": "./assets/audio/kill.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.kill",
      "bytes": 4696,
      "sha256": "19eff37cb3c03792fea96435021b99b8ff54103d0c157c49b85e368862b8d8d8"
    },
    {
      "path": "assets/audio/levelup.ogg",
      "url": "./assets/audio/levelup.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.levelup",
      "bytes": 5002,
      "sha256": "fef9aacf8a1c758f3b73a4bf203c646247bf73505f6e868bbf4ff076cfbd4c4b"
    },
    {
      "path": "assets/audio/nova.ogg",
      "url": "./assets/audio/nova.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.nova",
      "bytes": 4921,
      "sha256": "b1849bfc610a96926a93650a9505bb7097ef7c364218a27031088d82203b6e2c"
    },
    {
      "path": "assets/audio/oath.ogg",
      "url": "./assets/audio/oath.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.oath",
      "bytes": 4384,
      "sha256": "13ae8531caf56395af5346f3051a6733fd79902be91d60de578d2d320869ceb1"
    },
    {
      "path": "assets/audio/over.ogg",
      "url": "./assets/audio/over.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.over",
      "bytes": 5029,
      "sha256": "4b598fbe10cc666338f4aa1d3cd71303959acca21d2c273ade66461fd24daf31"
    },
    {
      "path": "assets/audio/overload.ogg",
      "url": "./assets/audio/overload.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.overload",
      "bytes": 5198,
      "sha256": "d0c93702aaf3c2c2d00bb32820eb1982106ad12450c7df7ce218cabf74cc8127"
    },
    {
      "path": "assets/audio/portal.ogg",
      "url": "./assets/audio/portal.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.portal",
      "bytes": 4480,
      "sha256": "4eab2c58f375cad1c63e3e351b897e53510dbd048c6a24052c8bed5721180847"
    },
    {
      "path": "assets/audio/realm.ogg",
      "url": "./assets/audio/realm.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.realm",
      "bytes": 4550,
      "sha256": "7b0efd5ee96ee9a44a89d869c0e26fee2736d0f5fd1837e4d27c1f67be4f5cab"
    },
    {
      "path": "assets/audio/shoot.ogg",
      "url": "./assets/audio/shoot.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.shoot",
      "bytes": 3922,
      "sha256": "5d08b328dea9f6a70897ae5e6641869eae60d7444d9550e85a80d82ad794714d"
    },
    {
      "path": "assets/audio/statue.ogg",
      "url": "./assets/audio/statue.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.statue",
      "bytes": 4434,
      "sha256": "b77d56788150f0a1aefaeb8fb6770a469dacebacd181253d9a6e00c30093c689"
    },
    {
      "path": "assets/audio/superconduct.ogg",
      "url": "./assets/audio/superconduct.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.superconduct",
      "bytes": 4609,
      "sha256": "956c577c1e8af01981b2f0726c88cc5ec969eb13e8342ede30f2e0197c778517"
    },
    {
      "path": "assets/audio/timestop.ogg",
      "url": "./assets/audio/timestop.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.timestop",
      "bytes": 4852,
      "sha256": "53f431d501e1c683bd38f04da7490e86251555c2121971ad0d69ffd09751fb75"
    },
    {
      "path": "assets/audio/trap.ogg",
      "url": "./assets/audio/trap.ogg?v=11920",
      "kind": "sfx",
      "source": "SFX_NAMES.trap",
      "bytes": 4130,
      "sha256": "0b9e907d29d272f04213ac44ed9e8846c4743c5a0f556e0c1c8217e0bc7caa25"
    },
    {
      "path": "assets/CREDITS.md",
      "url": "./assets/CREDITS.md",
      "kind": "license",
      "source": "素材授权说明",
      "bytes": 1748,
      "sha256": "7b04d2ad8d8f0c6ba04952233b6e2f13bf40ae95e66aa8c8fa19699202e088f1"
    },
    {
      "path": "assets/fonts/FUSION-PIXEL-OFL-1.1.txt",
      "url": "./assets/fonts/FUSION-PIXEL-OFL-1.1.txt",
      "kind": "license",
      "source": "WOFF2授权",
      "bytes": 4418,
      "sha256": "bc518cf64b8032c07690f33cc270c35c179255a6ac8efa7c165ebae7e8f76a63"
    },
    {
      "path": "assets/fonts/pixel-cn.woff2",
      "url": "./assets/fonts/pixel-cn.woff2",
      "kind": "interface",
      "source": "index.html",
      "bytes": 917416,
      "sha256": "015b2d24c9416b503249a7cf7e1d8421568c33c1fc2daff8e50ad3726b214987"
    },
    {
      "path": "assets/icon-192.png",
      "url": "./assets/icon-192.png",
      "kind": "icon",
      "source": "manifest.json",
      "bytes": 28890,
      "sha256": "905de3689fb5c0ffb3e074ce3edac69a42c196a7fee50676381114c417343644"
    },
    {
      "path": "assets/icon-512.png",
      "url": "./assets/icon-512.png",
      "kind": "icon",
      "source": "manifest.json",
      "bytes": 173306,
      "sha256": "9cd602295e81f222bad2103eecb6e48adf03b64d87d28aeff09c4acd009b4ae0"
    },
    {
      "path": "assets/icon-maskable-512.png",
      "url": "./assets/icon-maskable-512.png",
      "kind": "icon",
      "source": "manifest.json",
      "bytes": 11330,
      "sha256": "96502f926d44e164e31e2639cedec43c674b67a2024801e8442447ca25d2a108"
    },
    {
      "path": "assets/icon.svg",
      "url": "./assets/icon.svg",
      "kind": "interface",
      "source": "index.html",
      "bytes": 392,
      "sha256": "4e1f2f3662c0d65c6f3803fcab5cf65dd95a2eb2fdf65126162641dc69f3240d"
    },
    {
      "path": "assets/icons/allin.png",
      "url": "./assets/icons/allin.png",
      "kind": "card",
      "source": "RG.CARD_ICON.allin",
      "bytes": 10596,
      "sha256": "1cbf0315d5f7768bdaf1db87c068552cae6a65a556e1784fe6df795746be4820"
    },
    {
      "path": "assets/icons/ash.png",
      "url": "./assets/icons/ash.png",
      "kind": "card",
      "source": "RG.CARD_ICON.ash",
      "bytes": 15958,
      "sha256": "17a62204d63389b243f8fd33d438932a966a423dff759ebf78240bc4186420dd"
    },
    {
      "path": "assets/icons/barrier.png",
      "url": "./assets/icons/barrier.png",
      "kind": "card",
      "source": "RG.CARD_ICON.barrier",
      "bytes": 12731,
      "sha256": "6ef839e602f16c263aec4114c7884a61f88e01376f2c925d74baa272a85fe2d6"
    },
    {
      "path": "assets/icons/berserk.png",
      "url": "./assets/icons/berserk.png",
      "kind": "card",
      "source": "RG.CARD_ICON.berserk",
      "bytes": 14910,
      "sha256": "0afff6690957a49dbea3c6833dac7c4dfd3666418cdffcb61dca099e5c96339c"
    },
    {
      "path": "assets/icons/bigshot.png",
      "url": "./assets/icons/bigshot.png",
      "kind": "card",
      "source": "RG.CARD_ICON.bigshot",
      "bytes": 16460,
      "sha256": "e340751ebcd63e5b87499160c7c6fbba1efbad84cd78f4081cf46d6e2a71f399"
    },
    {
      "path": "assets/icons/boots.png",
      "url": "./assets/icons/boots.png",
      "kind": "card",
      "source": "RG.CARD_ICON.boots",
      "bytes": 14476,
      "sha256": "7fde7ba43de5ebf46ddc7906ff9ee73638700000926f7fa773acbcfa6789dacf"
    },
    {
      "path": "assets/icons/combostorm.png",
      "url": "./assets/icons/combostorm.png",
      "kind": "card",
      "source": "RG.CARD_ICON.combostorm",
      "bytes": 17266,
      "sha256": "3cd62b28e41684782e432f6ef201fa416cadae7deecad4a5c9c4a35f86c2c4b8"
    },
    {
      "path": "assets/icons/crit.png",
      "url": "./assets/icons/crit.png",
      "kind": "card",
      "source": "RG.CARD_ICON.crit",
      "bytes": 15077,
      "sha256": "8a959204bf138eb83e07bad3a3c6443c0f114b275977977013b0f2265120ac4c"
    },
    {
      "path": "assets/icons/critd.png",
      "url": "./assets/icons/critd.png",
      "kind": "card",
      "source": "RG.CARD_ICON.critd",
      "bytes": 15635,
      "sha256": "21fe0468b319b16e0d58cfbca84014df44ca09640fd972b74b02e16c439519e3"
    },
    {
      "path": "assets/icons/crystal.png",
      "url": "./assets/icons/crystal.png",
      "kind": "card",
      "source": "RG.CARD_ICON.crystal",
      "bytes": 16569,
      "sha256": "94642294bfc1244fb3c9a2f4ded666ac87ca4d9659e8b9705282a9738d7f9084"
    },
    {
      "path": "assets/icons/debt.png",
      "url": "./assets/icons/debt.png",
      "kind": "card",
      "source": "RG.CARD_ICON.debt",
      "bytes": 13598,
      "sha256": "36c2dab3bad8f2a043f964be9af2c19d13577019f6cb2c2e207798f06e783cc4"
    },
    {
      "path": "assets/icons/echo.png",
      "url": "./assets/icons/echo.png",
      "kind": "card",
      "source": "RG.CARD_ICON.echo",
      "bytes": 14790,
      "sha256": "cc4c6923e32877b71f61a99b7d50bff5f517501db0f412f5b34c942d5098be0b"
    },
    {
      "path": "assets/icons/ember.png",
      "url": "./assets/icons/ember.png",
      "kind": "card",
      "source": "RG.CARD_ICON.ember",
      "bytes": 12715,
      "sha256": "1c52c29084fb73f30996b5a4459d39a63018c50a9373b07af4a586d130c9c73a"
    },
    {
      "path": "assets/icons/evade.png",
      "url": "./assets/icons/evade.png",
      "kind": "card",
      "source": "RG.CARD_ICON.evade",
      "bytes": 13556,
      "sha256": "c33ef302bf6dd51879043011f07626c1f52437caf97d0571f8da1de11920a66d"
    },
    {
      "path": "assets/icons/explosive.png",
      "url": "./assets/icons/explosive.png",
      "kind": "card",
      "source": "RG.CARD_ICON.explosive",
      "bytes": 12945,
      "sha256": "42886218f898f86857bc1c154e6c39b1d438188f9954534244f9e107fc1cda42"
    },
    {
      "path": "assets/icons/frenzy.png",
      "url": "./assets/icons/frenzy.png",
      "kind": "card",
      "source": "RG.CARD_ICON.frenzy",
      "bytes": 14291,
      "sha256": "8888a873fd86a7b239c35040658bbfad4fceded7643d46254e8f471ef4acbf2f"
    },
    {
      "path": "assets/icons/frost.png",
      "url": "./assets/icons/frost.png",
      "kind": "card",
      "source": "RG.CARD_ICON.frost",
      "bytes": 17816,
      "sha256": "96384ebbd4b05eae01814cac9f9d98b3193d243202177e730738f487c1efc2f0"
    },
    {
      "path": "assets/icons/harmony.png",
      "url": "./assets/icons/harmony.png",
      "kind": "card",
      "source": "RG.CARD_ICON.harmony",
      "bytes": 14541,
      "sha256": "3c23d4efc1b13cd57340b83a0f9b7f5a3be716f4c25eb8575fb819f244f21adb"
    },
    {
      "path": "assets/icons/heal.png",
      "url": "./assets/icons/heal.png",
      "kind": "card",
      "source": "RG.CARD_ICON.heal",
      "bytes": 17587,
      "sha256": "847426a0db402cbdd62bd166d7cc932df5c357790539489992b611470c6f1a66"
    },
    {
      "path": "assets/icons/healbig.png",
      "url": "./assets/icons/healbig.png",
      "kind": "card",
      "source": "RG.CARD_ICON.healbig",
      "bytes": 17582,
      "sha256": "9c0b907f13e27811f53e1f57eb551d1f9b884fb0977dd4b8707900b46453bd82"
    },
    {
      "path": "assets/icons/heart.png",
      "url": "./assets/icons/heart.png",
      "kind": "card",
      "source": "RG.CARD_ICON.heart",
      "bytes": 16337,
      "sha256": "bbdfd0e156ab24f4314b2a67add20f45838ea1cffaebf8a254f3f19209c7bd40"
    },
    {
      "path": "assets/icons/magnet.png",
      "url": "./assets/icons/magnet.png",
      "kind": "card",
      "source": "RG.CARD_ICON.magnet",
      "bytes": 13374,
      "sha256": "6b69858233951e736fe2c10d0f57fada2a21a617fd521e467cddef5e3f38c5ef"
    },
    {
      "path": "assets/icons/pact.png",
      "url": "./assets/icons/pact.png",
      "kind": "card",
      "source": "RG.CARD_ICON.pact",
      "bytes": 13781,
      "sha256": "20473a179472996a207963aa7b69abb8be02d2fe9e083a2a1ac788d2f0d12411"
    },
    {
      "path": "assets/icons/phantom.png",
      "url": "./assets/icons/phantom.png",
      "kind": "card",
      "source": "RG.CARD_ICON.phantom",
      "bytes": 15289,
      "sha256": "ba3077e81c53135a383f583ae495413e0b4b10f2badf097240fdd7f561dcf33c"
    },
    {
      "path": "assets/icons/power.png",
      "url": "./assets/icons/power.png",
      "kind": "card",
      "source": "RG.CARD_ICON.power",
      "bytes": 17103,
      "sha256": "6b29d0911248c0012b6f75218773f38727b06ef06fdc12c250c3e54ab861f0d4"
    },
    {
      "path": "assets/icons/regen.png",
      "url": "./assets/icons/regen.png",
      "kind": "card",
      "source": "RG.CARD_ICON.regen",
      "bytes": 15456,
      "sha256": "1ef778aff3e95b3ee9383c59f069c8198e1debbd2e259f51f350ea95d4c60a70"
    },
    {
      "path": "assets/icons/ricochet.png",
      "url": "./assets/icons/ricochet.png",
      "kind": "card",
      "source": "RG.CARD_ICON.ricochet",
      "bytes": 14163,
      "sha256": "1f30585b3a8328faab59db7f92278ed48e64cdf54e6ea859e25d5050e4c1e87c"
    },
    {
      "path": "assets/icons/seed.png",
      "url": "./assets/icons/seed.png",
      "kind": "card",
      "source": "RG.CARD_ICON.seed",
      "bytes": 13879,
      "sha256": "37bd05147387b11653a9af18dcba6ed8b6660c7d62d553ca104254e801a5b70a"
    },
    {
      "path": "assets/icons/shell.png",
      "url": "./assets/icons/shell.png",
      "kind": "card",
      "source": "RG.CARD_ICON.shell",
      "bytes": 16234,
      "sha256": "f04ab93d5b3103b1c4052e5dd28dfbfee8d4f36c084bba3b5160a09069c13e7a"
    },
    {
      "path": "assets/icons/shieldcore.png",
      "url": "./assets/icons/shieldcore.png",
      "kind": "card",
      "source": "RG.CARD_ICON.shieldcore",
      "bytes": 15303,
      "sha256": "5ba99df09746ef035f04451dcffbcf31985b132c6f9bc39fa477213e8da9c458"
    },
    {
      "path": "assets/icons/split.png",
      "url": "./assets/icons/split.png",
      "kind": "card",
      "source": "RG.CARD_ICON.split",
      "bytes": 13460,
      "sha256": "8467291a8af5e8ca82bab6ac4bf9f16c13ff9a986d7eeda793e4a3892cd72e29"
    },
    {
      "path": "assets/icons/stance.png",
      "url": "./assets/icons/stance.png",
      "kind": "card",
      "source": "RG.CARD_ICON.stance",
      "bytes": 14802,
      "sha256": "8ea5cde36cd3b519129cf7b452456ddcc50c253763f2542934b25959fd4d133c"
    },
    {
      "path": "assets/launcher-mage-v1-192.png",
      "url": "./assets/launcher-mage-v1-192.png",
      "kind": "art",
      "source": "RG.ART.launcher",
      "bytes": 76683,
      "sha256": "a84b0eed33daf61ee41f48b5b2c5e861741ab863152f5b7648b16fed6971bdb3"
    },
    {
      "path": "index.html",
      "url": "./index.html",
      "kind": "page",
      "source": "网页入口",
      "bytes": 5162,
      "sha256": "3ec74d2acebdc8f2b2368e85b2d39354fcab78789cde220610f9ef136a6ab696"
    },
    {
      "path": "js/audio.js",
      "url": "./js/audio.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 38241,
      "sha256": "272f18efc79b98342325ad3c6ab3149b947914df3c7b1c6e8ad3473362b95152"
    },
    {
      "path": "js/data_actives.js",
      "url": "./js/data_actives.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 5591,
      "sha256": "73c087c1ed8311bd91bc45bfef9237099e67b4a9e45b3c0250f1fa2b9a58cf5d"
    },
    {
      "path": "js/data_balance.js",
      "url": "./js/data_balance.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 24031,
      "sha256": "2ae657ff884005e699e639ed9014223d8343d11c35c78a2bc46ec71f5896bab6"
    },
    {
      "path": "js/data_enemies.js",
      "url": "./js/data_enemies.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 23895,
      "sha256": "7663c4eca3b7f2c82df7eaf3aee6892f76ce1bd3eb723596b1f2faccb4c59e3f"
    },
    {
      "path": "js/data_passives.js",
      "url": "./js/data_passives.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 78846,
      "sha256": "aab9321f66842efbe968de0fa56e4dc87bbd6630f2ac875ad2cd4182b455429c"
    },
    {
      "path": "js/data_weapons.js",
      "url": "./js/data_weapons.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 29167,
      "sha256": "a735f89f4c29821a3975570151e3bc4839796eb8c9c74d6af02756769c39dc4e"
    },
    {
      "path": "js/draw_menus.js",
      "url": "./js/draw_menus.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 74590,
      "sha256": "f7a276b5f5a495950fbd85801e3a1013d091028269c3c13e81ce7ed9cf616e0b"
    },
    {
      "path": "js/draw.js",
      "url": "./js/draw.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 147820,
      "sha256": "f8bb63d5d28db2ef0bb67a9017dad235c93f4b2579724d8f7e416915b36027c4"
    },
    {
      "path": "js/entities.js",
      "url": "./js/entities.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 196257,
      "sha256": "f592d59feb68a54d54bbc8e1111d880c772812252f87fd68c5427826c9c20200"
    },
    {
      "path": "js/main.js",
      "url": "./js/main.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 47032,
      "sha256": "4bfb8cfe22422a320f568d57a51c74d03c13019a3e1db6710e863ee82146e34f"
    },
    {
      "path": "js/systems_bosses.js",
      "url": "./js/systems_bosses.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 58278,
      "sha256": "f5bfa7afef09e712b534a607605c21802f0f209f6cc4ab91d96d4abc2f4754c8"
    },
    {
      "path": "js/systems_growth.js",
      "url": "./js/systems_growth.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 89030,
      "sha256": "1be605a8a45cea3134bd3c4410337b6461f29be3f6dfa69e5d9da91f475e28d1"
    },
    {
      "path": "js/systems_persistence.js",
      "url": "./js/systems_persistence.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 55587,
      "sha256": "1b46f9a253d04138116aaddae2afda2fee2a112e82c6c1f02a12c3cee932ba0f"
    },
    {
      "path": "js/systems_run.js",
      "url": "./js/systems_run.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 13442,
      "sha256": "8cce082a2dfe64b613336d0282929489de99f861a4ae50c166dbb2336de8b579"
    },
    {
      "path": "js/systems_spawning.js",
      "url": "./js/systems_spawning.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 45366,
      "sha256": "9ff576b9a19abcf29c60f23a03f43ef733cdf64000d2243f66d5d191296c415e"
    },
    {
      "path": "js/util.js",
      "url": "./js/util.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 18099,
      "sha256": "0a07787b2ce5a9f1aec079fdcff0240984ac38d8bc86499184e5fddce0a3ca90"
    },
    {
      "path": "js/walls.js",
      "url": "./js/walls.js?v=12028",
      "kind": "script",
      "source": "index.html",
      "bytes": 7195,
      "sha256": "8a143dc3250ddcd50a449cfc2efe07fdc0072c491ec21aeeaed36d2b8be58d1f"
    },
    {
      "path": "manifest.json",
      "url": "./manifest.json",
      "kind": "manifest",
      "source": "PWA入口",
      "bytes": 597,
      "sha256": "6e10e912321308bd04122dce15a727c6bc2351a34ad389c207c8fb8044497098"
    }
  ]
};
  if (typeof module === "object" && module.exports) module.exports = manifest;
  else root.RG_RELEASE_ASSETS = manifest;
})(typeof self !== "undefined" ? self : globalThis);
