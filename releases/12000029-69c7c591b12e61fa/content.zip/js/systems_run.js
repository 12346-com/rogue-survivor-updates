// ============ 对局生命周期:边界 / 墙体 / 开局 / BOSS 连战 ============
(function(RG){
  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgBALANCERunAddTempWall=RG.BALANCE.run.addTempWall,
    cfgBALANCERunStartRun=RG.BALANCE.run.startRun,
    cfgBALANCERunSpawnRushBoss=RG.BALANCE.run.spawnRushBoss;

  const {rand,clamp,TAU}=RG;
  const ARENA_R=RG.BALANCE.run.common.ARENA_R;
  // 稳定地图身份与图内顺序分开；旧现场仍走原八首领/45分钟时间表。
  RG.MAPS=RG.BALANCE.maps;
  RG.mapConfig=id=>RG.MAPS[id||RG.run?.mapId]||RG.MAPS.legacy;
  RG.mapUnlocked=id=>id==='valley'||id==='workshop'&&!!RG.meta?.maps?.workshop?.unlocked;
  // 工坊正式入口在两只新怪和迁移首领公平性验收后开放。
  RG.WORKSHOP_READY=true;
  RG.selectMap=function(id){
    if(!RG.mapUnlocked(id)||id==='workshop'&&!RG.WORKSHOP_READY)return false;
    RG.selectedMap=id;RG.state='loadout';return true;
  };
  RG.retryRun=function(){
    if(RG.run?.rushMode)RG.startRush(RG.run.rushLv);
    else RG.startRun(RG.lastWeapon,undefined,1,'main',RG.run?.mapId||'legacy');
  };
  RG.continueRun=function(){
    if(RG.state!=='win'||!RG.run?.won)return false;
    RG.run.finalT=RG.run.t+RG.BALANCE.run.continueRun.finalT_offset;RG.run.finalStacks++;RG.state='play';RG.checkpointPending=true;return true;
  };
  // 90度旋转/镜像保持轴对齐碰撞；中心、十字通路和外围环路均留出通行空间。
  RG.workshopLayout=function(variant){
    const turns=((variant??RG.randi(0,3))%4+4)%4,mirror=Math.random()<.5;
    const walls=[];
    for(const [cx,cy]of [[-760,-760],[760,-760],[-760,760],[760,760]]){
      for(const w of [{x:cx-240,y:cy-180,w:320,h:48},{x:cx+192,y:cy-180,w:48,h:290},{x:cx-180,y:cy+150,w:210,h:48}]){
        let x=w.x+w.w/2,y=w.y+w.h/2,width=w.w,height=w.h;
        if(mirror)x=-x;
        for(let i=0;i<turns;i++){[x,y]=[-y,x];[width,height]=[height,width];}
        walls.push({x:x-width/2,y:y-height/2,w:width,h:height});
      }
    }
    return {variant:turns,mirror,walls,boundary:{pts:[{x:-1510,y:-1510},{x:1510,y:-1510},{x:1510,y:1510},{x:-1510,y:1510}]}};
  };
  RG.resetBattleState = function () {
    if (RG.stopSfx) RG.stopSfx();   // 返回菜单、读档和重开都取消尚未响起的连击短提示。
    if (RG.releaseRunInput) RG.releaseRunInput();
    RG.clearBattleCollections(RG.BATTLE_ARRAYS); RG.clearBattleFeedback();
    RG.P = null;
    RG.killTimes=[]; RG.comboKills=[]; RG.multiKillN=0; RG.combo=0; RG.comboT=0; RG.killStreak=0;
    RG.portal = null; RG.keysHeld = 0; RG.timeStop = 0; RG.spinnerSeq=0; RG.tempWalls=0;
    RG.auraT = 0; RG.auraPulse = 0; RG.bossIntro = 0; RG.bossIntroName = "";
    RG.realm = { active: false, lv: 0, mainWalls: null, mainBoundary: null };
    RG.walls = []; RG.boundary = null;
    RG._tempWalls=[]; if(RG.clearWallGrid)RG.clearWallGrid(); if(RG.clearEnemyGrid)RG.clearEnemyGrid();
    RG.cam = { x: 0, y: 0, shake: 0 };
    RG.run = null;
    RG.menuRects = []; RG.runCountdown=null; RG.offerKind='normal'; RG.checkpointPending=false; RG.checkpointResumeState='play';
  };
  // ---------- 多边形边界 ----------
  RG.genBoundary = function () {
    const pts = [], n = 16;
    for (let i = 0; i < n; i++) { const a = i / n * TAU; const r = rand(1500, 2050); pts.push({ x: Math.cos(a) * r, y: Math.sin(a) * r }); }
    RG.boundary = { pts };
  };
  RG.insideArena = function (x, y) {
    const pts = RG.boundary.pts; let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
      if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  };
  RG.constrain = function (ent) {
    let k = 0;
    while (!RG.insideArena(ent.x, ent.y) && k++ < 40) { ent.x += (0 - ent.x) * 0.18; ent.y += (0 - ent.y) * 0.18; }
  };

  // ---------- 墙体 ----------
  RG.genWalls = function () {
    RG.walls = []; RG.tempWalls = 0;
    const count = RG.randi(26, 34);
    let tries = 0;
    while (RG.walls.length < count && tries < 700) {
      tries++;
      const horizontal = Math.random() < 0.6;
      const w = horizontal ? rand(130, 430) : rand(40, 64);
      const h = horizontal ? rand(40, 64) : rand(130, 430);
      const x = rand(-ARENA_R, ARENA_R) - w / 2, y = rand(-ARENA_R, ARENA_R) - h / 2;
      const cx = x + w / 2, cy = y + h / 2;
      if (Math.hypot(cx, cy) < 260) continue;
      if (!RG.insideArena(cx, cy) || !RG.insideArena(x, y) || !RG.insideArena(x + w, y + h)) continue;
      let ok = true;
      for (const o of RG.walls) if (x - 96 < o.x + o.w && x + w + 96 > o.x && y - 96 < o.y + o.h && y + h + 96 > o.y) { ok = false; break; }
      if (ok) RG.walls.push({ x, y, w, h });
    }
  };
  RG.addTempWall = function () {
    const P = RG.P, a = P.face + Math.PI + rand(-0.5, 0.5), d = rand(cfgBALANCERunAddTempWall.d_min, cfgBALANCERunAddTempWall.d_max);   // 身后生成,挡追兵
    const horizontal = Math.random() < cfgBALANCERunAddTempWall.horizontal_threshold;
    const w = horizontal ? rand(cfgBALANCERunAddTempWall.w_min, cfgBALANCERunAddTempWall.w_max) : cfgBALANCERunAddTempWall.w, h = horizontal ? cfgBALANCERunAddTempWall.h : rand(cfgBALANCERunAddTempWall.h_min, cfgBALANCERunAddTempWall.h_max);
    RG.walls.push({ x: P.x + Math.cos(a) * d - w / 2, y: P.y + Math.sin(a) * d - h / 2, w, h, ttl: RG.PASSIVES.barrier.duration, temp: true });
    RG.addText(P.x + Math.cos(a) * d, P.y + Math.sin(a) * d, "壁垒!", "#818cf8", 14);
  };

  // ---------- 开局 ----------
  RG.xpFor = lv => { const c=RG.BALANCE.experience; return Math.floor(c.base + lv * c.perLevel + Math.pow(lv, c.power)); };
  RG.startRun = function (weaponId, runOaths, initialWeaponLv=1, arenaMode="main", mapId=RG.selectedMap||'legacy') {
    RG.runCountdown=null;
    if (RG.mixedVer) return;   // 混版本加载:禁止开局,先按提示强刷
    if(arenaMode!=='rush'&&(!RG.MAPS[mapId]||mapId!=='legacy'&&!RG.mapUnlocked(mapId)||mapId==='workshop'&&!RG.WORKSHOP_READY))return false;
    const map=RG.mapConfig(arenaMode==='rush'?'legacy':mapId);
    if (RG.clearRunCheckpoint) RG.clearRunCheckpoint();
    RG.resetBattleState();
    RG.checkpointResumeState = "play"; RG.checkpointPending = false;
    if (!RG.weaponUnlocked(weaponId) && !RG.DEBUG) weaponId = "bolt";   // 未解锁武器兜底
    RG.lastWeapon = weaponId;
    const base=RG.BALANCE.player;
    RG.P = {
      x: 0, y: 0, r: base.r, face: 0,
      hp: base.maxhp, maxhp: base.maxhp, speed: base.speed,
      level: 1, xp: 0, xpNext: RG.xpFor(1), pickup: base.pickup,
      regen: 0, dmgMul: 1, cdMul: 1, armor: 0,
      evade: 0, critC: 0, critD: base.critD, freezeC: 0,
      shield: 0, shieldMax: 0, shieldT: 0, shieldRecoverSlow:false,
      giantT:0, giantStacks:0, injuryBonus:0, reviveSpent:false, stillT: 0, slowT: 0, iTimer: 0, moving: false,
      weapons: {}, passives: {}, weaponCd: {}, orbitAngle: 0,
      passiveHistory: [],
      actives: {}, activeOrder: [], activeCd: {}, activeGuard: 0, overdriveT: 0,
      autoCd: {}, boltBurstQueue: [], seekerBurstQueue:[], hammerQueue:[], novaQueue:[], reactionMul:1, boltDouble:false, shopRegen:RG.meta.perks.includes("p_regen"), shopRegenT:0,
      extraShots: 0, bulletR: 1, barrierT: RG.PASSIVES.barrier.period,
      evolved: {}, weaponElements: {}, elementMisses: 0, evoCount: 0,
      rerolls: base.rerolls + (RG.meta.perks.includes("p_reroll") ? RG.perkConfig("p_reroll").rerolls : 0),
      coinMul: RG.meta.perks.includes("p_coin") ? RG.perkConfig("p_coin").coinMul : 1,
      dashT: 0, dashCd: 0, dashA: 0,
      healBan: false, pity: 0, levelQueue: [], weaponOfferMisses:{},highOfferMisses:0,
      bloodrush: 0, interest: 0, soulSuck: 0, deflect: 0, voidstep: 0, doomChain: 0,
      xpMul: RG.meta.perks.includes("p_xp")?RG.perkConfig("p_xp").xpMul:1, elemMul: 1, rangedMul: 1, visionMul: 1, globalCdMul: 1, dashCdMul: 1,
      sinLocked: false, sinId: null, envyPower: null, hpLocked: false, critDLocked: false,
    };
    if (RG.meta.perks.includes("p_hp")) { RG.P.maxhp += RG.perkConfig("p_hp").health; RG.P.hp += RG.perkConfig("p_hp").health; }
    if (RG.meta.perks.includes("p_speed")) RG.P.speed *= RG.perkConfig("p_speed").speedMul;
    if (RG.meta.perks.includes("p_shield")) { RG.P.shieldMax += RG.perkConfig("p_shield").shields; RG.P.shield = RG.perkConfig("p_shield").shields; }
    if (RG.meta.perks.includes("p_lv2")) { RG.P.level = RG.perkConfig("p_lv2").level; RG.P.xpNext = RG.xpFor(RG.perkConfig("p_lv2").level); RG.P.levelQueue.push(RG.perkConfig("p_lv2").level); }
    // 誓约(局内风险换金币加成)
    const oaths = runOaths || RG.meta.oaths || [];
    let oathCoin = 0;
    for (const o of oaths) oathCoin += RG.oathConfig(o)?.coin || 0;
    RG.P.coinMul *= 1 + oathCoin;
    if (oaths.includes("blood")) { RG.P.maxhp = Math.round(RG.P.maxhp * RG.oathConfig("blood").hpMul); RG.P.hp = Math.min(RG.P.hp, RG.P.maxhp); RG.P.dmgMul *= RG.oathConfig("blood").damageMul; }
    if (oaths.includes("healban")) { RG.P.healBan = true; RG.P.regen = 0; }
    if (oaths.includes("glass")) { RG.P.maxhp = Math.max(1, Math.round(RG.P.maxhp * RG.oathConfig("glass").hpMul)); RG.P.hp = Math.min(RG.P.hp, RG.P.maxhp); RG.P.dmgMul *= RG.oathConfig("glass").damageMul; }
    if (oaths.includes("fog")) RG.P.visionMul *= RG.oathConfig("fog").visionMul;
    if (oaths.includes("frail")) RG.P.hurtMul = (RG.P.hurtMul || 1) * RG.oathConfig("frail").hurtMul;
    if (oaths.includes("poverty")) RG.P.coinMul *= RG.oathConfig("poverty").coinMul;
    RG.oathSw = oaths.includes("haste") ? RG.oathConfig("haste").enemySpeed : 1;
    RG.oathSwarm = oaths.includes("swarm");
    RG.oathFrail = oaths.includes("frail");
    if (oaths.length >= cfgBALANCERunStartRun.length_threshold && RG.unlockAchievement) RG.unlockAchievement("contract_3");
    RG.runMetaDaily = !!(RG.meta.daily && RG.meta.daily.key);
    RG.ricLast = -Infinity;
    RG.P.weapons[weaponId] = initialWeaponLv;
    RG.run = { mapId:arenaMode==='rush'?'legacy':map.id,t: 0, kills: 0, spawnT: 0, eliteT: cfgBALANCERunStartRun.eliteT, bossT: map.times[0], nextBossAt:map.times[0],bossDelayUntil:0,bossNum: 0, boss: null, packT: cfgBALANCERunStartRun.packT, trapT: cfgBALANCERunStartRun.trapT, keyT: map.keyFirst,
      id:Date.now().toString(36)+"-"+Math.random().toString(36).slice(cfgBALANCERunStartRun.id_sliceArg1),
      coins: 0, openingGold:arenaMode==='rush'?0:RG.BALANCE.economy.openingGold, shopVisits:0,shopThrough:RG.P.level,shopPending:[],finalT: map.finalAt, finalStacks: 0, finalBoss: null, won: false, statueT: cfgBALANCERunStartRun.statueT, rushMode: false, rushLv: 0, cardT: 0, rushEndT: 0,
      cycle:0,cycleStart:0,rampT:0,squad:null,squadT:0,squadRestT:cfgBALANCERunStartRun.squadRestT,squadSeq:0,rareSquadAt:cfgBALANCERunStartRun.rareSquadAt,roster:RG.makeEncounterRoster(map.id) };
    RG.offers = []; RG.offerRects = []; RG.offerKind = "normal";RG.selectedOffer=null;
    if (arenaMode === "rush") {
      // 连战直接生成空旷竞技场，省去随后被丢弃的随机边界与墙体。
      const pts = [], n = cfgBALANCERunStartRun.n;
      for (let i = 0; i < n; i++) { const a = i / n * TAU; pts.push({ x: Math.cos(a) * 1050, y: Math.sin(a) * 1050 }); }
      RG.boundary = { pts };
    } else if(map.id==='workshop'){
      const layout=RG.workshopLayout();RG.walls=layout.walls;RG.boundary=layout.boundary;RG.run.layout={variant:layout.variant,mirror:layout.mirror};RG.rebuildWallGrid(RG.walls);
      RG.walls.push(...RG.makeMeadowTrees(RG.walls,[RG.P]));RG.rebuildWallGrid(RG.walls);
    } else { RG.genBoundary(); RG.genWalls(); }
    RG.state = "play";
    if(RG.refreshResonance)RG.refreshResonance(RG.P);
    RG.playSfx("choose"); RG.startBgm();
    if(arenaMode!=="rush")RG.openRunShop();else RG.openNextLevelUp();
    if (RG.TEST_MOB && RG.spawnTestMobs) {
      setTimeout(() => { if (RG.state === "play") RG.spawnTestMobs(); }, cfgBALANCERunStartRun.startRun_setTimeoutArg2);
    }
  };

  // ---------- BOSS 连战(v8.5):主菜单入口,8 关 = 8 BOSS,强化技能组,每 50s 自动三选一,记录最短通关 ----------
  RG.startRush = function (lv, weaponId) {
    if (RG.mixedVer || !RG.meta) return;
    const difficulty=RG.rushDifficulty(RG.meta.rushDifficulty||1);
    // 先确定武器等级再生成局外“二级开局”的首轮卡牌，避免旧二级升级卡降级武器。
    RG.startRun(weaponId || RG.lastWeapon || "bolt",undefined,difficulty.weaponLv,"rush");
    RG.run.rushMode = true; RG.run.rushLv = lv; RG.run.cardT = RG.BALANCE.run.startRush.cardT;
    RG.run.rushDifficulty=difficulty.id;
    RG.enemies = []; RG.ebullets = []; RG.hbeams = []; RG.hazards = []; RG.keyItems = []; RG.portal = null; RG.statues = [];
    RG.spawnRushBoss(lv);
    RG.addText(RG.P.x, RG.P.y - 74, "† BOSS 连战 第 " + lv + " 关 · " + RG.BOSS_NAMES[lv - 1], "#ff5470", 18);
  };
  RG.spawnRushBoss = function (lv) {
    const b = RG.makeBoss(lv, true);
    b.rushBoss = true;
    b.escortKeys=RG.rushEscortKeys(b.bossKind);b.escortT=cfgBALANCERunSpawnRushBoss.escortT;
    b.x = RG.P.x; b.y = RG.P.y - 420;
    RG.pushOutOfWalls(b, RG.walls); RG.constrain(b);
    RG.enemies.push(b); RG.run.boss = b;
    RG.cam.shake = 18; RG.bossRoar();
    RG.bossIntro = cfgBALANCERunSpawnRushBoss.bossIntro; RG.bossIntroName = b.name;
    RG.addText(b.x, b.y - 60, "! " + b.name + " 等你已久!", "#ff5470", 18);
    RG.playSfx("boss");
  };

  RG.SYSTEM_RUN_VER="v12029";
})(window.RG);
