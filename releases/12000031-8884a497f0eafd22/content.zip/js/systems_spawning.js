// ============ 敌人与场景生成:普通怪 / 首领 / 秘境 / 终局 ============
(function(RG){
  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgBALANCESpawningCommon=RG.BALANCE.spawning.common,
    cfgBALANCESpawningEnemyTimeScale=RG.BALANCE.spawning.enemyTimeScale,
    cfgBALANCESpawningSpawnCadence=RG.BALANCE.spawning.spawnCadence,
    cfgBALANCESpawningSpawnBatchSize=RG.BALANCE.spawning.spawnBatchSize,
    cfgBALANCESpawningSpawnArrivalRate=RG.BALANCE.spawning.spawnArrivalRate,
    cfgBALANCESpawningSpawnSquadRate=RG.BALANCE.spawning.spawnSquadRate,
    cfgBALANCESpawningSpawnFieldCap=RG.BALANCE.spawning.spawnFieldCap,
    cfgETYPESBomberSpawnSquadCap=RG.ETYPES.bomber.rules.spawnSquadCap,
    cfgBALANCESpawningBaseEnemy=RG.BALANCE.spawning.baseEnemy,
    cfgBALANCESpawningPlaceFormationEnemy=RG.BALANCE.spawning.placeFormationEnemy,
    cfgBALANCESpawningSpawnEnemy=RG.BALANCE.spawning.spawnEnemy,
    cfgBALANCESpawningSpawnPack=RG.BALANCE.spawning.spawnPack,
    cfgBALANCESpawningMakeSpawnSquad=RG.BALANCE.spawning.makeSpawnSquad,
    cfgBALANCESpawningUpdateSpawnDirector=RG.BALANCE.spawning.updateSpawnDirector,
    cfgBALANCESpawningUpdateRushEscorts=RG.BALANCE.spawning.updateRushEscorts,
    cfgBALANCESpawningMakeBoss=RG.BALANCE.spawning.makeBoss,
    cfgBOSS_SKILLSGolemMakeBoss=RG.BOSS_SKILLS.golem.makeBoss,
    cfgBOSS_SKILLSEyeMakeBoss=RG.BOSS_SKILLS.eye.makeBoss,
    cfgBOSS_SKILLSGluttonyMakeBoss=RG.BOSS_SKILLS.gluttony.makeBoss,
    cfgBOSS_SKILLSVoidMakeBoss=RG.BOSS_SKILLS.void.makeBoss,
    cfgBALANCESpawningSpawnBoss=RG.BALANCE.spawning.spawnBoss,
    cfgBALANCESpawningSpawnTrap=RG.BALANCE.spawning.spawnTrap,
    cfgBALANCESpawningSpawnKeys=RG.BALANCE.spawning.spawnKeys,
    cfgBALANCESpawningOpenPortal=RG.BALANCE.spawning.openPortal,
    cfgBALANCESpawningEnterRealm=RG.BALANCE.spawning.enterRealm,
    cfgBALANCESpawningExitRealm=RG.BALANCE.spawning.exitRealm,
    cfgBALANCESpawningSpawnFinalBoss=RG.BALANCE.spawning.spawnFinalBoss;

  const {rand,clamp,dist2,pick,TAU}=RG;
  RG.enemyContractSpeed = speed => speed * (RG.oathSw || 1);
  RG.BOSS_INTERVAL = cfgBALANCESpawningCommon.BOSS_INTERVAL;
  RG.MAIN_FINAL_TIME = cfgBALANCESpawningCommon.MAIN_FINAL_TIME;
  // 连战生命与初始武器等级由难度统一决定，不再随关卡乘算。
  RG.rushBossHp = (n,diff) => RG.rushDifficulty(diff).hp;
  RG.rushBossDamage=(n,diff)=>(cfgBALANCESpawningMakeBoss.dmg_offset+n*cfgBALANCESpawningMakeBoss.dmg_factor)*(cfgBALANCESpawningMakeBoss.dmg_factor_2*RG.rushDifficulty(diff).dmg);
  RG.realmBossStats=function(lv,time){const c=cfgBALANCESpawningEnterRealm,scale=1+time/60*c.scale_factor;return {hp:c.hp_factor*(1+(lv-1)*c.hp_factor_2)*scale,maxhp:c.maxhp_factor*(1+(lv-1)*c.maxhp_factor_2)*scale,dmg:c.dmg_offset+lv*c.dmg_factor};};
  RG.finalBossStats=function(time,stacks){const c=cfgBALANCESpawningSpawnFinalBoss,scale=RG.enemyTimeScale(time).hp;return {hp:c.hp_factor*(1+stacks*c.hp_factor_2)*scale,maxhp:c.maxhp_factor*(1+stacks*c.maxhp_factor_2)*scale,dmg:c.dmg_offset+stacks*c.dmg_factor};};
  RG.bossCodexInfo=function(id,diff){
    const info=RG.BOSS_INFO[id];if(!info)return null;
    let stats,hp,dmg;
    if(info.rushLevel){const difficulty=RG.rushDifficulty(diff??RG.meta?.rushDifficulty??1);hp=RG.rushBossHp(info.rushLevel,difficulty.id);dmg=RG.rushBossDamage(info.rushLevel,difficulty.id);stats=`连战${difficulty.name}：生命 ${RG.configNumber(hp)} · 接触伤害 ${RG.configNumber(dmg)}\n主线生命、伤害随地图和时间成长。`;}
    else if(id==='devourer'){const time=RG.mapConfig('valley').finalAt;({hp,dmg}=RG.finalBossStats(time,0));stats=`荒谷首次终局（${RG.fmtTime(time)}）：生命 ${RG.configNumber(hp)} · 接触伤害 ${RG.configNumber(dmg)}\n无尽阶数和实际出场时间会提高生命。`;}
    else if(id==='guard'){({hp,dmg}=RG.realmBossStats(1,0));stats=`第一钥印基础：生命 ${RG.configNumber(hp)} · 接触伤害 ${RG.configNumber(dmg)}\n实际生命随入场时间与钥印阶段成长。`;}
    else stats='历史隐藏首领记录；不属于当前连战八关。';
    return {name:info.name,stats,hp,dmg,mechanism:info.mechanism,randomResists:!!info.randomResists};
  };
  RG.RUSH_DIFFICULTIES = RG.BALANCE.rushDifficulties;
  RG.rushDifficulty = id => RG.RUSH_DIFFICULTIES.find(d=>d.id===id)||RG.RUSH_DIFFICULTIES[0];
  RG.rushBestTime=(lv,diff)=>RG.meta.bossRush?.bestByDifficulty?.[diff]?.[lv]??(diff===1?RG.meta.bossRush?.best?.[lv]:undefined);
  // 生命承担后期耐久，伤害平缓增加；45分钟以后按线性增长，避免周目乘算突跳。
  RG.enemyTimeScale = function(t){
    const m=Math.max(0,t||0)/60,base=Math.min(m,cfgBALANCESpawningEnemyTimeScale.base_cap),extra=Math.max(0,m-cfgBALANCESpawningEnemyTimeScale.extra_offset);
    return {hp:(1+cfgBALANCESpawningEnemyTimeScale.hp_factor*base+cfgBALANCESpawningEnemyTimeScale.hp_factor_2*base*base)*(1+extra*cfgBALANCESpawningEnemyTimeScale.hp_factor_3),dmg:(1+cfgBALANCESpawningEnemyTimeScale.dmg_factor*base+cfgBALANCESpawningEnemyTimeScale.dmg_factor_2*base*base)*(1+extra*cfgBALANCESpawningEnemyTimeScale.dmg_factor_3),xp:1+cfgBALANCESpawningEnemyTimeScale.xp_factor*m,speed:1+Math.min(cfgBALANCESpawningEnemyTimeScale.speed_cap,m*cfgBALANCESpawningEnemyTimeScale.speed_factor)};
  };
  RG.makeEncounterRoster = function(mapId=RG.run?.mapId){
    if(mapId==='workshop')return {revision:RG.BALANCE.spawning.makeEncounterRoster.revision,element:'mortar',control:'tether',ambush:'scavenger',ranged:'prism',special:'warder',keys:[...RG.MEADOW_MOB_KEYS,'prism','amplifier']};
    const element=pick(["flamer","volt"]),control=pick(["ice","crystal"]),ambush=pick(["hound","stalker"]),ranged=pick(["shooter","howler"]),special=pick(["splitter","summoner","homing"]);
    return {element,control,ambush,ranged,special,keys:["grunt","swarm","brute","bulwark","bomber","smasher","colossus","healer",element,control,ambush,ranged,special,...(mapId==='workshop'?['prism','amplifier']:[])]};
  };
  RG.fieldTimeScale=function(t){
    const s=RG.enemyTimeScale(t),map=RG.run?.rushMode?RG.mapConfig('legacy'):RG.mapConfig();
    return {...s,hp:s.hp*map.hp,dmg:s.dmg*map.dmg,xp:s.xp*map.xp};
  };
  // 解锁表仅限制初次亮相，此后不再每8分钟退回开局。
  RG.spawnCycleTime=t=>Math.min(RG.BALANCE.spawning.spawnCycleTime.spawnCycleTime_cap,Math.max(0,t||0));
  RG.spawnCadence=t=>Math.max(cfgBALANCESpawningSpawnCadence.spawnCadence_floor,cfgBALANCESpawningSpawnCadence.spawnCadence_offset-Math.min(cfgBALANCESpawningSpawnCadence.spawnCadence_cap,Math.max(0,t))*cfgBALANCESpawningSpawnCadence.spawnCadence_factor-Math.max(0,Math.min(t,cfgBALANCESpawningSpawnCadence.spawnCadence_cap_2)-cfgBALANCESpawningSpawnCadence.spawnCadence_offset_2)*cfgBALANCESpawningSpawnCadence.spawnCadence_factor_2);
  RG.spawnBatchSize=t=>1+Math.min(cfgBALANCESpawningSpawnBatchSize.spawnBatchSize_cap,Math.floor(Math.max(0,t)/cfgBALANCESpawningSpawnBatchSize.spawnBatchSize_divisor));
  // 批量只折算成持续到达速率，单次出场一只；清场和掉帧都不积攒补满债务。
  RG.spawnArrivalRate=t=>Math.min(cfgBALANCESpawningSpawnArrivalRate.spawnArrivalRate_cap,cfgBALANCESpawningSpawnArrivalRate.spawnArrivalRate_factor*RG.spawnBatchSize(t)/RG.spawnCadence(t));
  // 每个新编队按实际刷怪时间独立入场，首领/秘境/暂停期间不会跳过适应期。
  RG.SQUAD_ENTRY_SECONDS=cfgBALANCESpawningCommon.SQUAD_ENTRY_SECONDS;
  RG.OPENING_ENTRY_SECONDS=cfgBALANCESpawningCommon.OPENING_ENTRY_SECONDS;
  const entryCurve=x=>{const p=clamp(x,0,1);return p*p*p*(10+p*(-15+6*p));};
  RG.spawnSquadProgress=squad=>entryCurve((squad?.entryElapsed||0)/RG.SQUAD_ENTRY_SECONDS);
  RG.spawnSquadRate=function(t,squad){
    const normal=RG.spawnArrivalRate(t)*(squad?.batchMul||1)*(RG.oathSwarm?RG.oathConfig("swarm").arrivalMul:1);
    // 初次入场保持适应期，后续交接沿用旧组到达速率，不重复跌回每秒半只。
    const initial=Math.min(normal,squad?.entryRate??cfgBALANCESpawningSpawnSquadRate.initial);
    const rate=initial+(normal-initial)*RG.spawnSquadProgress(squad);
    // 开局缓冲使用绝对速率，避免高密度契约把新手适应曲线放大。
    const opening=cfgBALANCESpawningSpawnSquadRate.opening_offset+(normal-cfgBALANCESpawningSpawnSquadRate.opening_offset)*entryCurve(t/RG.OPENING_ENTRY_SECONDS);
    return Math.min(rate,opening);
  };
  RG.spawnFieldCap=function(k,t){
    if(RG.ETYPES[k].strictCap)return RG.ETYPES[k].fieldCap;
    const type=RG.ETYPES[k],extra=type.ranged?Math.min(cfgBALANCESpawningSpawnFieldCap.rangedExtra,Math.floor(t/cfgBALANCESpawningSpawnFieldCap.rangedEvery)):type.support||['splitter','colossus','bomber'].includes(k)?0:cfgBALANCESpawningSpawnFieldCap.meleeExtra;
    const base=(type.fieldCap||cfgBALANCESpawningSpawnFieldCap.base)+extra;
    if(RG.ETYPES[k].strictCap||["healer","summoner","splitter","colossus"].includes(k))return base;
    return base===cfgBALANCESpawningSpawnFieldCap.spawnFieldCap?cfgBALANCESpawningSpawnFieldCap.spawnFieldCap:Math.min(base+cfgBALANCESpawningSpawnFieldCap.spawnFieldCap_offset,base+Math.floor(Math.max(0,t)/cfgBALANCESpawningSpawnFieldCap.spawnFieldCap_divisor));
  };
  RG.spawnSquadCap=function(k,t,squad){
    const cap=RG.spawnFieldCap(k,t),index=squad.keys.indexOf(k);
    // 引爆者和第三种怪只做少量支援，不能在主力达到上限后反客为主。
    return index>0&&(k==="bomber"||k==="healer"||index>=cfgETYPESBomberSpawnSquadCap.index_threshold)?Math.min(cap,cfgETYPESBomberSpawnSquadCap.spawnSquadCap_offset+Math.min(1,Math.floor(t/cfgETYPESBomberSpawnSquadCap.spawnSquadCap_divisor))):cap;
  };
  RG.spawnPool=function(t){return (RG.run.roster||{keys:Object.keys(RG.ETYPES)}).keys.filter(k=>RG.ETYPES[k].weight(RG.spawnCycleTime(t))>0);};
  RG.spawnCompatible=function(k,counts){
    return ![['prism','volt'],['prism','howler'],['amplifier','healer'],['amplifier','summoner']].some(([a,b])=>k===a&&counts[b]||k===b&&counts[a]);
  };
  // ---------- 生成 ----------
  function baseEnemy(typeKey, elite) {
    const t = RG.ETYPES[typeKey], ang = rand(0, TAU), R = Math.hypot(RG.W, RG.H) / cfgBALANCESpawningBaseEnemy.R_divisor + cfgBALANCESpawningBaseEnemy.R_offset;
    const scale = RG.fieldTimeScale(RG.run.t);
    return {
      type: typeKey, x: RG.P.x + Math.cos(ang) * R, y: RG.P.y + Math.sin(ang) * R,
      r: t.r * (elite ? cfgBALANCESpawningBaseEnemy.r : 1) * rand(cfgBALANCESpawningBaseEnemy.r_min, cfgBALANCESpawningBaseEnemy.r_max),
      hp: t.hp * scale.hp * (elite ? cfgBALANCESpawningBaseEnemy.hp : 1), maxhp: t.hp * scale.hp * (elite ? cfgBALANCESpawningBaseEnemy.maxhp : 1),
      speed: RG.enemyContractSpeed(t.speed * scale.speed * (elite ? cfgBALANCESpawningBaseEnemy.speed : 1) * rand(cfgBALANCESpawningBaseEnemy.speed_min, cfgBALANCESpawningBaseEnemy.speed_max)),
      dmg: t.dmg * scale.dmg * (elite ? cfgBALANCESpawningBaseEnemy.dmg : 1),
      xp: t.xp * (elite ? cfgBALANCESpawningBaseEnemy.xp : 1) * scale.xp, elite: !!elite, ranged: t.ranged, slow: t.slow, support: t.support, fuse: t.fuse, keep: t.keep, splitMob: t.splitMob,
      homing: t.homing, ghost: t.ghost, life: t.life || 0,
      vx: 0, vy: 0, frozen: 0, flash: 0, shootT: rand(1, cfgBALANCESpawningBaseEnemy.shootT_max), hitCds: {}, boss: false, alpha: 1,
      navT: rand(0, cfgBALANCESpawningBaseEnemy.navT_max), steerA: null,
    };
  }
  // 主方向80%、反方向20%；沿宽扇面逐格排开，后续批次使用外侧弧线。
  // 按实际体型检查空位，墙边不能把一整批怪挤回同一个点。
  RG.placeFormationEnemy=function(e,formation){
    const sequence=formation.spawnIndex||0;formation.spawnIndex=sequence+1;
    const opposite=sequence%cfgBALANCESpawningPlaceFormationEnemy.opposite===cfgBALANCESpawningPlaceFormationEnemy.opposite_2,sideSequence=opposite?Math.floor(sequence/cfgBALANCESpawningPlaceFormationEnemy.sideSequence_divisor):sequence-Math.floor(sequence/cfgBALANCESpawningPlaceFormationEnemy.sideSequence_divisor);
    const columns=opposite?cfgBALANCESpawningPlaceFormationEnemy.columns:cfgBALANCESpawningPlaceFormationEnemy.columns_2,span=opposite?cfgBALANCESpawningPlaceFormationEnemy.span:cfgBALANCESpawningPlaceFormationEnemy.span_2,angle=formation.angle+(opposite?Math.PI:0);
    const columnAt=i=>Math.floor(columns/2)+(i%2?-(i+1)/2:i/2);
    const radius=Math.max(cfgBALANCESpawningPlaceFormationEnemy.radius_floor,Math.min(RG.W,RG.H)*cfgBALANCESpawningPlaceFormationEnemy.radius_factor+cfgBALANCESpawningPlaceFormationEnemy.radius_offset),original={x:e.x,y:e.y};
    for(let attempt=0;attempt<columns*cfgBALANCESpawningPlaceFormationEnemy.placeFormationEnemy_factor;attempt++){
      const slot=sideSequence+attempt,column=columnAt(slot%columns),row=(Math.floor(sideSequence/columns)%cfgBALANCESpawningPlaceFormationEnemy.row)+Math.floor(attempt/columns);
      const a=angle-span/2+column*span/(columns-1),distance=radius+row*cfgBALANCESpawningPlaceFormationEnemy.distance_factor;
      e.x=RG.P.x+Math.cos(a)*distance;e.y=RG.P.y+Math.sin(a)*distance;
      RG.pushOutOfWalls(e,RG.walls);RG.constrain(e);
      if(dist2(e.x,e.y,RG.P.x,RG.P.y)<cfgBALANCESpawningPlaceFormationEnemy.placeFormationEnemy_factor_2*cfgBALANCESpawningPlaceFormationEnemy.placeFormationEnemy_factor_2)continue;
      const clear=RG.enemies.every(o=>o.dead||o.dying||dist2(e.x,e.y,o.x,o.y)>=Math.pow(RG.enemyBodyRadius(e)+RG.enemyBodyRadius(o)+cfgBALANCESpawningPlaceFormationEnemy.clear_offset,2));
      if(clear){e.spawnSide=opposite?"secondary":"main";return;}
    }
    e.x=original.x;e.y=original.y; // 扇面被地形堵满时沿用原来的分散出生。
  };
  RG.spawnEnemy = function (typeKey, elite, formation) {
    const type=RG.ETYPES[typeKey];
    if(type.strictCap&&RG.enemies.filter(e=>e.type===typeKey&&!e.dead&&!e.dying).length>=type.fieldCap)return null;
    if(type.noElite)elite=false;
    const e = baseEnemy(typeKey, elite);
    if(elite&&typeKey==='bomber'){e.hp*=RG.MOB_SKILLS.bomber.eliteHp;e.maxhp*=RG.MOB_SKILLS.bomber.eliteHp;}
    if(typeKey==='amplifier')RG.run.amplifierPresent=true;
    if(formation)RG.placeFormationEnemy(e,formation);
    if (e && !e.name && RG.ETYPES[typeKey]) e.name = RG.ETYPES[typeKey].name;
    if (RG.TEST_MOB && (typeKey === "stalker" || typeKey === "crystal" || typeKey === "howler")) {
      e.testMob = true; e.xp = Math.max(1, e.xp | 0);
    }
    if (RG.seenMob) RG.seenMob(typeKey);
    if(RG.run&&RG.run.squad)e.squadId=formation?.id??RG.run.squad.id;
    if (elite && Math.random() < cfgBALANCESpawningSpawnEnemy.chance_threshold) e.chest = true;   // 宝箱精英:击杀掉免费卡+金币
    else if (elite && Math.random() < cfgBALANCESpawningSpawnEnemy.chance_threshold_2) {
      // 精英词缀:逼玩家看词缀决定击杀顺序
      e.affix = pick(["boom", "swift", "split", "shield"]);
      if (e.affix === "swift") e.speed *= cfgBALANCESpawningSpawnEnemy.speed;
      if (e.affix === "shield") e.shieldHp = e.maxhp * cfgBALANCESpawningSpawnEnemy.shieldHp_factor;
      // 5 分钟后:25% 精英追加迅/盾效果(不覆盖主词缀字段,death 钩子无需感知)
      if (RG.run.t > cfgBALANCESpawningSpawnEnemy.t_threshold && Math.random() < cfgBALANCESpawningSpawnEnemy.chance_threshold_3) {
        if (e.affix !== "swift") e.speed *= cfgBALANCESpawningSpawnEnemy.speed;
        else e.shieldHp = (e.shieldHp || 0) + e.maxhp * cfgBALANCESpawningSpawnEnemy.shieldHp_factor;
      }
    }
    RG.pushOutOfWalls(e, RG.walls); RG.constrain(e);
    RG.enemies.push(e); return e;
  };
  RG.spawnPack = function () {
    if(RG.run.mapId==='workshop'&&!RG.run.rushMode){for(let i=0;i<RG.SPAWN_COUNTS.meadowPack;i++)RG.spawnEnemy('scavenger',false);return;}
    const ct=RG.spawnCycleTime(RG.run.t,RG.run.cycleStart);
    const n = cfgBALANCESpawningSpawnPack.n_offset + Math.min(cfgBALANCESpawningSpawnPack.n_cap, Math.floor(ct / cfgBALANCESpawningSpawnPack.n_divisor));
    const ang = rand(0, TAU), cx = RG.P.x + Math.cos(ang) * 280, cy = RG.P.y + Math.sin(ang) * 280;
    const t = RG.ETYPES.swarm, scale = RG.fieldTimeScale(RG.run.t);
    for (let i = 0; i < n; i++) {
      const a = i / n * TAU;
      const e = {
        type: "swarm", x: cx + Math.cos(a) * rand(20, 90), y: cy + Math.sin(a) * rand(20, 90),
        r: t.r * rand(cfgBALANCESpawningSpawnPack.r_min, cfgBALANCESpawningSpawnPack.r_max), hp: t.hp * scale.hp, maxhp: t.hp * scale.hp,
        speed: RG.enemyContractSpeed(t.speed * scale.speed * rand(cfgBALANCESpawningSpawnPack.speed_min, cfgBALANCESpawningSpawnPack.speed_max)), dmg: t.dmg * scale.dmg, xp: t.xp * scale.xp,
        elite: false, ranged: false, slow: false, homing: false, ghost: false, life: 0,
        vx: 0, vy: 0, frozen: 0, flash: 0, shootT: cfgBALANCESpawningSpawnPack.shootT, hitCds: {}, boss: false, alpha: 1,
        navT: rand(0, cfgBALANCESpawningSpawnPack.navT_max), steerA: null,
      };
      RG.pushOutOfWalls(e, RG.walls); RG.constrain(e);
      RG.enemies.push(e);
    }
    RG.addText(cx, cy, "狼群来袭!", "#6ee7b7", 15);
  };

  // 刷怪编组表：每一波只启用一个有明确配合关系的小队，避免后期把全部怪种搅在一起。
  // 数组顺序同时表达战术关系：首位是主力，其余是少量掩护/支援单位。
  const nextSquadId=()=>RG.run.squadSeq=(RG.run.squadSeq||0)+1;
  RG.makeSpawnSquad = function (t, groupIndex) {
    const r=RG.run.roster||(RG.run.roster=RG.makeEncounterRoster()),pool=RG.spawnPool(t),has=k=>pool.includes(k);
    let groups=t<cfgBALANCESpawningMakeSpawnSquad.groups_threshold?[["grunt",r.ambush],["swarm","grunt"],[r.ranged,"grunt"]]:t<cfgBALANCESpawningMakeSpawnSquad.groups_threshold_2?[[r.ranged,r.ambush],["brute","grunt"],["swarm","bomber"],[r.control,"bulwark"],[r.element,r.ambush]]:t<cfgBALANCESpawningMakeSpawnSquad.groups_threshold_3?[["smasher",r.ranged],[r.element,"bulwark"],[r.special,"swarm"],[r.control,"brute"],["colossus","healer","grunt"]]:[
      ["smasher",r.element,"bomber"],["bulwark",r.element,r.control],["colossus","healer","brute"],[r.special,r.ranged,"grunt"],[r.control,r.ambush,r.ranged],[r.element,"smasher","grunt"],
    ];
    const meadow=RG.run.mapId==='workshop'&&!RG.run.rushMode;
    if(meadow)groups=t<cfgBALANCESpawningMakeSpawnSquad.groups_threshold?[['phantasm','sporepod'],['scavenger','phantasm','sporepod']]:[
      ['prism','phantasm','sporepod'],['amplifier','phantasm','scavenger'],['crucible','sporepod','warder'],['mortar','phantasm','tether'],['sporepod','scavenger','warder'],['phantasm','tether','mortar']];
    const candidates=groups.map(g=>g.filter(has)).filter(g=>g.length);
    if(!candidates.length)return {primary:null,keys:[]};
    let rare=false,group;
    if(!meadow&&groupIndex==null&&t>=cfgBALANCESpawningMakeSpawnSquad.t_threshold&&Math.random()<cfgBALANCESpawningMakeSpawnSquad.chance_threshold&&t-(RG.run.rareSquadAt??cfgBALANCESpawningMakeSpawnSquad.makeSpawnSquad)>=cfgBALANCESpawningMakeSpawnSquad.range_threshold){
      rare=true;RG.run.rareSquadAt=t;group=["smasher",r.element,"bomber"].filter(has);
    }else{
      const i=groupIndex==null?((Math.random()*candidates.length)|0):groupIndex%candidates.length;
      group=candidates[i];
    }
    return {primary:group[0],keys:group.slice(),id:nextSquadId(),angle:rand(0,TAU),rare,batchMul:group[0]==="summoner"?RG.ETYPES.summoner.rules.makeSpawnSquad.batchMul:1,entryElapsed:0};
  };
  RG.updateSpawnDirector = function(dt){
    const run=RG.run,t=run.t,ct=RG.spawnCycleTime(t),P=RG.P;
    const meadow=run.mapId==='workshop'&&!run.rushMode,packKey=meadow?'scavenger':'swarm',filler=meadow?'phantasm':'grunt';
    if(run.rampT>0)run.rampT=Math.max(0,run.rampT-dt);
    const ramp=run.rampT||0;if(ramp>cfgBALANCESpawningUpdateSpawnDirector.ramp_threshold)return;
    const screenCap=RG.touchMode?(RG.fxAutoReduced?cfgBALANCESpawningUpdateSpawnDirector.screenCap:RG.fxQuality==="low"?cfgBALANCESpawningUpdateSpawnDirector.screenCap_2:cfgBALANCESpawningUpdateSpawnDirector.screenCap_3):cfgBALANCESpawningUpdateSpawnDirector.screenCap_4;
    const cap=Math.min(screenCap,RG.mapConfig().mobCap||screenCap);
    // 存量怪自然交接，新编队只能占用空出的种类位置，最多四种。
    const alive=RG.enemies.filter(e=>!e.dead&&!e.dying&&!e.boss),counts={};for(const e of alive)counts[e.type]=(counts[e.type]||0)+1;
    const normalTarget=Math.min(cap,cfgBALANCESpawningUpdateSpawnDirector.normalTarget_offset+Math.floor(t/cfgBALANCESpawningUpdateSpawnDirector.normalTarget_divisor)),stage=Math.floor(t/cfgBALANCESpawningUpdateSpawnDirector.stage_divisor);
    const target=Math.min(normalTarget,Math.floor(cfgBALANCESpawningUpdateSpawnDirector.target_offset+(normalTarget-cfgBALANCESpawningUpdateSpawnDirector.target_offset)*entryCurve(t/RG.OPENING_ENTRY_SECONDS)));
    const handoff=()=>{
      if(run.squad){run.outgoingSquad={...run.squad,remaining:RG.SQUAD_ENTRY_SECONDS};run.handoffRate=RG.spawnSquadRate(t,run.squad);}
      run.squad=null;run.squadRestT=RG.BALANCE.spawning.handoff.squadRestT;
    };
    if(run.encounterStage!==stage){run.encounterStage=stage;handoff();}
    if(run.outgoingSquad){run.outgoingSquad.remaining-=dt;if(run.outgoingSquad.remaining<=0)run.outgoingSquad=null;}
    if(run.squad){
      // 旧现场缺少入场时钟，恢复后仍给足40秒，保留原来的正常持续时间。
      if(!Number.isFinite(run.squad.entryElapsed)){run.squad.entryElapsed=0;run.squadT=Math.max(0,run.squadT||0)+RG.SQUAD_ENTRY_SECONDS;run.spawnT=Math.max(run.spawnT||0,cfgBALANCESpawningUpdateSpawnDirector.spawnT_floor);}
      run.squad.entryElapsed=Math.min(RG.SQUAD_ENTRY_SECONDS,run.squad.entryElapsed+dt);
      run.squadT-=dt;if(run.squadT<=0)handoff();
    }
    if(!run.squad){
      run.squadRestT=(run.squadRestT||0)+dt;
      if(run.squadRestT>=cfgBALANCESpawningUpdateSpawnDirector.squadRestT_threshold){
        run.squadT=RG.SQUAD_ENTRY_SECONDS+rand(cfgBALANCESpawningUpdateSpawnDirector.squadT_min,cfgBALANCESpawningUpdateSpawnDirector.squadT_max);run.squadRestT=0;
        // 10分钟后的阶段首波有鲜明主力，其余波按本局常客随机轮换。
        run.squad=RG.makeSpawnSquad(t,stage>=cfgBALANCESpawningUpdateSpawnDirector.squad_threshold&&run.stageOpening!==stage?0:undefined);run.stageOpening=stage;
        if(run.handoffRate!=null){run.squad.entryRate=run.handoffRate;delete run.handoffRate;}
        // 正常交接保留到达时钟，首轮仍以低速进入。
        if(!run.outgoingSquad)run.spawnT=Math.max(run.spawnT||0,1/RG.spawnSquadRate(t,run.squad));
        if(run.squad.primary&&t>cfgBALANCESpawningUpdateSpawnDirector.t_threshold)RG.addText(P.x,P.y-70,(run.squad.rare?"! 稀有 ":"! ")+RG.ETYPES[run.squad.primary].name+"编队接近",RG.ETYPES[run.squad.primary].color,13);
      }
    }
    const allowed=k=>{
      const types=new Set(Object.keys(counts));types.add(k);
      // 祭司会召唤游荡者与疾行虫，提前为两种召唤物留位。
      if(types.has("summoner")){types.add("grunt");types.add("swarm");}
      return (counts[k]||0)>0||types.size<=RG.BALANCE.spawning.allowed.size_threshold;
    };
    const progress=RG.spawnSquadProgress(run.squad),settled=!!run.squad&&progress>=1&&ramp<=0&&t>=RG.OPENING_ENTRY_SECONDS;
    run.eliteT-=dt;if(run.eliteT<=0&&settled){run.eliteT=Math.max(cfgBALANCESpawningUpdateSpawnDirector.eliteT_floor,cfgBALANCESpawningUpdateSpawnDirector.eliteT_offset-t/cfgBALANCESpawningUpdateSpawnDirector.eliteT_divisor);run.elitePending=true;}
    run.packT-=dt;if(run.packT<=0){
      if(settled){run.packT=Math.max(cfgBALANCESpawningUpdateSpawnDirector.packT_floor,cfgBALANCESpawningUpdateSpawnDirector.packT_offset-t/cfgBALANCESpawningUpdateSpawnDirector.packT_divisor);
        if(t>cfgBALANCESpawningUpdateSpawnDirector.t_threshold_2&&allowed(packKey)&&alive.length<target-cfgBALANCESpawningUpdateSpawnDirector.updateSpawnDirector_offset){run.packPending=cfgBALANCESpawningUpdateSpawnDirector.packPending_offset+Math.min(cfgBALANCESpawningUpdateSpawnDirector.packPending_cap,Math.floor(ct/cfgBALANCESpawningUpdateSpawnDirector.packPending_divisor));RG.addText(P.x,P.y-70,meadow?"拾荒机群接近!":"狼群接近!","#6ee7b7",13);}}
    }
    run.spawnT-=dt;
    if(run.spawnT<=0){
      const rate=RG.spawnSquadRate(t,run.squad)/(1+ramp/cfgBALANCESpawningUpdateSpawnDirector.rate_divisor*cfgBALANCESpawningUpdateSpawnDirector.rate_factor);
      // 正常帧保留不足一帧的余量，使30/60/120帧出生次数一致；长卡顿直接丢弃债务。
      const interval=1/rate;run.spawnT=dt>=interval?interval:run.spawnT+interval;
      if(run.squad&&alive.length<target){
        const eligible=(k,squad)=>RG.ETYPES[k].weight(ct)>0&&allowed(k)&&RG.spawnCompatible(k,counts)&&(counts[k]||0)<RG.spawnSquadCap(k,t,squad)&&!(k==='splitter'&&counts.summoner||k==='summoner'&&counts.splitter);
        const keys=run.squad.keys.filter((k,i)=>((run.squad.entryElapsed||0)>=i*cfgBALANCESpawningUpdateSpawnDirector.keys_factor)&&eligible(k,run.squad)&&(counts[k]||0)<Math.ceil(RG.spawnSquadCap(k,t,run.squad)*(cfgBALANCESpawningUpdateSpawnDirector.keys_offset+cfgBALANCESpawningUpdateSpawnDirector.keys_factor_2*progress)));
        let k=keys.includes(run.squad.primary)&&Math.random()<cfgBALANCESpawningUpdateSpawnDirector.k_threshold?run.squad.primary:pick(keys);
        const old=run.outgoingSquad,oldKeys=old?old.keys.filter(k=>eligible(k,old)):[];
        if(oldKeys.length&&(!k||Math.random()>(cfgBALANCESpawningUpdateSpawnDirector.updateSpawnDirector_offset_2+cfgBALANCESpawningUpdateSpawnDirector.updateSpawnDirector_factor*progress)))k=pick(oldKeys);
        if(settled&&run.packPending>0&&eligible(packKey,run.squad)&&Math.random()<cfgBALANCESpawningUpdateSpawnDirector.chance_threshold){k=packKey;run.packPending--;}
        // 功能怪数量满额时仍由游荡者维持到达，不能空等几十秒换组。
        if(t>=RG.OPENING_ENTRY_SECONDS&&(run.squad.entryElapsed||0)>=cfgBALANCESpawningUpdateSpawnDirector.range_threshold&&eligible(filler,run.squad)&&(!k||Math.random()<cfgBALANCESpawningUpdateSpawnDirector.chance_threshold_2))k=filler;
        if(k){const elite=!!run.elitePending&&settled&&k!=="swarm",formation=old?.keys.includes(k)&&!run.squad.keys.includes(k)?old:run.squad;RG.spawnEnemy(k,elite,formation);if(elite)run.elitePending=false;}
      }
    }
    run.trapT-=dt;if(run.trapT<=0&&settled){run.trapT=cfgBALANCESpawningUpdateSpawnDirector.trapT;if(t>cfgBALANCESpawningUpdateSpawnDirector.t_threshold_3){const a=rand(0,TAU),d=rand(cfgBALANCESpawningUpdateSpawnDirector.d_min,cfgBALANCESpawningUpdateSpawnDirector.d_max);RG.spawnTrap(P.x+Math.cos(a)*d,P.y+Math.sin(a)*d);}}
  };
  // 入口与调度共用实际登场时刻；延迟不会改写主线顺序或跳过欠下的首领。
  RG.scheduledBossAt=function(){
    const run=RG.run;
    const planned=run.won||run.bossNum>=RG.mapConfig().bosses.length?run.finalT:(run.nextBossAt||RG.mapConfig().times[0]);
    return Math.max(planned,run.bossDelayUntil||0);
  };
  RG.REALM_SEAL_SECONDS=cfgBALANCESpawningCommon.REALM_SEAL_SECONDS;
  RG.realmEntrySeal=function(){
    if(!RG.run||!RG.P||RG.run.rushMode||RG.realm.active)return 'unavailable';
    // 濒死动画结束才结算击杀；零血但尚未结算的首领仍须保留在主线。
    const alive=e=>e&&e.boss&&!e.realmBoss&&!e.dead;
    if(alive(RG.run.boss)||alive(RG.run.finalBoss)||RG.enemies.some(alive))return 'battle';
    // 时停继续消耗局内时间，登场须等时停结束；不采用可能过期的显示倒计时。
    const at=Math.max(RG.scheduledBossAt(),RG.run.t+Math.max(0,RG.timeStop||0));
    return at-RG.run.t<=RG.REALM_SEAL_SECONDS?'soon':'';
  };
  RG.realmPortalLabel=function(){
    if(RG.portal?.exit)return '返回';
    const seal=RG.realmEntrySeal();
    return seal==='battle'?'入口封印 · 首领战斗中':seal==='soon'?'入口封印 · 首领即将登场':seal?'入口暂不可用':'秘境之门 · 靠近进入';
  };
  RG.updateBossSchedule=function(){
    const run=RG.run;if(run.rushMode)return;
    run.bossT=Math.max(0,RG.scheduledBossAt()-run.t);
    if(RG.realm.active||run.boss||run.finalBoss||RG.timeStop>0||run.t<(run.bossDelayUntil||0))return;
    if(run.won||run.bossNum>=RG.mapConfig().bosses.length){if(run.t>=run.finalT)RG.spawnFinalBoss();return;}
    if(run.bossT<=0)RG.spawnBoss();
  };
  RG.rushEscortKeys=function(kind){
    const r=RG.run.roster;
    const groups={gluttony:[r.ambush,r.ranged],golem:[r.element,"bomber"],eye:[r.ambush,r.control],shadow:[r.control,r.ranged],mirror:["brute","flamer"],domain:[r.element,r.ambush],furnace:[r.control,"bomber"],void:[r.ambush,r.ranged]};
    return groups[kind]||["grunt",r.ranged];
  };
  RG.updateRushEscorts=function(b,dt){
    if(!RG.run.rushMode||!b.rushBoss||b.dead||b.dying)return;
    const d=RG.rushDifficulty(RG.run.rushDifficulty),limit=d.escorts;if(!limit)return;
    b.escortT=(b.escortT??cfgBALANCESpawningUpdateRushEscorts.escortT)-dt;if(b.escortT>0)return;
    const phase=b.mechanicPhase||1,age=b.fightElapsed||0;
    const stageLimit=Math.min(limit,phase===3?limit:phase===2?Math.ceil(limit*cfgBALANCESpawningUpdateRushEscorts.stageLimit_factor):age>=cfgBALANCESpawningUpdateRushEscorts.stageLimit_threshold?cfgBALANCESpawningUpdateRushEscorts.stageLimit:1);
    const alive=RG.enemies.filter(e=>e.rushEscort&&!e.dead&&!e.dying),keys=b.escortKeys||RG.rushEscortKeys(b.bossKind);
    b.escortT=alive.length<stageLimit?(d.id===3?cfgBALANCESpawningUpdateRushEscorts.escortT_2:cfgBALANCESpawningUpdateRushEscorts.escortT_3):(d.id===3?cfgBALANCESpawningUpdateRushEscorts.escortT:cfgBALANCESpawningUpdateRushEscorts.escortT_4);
    if(alive.length<stageLimit){
      const index=b.escortIndex||0,k=keys[phase===1?0:index%cfgBALANCESpawningUpdateRushEscorts.k===cfgBALANCESpawningUpdateRushEscorts.k_2?1:0],m=RG.spawnEnemy(k,false),scale=1+(RG.run.rushLv-1)*cfgBALANCESpawningUpdateRushEscorts.scale_factor;
      b.escortIndex=index+1;
      m.rushEscort=true;m.squadId="rush-"+RG.run.rushLv;m.hp*=scale;m.maxhp=m.hp;m.dmg*=d.dmg;m.xp*=cfgBALANCESpawningUpdateRushEscorts.xp;
    }
  };
  // BOSS 模板:主线 spawnBoss 与连战模式共用;cycle=周目(技能组逐层解锁),rush=连战强化技能组
  RG.makeBoss = function (n, rush) {
    const ang = rand(0, TAU), R = Math.hypot(RG.W, RG.H) / cfgBALANCESpawningMakeBoss.R_divisor + cfgBALANCESpawningMakeBoss.R_offset;
    const m=Math.min(cfgBALANCESpawningMakeBoss.m_cap,RG.run.t/60),scale=rush?1:1+cfgBALANCESpawningMakeBoss.scale_factor*m+cfgBALANCESpawningMakeBoss.scale_factor_2*m*m;
    const difficulty=RG.rushDifficulty(RG.run.rushDifficulty||RG.meta?.rushDifficulty||1);
    const hp=rush?RG.rushBossHp(n,difficulty.id):cfgBALANCESpawningMakeBoss.hp_factor*Math.pow(n,cfgBALANCESpawningMakeBoss.hp_powArg2)*scale;
    const cycle = rush ? 1 : Math.ceil(n / cfgBALANCESpawningMakeBoss.cycle_divisor);
    const b = {
      type: "boss", name: RG.BOSS_NAMES[(n - 1) % 8] + (rush ? "" : (n > 8 ? "·" + Math.ceil(n / 8) + "周目" : "")),
      pattern: ((n - 1) % cfgBALANCESpawningMakeBoss.pattern) + 1, bossKind: RG.BOSS_KINDS[(n - 1) % cfgBALANCESpawningMakeBoss.bossKind],
      x: RG.P.x + Math.cos(ang) * R, y: RG.P.y + Math.sin(ang) * R,
      // 体型/移速按 BOSS 种类分化(用户反馈:不同 BOSS 不该一个模子):暴食中速中体 / 魔像超大慢肉 / 深渊之眼小而快 / 终焉中大体 / 镜像中速 / 领域中速 / 熔炉极慢极大体 / 虚空中速
      r: [cfgBALANCESpawningMakeBoss.r, cfgBALANCESpawningMakeBoss.r_2, cfgBALANCESpawningMakeBoss.r_3, cfgBALANCESpawningMakeBoss.r_4, cfgBALANCESpawningMakeBoss.r_5, cfgBALANCESpawningMakeBoss.r_6, cfgBALANCESpawningMakeBoss.r_7, cfgBALANCESpawningMakeBoss.r_8][(n - 1) % cfgBALANCESpawningMakeBoss.r_9] + (n - 1) * cfgBALANCESpawningMakeBoss.r_factor,
      hp, maxhp:hp,
      speed: RG.enemyContractSpeed([cfgBALANCESpawningMakeBoss.speed, cfgBALANCESpawningMakeBoss.speed_2, cfgBALANCESpawningMakeBoss.speed_3, cfgBALANCESpawningMakeBoss.speed_4, cfgBALANCESpawningMakeBoss.speed_5, cfgBALANCESpawningMakeBoss.speed_6, cfgBALANCESpawningMakeBoss.speed_7, cfgBALANCESpawningMakeBoss.speed_8][(n - 1) % cfgBALANCESpawningMakeBoss.speed_9] + n * cfgBALANCESpawningMakeBoss.speed_factor), dmg: rush?RG.rushBossDamage(n,difficulty.id):cfgBALANCESpawningMakeBoss.dmg_offset+n*cfgBALANCESpawningMakeBoss.dmg_factor, xp: cfgBALANCESpawningMakeBoss.xp,
      flash: 0, hitCds: {}, boss: true, elite: false, ranged: false, slow: false, homing: false, ghost: true,
      life: 0, vx: 0, vy: 0, frozen: 0, alpha: 1,
      // 主线与连战共用首轮错峰：先看到核心攻击，再逐步展示位移和辅助招式。
      burstT:n===4?cfgBALANCESpawningMakeBoss.burstT:cfgBALANCESpawningMakeBoss.burstT_2,chargeT:n===4?cfgBALANCESpawningMakeBoss.chargeT:n===7?cfgBALANCESpawningMakeBoss.chargeT_2:cfgBALANCESpawningMakeBoss.chargeT_3,charging:0,slamT:cfgBALANCESpawningMakeBoss.slamT,spiralA:rand(0,TAU),spiralT:rush?cfgBALANCESpawningMakeBoss.spiralT:cfgBALANCESpawningMakeBoss.spiralT_2,summonT:cfgBALANCESpawningMakeBoss.summonT,enraged:false,
      navT: 0, steerA: null,
      // v8.5 技能组:周目(cycle)解锁 W2/W3;狂暴阈值随周目提前;弹速随周目 +8%/周目
      cycle, spdMul: 1 + cfgBALANCESpawningMakeBoss.spdMul_factor * (cycle - 1), enrageAt:rush?cfgBALANCESpawningMakeBoss.enrageAt:n<=cfgBALANCESpawningMakeBoss.enrageAt_threshold?cfgBALANCESpawningMakeBoss.enrageAt:cfgBALANCESpawningMakeBoss.enrageAt_2,
      mechanicsTier:rush?cfgBALANCESpawningMakeBoss.mechanicsTier:n<=cfgBALANCESpawningMakeBoss.mechanicsTier_threshold?cfgBALANCESpawningMakeBoss.mechanicsTier_2:n<=cfgBALANCESpawningMakeBoss.mechanicsTier_threshold_2?cfgBALANCESpawningMakeBoss.mechanicsTier:1,attackMul:rush?difficulty.attack:n<=cfgBALANCESpawningMakeBoss.attackMul_threshold?cfgBALANCESpawningMakeBoss.attackMul:1,
      hunT:cfgBALANCESpawningMakeBoss.hunT,veinT:cfgBALANCESpawningMakeBoss.veinT,starT:cfgBALANCESpawningMakeBoss.starT,rockT:cfgBALANCESpawningMakeBoss.rockT,gazeT:cfgBALANCESpawningMakeBoss.gazeT,tpT:cfgBALANCESpawningMakeBoss.tpT,echoT:cfgBALANCESpawningMakeBoss.echoT,miT:cfgBALANCESpawningMakeBoss.miT,domT:cfgBALANCESpawningMakeBoss.domT,warpT:cfgBALANCESpawningMakeBoss.warpT,waveT:cfgBALANCESpawningMakeBoss.waveT,shwaveT:cfgBALANCESpawningMakeBoss.shwaveT,mwaveT:cfgBALANCESpawningMakeBoss.mwaveT,domShotT:cfgBALANCESpawningMakeBoss.domShotT,fbigT:cfgBALANCESpawningMakeBoss.fbigT,
      baitA: false, s1: false, s2: false, s3: false, pupA: false, furSplit: false, _chPrev: 0,
    };
    // 种类补正:魔像更肉 +25%,深渊之眼更脆但更快已体现,血 -15%
    if (!rush && b.bossKind === "golem") { b.hp *= cfgBOSS_SKILLSGolemMakeBoss.hp; b.maxhp *= cfgBOSS_SKILLSGolemMakeBoss.maxhp; }
    if (!rush && b.bossKind === "eye") { b.hp *= cfgBOSS_SKILLSEyeMakeBoss.hp; b.maxhp *= cfgBOSS_SKILLSEyeMakeBoss.maxhp; }
    if (!rush && b.bossKind === "gluttony") { b.hp += cfgBOSS_SKILLSGluttonyMakeBoss.hp; b.maxhp += cfgBOSS_SKILLSGluttonyMakeBoss.maxhp; }
    // 三档首发时间也区分；预警与攻击持续时长仍按真实秒数运行。
    if(rush)for(const key of ['burstT','chargeT','slamT','summonT','hunT','veinT','starT','rockT','gazeT','tpT','echoT','waveT','shwaveT','domShotT','fbigT'])b[key]*=difficulty.attack;
    // 新 BOSS 专属字段初始化
    if (b.bossKind === "mirror") RG.initFrostBoss(b);
    if (b.bossKind === "domain") { b.domT = RG.BOSS_SKILLS.domain.makeBoss.domT_factor*(rush?difficulty.attack:1); b.domPhase = 0; }
    if (b.bossKind === "furnace") { b.heat = 0; b.fireT = 0; b.overT = RG.BOSS_SKILLS.furnace.makeBoss.overT; b.overWarned = false; }
    if (b.bossKind === "void") { const pace=rush?difficulty.attack:1;b.warpT = cfgBOSS_SKILLSVoidMakeBoss.warpT_factor*pace; b.whT = cfgBOSS_SKILLSVoidMakeBoss.whT_factor*pace; b.whRead = cfgBOSS_SKILLSVoidMakeBoss.whRead_factor*pace; }
    return b;
  };
  RG.spawnBoss = function () {
    const map=RG.mapConfig();if(RG.run.bossNum>=map.bosses.length)return;
    RG.run.bossNum++;
    const seq=RG.run.bossNum,n=map.bosses[seq-1];
    RG.run.nextBossAt=map.times[seq]??map.finalAt;RG.run.bossT=Math.max(0,RG.run.nextBossAt-RG.run.t);
    const b = RG.makeBoss(n, false);
    b.bossNumber = n;
    b.mapBossNumber=seq;
    if(map.bossHp){b.hp=b.maxhp=map.bossHp[seq-1];b.dmg=map.bossDmg[seq-1];b.r=[cfgBALANCESpawningSpawnBoss.r,cfgBALANCESpawningSpawnBoss.r_2,cfgBALANCESpawningSpawnBoss.r_3][seq-1];}
    if(map.id==='workshop'&&seq===map.bosses.length){b.final=true;RG.run.finalBoss=b;}
    // v8.17(玩家反馈):BOSS 登场不再清杀全场小怪——刷怪导演暂停至 BOSS 死亡,存量怪继续在场游弋
    RG.pushOutOfWalls(b, RG.walls); RG.constrain(b);
    RG.enemies.push(b); RG.run.boss = b;
    RG.cam.shake = 18; RG.bossRoar();
    RG.bossIntro = cfgBALANCESpawningSpawnBoss.bossIntro; RG.bossIntroName = b.name;
    RG.addText(b.x, b.y - 60, "! " + b.name + " 出现!", "#ff5470", 18);
  };
  RG.spawnTrap = (x, y, big) => RG.hazards.push({ x, y, r: big === cfgBALANCESpawningSpawnTrap.r ? cfgBALANCESpawningSpawnTrap.r_2 : big ? cfgBALANCESpawningSpawnTrap.r_3 : cfgBALANCESpawningSpawnTrap.r_4, phase: "warn", t: cfgBALANCESpawningSpawnTrap.t, hitCd: 0, dur: big ? cfgBALANCESpawningSpawnTrap.dur : cfgBALANCESpawningSpawnTrap.dur_2 });   // v8.20:big=2 超大地刺(裂地魔像地脉用)

  // ---------- 钥匙 / 时停 / 秘境 ----------
  RG.spawnKeys = function () {
    RG.keyItems = [];
    for (let i = 0; i < 3; i++) {
      let x, y, k = 0;
      do { const a = rand(0, TAU), d = rand(cfgBALANCESpawningSpawnKeys.d_min, cfgBALANCESpawningSpawnKeys.d_max); x = Math.cos(a) * d; y = Math.sin(a) * d; k++; }
      while ((!RG.insideArena(x, y) || RG.blockedPoint(x, y)) && k < 60);
      RG.keyItems.push({ x, y, taken: false, bob: rand(0, TAU) });
    }
    RG.addText(RG.P.x, RG.P.y - 60, "钥 三把钥匙已散落地图,集齐触发秘境!", "#ffd166", 16);
    RG.playSfx("levelup");
  };
  RG.openPortal = function () {
    let x, y, k = 0;
    do { const a = rand(0, TAU), d = rand(cfgBALANCESpawningOpenPortal.d_min, cfgBALANCESpawningOpenPortal.d_max); x = Math.cos(a) * d; y = Math.sin(a) * d; k++; }
    while ((!RG.insideArena(x, y) || RG.blockedPoint(x, y)) && k < 60);
    RG.portal = { x, y, r: cfgBALANCESpawningOpenPortal.r, swirl: 0 };
    RG.timeStop = cfgBALANCESpawningOpenPortal.timeStop;
    RG.auraT = cfgBALANCESpawningOpenPortal.auraT; RG.auraPulse = 0;
    RG.addText(x, y - 50, "门 秘境之门已开启!时停 + 惩戒光环 15 秒!", "#c084fc", 18);
    RG.playSfx("timestop");
  };
  RG.enterRealm = function () {
    // 所有入口（含旧现场恢复后的调用）都先校验，封印时保留门与主线实体。
    if(RG.realmEntrySeal())return false;
    RG.clearActiveSceneEffects();
    RG.realm.active = true; RG.realm.lv++;
    RG.playSfx("realm");
    if (RG.setAmbient) RG.setAmbient("vault");   // P3 环境音通道(素材缺省时静默)
    RG.realm.mainWalls = RG.walls; RG.realm.mainBoundary = RG.boundary;
    RG.realm.mainPos = { x: RG.P.x, y: RG.P.y };
    // 5×5 → 15×15 格秘境(96px/格),外墙 + 4 内柱,中心留空
    const walls = [], C = cfgBALANCESpawningEnterRealm.C, N = cfgBALANCESpawningEnterRealm.N, half = N * C / cfgBALANCESpawningEnterRealm.half_divisor;
    walls.push({ x: -half, y: -half, w: N * C, h: cfgBALANCESpawningEnterRealm.h });
    walls.push({ x: -half, y: half - 36, w: N * C, h: cfgBALANCESpawningEnterRealm.h });
    walls.push({ x: -half, y: -half, w: cfgBALANCESpawningEnterRealm.w, h: N * C });
    walls.push({ x: half - 36, y: -half, w: cfgBALANCESpawningEnterRealm.w, h: N * C });
    for (const [cx, cy] of [[cfgBALANCESpawningEnterRealm.enterRealm, cfgBALANCESpawningEnterRealm.enterRealm], [cfgBALANCESpawningEnterRealm.enterRealm_2, cfgBALANCESpawningEnterRealm.enterRealm], [cfgBALANCESpawningEnterRealm.enterRealm, cfgBALANCESpawningEnterRealm.enterRealm_2], [cfgBALANCESpawningEnterRealm.enterRealm_2, cfgBALANCESpawningEnterRealm.enterRealm_2]])
      walls.push({ x: -half + cx * C + 8, y: -half + cy * C + 8, w: C - cfgBALANCESpawningEnterRealm.w_offset, h: C - cfgBALANCESpawningEnterRealm.h_offset });
    RG.walls = walls; RG.rebuildWallGrid(RG.walls);
    RG.boundary = { pts: [{ x: -half, y: -half }, { x: half, y: -half }, { x: half, y: half }, { x: -half, y: half }] };
    RG.enemies = []; RG.ebullets = []; RG.bullets = []; RG.booms = []; RG.hazards = [];
    RG.hbeams=[];RG.voltBeams=[];RG.run.amplifierPresent=false;
    RG.gems = []; RG.keyItems = []; RG.portal = null;
    RG.P.x = 0; RG.P.y = half - 70;
    RG.realm.orbT = cfgBALANCESpawningEnterRealm.orbT;
    for (let i = 0; i < 2; i++) RG.orbs.push({ x: rand(-half + 120, half - 120), y: rand(-half + 120, half - 120), r: cfgBALANCESpawningEnterRealm.r, heal: cfgBALANCESpawningEnterRealm.heal });
    const lv = RG.realm.lv;
    const b = {
      type: "boss", name: RG.BOSS_INFO.guard.name+'·第' + lv + "钥印", pattern: 0, bossKind: "guard", guardSkin:(lv-1)%cfgBALANCESpawningEnterRealm.guardSkin,
      x: 0, y: -40, r: cfgBALANCESpawningEnterRealm.r_2,
      ...RG.realmBossStats(lv,RG.run.t),
      speed: RG.enemyContractSpeed(cfgBALANCESpawningEnterRealm.speed_offset + lv * cfgBALANCESpawningEnterRealm.speed_factor), xp: cfgBALANCESpawningEnterRealm.xp,
      flash: 0, hitCds: {}, boss: true, elite: false, ranged: false, slow: false, homing: false, ghost: true,
      life: 0, vx: 0, vy: 0, frozen: 0, alpha: 1,
      burstT: cfgBALANCESpawningEnterRealm.burstT, chargeT: cfgBALANCESpawningEnterRealm.chargeT, charging: 0, slamT: cfgBALANCESpawningEnterRealm.slamT, spiralA: 0, spiralT: cfgBALANCESpawningEnterRealm.spiralT, summonT: cfgBALANCESpawningEnterRealm.summonT, enraged: false,
      navT: 0, steerA: null, realmBoss: true, isClone: false, realmPhase:1, keyT:cfgBALANCESpawningEnterRealm.keyT, gridT:cfgBALANCESpawningEnterRealm.gridT, realmOrbT:cfgBALANCESpawningEnterRealm.realmOrbT,resists:RG.randomGuardResists(),
    };
    RG.enemies.push(b); RG.run.boss = b;
    RG.cam.x = 0; RG.cam.y = 0;
    RG.addText(0, -140, "⚡ 秘境 " + lv + ":击破三重钥印,获得传说被动三选一!", "#c084fc", 18);
    RG.bossRoar(); RG.cam.shake = 14;
    RG.bossIntro = cfgBALANCESpawningEnterRealm.bossIntro; RG.bossIntroName = b.name;
    return true;
  };
  RG.exitRealm = function () {
    RG.clearActiveSceneEffects();
    RG.realm.active = false;
    if (RG.setAmbient) RG.setAmbient(null);
    RG.walls = RG.realm.mainWalls; RG.rebuildWallGrid(RG.walls); RG.boundary = RG.realm.mainBoundary;
    RG.P.x = RG.realm.mainPos.x; RG.P.y = RG.realm.mainPos.y;
    RG.enemies = []; RG.ebullets = [];
    RG.hbeams=[];RG.voltBeams=[];RG.run.amplifierPresent=false;
    RG.run.boss = null;
    const P = RG.P;
    P.iTimer = cfgBALANCESpawningExitRealm.iTimer;
    const canHeal = !P.healBan && !P.hpLocked && !P.healBlocked;
    if (canHeal) P.hp = Math.min(P.maxhp, P.hp + P.maxhp * cfgBALANCESpawningExitRealm.hp_factor);
    RG.addText(P.x, P.y - 50, "秘境通关!" + (canHeal ? "回复 30% 生命," : "") + "无敌 5 秒", "#c084fc", 16);
    RG.addCoin(cfgBALANCESpawningExitRealm.exitRealm_addCoinArg1);
    RG.run.keyT = RG.mapConfig().keyRepeat;
    // v8.17(玩家反馈):出秘境不再瞬间全屏刷怪——14s 梯度进场(前 5s 完全安静,之后渐强),
    // 精英/狼群/陷阱顺延到缓冲结束后,BOSS 计时保底 20s 给玩家喘息
    RG.run.rampT = cfgBALANCESpawningExitRealm.rampT;
    RG.run.bossDelayUntil=RG.run.t+cfgBALANCESpawningExitRealm.bossDelayUntil_offset;
    RG.run.bossT = Math.max((RG.run.nextBossAt||cfgBALANCESpawningExitRealm.bossT)-RG.run.t,cfgBALANCESpawningExitRealm.bossT_floor);
    RG.run.squad = null; RG.run.squadT = 0;
  };

  // 45 分钟最终 BOSS:击杀通关；之后每 5 分钟可再挑战(更强)。
  RG.spawnFinalBoss = function () {
    if(RG.run.mapId==='workshop'){
      const map=RG.mapConfig(),b=RG.makeBoss(cfgBALANCESpawningSpawnFinalBoss.b_makeBossArg1,false),mul=1+RG.run.finalStacks*cfgBALANCESpawningSpawnFinalBoss.mul_factor;
      b.hp=b.maxhp=map.bossHp[2]*mul;b.dmg=map.bossDmg[2];b.r=cfgBALANCESpawningSpawnFinalBoss.r;b.final=true;b.bossNumber=cfgBALANCESpawningSpawnFinalBoss.bossNumber;
      RG.pushOutOfWalls(b,RG.walls);RG.constrain(b);RG.enemies.push(b);RG.run.finalBoss=RG.run.boss=b;
      RG.bossIntro=cfgBALANCESpawningSpawnFinalBoss.bossIntro;RG.bossIntroName=b.name;RG.bossRoar();return;
    }
    const stacks = RG.run.finalStacks;
    const ang = rand(0, TAU), R = Math.hypot(RG.W, RG.H) / cfgBALANCESpawningSpawnFinalBoss.R_divisor + cfgBALANCESpawningSpawnFinalBoss.R_offset;
    const b = {
      type: "boss", name: RG.BOSS_INFO.devourer.name + (stacks > 0 ? "·" + (stacks + 1) + "阶" : ""),
      pattern: cfgBALANCESpawningSpawnFinalBoss.pattern, bossKind: "devourer", x: RG.P.x + Math.cos(ang) * R, y: RG.P.y + Math.sin(ang) * R, r: cfgBALANCESpawningSpawnFinalBoss.r_2,
      ...RG.finalBossStats(RG.run.t,stacks),
      speed: RG.enemyContractSpeed(cfgBALANCESpawningSpawnFinalBoss.speed_enemyContractSpeedArg1), xp: cfgBALANCESpawningSpawnFinalBoss.xp,
      flash: 0, hitCds: {}, boss: true, elite: false, ranged: false, slow: false, homing: false, ghost: true,
      life: 0, vx: 0, vy: 0, frozen: 0, alpha: 1,
      burstT: cfgBALANCESpawningSpawnFinalBoss.burstT, chargeT: cfgBALANCESpawningSpawnFinalBoss.chargeT, charging: 0, slamT: cfgBALANCESpawningSpawnFinalBoss.slamT, spiralA: rand(0, TAU), spiralT: 0, summonT: cfgBALANCESpawningSpawnFinalBoss.summonT, enraged: false,
      navT: 0, steerA: null, cloneT: cfgBALANCESpawningSpawnFinalBoss.cloneT, final: true,
    };
    RG.pushOutOfWalls(b, RG.walls); RG.constrain(b);
    RG.enemies.push(b); RG.run.finalBoss = b;RG.run.boss=b;
    RG.cam.shake = 20; RG.bossRoar();
    RG.bossIntro = cfgBALANCESpawningSpawnFinalBoss.bossIntro_2; RG.bossIntroName = b.name;
    RG.addText(RG.P.x, RG.P.y - 80, "! 终局挑战 —— " + b.name + " 降临!", "#ff5470", 20);
  };

  // 直接测试:T 键 / ?testmobs=1 在玩家周围刷三只新怪
  RG.spawnTestMobs = function () {
    if (!RG.P || !RG.run) return;
    const types = ["stalker", "crystal", "howler"];
    types.forEach((typeKey, i) => {
      const e = RG.spawnEnemy(typeKey, false);
      const a = (i / types.length) * Math.PI * 2 + (RG.run.t || 0);
      e.x = RG.P.x + Math.cos(a) * (140 + i * 30);
      e.y = RG.P.y + Math.sin(a) * (140 + i * 30);
      RG.pushOutOfWalls(e, RG.walls);
    });
    RG.addText(RG.P.x, RG.P.y - 50, "测试:潜伏者 / 结晶魔 / 哀嚎者", "#67e8f9", 14, { pop: true, life: 1.2 });
  };
  RG.SYSTEM_SPAWNING_VER="v12031";
})(window.RG);
