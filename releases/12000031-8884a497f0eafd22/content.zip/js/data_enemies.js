// ============ 数据:怪物与 BOSS(移速差异化拉大/周期制刷新 v8.17) ============
(function (RG) {
  // 移速设计(v7.4 拉开梯度):巨像 17(极慢极肉) < 布鲁特 34 < 寒霜 40 < 喷吐 44 < 游荡 50 < 疾行 142 < 怨灵 195(追踪极快)
  // weight(t)用于首次亮相门槛，此后不归零；每局常客与组合由systems_spawning.js确定。
  //   · 生命、伤害、经验随整局时间平滑成长，四首领后的周目乘算已取消。
  //   · 基础fieldCap限制功能怪数量，主力上限由生成模块随时间小幅增加。
  //   · burst = 导演每批生成数量(群怪成批,单体零散);fieldCap = 该类怪场上限(差异化冷却,大体型/功能怪低上限)。
  RG.ETYPES = {
    colossus: { name: "巨像",     hp: 383, speed: 17,  dmg: 32, r: 30, color: "#7f1d1d", xp: 24, weight: t => t >= 280 ? 2 : 0, fieldCap: 2, res:{elec:-.25,poison:.10,earth:.70} },
    brute:    { name: "巨壳兽",   hp: 103, speed: 34,  dmg: 22, r: 22, color: "#ef4444", xp: 8,  weight: t => t >= 140 ? 3 : 0, fieldCap: 10, res:{ice:-.10,poison:-.15,earth:.30} },
    ice:      {rules:{
  "weaponElementHit": {
    "weaponElementHit": 1.8
  }
}, name: "寒霜吐息", hp: 29,  speed: 40,  dmg: 6,  r: 12, color: "#7dd3fc", xp: 3,  weight: t => t >= 178 ? 5 : 0, ranged: true, slow: true, burst: 2, res:{fire:-.30,ice:.70} },
    shooter:  { name: "喷吐者",   hp: 27,  speed: 44,  dmg: 7,  r: 12, color: "#f59e0b", xp: 2,  weight: t => t >= 110 ? 5 : 0, ranged: true, res:{elec:-.15,poison:.20} },
    grunt:    { name: "游荡者",   hp: 21,  speed: 50,  dmg: 9,  r: 13, color: "#c26db2", xp: 1,  weight: t => t >= 0 ? 10 : 0, burst: 2, res:{} },
    swarm:    { name: "疾行虫",   hp: 12,   speed: 142, dmg: 6,  r: 9,  color: "#6ee7b7", xp: 1,  weight: t => t >= 60 ? 8 : 0, burst: 3, res:{fire:-.20,ice:.10,poison:.15} },
    healer:   {rules:{
  "updateEnemies": {
    "healT": 2.5,
    "value_threshold": 170,
    "hp_factor": 0.08,
    "healCd": 4
  }
}, name: "唤生者",   hp: 43,  speed: 38,  dmg: 0,  r: 16, color: "#b14fe8", xp: 5,  weight: t => t >= 165 ? 4 : 0, support: true, keep: 170, fieldCap: 3, res:{elec:-.20,poison:.30} },
    bomber:   {rules:{
  "spawnSquadCap": {
    "index_threshold": 2,
    "spawnSquadCap_offset": 3,
    "spawnSquadCap_divisor": 1800
  },
  "updateEnemies": {
    "navT": 0.22,
    "value_45_offset": 45,
    "value_22_factor": 22,
    "value_factor": 0.12,
    "fire_offset": 20,
    "fire_factor": 0.4,
    "applyElementOutput_applyElementOutputArg3": 3
  }
}, name: "引爆者",   hp: 30,  speed: 168, dmg: 22, r: 12, color: "#f97316", xp: 3,  weight: t => t >= 95 ? 4 : 0, fuse: true, fieldCap: 8, res:{fire:.70,ice:-.30} },
    summoner: {rules:{
  "makeSpawnSquad": {
    "batchMul": 0.65
  }
}, name: "唤兽祭司", hp: 58,  speed: 25,  dmg: 0,  r: 18, color: "#8b5cf6", xp: 8,  weight: t => t >= 230 ? 3 : 0, support: true, keep: 260, fieldCap: 2, res:{fire:-.15,elec:.10,poison:.25} },
    splitter: {rules:{
  "killEnemy": {
    "hp": 0.25,
    get maxhp(){return this.hp;},
    "r": 0.7,
    "xp_factor": 0.3,
    "n": 3,
    "n_2": 2,
    "hp_2": 0.35,
    "maxhp_2": 0.35,
    "r_2": 8,
    "speed_enemyContractSpeedArg1": 125,
    "dmg": 0.45
  }
}, name: "母巢生物", hp: 67,  speed: 30,  dmg: 14, r: 20, color: "#a3e635", xp: 6,  weight: t => t >= 130 ? 4 : 0, splitMob: true, fieldCap: 4, res:{fire:-.25,poison:.40,earth:.10} },
    homing:   {rules:{
  "updateEnvyPower": {
    "envyCd": 8,
    "envyCd_2": 14,
    "n": 3,
    "n_2": 24,
    "value_factor": 0.18,
    "value": 32,
    "value_2": 18
  }
}, name: "怨灵",     hp: 27,  speed: 195, dmg: 15, r: 11, color: "#e0d0ff", xp: 3,  weight: t => t >= 190 ? 5 : 0, homing: true, life: 12, ghost: true, fieldCap: 6, res:{ice:.30,elec:.10,earth:-.25} },
    hound:    {rules:{
  "enemyCastDamageMul": {
    "enemyCastDamageMul": 0.6
  },
  "updateEnemies": {
    "chargeCd": 1.2,
    "d_threshold": 520,
    "chargeCd_2": 3
  }
}, name: "冲锋犬",   hp: 47,  speed: 82,  dmg: 18, r: 14, color: "#f97316", xp: 4,  weight: t => t >= 45 ? 5 : 0, fieldCap: 8, res:{fire:.10,ice:-.20,earth:.10} },
    bulwark:  {rules:{
  "hurtEnemy": {
    "range_threshold": 1.05,
    "chance_threshold": 0.2
  },
  "updateEnemies": {
    "stop": 145,
    "gx_factor": 62,
    "gy_factor": 62,
    "stop_2": 18,
    "lag_threshold": 90,
    "speed_cap": 1.35,
    "speed_offset": 90,
    "speed_divisor": 260,
    "speed_factor": 0.35,
    "face_factor": -1.15,
    "face_factor_2": 1.15
  }
}, name: "盾兽",     hp: 243, speed: 24,  dmg: 0,  r: 28, color: "#94a3b8", xp: 12, weight: t => t >= 125 ? 2 : 0, fieldCap: 3, res:{elec:-.20,earth:.50} },
    flamer:   {rules:{
  "updateEnemies": {
    "flameCd": 1.8,
    "vx_factor": 145,
    "vy_factor": 145,
    "r": 16,
    "dmg_factor": 1.15,
    "life": 5,
    "dir_threshold": 310,
    "dir_threshold_2": 230,
    "d_threshold": 540,
    "flameCd_2": 3.6,
    "flameWind": 1.2
  }
}, name: "喷火兽",   hp: 89,  speed: 34,  dmg: 20, r: 20, color: "#fb923c", xp: 8,  weight: t => t >= 150 ? 3 : 0, fieldCap: 4, res:{fire:.70,ice:-.30} },
    smasher:  {rules:{
  "enemyCastDamageMul": {
    "enemyCastDamageMul": 0.5
  },
  "updateEnemies": {
    "slamCd": 2.2,
    "slamGuardT": 0.9,
    "d_threshold": 245,
    "slamCd_2": 4.5,
    "d_threshold_2": 120
  }
}, name: "捶地兽",   hp: 193, speed: 30,  dmg: 28, r: 27, color: "#a16207", xp: 13, weight: t => t >= 205 ? 2 : 0, fieldCap: 3, res:{ice:-.20,earth:.60} },
    volt:     {rules:{
  "updateEnemies": {
    "voltCd": 2,
    "dir_threshold": 310,
    "dir_threshold_2": 230,
    "d_threshold": 560,
    "voltCd_2": 3.5,
    "voltCastT": 0.92,
    "L_cap": 480,
    "points_divisor": 3,
    "points_factor": 70,
    "points_factor_2": 2,
    "warn": 0.7,
    "fire": 0.22
  }
}, name: "电击兽",   hp: 75,  speed: 48,  dmg: 18, r: 17, color: "#22d3ee", xp: 9,  weight: t => t >= 250 ? 3 : 0, fieldCap: 4, ranged: true, res:{elec:.70,poison:-.20} },
    // ---- v11.7 新怪 ----
    stalker:  {rules:{
  "updateEnemies": {
    "stalkCd": 2.4,
    "d_threshold": 260
  }
}, name: "潜伏者",   hp: 59,  speed: 90,  dmg: 22, r: 14, color: "#c084fc", xp: 7,  weight: t => t >= 120 ? 3 : 0, fieldCap: 5, res:{ice:-.15,elec:.20,poison:.10} },
    crystal:  { name: "结晶魔",   hp: 133, speed: 28,  dmg: 16, r: 22, color: "#a5f3fc", xp: 10, weight: t => t >= 200 ? 2 : 0, fieldCap: 3, res:{ice:.65,fire:-.25,earth:.25} },
    howler:   {rules:{
  "updateEnemies": {
    "want": 230,
    "dir_offset": 40,
    "howlCd": 2.6,
    "howlCd_2": 4.2,
    "layer_threshold": 3
  }
}, name: "哀嚎者",   hp: 41,  speed: 42,  dmg: 8,  r: 13, color: "#f0abfc", xp: 6,  weight: t => t >= 160 ? 4 : 0, fieldCap: 4, ranged: true, slow: true, res:{elec:-.25,poison:.15,earth:.10} },
    prism:    { name: "棱镜哨兵", hp: 58, speed: 32, dmg: 12, r: 17, color: "#67e8f9", xp: 7, weight: t=>t>=90?3:0, fieldCap:2, strictCap:true, noElite:true, ranged:true, res:{elec:.30,earth:-.20} },
    amplifier:{rules:{
  "updateEnemies": {
    "dir_threshold": 270,
    "dir_threshold_2": 210
  }
}, name: "增幅炉", hp: 79, speed: 22, dmg: 0, r: 21, color: "#fbbf24", xp: 9, weight:t=>t>=180?2:0, fieldCap:1, strictCap:true, noElite:true, support:true, keep:240, res:{ice:-.25,fire:.30} },
    scavenger:{name:"拾荒机",hp:18,speed:105,dmg:6,r:11,color:"#d9ad62",xp:2,weight:t=>t>=45?5:0,fieldCap:10,strictCap:true,noElite:true,meadow:true,res:{elec:-.20}},
    sporepod:{rules:{
  "killEnemy": {
    "length_threshold": 6,
    "r": 65,
    "t": 1.2,
    "dur": 0.25
  }
},name:"虚空孢囊",hp:35,speed:42,dmg:10,r:18,color:"#a3db70",xp:3,weight:t=>t>=25?6:0,fieldCap:16,strictCap:true,noElite:true,meadow:true,res:{fire:-.25,poison:.40}},
    warder:{rules:{
  "updateMeadowMob": {
    "updateMeadowMob_moveArg1": 220,
    "meadowCd": 5,
    "updateMeadowMob_factor": 180,
    "shieldHp_factor": 0.15
  }
},name:"结界官",hp:66,speed:30,dmg:0,r:17,color:"#bd9bed",xp:7,weight:t=>t>=120?2:0,fieldCap:2,strictCap:true,noElite:true,meadow:true,res:{elec:-.20}},
    tether:{rules:{
  "updateMeadowMob": {
    "updateMeadowMob_factor": 80,
    "slowT": 0.4,
    "tetherGuardT": 3,
    "updateMeadowMob_moveArg1": 280,
    "d_threshold": 520,
    "meadowCd": 6
  }
},name:"牵引者",hp:52,speed:36,dmg:0,r:16,color:"#86c6d0",xp:6,weight:t=>t>=210?2:0,fieldCap:2,strictCap:true,noElite:true,meadow:true,res:{earth:-.20}},
    mortar:{rules:{
  "updateMeadowMob": {
    "updateMeadowMob_moveArg1": 320,
    "d_threshold": 650,
    "length_threshold": 6,
    "meadowCd": 5.5,
    "r": 80,
    "t": 1.4,
    "dur": 0.25
  }
},name:"熔渣迫击兵",hp:60,speed:28,dmg:16,r:18,color:"#ef9c58",xp:6,weight:t=>t>=150?3:0,fieldCap:3,strictCap:true,noElite:true,ranged:true,meadow:true,res:{fire:.40,ice:-.25}},
    crucible:{rules:{
  "updateMeadowMob": {
    "d_threshold": 220,
    "meadowCd": 5,
    "updateMeadowMob_moveArg1": 90
  }
},name:"熔炉坩埚兵",hp:150,speed:27,dmg:21,r:25,color:"#c77543",xp:10,weight:t=>t>=90?3:0,fieldCap:8,strictCap:true,noElite:true,meadow:true,res:{fire:.40,ice:-.25,earth:.25}},
    phantasm:{rules:{
  "updateMeadowMob": {
    "dart": 5,
    "dart_threshold": 3.8,
    "updateMeadowMob": 1.55
  }
},name:"虚影",hp:23,speed:62,dmg:8,r:13,color:"#a9a0db",xp:1,weight:t=>t>=0?10:0,fieldCap:36,strictCap:true,noElite:true,meadow:true,res:{ice:.15,earth:-.15}},
  };

  // 技能参数与预警共用，确保显示范围等于实际判定。
  RG.MOB_SKILLS={hound:{distance:420,speed:600},bomber:{radius:135,eliteRadius:165,eliteHp:1.3,eliteDamage:1.25,fuse:.75},
    shooter:{wind:.5,eliteWind:.35,cd:[.8,1.4],eliteCd:[.6,1]},splitter:{generations:1,eliteGenerations:2},
    smasher:{radius:230,eliteRadius:280,wind:.7,eliteWind:.5,strike:.1,half:1.15,stun:.5},
    howler:{range:500,speed:440,interval:.28,debuff:5,minDamage:1,maxDamage:3},stalker:{wind:.7,recover:.6,offset:48,cd:3.2}};
  RG.enemyBodyRadius=e=>Math.max(12,e.r*1.45);
  RG.WORKSHOP_MOBS={prism:{range:600,width:12,warn:1.2,fire:.18,recover:.65,cd:4.8},amplifier:{radius:300,hold:.4,speed:1.15,damage:1.10}};

  RG.BOSS_RESISTS={
    gluttony:{fire:.20,poison:.50,earth:-.20},golem:{fire:.10,elec:-.25,poison:.20,earth:.60},
    eye:{ice:.20,elec:.40,poison:-.20},shadow:{ice:.40,elec:.20,earth:-.25},
    mirror:{fire:0,ice:.65,elec:0,poison:0,earth:0},domain:{fire:.30,ice:.30,poison:-.20,earth:.20},
    furnace:{fire:.60,ice:-.30,elec:.10,earth:.40},void:{fire:-.25,elec:.20,poison:.50},
    devourer:{fire:.25,ice:.25,elec:.25,poison:.25,earth:.25},
    heretic:{fire:-.30,ice:.30,elec:.15,poison:.15,earth:.35},
  };
  RG.randomGuardResists=function(){
    const ids=["fire","ice","elec","poison","earth"],out={};
    for(let i=ids.length-1;i>0;i--){const j=(Math.random()*(i+1))|0;[ids[i],ids[j]]=[ids[j],ids[i]];}
    out[ids[0]]=-.25;out[ids[1]]=.45;out[ids[2]]=.35;return out;
  };

  // 第五首领保留mirror内部标识与素材格，旧现场迁移后使用全新的寒冰技能组。
  RG.FROST_BOSS = {phaseAt:.5,speed:24,shieldEvery:25,shield:[.05,.20],corpseRange:720,contact:.35,
    field:{first:2,cd:4.5,warn:.8,length:460,width:160,grow:1.35,freeze:.5,damage:.18,life:.65},
    breath:{first:16,cd:13,warn:.25,interval:.2,count:[3,5],shots:[24,32],speed:230,damage:.06},
    slow:{first:8,cd:9,radius:[220,300],life:6},
    wall:{first:28,cd:23,warn:.6,radius:[175,210],thickness:18,life:10,count:3,gap:2}};
  // 终焉之影的弹幕降频覆盖主线、连战和影分身，冲撞/分身机制保留。
  RG.SHADOW_BOSS = {burst:[4,5.2],spiral:.24,miFirst:8,miCd:12,waveCd:8};
  RG.BOSS_NAMES = ["暴食之主", "裂地魔像", "深渊之眼", "终焉之影", "寒霜领主", "领域主宰", "巨械·熔炉核心", "虚空母巢"];
  RG.HERETIC_NAME = "渎圣者";
  // v11.7 第9首领:渎圣者(雕像/契约主题,神圣反噬)——仅秘境献祭小概率召唤为隐藏强敌,不进主线 8 循环
  RG.HERETIC_PATTERN = ["圣痕烙印", "忏悔锁链", "渎圣新星"];
  // v8.5:老四技能组重做后的描述(周目 2/3 会追加快慢辐射波/毒气/瞬移/多重激光/分裂/狂暴新招)
  RG.BOSS_PATTERN_DESC = ["吞噬引力+食饵", "双震地+地脉十字震爆", "凝视射线+米字狂暴", "影分身+米字影弹+Z字冲撞", "寒冰场+全向吐息+减速场+冻结尸体+冰墙；火与灼烧三倍", "减速领域+空间双门+小门弹幕+隐遁+远距黑洞+二阶段折射激光；反射玩家激光", "DPS检验+过热分裂", "虫洞空间控制"];
  // 首领身份与名称由生成、击败记录和图鉴共用；特殊首领不冒充连战关卡。
  RG.BOSS_KINDS=['gluttony','golem','eye','shadow','mirror','domain','furnace','void'];
  RG.BOSS_INFO=Object.fromEntries(RG.BOSS_KINDS.map((id,i)=>[id,{rushLevel:i+1,get name(){return RG.BOSS_NAMES[i];},get mechanism(){
    if(id!=='domain')return RG.BOSS_PATTERN_DESC[i];
    const s=RG.BOSS_SKILLS.domain.space;
    return `脚底减速领域；双门转移远程攻击（${s.pair.cd.join('—')}秒冷却，存在${s.pair.life}秒）；${s.small.count.join('—')}小门依次吐弹；消隐${s.vanish.life}秒前释放辐射弹；远距黑洞传送双方单位，近战重伤${s.hole.wound}秒。\n生命降至${s.phaseAt*100}%后${s.ultimateDelay}秒展开${s.ultimate.life}秒门阵：激光前摇${s.ultimate.warn}秒，持续${s.ultimate.laserLife}秒并反弹，每次有效命中回血${s.ultimate.heal*100}%，可以超过生命上限；停双门与小门。被动反射激光武器。`;
  }}]));
  Object.assign(RG.BOSS_INFO,{
    devourer:{name:'终焉·吞噬者',mechanism:'荒谷终局首领：冲锋、旋转弹幕与召唤交替施压；首次击败可通关，继续无尽后后续阶数更强。'},
    guard:{name:'秘境典狱官',mechanism:'秘境独立首领：随钥印阶段强化弹幕、锁界与追踪攻击；击败后获得传说被动并开放出口。',randomResists:true},
    heretic:{get name(){return RG.HERETIC_NAME;},mechanism:RG.HERETIC_PATTERN.join('、')+'；保留旧版隐藏首领图鉴记录。'}
  });
  RG.MEADOW_MOB_KEYS=['scavenger','sporepod','warder','tether','mortar','crucible','phantasm'];
  RG.DATA_ENEMIES_VER="v12031";
  // 首领各招式的实际参数；实例计时与状态不写回此表。
  RG.BOSS_SKILLS=RG.freezeConfig({
  "golem": {
  "makeBoss": {
    "hp": 1.25,
    get maxhp(){return this.hp;}
  },
  "updateBoss": {
    "bossPhaseAllows_bossPhaseAllowsArg2": 2,
    "maxhp_factor": 0.75,
    "stoneT": 2,
    "rand_min": 40,
    "rand_max": 160,
    "maxhp_factor_2": 0.5,
    "bossPhaseAllows_bossPhaseAllowsArg2_2": 3,
    "maxhp_factor_3": 0.25,
    "veinT_factor": 10,
    "value_factor": 170,
    "spawnTrap_spawnTrapArg3": 2,
    "s_threshold": 3,
    "sp_offset": 170,
    "sp_factor": 62,
    "r": 6,
    "dmg_factor": 0.5,
    "life": 4,
    "starT_factor": 6.5,
    "sa_divisor": 6,
    "value_factor_2": 130,
    "rockT_factor": 8,
    "bigShots_bigShotsArg2": 5,
    "bigShots_bigShotsArg3": 95,
    "bigShots_bigShotsArg4": 0.9,
    "bigShots_bigShotsArg5": 0.9,
    "slamT_min": 4,
    "slamT_max": 5.5,
    "slamEcho": 0.5,
    "value_threshold": 3,
    "poisonZone_poisonZoneArg3_2": 110,
    "poisonZone_poisonZoneArg4_2": 5,
    "dmg_factor_5": 0.35,
    "value": 3,
    "value_2": 2,
    "burstT_factor_2": 3.2,
    "value_8_offset": 8,
    "vx_factor_7": 160,
    "vy_factor_7": 160,
    "dmg_factor_2": 0.5
  },
  "puppetAttack": {
    "puppetAttack_offset": 180
  },
  "updateEnvyPower": {
    "envyCd": 12,
    "value_165_factor": 165
  }
},
  "eye": {
  "makeBoss": {
    "hp": 0.85,
    get maxhp(){return this.hp;}
  },
  "updateBoss": {
    "gazeT": 11,
    "gazeT_2": 10,
    "gazeT_3": 6,
    "len": 560,
    "dmg_factor": 0.6,
    "w": 22,
    "warn": 0.9,
    "fire": 0.28,
    "i_factor": 0.35,
    "fireHBeam_fireHBeamArg4": 700,
    "dmg_factor_2": 0.8,
    "fireHBeam_fireHBeamArg6": 26,
    "fireHBeam_fireHBeamArg7": 0.8,
    "tpT_factor": 9,
    "vx_factor": 200,
    "vy_factor": 200,
    "r": 6,
    "dmg_factor_3": 0.5,
    "life": 4,
    "orbT_factor": 3,
    "orbT_factor_2": 7,
    "homingShot_homingShotArg2": 4,
    "homingShot_homingShotArg3": 150,
    "homingShot_homingShotArg4": 0.5,
    "homingShot_homingShotArg6": 7
  },
  "puppetAttack": {
    "along_threshold": 400,
    "puppetAttack_offset": 8
  },
  "updateEnvyPower": {
    "envyCd": 14,
    "d_threshold": 520,
    "value_18_offset": 18,
    "value_135_factor": 135
  }
},
  "gluttony": {
  "makeBoss": {
    "hp": 300,
    get maxhp(){return this.hp;}
  },
  "updateBoss": {
    "hunT_factor": 10,
    "hunActive": 1.4,
    "hd_threshold": 380,
    "hd_threshold_2": 30,
    "bossPhaseAllows_bossPhaseAllowsArg2": 2,
    "maxhp_factor": 0.6,
    "maxhp_factor_2": 33,
    "maxhp_factor_3": 0.22,
    "value_70_factor": 70,
    "hp_factor": 0.04,
    "poisonZone_poisonZoneArg3": 90,
    "poisonZone_poisonZoneArg4": 6,
    "dmg_factor": 0.3,
    "waveT_factor": 5.5,
    "radialWaves_radialWavesArg2": 14,
    "dmg_factor_2": 0.45,
    "bigShots_bigShotsArg2": 3,
    "bigShots_bigShotsArg3": 150,
    "bigShots_bigShotsArg4": 0.8,
    "bigShots_bigShotsArg5": 0.55
  },
  "updateEnvyPower": {
    "envyCd": 12,
    "value_320_offset": 320,
    "value_115_factor": 115
  }
},
  "domain": {
  "space": {
    "phaseAt":0.5,"ultimateDelay":5,"moveStop":150,
    "slow":{"first":3,"cd":9,"radius":200,"life":6},
    "pair":{"first":5,"cd":[20,26],"life":7,"warn":0.21,"length":150,"offset":110,"exitMin":160,"exitMax":320},
    "small":{"first":10,"cd":23,"count":[5,7],"sequence":15,"life":3.9,"length":68,"distance":[150,320],"shotEvery":0.7,"speed":180,"damage":0.35,"shots":5,"spread":0.8,"homingTurn":1.8},
    "vanish":{"first":18,"cd":26,"life":2.6,"shots":36,"speed":230,"damage":0.45},
    "hole":{"distance":650,"cd":30,"life":11,"length":150,"offset":110,"wound":6},
    "ultimate":{"life":17,"count":14,"length":105,"radius":[160,570],"interval":[1.2,2.8],"initial":[0.1,2.4],"warn":0.4,"laserLife":3.6,"laserLength":2200,"width":3,"reflections":3,"tick":0.25,"damage":0.18,"heal":0.06},
    "teleportCooldown":0.5,"projectileCooldown":0.12,"exitPadding":28
  },
  "makeBoss": {
    "domT_factor": 5
  },
  "updateBoss": {
    "cyc_threshold": 2,
    "domShotT_factor": 3,
    "homingShot_homingShotArg3": 150,
    "homingShot_homingShotArg4": 0.5,
    "domT": 5,
    "burstT": 1.8,
    "burstT_2": 1.2,
    "speed_2": 150,
    "speed_3": 170,
    "damage": 0.4,
    "damage_2": 0.5,
    "r": 6,
    "life": 4,
    "spiralA_offset": 0.35,
    "domPhase": 2,
    "domT_factor": 8,
    "r_factor": 260,
    "r_2": 1.3,
    "t": 8,
    "value_threshold": 3,
    "r_3": 170,
    "domT_factor_2": 6,
    "r_factor_2": 200,
    "t_2": 6
  }
},
  "furnace": {
  "makeBoss": {
    "overT": 0.8
  },
  "updateBoss": {
    "cyc_threshold": 3,
    "fbigT_factor": 7,
    "bigShots_bigShotsArg2": 2,
    "bigShots_bigShotsArg3": 130,
    "bigShots_bigShotsArg4": 0.8,
    "bigShots_bigShotsArg5": 0.4,
    "chargeT_min": 4.5,
    "chargeT_max": 6,
    "phaseB_bossPhaseAllowsArg2": 2,
    "phaseB_factor": 0.7,
    "phaseC_bossPhaseAllowsArg2": 3,
    "phaseC_factor": 0.4,
    "heat": 100,
    "heat_cap": 100,
    "heat_factor": 3,
    "fireT": 2.5,
    "fireT_2": 0.3,
    "length_threshold": 12,
    "workshopPointFree_workshopPointFreeArg3": 36,
    "r_offset": 66,
    "r_4": 36,
    "t_3": 1.2,
    "dur": 1.5,
    "dmg_factor": 0.6,
    "heat_threshold": 100,
    "overT": 0.8,
    "value_300_factor": 300,
    "hurtPlayer_hurtPlayerArg1": 55,
    "value_threshold_2": 2,
    "bossRealSplit_bossRealSplitArg2": 2,
    "bossRealSplit_bossRealSplitArg3": 0.22
  },
  "receiveDamage": {
    "taken": 1.3
  },
  "hurtEnemy": {
    "heat_cap": 110,
    "heat_factor": 200
  }
},
  "void": {
  "makeBoss": {
    "warpT_factor": 5,
    "whT_factor": 2,
    "whRead_factor": 8
  },
  "receiveDamage": {
    "taken": 1.25
  },
  "updateEnemyBullets": {
    "aegisCleared_cap": 999
  },
  "updateBoss": {
    "burstT_factor": 2,
    "vx_factor_2": 200,
    "vy_factor_2": 200,
    "r": 6,
    "dmg_factor_2": 0.5,
    "life": 4,
    "warpT": 5,
    "warpT_factor": 5,
    "charging_2": 0.5,
    "vx_factor_3": 420,
    "vy_factor_3": 420,
    "bossPhaseAllows_bossPhaseAllowsArg2": 2,
    "maxhp_factor": 0.6,
    "whT": 2,
    "whT_2": 7,
    "whT_3": 6,
    "n2": 4,
    "n2_2": 3,
    "wx_min": 150,
    "wx_max": 420,
    "wy_min": 150,
    "wy_max": 420,
    "workshopPointFree_workshopPointFreeArg3_2": 60,
    "value_threshold_3": 120,
    "r_5": 60,
    "value_threshold_2": 2,
    "poisonZone_poisonZoneArg3": 95,
    "poisonZone_poisonZoneArg4": 6,
    "dmg_factor_3": 0.3,
    "whRead": 8,
    "length_threshold_2": 2,
    "whRead_factor": 8,
    "value_threshold": 3,
    "vx_factor_4": 210,
    "vy_factor_4": 210,
    "charging_3": 0.55,
    "vx_factor_5": 430,
    "vy_factor_5": 430
  }
},
  "shared": {
  "updateWorkshopRunes": {
    "hold_cap": 1.2,
    "hold_threshold": 1.2,
    "workshopRuneT": 8,
    "runeCd": 8,
    "runeCd_2": 22,
    "length_threshold": 3,
    "d_offset": 220,
    "d_divisor": 16,
    "updateWorkshopRunes_offset": 100,
    "updateWorkshopRunes_workshopPointFreeArg3": 60,
    "range_threshold": 150,
    "r": 60,
    "t": 9
  },
  "updateWorkshopValves": {
    "length_threshold": 4,
    "d_offset": 300,
    "d_divisor": 16,
    "updateWorkshopValves_workshopPointFreeArg3": 90,
    "updateWorkshopValves_offset": 150,
    "range_threshold": 240,
    "r": 90,
    "ready_threshold": 50,
    "available_sliceArg2": 2,
    "hold_cap": 1.2,
    "hold_threshold": 1.2,
    "valveCooldown": 25,
    "overT": 1.8,
    "coolingT": 6,
    "workshopColdT": 2.5,
    "workshopCoolT": 8
  },
  "closeWorkshopHole": {
    "workshopRiftT": 1.2
  },
  "updateWorkshopHoles": {
    "wormCd": 1.5,
    "length_threshold": 10,
    "r": 12,
    "hp": 25,
    get maxhp(){return this.hp;},
    "speed": 110,
    "dmg_factor": 0.4,
    "life": 5
  },
  "spawnWorkshopHoles": {
    "limit": 4,
    "limit_2": 3,
    "d_offset": 260,
    "d_divisor": 16,
    "workshopPointFree_workshopPointFreeArg3": 100,
    "value_threshold": 220,
    "value_threshold_2": 160,
    "r": 60,
    "hp": 400,
    get maxhp(){return this.hp;},
    "t": 7.5,
    "warn": 1.5,
    "wormCd": 1.5
  },
  "beginWorkshopWarp": {
    "r_factor": 1.45,
    "d_offset": 220,
    "d_divisor": 16,
    "d_factor": 70,
    "value_offset": 80
  },
  "updateWorkshopWarp": {
    "r_factor": 1.45,
    "t": 0.65,
    "charging": 0.5,
    "vx_factor": 420,
    "vy_factor": 420
  },
  "updateWorkshopHeat": {
    "coolingT": 6,
    "dmg_factor": 0.9,
    "heat_cap": 100,
    "heat_factor": 2,
    "heat_threshold": 100,
    "r": 240,
    "overT": 1.8
  },
  "updateBossProgress": {
    "extreme": 3,
    "phase_threshold": 28,
    "phase_threshold_2": 0.35,
    "phase_threshold_3": 55,
    "phase": 3,
    "phase_threshold_4": 12,
    "phase_threshold_5": 0.7,
    "phase_2": 2,
    "spdMul_factor": 0.08,
    "escortT": 8,
    "escortT_cap": 2.4
  },
  "clearFrostBoss": {
    "delay": 0.08
  },
  "updateFrostBoss": {
    "bossPhaseAllows_bossPhaseAllowsArg2": 2,
    "fightElapsed_threshold": 45,
    "phase": 2,
    "mechanicPhase_floor": 2,
    "value": -0.48,
    "value_2": 0.48,
    "r": 9,
    "life": 2.3,
    "offset_factor": 1.7
  },
  "updateRealmBoss": {
    "next_threshold": 0.3,
    "next": 3,
    "next_threshold_2": 0.6,
    "next_2": 2,
    "enraged": 3,
    "pull_offset": 160,
    "pull_factor": 0.55,
    "n": 18,
    "n_2": 22,
    "n_3": 26,
    "gap": 0.36,
    "vx_offset": 165,
    "vx_factor": 16,
    "vy_offset": 165,
    "vy_factor": 16,
    "r": 6,
    "dmg_factor": 0.52,
    "life": 5,
    "keyT": 1.4,
    "keyT_2": 4.2,
    "keyT_3": 3.6,
    "keyT_4": 3,
    "t": 0.8,
    "max": 0.8,
    "realmCastT": 0.8,
    "gridT": 4.2,
    "gridT_2": 7.5,
    "gridT_3": 6.5,
    "gridT_4": 5.5,
    "span": 1440,
    "w_offset": 22,
    "w_factor": 4,
    "dmg_factor_2": 0.72,
    "warn": 0.9,
    "fire": 0.28,
    "realmCastT_2": 0.9,
    "realmOrbT": 6,
    "realmOrbT_2": 9,
    "realmOrbT_3": 7.5,
    "value_125_offset": 125,
    "realmPhase_factor": 12,
    "homingShot_homingShotArg4": 0.44,
    "homingShot_homingShotArg6": 6
  },
  "updateBoss": {
    "f": 0.65,
    "mechanicsTier_threshold": 2,
    "phase_threshold": 3,
    "phase_threshold_2": 0.35,
    "phase": 3,
    "phase_threshold_3": 0.6,
    "phase_2": 2,
    "rushDifficulty": 3,
    "value": 3,
    "value_2": 2,
    "enrageAt": 0.3,
    "speed": 1.25,
    "charging": 0.9,
    "vx_factor": 460,
    "vy_factor": 460,
    "chargeT_min_2": 5,
    "chargeT_max_2": 7,
    "chargeWind": 0.55,
    "cloneT": 30,
    "dens": 0.62,
    "densN": 5,
    "r": 6,
    "life": 4,
    "vx_factor_2": 200,
    "vy_factor_2": 200,
    "W2_threshold": 2,
    "W3_threshold": 3,
    "burstT_min": 2.6,
    "burstT_max": 3.4,
    "n_offset": 10,
    "n_factor": 2,
    "vx_factor_6": 190,
    "vy_factor_6": 190,
    "dmg_factor_4": 0.55,
    "life_2": 5,
    "spiralA_factor": 3.3,
    "spiralT": 0.13,
    "spiralT_2": 0.8,
    "arms": 3,
    "arms_2": 2,
    "r_6": 5,
    "dmg_factor_6": 0.45,
    "summonT_factor": 7
  }
},
  "shadow": {
  "updateBoss": {
    "echoT": 8,
    "echoT_2": 12,
    "bossRealSplit_bossRealSplitArg3": 0.3,
    "vx_factor": 260,
    "vy_factor": 260,
    "r": 6,
    "dmg_factor": 0.5,
    "life": 4,
    "vx_offset": 0.11,
    "vx_factor_2": 130,
    "vy_offset": 0.11,
    "vy_factor_2": 130,
    "life_2": 6,
    "radialWaves_radialWavesArg2": 12,
    "dmg_factor_2": 0.4,
    "eTpT_factor": 5,
    "prog_divisor": 0.9,
    "lat_divisor": 3,
    "lat_divisor_2": 2,
    "lat_factor": 300
  },
  "killEnemy": {
    "range_threshold": 2,
    "killEnemy_poisonZoneArg3": 100,
    "killEnemy_poisonZoneArg4": 5,
    "killEnemy_factor": 0.3
  },
  "updatePlayerMovement": {
    "pd_offset": 34,
    "pd_factor": 2,
    "pd_factor_2": 0.18,
    "vx_factor": 390,
    "vy_factor": 390,
    "r": 5,
    "life": 1.1
  }
},
  "mirror": {
  "receiveDamage": {
    "dmg": 3
  }
}
});
  for(const data of [RG.ETYPES,RG.MOB_SKILLS,RG.WORKSHOP_MOBS,RG.BOSS_RESISTS,RG.FROST_BOSS,RG.SHADOW_BOSS,RG.MEADOW_MOB_KEYS,RG.BOSS_KINDS,RG.BOSS_INFO])RG.freezeConfig(data);
  // 实际投射/召唤数量；对应角度分布读取同一数量。
  RG.SPAWN_COUNTS=RG.freezeConfig({
  "affixSplit": 3,
  "bossSplit": 3,
  "envyShadow": 8,
  "domainRadial": 8,
  "voidFan": 8,
  "voidFission": 5,
  "gluttonyBait": 4,
  "golemCross": 4,
  "eyeRays": 8,
  "eyeRadial": 6,
  "shadowRadial": 8,
  "voidBrood": 3,
  "meadowPack": 4
});
})(window.RG);
