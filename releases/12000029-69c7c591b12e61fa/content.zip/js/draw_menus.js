// ============ 自适应像素界面：固定导航、按可用空间分页、共享文本与面板 ============
(function (RG) {
  const {ctx2:c, pixelRect, artReady, drawCover, drawUiIcon, drawCurrency, drawCardAtlasIcon, drawBossCell, BOSS_ATLAS_CELLS}=RG.DrawKit;
  const gold='#d9b879', ink='#e9e4d9', muted='#a6a7b5';
  RG.uiPages={}; RG.uiTabs={}; RG.uiNav=[]; RG.uiTextBoxes=[];
  // 字号以实际CSS像素计，避免固定卡片间距又被UIS二次放大。
  function font(n,b){c.font=(b?'bold ':'')+n+'px "PixelCN", "Microsoft YaHei", sans-serif';}
  function text(str,x,y,w,n=13,color=ink,b=false,align='left'){
    font(n,b); c.fillStyle=color;c.textAlign=align;c.textBaseline='alphabetic';
    let s=String(str==null?'':str);while(s.length>1&&c.measureText(s).width>w)s=s.slice(0,-2)+'…';
    // 奖励、余额与价格中的货币单位统一用生成金币，正文含义保留。
    const matches=[...s.matchAll(/\d[\d,.]*\s*金(?!币)|金\s*\d[\d,.]*/g)];
    if(matches.length){
      const parts=[];let cursor=0;for(const m of matches){if(m.index>cursor)parts.push({s:s.slice(cursor,m.index)});parts.push({money:m[0].replace(/[金\s]/g,'')});cursor=m.index+m[0].length;}if(cursor<s.length)parts.push({s:s.slice(cursor)});
      parts.forEach(p=>p.w=c.measureText(p.s??p.money).width+(p.money?n+5:0));const total=parts.reduce((v,p)=>v+p.w,0);let xx=align==='center'?x+(w-total)/2:align==='right'?x+w-total:x;
      const metrics=c.measureText(s),cy=y-((metrics.actualBoundingBoxAscent??n*.8)-(metrics.actualBoundingBoxDescent??n*.2))/2;
      for(const p of parts){if(p.money)drawCurrency(p.money,{x:xx,y:cy-(n+2)/2,w:p.w,h:n+2},{align:'left',padding:0,gap:3,iconSize:n+2,fontSize:n,color,bold:b});else{c.textAlign='left';c.fillText(p.s,xx,y);}xx+=p.w;}
    }else c.fillText(s,align==='center'?x+w/2:align==='right'?x+w:x,y);
    RG.uiTextBoxes.push({x,y:y-n,w:Math.min(w,c.measureText(s).width),h:n,text:s});
  }
  function textRows(str,w,n=13,b=false){
    font(n,b);const rows=[];let line='';for(const ch of String(str||'')){if(ch==='\n'){rows.push(line);line='';continue;}if(c.measureText(line+ch).width>w&&line){rows.push(line);line='';}line+=ch;}if(line)rows.push(line);return rows;
  }
  function wrap(str,x,y,w,lines=3,n=13,color=muted){
    const rows=textRows(str,w,n);
    rows.slice(0,lines).forEach((r,i)=>text(r+(i===lines-1&&rows.length>lines?'…':''),x,y+i*(n+5),w,n,color));
  }
  function panel(x,y,w,h,color=gold,selected=false){
    c.fillStyle=selected?'#242333':'#111722';pixelRect(x,y,w,h,5);c.fill();
    c.strokeStyle=selected?color:'#343642';c.lineWidth=selected?2:1;pixelRect(x+.5,y+.5,w-1,h-1,5);c.stroke();
    if(h>128&&w>140){const r=Math.min(26,h*.15),cx=x+w-r-18,cy=y+h-r-18;c.save();c.globalAlpha=.11;c.strokeStyle=color;c.lineWidth=1;c.beginPath();c.moveTo(cx,cy-r);c.lineTo(cx+r,cy);c.lineTo(cx,cy+r);c.lineTo(cx-r,cy);c.closePath();c.stroke();c.fillStyle=color;c.fillRect(cx-2,cy-2,4,4);c.fillRect(x+16,y+h-20,Math.max(0,w-r*3-40),1);c.restore();}
    c.fillStyle=color;for(const [a,b] of [[x+5,y+5],[x+w-9,y+5],[x+5,y+h-7],[x+w-9,y+h-7]])c.fillRect(a,b,4,2);
  }
  // 普通按钮共用蓝钢倒角；主页四种用途只改变面色与细小识别线。
  function steelButton(x,y,w,h,tint=[110,133,167],selected=false){
    c.save();c.beginPath();c.rect(x,y,w,h);c.clip();
    const cut=Math.min(9,Math.max(6,Math.floor(h*.17)));
    const paint=(i,b,fill)=>{c.fillStyle=fill;pixelRect(x+i,y+i,w-i*2,h-i*2-b,Math.max(3,cut-i));c.fill();};
    paint(0,0,'#080e1b');
    const metal=c.createLinearGradient(x,y,x+w*.12,y+h);
    metal.addColorStop(0,selected?'#c1ccdf':'#8493ac');metal.addColorStop(.18,'#5e6f88');metal.addColorStop(.63,'#2e3c51');metal.addColorStop(1,'#172438');
    paint(1,2,metal);paint(3,2,'#111b2b');
    const inner=c.createLinearGradient(0,y+4,0,y+h-6);inner.addColorStop(0,'#53657f');inner.addColorStop(.5,'#1c2a3e');inner.addColorStop(1,'#5c708a');paint(4,2,inner);
    const face=c.createLinearGradient(0,y+6,0,y+h-8),tone=s=>'rgb('+tint.map(v=>Math.round(v*s)).join(',')+')';
    face.addColorStop(0,tone(selected?.20:.43));face.addColorStop(.3,tone(selected?.13:.32));face.addColorStop(1,tone(selected?.09:.22));paint(6,2,face);
    if(selected){c.fillStyle='#d9b879';c.fillRect(x+9,y+10,3,h-22);}
    c.fillStyle='rgba(230,239,251,.05)';for(let k=0;k<Math.floor(w/23);k++)c.fillRect(Math.floor(x+10+k*23),Math.floor(y+10+(k%4)*4),3,1);
    c.fillStyle='#bdccdf';c.fillRect(x+cut+2,y+2,Math.max(0,w-cut*2-4),1);c.fillStyle='#7387a7';c.fillRect(x+2,y+cut,1,Math.max(0,h-cut*2-3));
    c.fillStyle='#111b2b';c.fillRect(x+cut,y+h-4,Math.max(0,w-cut*2),2);c.restore();
  }
  function primaryButton(x,y,w,h){
    c.save();const face=c.createLinearGradient(0,y+3,0,y+h-3);face.addColorStop(0,'#534366');face.addColorStop(.3,'#41334f');face.addColorStop(1,'#251e36');
    c.fillStyle=face;pixelRect(x+3,y+3,w-6,h-6,7);c.fill();
    const frame=artReady('menuframe');c.imageSmoothingEnabled=false;
    if(frame)c.drawImage(frame,x,y,w,h);
    else{c.strokeStyle='#d0dbea';c.lineWidth=2;pixelRect(x+1,y+1,w-2,h-2,7);c.stroke();c.strokeStyle='#827498';c.lineWidth=1;pixelRect(x+4,y+4,w-8,h-8,5);c.stroke();}
    c.restore();
  }
  const outlinedIcons=new Map();
  function menuIcon(action,r){
    const img=artReady(action==='settings'?'menusettings':'menubook'),size=Math.min(36,r.h-8),x=r.x+(r.w-size)/2,y=r.y+(r.h-size)/2;
    c.save();c.imageSmoothingEnabled=false;
    if(img){
      let outlined=outlinedIcons.get(img);
      if(!outlined){
        outlined=document.createElement('canvas');outlined.width=outlined.height=140;const g=outlined.getContext('2d');g.imageSmoothingEnabled=false;
        for(const [dx,dy]of [[-4,0],[4,0],[0,-4],[0,4],[-3,-3],[3,-3],[-3,3],[3,3]])g.drawImage(img,6+dx,6+dy,128,128);
        g.globalCompositeOperation='source-in';g.fillStyle='#fff';g.fillRect(0,0,140,140);g.globalCompositeOperation='source-over';g.drawImage(img,6,6,128,128);outlinedIcons.set(img,outlined);
      }
      c.drawImage(outlined,x,y,size,size);
    }else{
      // 无素材时仍画无底框图案，保留白色轮廓与原触区。
      c.translate(x,y);c.scale(size/32,size/32);c.strokeStyle='#fff';c.lineWidth=3;c.fillStyle='#52657f';
      if(action==='settings'){c.beginPath();for(let i=0;i<32;i++){const a=i*Math.PI/16,rr=i%4<2?14:11;const xx=16+Math.cos(a)*rr,yy=16+Math.sin(a)*rr;if(i)c.lineTo(xx,yy);else c.moveTo(xx,yy);}c.closePath();c.fill();c.stroke();c.beginPath();c.arc(16,16,6,0,Math.PI*2);c.stroke();}
      else{c.fillRect(5,3,23,27);c.strokeRect(5,3,23,27);c.strokeStyle='#abc5dc';c.lineWidth=1;c.strokeRect(10,6,15,20);c.fillStyle='#cbb4e5';c.fillRect(16,10,5,10);}
    }c.restore();
  }
  function button(rects,r,label,color=gold,on=false){
    if((RG.state==='menu'&&['settings','achievements'].includes(r.action))||(RG.state==='pause'&&r.action==='settings'))menuIcon(r.action,r);
    else{
      const tones={rush:[154,78,100],daily:[119,105,181],shop:[144,126,89],guide:[87,144,146]},tint=RG.state==='menu'?tones[r.action]:null;
      if(on&&['resume','buy','restore','practice','confirm'].includes(r.action))primaryButton(r.x,r.y,r.w,r.h);
      else steelButton(r.x,r.y,r.w,r.h,tint||(on?[119,105,160]:[110,133,167]),on);
      if(tint){c.fillStyle=color;c.fillRect(r.x+8,r.y+12,2,r.h-24);}
      const auxiliary=r.action==='back'?'back':r.action==='page'?(r.delta<0?'previous':'next'):r.action==='save-run'?'save':r.action==='pause-stats'?'stats':/^重骰 /.test(label)?'reroll':null;
      const price=/^(?:解锁 · |金币不足 · )?(\d+) 金$/.exec(label);
      if(auxiliary){
        const size=Math.min(28,r.h-8);drawUiIcon(auxiliary,r.x+(r.w-size)/2-(auxiliary==='reroll'?10:0),r.y+(r.h-size)/2,size);
        if(auxiliary==='reroll')text(RG.P.rerolls,r.x+r.w/2+12,r.y+r.h/2+5,24,12,color,true);
      }else if(r.action==='buy'&&label==='已拥有')drawUiIcon('owned',r.x+r.w/2-13,r.y+r.h/2-13,26);
      else if(r.action==='buy'&&price){
        const locked=label.startsWith('金币不足');if(locked)drawUiIcon('locked',r.x+8,r.y+r.h/2-10,20);
        drawCurrency(Number(price[1]),{x:r.x+(locked?28:0),y:r.y,w:r.w-(locked?28:0),h:r.h},{fontSize:14,iconSize:20,color});
      }else text(label,r.x+8,r.y+r.h/2+5,r.w-16,12,color,true,'center');
    }rects.push(r);
  }
  function bounds(){const s=RG.safe||{};const x=(s.left||0)+16,y=(s.top||0)+12,w=RG.W-x-(s.right||0)-16,h=RG.H-y-(s.bottom||0)-12;return {x,y,w,h};}
  let skySource,skyFrames=[];
  RG.dayNightPhase=t=>{const p=(((t||0)%96)+96)%96/6;return {frame:Math.floor(p),next:(Math.floor(p)+1)%16,mix:p%1};};
  function prepareSky(img){
    if(skyFrames.length===16&&skySource===img)return;skySource=img;skyFrames=[];
    // 只给原峡谷换光照，不重画建筑与地形；320×180×16约3.5MiB。
    const colors=[['#182139','#526080'],['#313e59','#ad7d8b'],['#5c607b','#e8a484'],['#65839a','#d8b7ac'],['#7295a9','#c6c4c3'],['#789bac','#ccc1b5'],['#748fa5','#d3b5a7'],['#69788f','#e6a087'],['#4e4f70','#c27d86'],['#353754','#7d6888'],['#232c47','#56607d'],['#18223b','#3b496b'],['#151c35','#313c5b'],['#17213a','#38476a'],['#1b2842','#435575'],['#1b2841','#4a5b79']];
    for(let i=0;i<16;i++){const cv=document.createElement('canvas');cv.width=320;cv.height=180;const g=cv.getContext('2d');g.imageSmoothingEnabled=false;const grad=g.createLinearGradient(0,0,0,180);grad.addColorStop(0,colors[i][0]);grad.addColorStop(1,colors[i][1]);g.fillStyle=grad;g.fillRect(0,0,320,180);
      if(img){g.drawImage(img,0,0,320,180);g.globalCompositeOperation='source-atop';g.globalAlpha=i>=10||i===0||i===15?.25:i===2||i===7||i===8?.12:.04;g.fillStyle=i>=10||i===0||i===15?'#14213d':'#edaa82';g.fillRect(0,0,320,180);g.globalAlpha=1;g.globalCompositeOperation='source-over';}
      else{g.fillStyle='#35435c';g.fillRect(0,135,320,45);g.fillRect(238,88,20,72);g.fillRect(282,70,14,95);}
      skyFrames.push(cv);
    }RG.skyFrameCount=skyFrames.length;
  }
  function backdrop(){
    const menu=RG.state==='menu',g=c.createLinearGradient(0,0,0,RG.H);
    g.addColorStop(0,menu?'#50617b':'#1b2435');g.addColorStop(.6,menu?'#8b7c92':'#202333');g.addColorStop(1,menu?'#58435b':'#111722');
    c.fillStyle=g;c.fillRect(0,0,RG.W,RG.H);
    if(menu){
      const img=artReady('menuvalley');
      prepareSky(img);const phase=RG.dayNightPhase(RG.previewDayNightTime??performance.now()/1000),portrait=RG.H>RG.W,h=portrait?RG.W*180/320:RG.H,y=portrait?RG.H-h:0;
      c.save();c.imageSmoothingEnabled=false;c.drawImage(skyFrames[phase.frame],0,y,RG.W,h);c.globalAlpha=phase.mix;c.drawImage(skyFrames[phase.next],0,y,RG.W,h);c.restore();
    }else{
      // 二级页面保留深灰遗迹剪影，不沿用主页的彩色天空。
      c.save();c.globalAlpha=.12;c.filter='grayscale(1)';drawCover(artReady('menu'),RG.W,RG.H);c.restore();
      c.save();c.strokeStyle='#394250';c.globalAlpha=.28;c.lineWidth=1;
      const step=RG.W/6;for(let i=0;i<6;i++){const x=(i+.5)*step,w=step*.8;c.beginPath();c.moveTo(x-w/2,RG.H);c.lineTo(x-w/2,RG.H*.27);c.quadraticCurveTo(x-w*.4,RG.H*.13,x,RG.H*.06);c.quadraticCurveTo(x+w*.4,RG.H*.13,x+w/2,RG.H*.27);c.lineTo(x+w/2,RG.H);c.stroke();}c.restore();
    }
  }
  function shell(title,sub,rects,back=true,maxH=0){RG.uiNav=[];RG.uiNavState=RG.state;RG.uiTextBoxes=[];backdrop();const b=bounds();if(b.w>1080){b.x+=(b.w-1080)/2;b.w=1080;}if(maxH&&b.h>maxH){b.y+=(b.h-maxH)/2;b.h=maxH;}
    if(back)button(rects,{x:b.x,y:b.y,w:76,h:44,action:'back'},'‹ 返回',muted);
    const landscape=RG.W>RG.H&&RG.H<=600&&b.w>=400;
    const tx=b.x+(back?90:0),tw=b.w-(back?90:0)-(landscape?146:0);
    text(title,tx,b.y+23,tw,Math.min(19,tw/7),gold,true);
    if(['强化商店','局外成长'].includes(title))drawCurrency(RG.meta.coins,{x:tx,y:b.y+29,w:Math.min(tw,148),h:22},{align:'left',padding:0,fontSize:12,iconSize:18});
    else text(sub,tx,b.y+43,tw,11,muted);
    c.fillStyle='#34313c';c.fillRect(b.x,b.y+57,b.w,1);
    return {...b,landscape,top:b.y+(landscape?60:70),bottom:b.y+b.h-56,footer:b.y+b.h-44,pager:landscape?{x:b.x+b.w-140,y:b.y}:null};
  }
  function tabs(key,b,items){
    const selected=RG.uiTabs[key]=items.some(i=>i[0]===RG.uiTabs[key])?RG.uiTabs[key]:items[0][0];
    if(b.landscape){
      if(items.length>5){
        const side=b.w>=700?154:130,gap=6,w=(side-gap)/2;
        items.forEach((a,i)=>button(RG.uiNav,{x:b.x+(i%2)*(w+gap),y:b.top+Math.floor(i/2)*50,w,h:44,action:'tab',key,id:a[0]},a[1],a[0]===selected?gold:muted,a[0]===selected));
        c.fillStyle='#34313c';c.fillRect(b.x+side+6,b.top,1,b.y+b.h-b.top);b.x+=side+12;b.w-=side+12;b.bottom=b.y+b.h;return selected;
      }
      // 手机横屏：分类靠左，正文使用全部剩余高度；翻页留在标题栏。
      const w=b.w>=700?108:88,gap=6,step=items.length>1?Math.min(50,(b.y+b.h-b.top-44)/(items.length-1)):50;
      items.forEach((a,i)=>button(RG.uiNav,{x:b.x,y:b.top+i*step,w,h:44,action:'tab',key,id:a[0]},a[1],a[0]===selected?gold:muted,a[0]===selected));
      c.fillStyle='#34313c';c.fillRect(b.x+w+gap,b.top,1,b.y+b.h-b.top);
      b.x+=w+gap*2;b.w-=w+gap*2;b.bottom=b.y+b.h;
    }else{const gap=6,w=(b.w-gap*(items.length-1))/items.length;items.forEach((a,i)=>button(RG.uiNav,{x:b.x+i*(w+gap),y:b.top,w,h:44,action:'tab',key,id:a[0]},a[1],a[0]===selected?gold:muted,a[0]===selected));b.top+=54;}
    return selected;
  }
  function page(items,key,b,minH=82,cols=1){
    const gap=10,rows=Math.max(1,Math.floor((b.bottom-b.top+gap)/(minH+gap))),per=rows*cols,pages=Math.max(1,Math.ceil(items.length/per));
    const p=RG.uiPages[key]=RG.clamp(RG.uiPages[key]||0,0,pages-1);const w=(b.w-gap*(cols-1))/cols,h=Math.min(minH+22,(b.bottom-b.top-gap*(rows-1))/rows);
    if(b.pager){const q=b.pager;if(pages>1){button(RG.uiNav,{x:q.x,y:q.y,w:44,h:44,action:'page',key,delta:-1},'‹');button(RG.uiNav,{x:q.x+96,y:q.y,w:44,h:44,action:'page',key,delta:1},'›');}text((p+1)+'/'+pages,q.x+46,q.y+28,48,11,muted,false,'center');}
    else if(pages>1){button(RG.uiNav,{x:b.x,y:b.footer,w:72,h:44,action:'page',key,delta:-1},'‹ 上页');button(RG.uiNav,{x:b.x+b.w-72,y:b.footer,w:72,h:44,action:'page',key,delta:1},'下页 ›');text((p+1)+' / '+pages,b.x+80,b.footer+28,b.w-160,13,muted,false,'center');}
    else text('罪恶之下  /  '+(RG.VERSION||''),b.x,b.footer+28,b.w,11,'#a6a7b5',false,'center');
    return items.slice(p*per,(p+1)*per).map((item,i)=>({item,x:b.x+(i%cols)*(w+gap),y:b.top+Math.floor(i/cols)*(h+gap),w,h}));
  }
  function iconArt(id,x,y,size){if(id==='greed'){drawUiIcon('coin',x,y,size);return;}if(String(id).startsWith('mob:')){RG.DrawKit.drawEnemyIcon(id.slice(4),x,y,size);return;}if(RG.PASSIVES[id])id=RG.PASSIVES[id].icon||id.replace(/_(s|m|l|xl)$/,'');const img=RG.CARD_ICON&&RG.CARD_ICON[id];if(img&&img.complete&&img.naturalWidth>0){c.drawImage(img,x,y,size,size);return;}if(drawCardAtlasIcon(id,x,y,size))return;
    c.save();c.translate(x,y);c.scale(size/32,size/32);c.strokeStyle=RG.WEAPONS[id]?.color||'#a6bdd4';c.fillStyle=c.strokeStyle;c.lineWidth=2;c.lineCap='square';
    if(id==='clock'){c.fillStyle=gold;for(const r of [[8,4,16,2],[8,26,16,2],[4,8,2,16],[26,8,2,16],[6,6,2,2],[24,6,2,2],[6,24,2,2],[24,24,2,2],[14,8,3,11],[17,16,7,3]])c.fillRect(...r);c.restore();return;}
    if(id==='scythe'){c.beginPath();c.moveTo(9,29);c.lineTo(22,5);c.moveTo(22,5);c.quadraticCurveTo(5,-2,2,17);c.quadraticCurveTo(11,8,22,5);c.stroke();}
    else if(id==='spinner'){c.fillRect(5,6,5,17);c.fillRect(22,9,5,17);c.beginPath();c.moveTo(8,7);c.lineTo(24,10);c.stroke();}
    else if(id==='kiwave'){c.beginPath();c.arc(16,16,8,0,Math.PI*2);c.stroke();c.fillRect(12,12,8,8);for(let i=0;i<4;i++){c.save();c.translate(16,16);c.rotate(i*Math.PI/2);c.fillRect(12,-1,4,2);c.restore();}}
    else {const glyph={audio:'♪',control:'↔',visual:'◇',trophy:'★',history:'≡',unknown:'?',heal:'+',regen:'+',seed:'↑',greed:'金',shieldcore:'◇',shell:'◇',boots:'»',power:'剑',crit:'◎',frenzy:'»',critd:'!',magnet:'⊕',evade:'↗',element:'火',dash:'»'}[id]||'◆';font(20,true);c.fillStyle=gold;c.textAlign='center';c.textBaseline='alphabetic';c.fillText(glyph,16,23);}
    c.restore();
  }
  function tile(r,title,desc,color=gold,icon){panel(r.x,r.y,r.w,r.h,color);const sz=icon?Math.min(32,r.h-24):0,tx=r.x+14+(sz?sz+10:0),tw=r.w-28-(sz?sz+10:0);
    if(icon)iconArt(icon,r.x+12,r.y+12,sz);
    text(title,tx,r.y+25,tw,13,color,true);wrap(desc,tx,r.y+45,tw,Math.max(1,Math.floor((r.h-48)/16)+1),11);
  }
  // 构筑详情按真实行数留高；关键条件与罪印代价不能被小卡片省略。
  function buildPage(items,key,b,cols){
    let w=(b.w-10*(cols-1))/cols,need=Math.max(86,...items.map(item=>59+textRows(item.desc,w-24,12).length*17));
    if(cols>1&&need>b.bottom-b.top){cols=1;w=b.w;need=Math.max(86,...items.map(item=>59+textRows(item.desc,w-24,12).length*17));}
    return page(items,key,b,need,cols);
  }
  function buildTile(r,color){
    panel(r.x,r.y,r.w,r.h,color);iconArt(r.item.icon,r.x+12,r.y+12,32);
    const titleRows=textRows(r.item.title,r.w-66,13,true);titleRows.slice(0,2).forEach((row,i)=>text(row,r.x+54,r.y+23+i*18,r.w-66,13,color,true));
    const rows=textRows(r.item.desc,r.w-24,12);rows.forEach((row,i)=>text(row,r.x+12,r.y+62+i*17,r.w-24,12,ink));
  }
  // 主页按构图限宽，角色与场景留在菜单外，按钮不随屏幕无限拉伸。
  function drawMenu(){
    RG.menuRects=[];RG.uiNav=[];RG.uiNavState=RG.state;RG.uiTextBoxes=[];backdrop();
    const b=bounds(),portrait=RG.H>RG.W,compact=RG.H<500;
    const left=b.x+4,navW=portrait?b.w-8:Math.min(370,b.w*.50),right=b.x+b.w;
    const titleY=b.y+(compact?42:64),titleSize=portrait?Math.min(35,b.w/6):Math.min(42,navW/5.4);
    c.save();c.shadowColor='#172035';c.shadowBlur=6;text('罪恶之下',left,titleY,navW,titleSize,'#fff0c5',true);c.restore();
    text('七宗罪 · 弹幕求生',left+2,titleY+23,navW,12,'#efe1d0');
    const heroX=portrait?b.x+b.w*.5:b.x+b.w*.68;
    const heroY=portrait?b.y+b.h*.45:b.y+b.h*.49;
    const heroSize=portrait?Math.min(210,b.h*.28):Math.min(215,b.h*.60),heroImg=artReady('launcher');
    if(heroImg){c.save();c.imageSmoothingEnabled=false;c.drawImage(heroImg,heroX-heroSize/2,heroY-heroSize/2+Math.sin(performance.now()*.0014)*2,heroSize,heroSize);c.restore();}
    else if(!RG.DrawKit.drawPlayerPortrait(heroX,heroY,heroSize)){
      c.fillStyle='#f2e9f4';c.fillRect(heroX-heroSize*.24,heroY-heroSize*.29,heroSize*.48,heroSize*.4);
      c.fillStyle='#281832';c.fillRect(heroX-heroSize*.13,heroY-heroSize*.12,heroSize*.26,heroSize*.18);
      c.fillStyle='#bd82ed';c.fillRect(heroX-heroSize*.08,heroY-heroSize*.05,heroSize*.05,heroSize*.04);c.fillRect(heroX+heroSize*.04,heroY-heroSize*.05,heroSize*.05,heroSize*.04);
    }
    if(!portrait){
      text('孤身入深渊',heroX-heroSize*.6,Math.min(b.y+b.h-17,heroY+heroSize*.60),heroSize*1.2,13,'#ffe8bb',true,'center');
      drawCurrency(RG.meta.coins,{x:left,y:b.y+b.h-24,w:Math.min(142,navW*.42),h:24},{align:'left',fontSize:11,iconSize:18,color:'#ffdfaa',padding:0});
      text('最佳 '+RG.fmtTime(RG.best.time),left+Math.min(150,navW*.45),b.y+b.h-7,navW-Math.min(150,navW*.45),11,'#ffdfaa');
    }
    // 顶角保留小入口，主角周围不叠大卡片。
    const topY=b.y+2,smallW=portrait?82:76;
    button(RG.menuRects,{x:right-smallW,y:topY,w:smallW,h:44,action:'settings'},'设置','#c5d5e4');
    button(RG.menuRects,{x:right-smallW,y:topY+50,w:smallW,h:44,action:'achievements'},'成就图鉴','#d9c6e7');
    const restore=!!RG.hasRunCheckpoint?.(),inlineRestore=restore&&!portrait&&b.h<330,mainH=compact?50:58,groupH=mainH+104+(restore&&!inlineRestore?52:0);
    const preferred=portrait?b.y+b.h*.60:b.y+Math.max(98,b.h*.34);
    const startY=restore?Math.max(b.y+92,Math.min(preferred,b.y+b.h-groupH-(portrait?8:21))):preferred;
    let r={x:left,y:startY,w:navW,h:mainH,action:'loadout'};
    if(inlineRestore){const rw=(navW-8)/2;button(RG.menuRects,{x:left,y:startY,w:rw,h:mainH,action:'restore'},'继续上局','#a8c6bc',true);r.x+=rw+8;r.w=rw;}
    else if(restore){button(RG.menuRects,{x:left,y:startY,w:navW,h:44,action:'restore'},'继续上局  ›','#a8c6bc',true);r.y+=52;}
    primaryButton(r.x,r.y,r.w,r.h);text(inlineRestore?'开始游戏':'开始游戏  ›',r.x+10,r.y+mainH/2+7,r.w-20,inlineRestore?16:compact?21:24,'#fff0c5',true,'center');RG.menuRects.push(r);
    const gap=8,secondY=r.y+mainH+gap,half=(navW-gap)/2;
    button(RG.menuRects,{x:left,y:secondY,w:half,h:44,action:'rush'},'BOSS 连战','#d894a4');
    button(RG.menuRects,{x:left+half+gap,y:secondY,w:half,h:44,action:'daily'},'今日挑战','#b9a5e4');
    const bottomY=secondY+52;
    if(bottomY+44<=b.y+b.h-(portrait?8:21)){
      button(RG.menuRects,{x:left,y:bottomY,w:half,h:44,action:'shop'},'商店','#e9cc91');
      button(RG.menuRects,{x:left+half+gap,y:bottomY,w:half,h:44,action:'guide'},'教程','#a8c6bc');
    }else{
      button(RG.menuRects,{x:left,y:b.y+b.h-44,w:half,h:44,action:'shop'},'商店','#e9cc91');
      button(RG.menuRects,{x:left+half+gap,y:b.y+b.h-44,w:half,h:44,action:'guide'},'教程','#a8c6bc');
    }
    if(RG.menuNotice&&RG.menuNotice.until>Date.now())text(RG.menuNotice.text,left,b.y+b.h-6,navW,11,ink);
  }
  function drawSinChoices(){
    RG.offerRects=[];RG.rerollRect=null;
    const b=shell('七宗罪 · 觉醒','七项同屏 · 点击罪印查看介绍',RG.offerRects,false);
    const colors=['#bba475','#8fb6c9','#dc7b87','#9da7ce','#d9b879','#bd8fb4','#edb28a'];
    const roles=['生命','权能','暴伤','壁垒','成长','仆人','极限'];
    const gap=b.w<600?5:9,cw=(b.w-gap*6)/7,ch=Math.min(310,b.bottom-b.top-12),y=b.top+(b.bottom-b.top-ch)/2;
    RG.offers.forEach((o,i)=>{
      const d=RG.OATH_NODES[o.id],x=b.x+i*(cw+gap),color=colors[i],selected=RG.selectedOffer===i;
      panel(x,y,cw,ch,color,selected);
      c.fillStyle=color;c.fillRect(x+cw*.3,y+3,cw*.4,2);
      text(String(i+1).padStart(2,'0'),x+4,y+22,cw-8,10,muted,false,'center');
      const cy=y+ch*.31,rr=Math.min(24,cw*.32);
      c.strokeStyle=color;c.lineWidth=1;c.beginPath();c.moveTo(x+cw/2,cy-rr);c.lineTo(x+cw/2+rr,cy);c.lineTo(x+cw/2,cy+rr);c.lineTo(x+cw/2-rr,cy);c.closePath();c.stroke();
      text(d.glyph,x+4,cy+8,cw-8,Math.min(24,cw*.48),color,true,'center');
      text(d.name[0],x+4,y+ch*.58,cw-8,18,ink,true,'center');
      text(d.name[1],x+4,y+ch*.58+25,cw-8,18,ink,true,'center');
      text(roles[i],x+4,y+ch-22,cw-8,11,color,false,'center');
      RG.offerRects.push({x,y,w:cw,h:ch,i});
    });
    text('选择一枚罪印，决定本局的力量与代价',b.x,b.footer+24,b.w,11,muted,false,'center');
    if(RG.selectedOffer==null)return;
    // 弹窗期间只保留弹窗触控区域，防止误点后方罪印或重复选定。
    const i=RG.selectedOffer,d=RG.OATH_NODES[RG.offers[i].id],color=colors[i];
    c.fillStyle='rgba(5,8,15,.82)';c.fillRect(0,0,RG.W,RG.H);RG.offerRects=[];RG.uiTextBoxes=[];
    const gain=d.briefGain,cost=d.briefCost,w=Math.min(520,b.w),tw=w-76;
    font(13);const countLines=str=>{let rows=1,line='';for(const ch of str){if(c.measureText(line+ch).width>tw){rows++;line='';}line+=ch;}return rows;};
    const gainRows=countLines(gain),costRows=countLines(cost),h=Math.min(b.h,248+(gainRows+costRows-2)*18),x=b.x+(b.w-w)/2,py=b.y+(b.h-h)/2;
    panel(x,py,w,h,color,true);
    // 延续像素卡牌边框：双层纹章、内沿和四角折线，不引入新画风素材。
    c.save();c.strokeStyle=color;c.globalAlpha=.4;c.lineWidth=1;
    c.strokeRect(x+7,py+7,w-14,h-14);
    for(const [cx,cy,sx,sy] of [[x+13,py+13,1,1],[x+w-13,py+13,-1,1],[x+13,py+h-13,1,-1],[x+w-13,py+h-13,-1,-1]]){
      c.beginPath();c.moveTo(cx+sx*21,cy);c.lineTo(cx,cy);c.lineTo(cx,cy+sy*21);c.stroke();c.fillStyle=color;c.fillRect(cx+sx*4-1,cy+sy*4-1,3,3);
    }
    font(104,true);c.textAlign='center';c.globalAlpha=.05;c.fillStyle=color;c.fillText(d.glyph,x+w-75,py+134);c.restore();
    const cx=x+48,cy=py+45;
    c.strokeStyle=color;c.lineWidth=1;
    for(const rr of [27,21]){c.beginPath();c.moveTo(cx,cy-rr);c.lineTo(cx+rr,cy);c.lineTo(cx,cy+rr);c.lineTo(cx-rr,cy);c.closePath();c.stroke();}
    text(d.glyph,cx-18,cy+8,36,24,color,true,'center');
    text(d.name,x+91,py+39,w-120,23,ink,true);
    text(roles[i]+'罪印 · 本局唯一',x+92,py+60,w-122,11,color);
    c.strokeStyle=color;c.globalAlpha=.3;c.beginPath();c.moveTo(x+23,py+79);c.lineTo(x+w-23,py+79);c.stroke();c.globalAlpha=1;
    const drawEffect=(label,str,yy,accent,rows)=>{
      c.fillStyle=accent;c.fillRect(x+24,yy-9,3,24+rows*18);
      text(label,x+38,yy,w-76,10,accent,true);
      wrap(str,x+38,yy+22,tw,rows,13,ink);
    };
    drawEffect('获得',gain,py+98,'#b8cfa1',gainRows);
    drawEffect('代价',cost,py+98+gainRows*18+35,'#df9ca4',costRows);
    const by=py+h-57,bw=(w-58)/2;
    button(RG.offerRects,{x:x+24,y:by,w:bw,h:44,action:'cancel'},'返回选择',muted);
    button(RG.offerRects,{x:x+34+bw,y:by,w:bw,h:44,action:'confirm'},'接受 · '+d.name,color,true);
  }
  function drawOffers(){
    if(RG.offerKind==='oathnode'&&RG.offers.length>3){drawSinChoices();return;}

    RG.offerRects=[];RG.rerollRect=null;RG.uiNav=[];RG.uiNavState=RG.state;RG.uiTextBoxes=[];backdrop();
    const b=bounds(),vertical=RG.H>RG.W,paged=RG.offers.length>3,pages=paged?Math.ceil(RG.offers.length/2):1;
    const p=RG.uiPages.weaponchoices=RG.clamp(RG.uiPages.weaponchoices||0,0,pages-1),start=paged?p*2:0,shown=paged?RG.offers.slice(start,start+2):RG.offers;
    const count=Math.max(1,shown.length),gap=vertical?10:8;
    const cw=vertical?Math.min(400,b.w):Math.min(250,(b.w-gap*(count-1))/count);
    const infos=shown.map(o=>RG.offerText(o)),descY=cw<190?60:70;
    const needed=Math.max(vertical?165:184,...infos.map(info=>descY+Math.max(0,textRows(info.desc,cw-26,12).length-1)*17+12));
    // 标题28px、按钮52px、上下各4px，其余高度交给正文，短横屏也保留完整前置名。
    const ch=Math.min(needed,(b.h-88-(vertical?gap*(count-1):0))/(vertical?count:1));
    const totalW=vertical?cw:cw*count+gap*(count-1),totalH=vertical?ch*count+gap*(count-1):ch;
    const x=b.x+(b.w-totalW)/2,y=b.y+Math.max(4,(b.h-totalH-80)/2);
    const title=RG.offerKind==='oathnode'?'罪印觉醒':RG.offers.some(o=>o.kind==='activeevolve')?'主动进化':RG.offers.some(o=>o.kind==='evolve')?'武器进化':RG.offerKind==='elementweapon'?'元素附魔':RG.offerKind==='discardweapon'?'选择丢弃武器':RG.offerKind==='realmreward'?'秘境 · 传说被动':'选择强化';
    text(title+(infos.some(info=>info.resonanceNote)?(RG.P.passives.resonanceheart?' · 四件含两件':' · 五件含三件'):'')+(paged?' · '+(p+1)+'/'+pages:''),x,y+18,totalW,21,'#f2dcac',true,'center');
    RG.offerCards=[];shown.forEach((o,i)=>{
      const info=infos[i],r={x:x+(vertical?0:i*(cw+gap)),y:y+28+(vertical?i*(ch+gap):0),w:cw,h:ch,i:start+i},selected=RG.selectedOffer===start+i;
      panel(r.x,r.y,cw,ch,info.color,selected);
      const sz=Math.min(cw<190?32:44,ch-28),tx=r.x+sz+22,tw=cw-sz-34;
      iconArt(info.icon,r.x+12,r.y+14,sz);
      text(info.title,tx,r.y+25,tw,14,ink,true);
      text([info.rn,info.lv].filter(Boolean).join(' · '),tx,r.y+44,tw,11,info.color);
      const rows=Math.max(1,Math.floor((ch-descY-12)/17)+1);
      wrap(info.desc,r.x+13,r.y+descY,cw-26,rows,12,ink);
      RG.offerRects.push(r);RG.offerCards.push({...r,item:info});
    });
    const controlsW=Math.min(paged?b.w-108:totalW,480),bx=b.x+(b.w-controlsW)/2,by=y+28+totalH+8,bw=paged?(controlsW-10)/2:(controlsW-20)/3;
    button(RG.offerRects,{x:bx,y:by,w:bw,h:44,action:'confirm'},RG.selectedOffer==null?'选择后确定':'确定',RG.selectedOffer==null?muted:gold,RG.selectedOffer!=null);
    button(RG.offerRects,{x:bx+bw+10,y:by,w:bw,h:44,action:'cancel'},'取消',muted);
    if(paged){button(RG.uiNav,{x:b.x,y:by,w:44,h:44,action:'page',key:'weaponchoices',delta:-1},'‹');button(RG.uiNav,{x:b.x+b.w-44,y:by,w:44,h:44,action:'page',key:'weaponchoices',delta:1},'›');}
    if(RG.P.rerolls>0&&!['active','oathnode','elementweapon','discardweapon'].includes(RG.offerKind)&&!RG.offers.some(o=>['evolve','activeevolve'].includes(o.kind))){const r={x:bx+2*(bw+10),y:by,w:bw,h:44};button([],r,'重骰 '+RG.P.rerolls,'#b8a4dd');RG.rerollRect=r;}
  }
  function maps(){
    const rects=RG.mapRects=[],b=shell('选择地图','每张地图独立开局 · 武器与永久成长共用',rects),ids=['valley','workshop'],cols=b.w>600?2:1;
    for(const r of page(ids,'maps',b,136,cols)){
      const m=RG.mapConfig(r.item),on=RG.mapUnlocked(m.id),ready=m.id!=='workshop'||RG.WORKSHOP_READY,p=RG.meta.maps?.[m.id];
      const status=!on?'击败荒谷秘境典狱官解锁':!ready?'已解锁 · 工坊内容准备中':m.desc;
      const reward=p?.firstClearPaid||p?.wins>0?'首通奖励已领':'首通奖励 '+m.firstClearGold+' 金';
      tile(r,m.name,status+'\n'+reward+'\n纪录 '+RG.fmtTime(p?.bestTime||0)+' · 通关 '+(p?.wins||0)+' 次',on&&ready?'#a5f3fc':muted);
      rects.push({...r,action:'map',id:m.id});
    }
  }
  function weapons(rush){const name=rush?'rushWeaponRects':'loadoutRects',rects=RG[name]=[],b=shell(rush?'连战备战':'主线备战',rush?RG.BOSS_NAMES[(RG.rushPendingLv||1)-1]:RG.mapConfig(RG.selectedMap||'valley').name+' · 其他武器可在商店或BOSS连战解锁',rects);
    if(b.landscape)b.bottom=b.y+b.h;
    if(rush){
      const d=RG.rushDifficulty(RG.meta.rushDifficulty||1),gap=8,w=(b.w-gap*2)/3;
      RG.RUSH_DIFFICULTIES.forEach((item,i)=>button(rects,{x:b.x+i*(w+gap),y:b.top,w,h:44,action:'difficulty',id:item.id},item.name,item.id===d.id?gold:muted,item.id===d.id));
      const best=RG.rushBestTime(RG.rushPendingLv||1,d.id);
      text(d.desc+(best===undefined?'':' · 纪录 '+best.toFixed(1)+'s'),b.x,b.top+61,b.w,11,muted);b.top+=72;
    }else{const m=RG.mapConfig(RG.selectedMap||'valley');text((m.id==='workshop'?'9 / 17 / 25分钟首领 · 击败母巢通关':m.id==='valley'?'30分钟终局 · 前五首领每5分钟登场':'45分钟终局 · 每5分钟一场首领'),b.x,b.top+13,b.w,11,muted);b.top+=24;}
    const ids=RG.WEAPON_ORDER.filter(id=>RG.weaponUnlocked(id)),cols=b.landscape?(b.w>=740?4:2):b.w>850?4:b.w>520?3:2;
    for(const r of page(ids,rush?'rushweapon':'loadout',b,92,cols)){const d=RG.WEAPONS[r.item];tile(r,d.name,d.desc,d.color,r.item);rects.push({...r,action:rush?'weapon':'start',id:r.item});}
  }
  function growth(){const rects=RG.growthRects=[],dc=RG.dailyChallenge(),b=shell('局外成长','金 '+Math.floor(RG.meta.coins||0)+' · 每次出征都更进一步',rects);
    const items=[['强化商店','解锁武器与永久强化','shop',gold],['挑战契约','已启用 '+(RG.meta.oaths||[]).length+' 项 · 风险换金币','oaths','#cf9c81'],['成就与图鉴','罪证、敌人和最近战绩','achievements','#85bfc5'],['今日挑战',(dc.contracts||[]).map(id=>RG.OATHS.find(o=>o.id===id)?.name||id).join(' + ')+(dc.done?' · 已完成':''),'daily','#b8a4dd']];
    const cols=b.w>520?2:1,gap=10,h=Math.min(126,(b.bottom-b.top-gap*(4/cols-1))/(4/cols));items.forEach((a,i)=>{const r={x:b.x+i%cols*(b.w+gap)/cols,y:b.top+Math.floor(i/cols)*(h+gap),w:(b.w-gap*(cols-1))/cols,h,action:a[2]};tile(r,a[0],a[1],a[3]);rects.push(r);});
  }
  function achievements(){const rects=RG.achRects=[],seen=RG.meta.seenMobs||[],got=RG.meta.achievements||{},b=shell('成就与图鉴','敌人 '+seen.filter(id=>RG.ETYPES[id]).length+'/'+Object.keys(RG.ETYPES).length+' · 成就 '+Object.keys(got).length+'/'+RG.ACHIEVEMENTS.length,rects);
    const category=tabs('achievements',b,[['achieve','成就'],['enemy','敌人'],['weapon','武器'],['history','战绩']]),items=[];
    if(category==='achieve')for(const a of RG.ACHIEVEMENTS)items.push({title:a.name,desc:(got[a.id]?'已达成 · ':'未达成 · ')+a.desc,color:got[a.id]?gold:muted,icon:'trophy'});
    if(category==='enemy'){drawCodex(b,rects,seen);return;}
    if(category==='weapon')for(const id of RG.WEAPON_ORDER){
      const w=RG.WEAPONS[id],ranged=RG.weaponIsRanged(id),first=RG.weaponStat(id,1),last=RG.weaponStat(id,7);
      items.push({title:w.name+' · '+RG.weaponRangeLabel(id),desc:(RG.weaponUnlocked(id)?'已解锁':(w.price?w.price+'金购买':id==='hammer'?'连战裂地魔像奖励':'连战领域主宰奖励'))+'\n'+w.desc+'\n'+(ranged?'受远程伤害加成；盾兽正面可格挡':'不受远程伤害加成；绕过盾兽格挡')+'\n'+(id==='vial'?'基础持续伤害':'基础单次伤害')+'：Lv1 '+(first.dmg??first.dot)+' → Lv7 '+(last.dmg??last.dot),color:w.color,icon:id});
    }
    if(category==='history')for(const r of RG.meta.runLog||[])items.push({title:(r.win?'通关':'战绩')+' · '+RG.fmtTime(r.t),desc:(r.mapId==='rush'?'首领连战':RG.mapConfig(r.mapId||'legacy').name)+' · '+r.kills+'击杀 · Lv'+r.lv+' · '+(r.tags||[]).join('/'),color:'#b8a4dd',icon:r.weapon||'history'});
    if(!items.length)text('暂无战绩，开始一局留下记录',b.x,b.top+32,b.w,12,muted,false,'center');
    const cols=b.w>650?3:b.w>430?2:1;
    RG.achCards=category==='weapon'?buildPage(items,'achievements',b,cols):page(items,'achievements',b,80,cols);
    for(const r of RG.achCards)if(category==='weapon')buildTile(r,r.item.color);else tile(r,r.item.title,r.item.desc,r.item.color,r.item.icon);
  }
  const bossKinds=['gluttony','golem','eye','shadow','mirror','domain','furnace','void','devourer','heretic'];
  RG.codexScroll={y:0,max:0};
  function codexData(key){
    const [tier,id]=key.split(':'),boss=tier==='boss',elite=tier==='elite',d=boss?null:RG.ETYPES[id],n=bossKinds.indexOf(id),base=RG.BALANCE.spawning.baseEnemy;
    const name=boss?(RG.BOSS_NAMES[n]||(id==='heretic'?RG.HERETIC_NAME:'秘境典狱官')):d.name+(elite?' · 精英':'');
    const c=RG.MOB_SKILLS,mechanisms={
      shooter:()=>`锁向吐弹，前摇${elite?c.shooter.eliteWind:c.shooter.wind}秒。`,
      howler:()=>`三段扇形波间隔${c.howler.interval}秒；每波${c.howler.minDamage}—${c.howler.maxDamage}伤害；削弱攻击和减伤${c.howler.debuff}秒。`,
      splitter:()=>`死亡裂解；${elite?c.splitter.eliteGenerations:c.splitter.generations}代幼体，后代生命和伤害递减。`,
      smasher:()=>`前摇${elite?c.smasher.eliteWind:c.smasher.wind}秒，${c.smasher.strike}秒扫过${elite?c.smasher.eliteRadius:c.smasher.radius}像素扇形，眩晕${c.smasher.stun}秒。`,
      bomber:()=>`接近引信${c.bomber.fuse}秒；爆炸半径${elite?c.bomber.eliteRadius:c.bomber.radius}。${elite?'精英生命及爆伤额外强化。':''}`,
      stalker:()=>`潜行突袭，前摇${c.stalker.wind}秒，恢复${c.stalker.recover}秒。`,
      bulwark:()=> '正面盾面抵挡远程攻击，背面和近程攻击可绕过。',
      colossus:()=> '缓慢重型近战，生命与接触伤害高。',brute:()=> '重型近战，追击接触伤害。',
      grunt:()=> '持续追击并以接触造成伤害。',swarm:()=> '高速成群包围，接触造成伤害。',
      ice:()=> '三向寒霜弹，命中减速。',healer:()=> `每${d.rules.updateEnemies.healT}秒治疗附近友军。`,
      summoner:()=> '保持距离召唤幼兽，召唤者死亡清除其随从。',homing:()=> '高速追踪并穿越墙体，寿命结束消失。',
      hound:()=> `远距锁向冲锋，冲刺期间基础承伤降低。`,flamer:()=> `蓄火${d.rules.updateEnemies.flameWind}秒后喷射火球。`,volt:()=> '施法时静止，预警后打出穿普通护盾的Z形电击。',
      crystal:()=> '结晶周身压制移动，死亡冻结周围单位。',
      scavenger:()=> '曲线追击，以接触造成伤害；当前尚无资源掠夺技能。',sporepod:()=> '死亡留下先预警、后爆发的孢子区域。',warder:()=> `每${d.rules.updateMeadowMob.meadowCd}秒给附近友军补至${d.rules.updateMeadowMob.shieldHp_factor*100}%最大生命的护盾，不叠加。`,tether:()=> '锁定玩家脚下落点后牵引；走出预警圈可规避，牵引不会穿墙。',mortar:()=> `锁定落点后预警${d.rules.updateMeadowMob.t}秒，爆炸半径${d.rules.updateMeadowMob.r}，冷却${d.rules.updateMeadowMob.meadowCd}秒。`,crucible:()=> '近距离锁向，红圈预警后释放扩张重砸冲击波。',phantasm:()=> '虚影短距突进，保持移动躲避。',prism:()=> `锁向前摇${RG.WORKSHOP_MOBS.prism.warn}秒，光束宽${RG.WORKSHOP_MOBS.prism.width}、冷却${RG.WORKSHOP_MOBS.prism.cd}秒，墙体可遮挡。`,amplifier:()=> `半径${RG.WORKSHOP_MOBS.amplifier.radius}内友军移动+${Math.round((RG.WORKSHOP_MOBS.amplifier.speed-1)*100)}%、伤害+${Math.round((RG.WORKSHOP_MOBS.amplifier.damage-1)*100)}%。`
    };
    let stats,mechanism,res=boss?RG.BOSS_RESISTS[id]||{}:d.res||{};
    if(boss){const b=RG.BALANCE.spawning.makeBoss;stats=`连战标准：生命 ${RG.rushBossHp(n+1,1)} · 接触伤害 ${Math.round((b.dmg_offset+(n+1)*b.dmg_factor)*b.dmg_factor_2*RG.rushDifficulty(1).dmg)}\n主线生命、伤害随地图和时间成长。`;
      mechanism=RG.BOSS_PATTERN_DESC[n]||'秘境独立首领，按钥印阶段强化弹幕与锁界。';
      if(id==='domain'){const s=RG.BOSS_SKILLS.domain.space;mechanism=`脚底减速领域；双门转移远程攻击（${s.pair.cd.join('—')}秒冷却，存在${s.pair.life}秒）；${s.small.count.join('—')}小门依次吐弹；消隐${s.vanish.life}秒前释放辐射弹；远距黑洞传送双方单位，近战重伤${s.hole.wound}秒。\n生命降至${s.phaseAt*100}%后${s.ultimateDelay}秒展开${s.ultimate.life}秒门阵：激光前摇${s.ultimate.warn}秒，持续${s.ultimate.laserLife}秒并反弹，每次有效命中回血${s.ultimate.heal*100}%，可以超过生命上限；停双门与小门。被动反射激光武器。`;}
    }else{const hp=d.hp*(elite?base.hp:1)*(elite&&id==='bomber'?c.bomber.eliteHp:1);stats=`基础生命 ${RG.configNumber(hp)} · 接触/弹体伤害 ${RG.configNumber(d.dmg*(elite?base.dmg:1))}\n移速 ${d.speed} 像素/秒 · 经验 ${d.xp*(elite?base.xp:1)}\n实际生命/伤害/经验随对局时间成长，精英移速有随机修正。`;mechanism=mechanisms[id]?.()||'按战场职责追击或支援。';}
    const resistance=RG.ELEMENT_ORDER.map(el=>RG.ELEMENTS[el].name+' '+((res[el]||0)>0?'抗性 ':res[el]<0?'弱点 ':'常规 ')+Math.round(Math.abs(res[el]||0)*100)+'%').join(' · ');
    return {name,boss,elite,id,stats,mechanism,resistance,n};
  }
  function codexIcon(key,x,y,size){const [tier,id]=key.split(':');if(tier==='boss'){const pos=BOSS_ATLAS_CELLS[id]||BOSS_ATLAS_CELLS.void;drawBossCell(pos[0],pos[1],x+size/2,y+size/2,size,0);}else RG.DrawKit.drawEnemyIcon(id,x,y,size);}
  function drawCodex(b,rects,seen){
    const groups=[['普通',Object.keys(RG.ETYPES).map(id=>'normal:'+id)],['稀有 · 精英',Object.keys(RG.ETYPES).filter(id=>!RG.ETYPES[id].noElite).map(id=>'elite:'+id)],['传说 · 首领',bossKinds.map(id=>'boss:'+id)]];
    const unlocked=key=>key.startsWith('boss:')?seen.includes(key):seen.includes(key.split(':')[1]);
    const view={x:b.x,y:b.top,w:b.w,h:b.bottom-b.top},s=RG.codexScroll;RG.codexViewport=view;
    c.save();c.beginPath();c.rect(view.x,view.y,view.w,view.h);c.clip();let y=view.y-s.y;
    const cols=b.w>640?4:b.w>400?3:2,gap=8,w=(b.w-gap*(cols-1))/cols,h=84;
    for(const [name,keys]of groups){text(name,view.x,y+20,view.w,14,gold,true);y+=32;
      keys.forEach((key,i)=>{const x=view.x+i%cols*(w+gap),yy=y+Math.floor(i/cols)*(h+gap);if(yy+h<view.y||yy>view.y+view.h)return;panel(x,yy,w,h,key.startsWith('boss:')?'#c9a0e3':key.startsWith('elite:')?gold:'#85bfc5');const on=unlocked(key);c.save();c.globalAlpha=on?1:.15;codexIcon(key,x+w/2-21,yy+5,42);c.restore();text(on?codexData(key).name:'尚未解锁',x+5,yy+68,w-10,11,on?ink:muted,false,'center');if(on)rects.push({x,y:Math.max(yy,view.y),w,h:Math.min(yy+h,view.y+view.h)-Math.max(yy,view.y),action:'codex',id:key});});
      y+=Math.ceil(keys.length/cols)*(h+gap)+16;
    }c.restore();s.max=Math.max(0,y+s.y-view.y-view.h);s.y=RG.clamp(s.y,0,s.max);
    if(s.max>0){c.fillStyle='#6e627e';c.fillRect(view.x+view.w-3,view.y+s.y/s.max*Math.max(0,view.h-32),3,32);}
    if(!RG.codexSelection)return;
    const d=codexData(RG.codexSelection),pw=Math.min(570,RG.W-32),ph=Math.min(600,RG.H-24),x=(RG.W-pw)/2,yy=(RG.H-ph)/2,compact=ph<420,icon=compact?46:82;
    c.fillStyle='rgba(0,0,0,.82)';c.fillRect(0,0,RG.W,RG.H);panel(x,yy,pw,ph,'#c9a0e3');RG.uiNav=[];rects.length=0;
    text(d.name,x+12,yy+25,pw-80,15,gold,true);button(rects,{x:x+pw-58,y:yy+6,w:48,h:44,action:'codexclose'},'关闭');codexIcon(RG.codexSelection,x+(pw-icon)/2,yy+38,icon);
    const body={x:x+18,y:yy+48+icon,w:pw-36,h:ph-62-icon};RG.codexViewport=body;
    const rows=textRows(d.stats+'\n\n'+d.mechanism+'\n\n元素克制：'+d.resistance,body.w-8,12),max=Math.max(0,rows.length*18-body.h);RG.codexDetailScroll=RG.clamp(RG.codexDetailScroll||0,0,max);RG.codexDetailMax=max;
    c.save();c.beginPath();c.rect(body.x,body.y,body.w,body.h);c.clip();rows.forEach((r,i)=>text(r,body.x,body.y+14+i*18-RG.codexDetailScroll,body.w-8,12,ink));c.restore();
  }
  function guide(){const rects=RG.guideRects=[],b=shell('新手指南','攻击会自动锁敌，专心走位',rects),keys=RG.controls?.bindings||RG.DEFAULT_KEYS,key=id=>RG.keyLabel(keys[id]),move=['up','left','down','right'].map(key).join(' / '),items=[['01  移动',RG.touchMode?'左侧拖动摇杆，绕开敌人包围':move+' 移动，绕开敌人包围'],['02  冲刺',RG.touchMode?'点击右侧冲刺按钮，短暂无敌并穿墙':key('dash')+' 冲刺，短暂无敌并穿墙'],['03  升级','经验升级，选中后确认；共鸣同族计1件，3/5档累计'],['04  主动与进化',(RG.touchMode?'点击右侧技能按钮':'主动技能 '+key('active1')+' / '+key('active2'))+'；暂停装备页可查进化条件']];
    const cols=b.w>520?2:1,h=(b.bottom-b.top-10*(4/cols-1))/(4/cols);items.forEach((a,i)=>tile({x:b.x+i%cols*(b.w+10)/cols,y:b.top+Math.floor(i/cols)*(h+10),w:(b.w-10*(cols-1))/cols,h},a[0],a[1],'#a4bf91'));
    button(rects,{x:b.x,y:b.footer,w:b.w,h:44,action:'practice'},'选择武器并开始',gold,true);
  }
  function rush(){const rects=RG.rushRects=[],b=shell('BOSS 连战','首通 '+RG.BALANCE.economy.rushFirst+' 金 · 破纪录 '+RG.BALANCE.economy.rushRecord+' 金',rects),br=RG.meta.bossRush||{unlocked:1,cleared:[],best:{}};
    const tier=tabs('rush',b,[['early','初阶试炼'],['late','高阶试炼']]),cols=b.w>800?4:2;
    for(const r of page(RG.BOSS_NAMES.slice(tier==='early'?0:4,tier==='early'?4:8),'rush',b,100,cols)){
      const id=RG.BOSS_NAMES.indexOf(r.item)+1,on=id<=br.unlocked,kind=['gluttony','golem','eye','shadow','mirror','domain','furnace','void'][id-1],bc=BOSS_ATLAS_CELLS[kind];
      c.fillStyle=on?'rgba(67,39,58,.70)':'rgba(22,27,39,.66)';pixelRect(r.x,r.y,r.w,r.h,5);c.fill();
      c.strokeStyle=on?'#a86579':'#4e5364';c.lineWidth=1;pixelRect(r.x+.5,r.y+.5,r.w-1,r.h-1,5);c.stroke();
      c.save();c.globalAlpha=on?1:.18;if(!drawBossCell(bc[0],bc[1],r.x+27,r.y+30,36,0))iconArt('trophy',r.x+9,r.y+12,36);c.restore();
      const tx=r.x+52,tw=r.w-62;
      text(id+' · '+(on?r.item:'???'),tx,r.y+23,tw,12,on?ink:muted,true);
      const best=RG.rushBestTime(id,RG.meta.rushDifficulty||1);
      text(on?(best!==undefined?'纪录 '+best.toFixed(1)+'s':br.cleared.includes(id)?'已通关 · 本难度待挑战':'首通 +'+RG.BALANCE.economy.rushFirst+' 金'):'尚未解锁',tx,r.y+44,tw,11,on?gold:muted);
      wrap(RG.BOSS_WEAPON_REWARDS[id-1].length?'解锁 '+RG.BOSS_WEAPON_REWARDS[id-1].map(w=>RG.WEAPONS[w].name).join(' / '):'无专属武器奖励',r.x+12,r.y+68,r.w-24,2,10,muted);
      if(on)rects.push({...r,action:'rushstart',id});
    }
  }
  function settings(){const rects=RG.setRects=[],b=shell('设置',RG.muted?(RG.touchMode?'当前静音 · 声音页可解除':'当前静音 · 战斗右上角可解除'):'即时生效 · 自动保存',rects);
    if(RG.controlEditing){drawControlEditor();return;}
    const category=tabs('settings',b,[['audio','声音'],['control','操作'],['visual','画面'],['keys','按键'],['save','存档'],...(RG.androidUpdateSupported?[['update','更新']]:[])]);
    if(category==='update'){
      const info=RG.androidUpdateInfo||{state:'unavailable',message:'更新器准备中'},paused=RG.returnState==='pause',busy=RG.androidUpdateActivating||['checking','downloading','applying'].includes(info.state);
      let y=b.top;text('当前版本 '+(info.version||RG.VERSION)+(info.availableVersion?'  →  '+info.availableVersion:''),b.x,y+16,b.w,12,ink,true);y+=28;
      wrap(paused?'请先回到主菜单，再下载或启用更新':info.message||'可检查内容更新',b.x,y+12,b.w,2,12,info.state==='error'? '#df9ca4':gold);y+=42;
      if(info.state==='downloading'){
        const ratio=info.total>0?Math.min(1,info.bytes/info.total):0;c.fillStyle='#34313c';c.fillRect(b.x,y,b.w,6);c.fillStyle=gold;c.fillRect(b.x,y,b.w*ratio,6);
        text(Math.floor(ratio*100)+'%  '+(info.bytes/1048576).toFixed(1)+' / '+(info.total/1048576).toFixed(1)+' MB',b.x,y+23,b.w,11,muted);y+=36;
      }
      const command=info.state==='ready'?'apply':info.state==='available'?'download':'check',label=command==='apply'?'重启并启用更新':command==='download'?'下载更新':busy?'正在更新…':'检查更新',gap=8,w=(b.w-gap)/2,enabled=!paused&&!busy&&info.state!=='unavailable';
      button(enabled?rects:[],{x:b.x,y,w,h:44,action:'android-update:'+command},label,enabled?gold:muted);
      button(enabled?rects:[],{x:b.x+w+gap,y,w,h:44,action:'android-update:configure'},'更新地址',enabled?ink:muted);y+=60;
      const lines=Math.max(0,Math.floor((b.y+b.h-y-8)/18));if(lines)wrap(info.notes||'内容更新保留存档；下载失败时仍可继续当前版本。',b.x,y+12,b.w,lines,12,muted);
      return;
    }
    if(category==='save'){
      const preview=RG.backupPreview,paused=RG.returnState==='pause',gap=8,bw=(b.w-gap)/2;
      let y=b.top;
      if(!preview){
        if(paused)button(rects,{x:b.x,y,w:bw,h:44,action:'save-run'},'保存本局',gold);
        button(rects,{x:paused?b.x+bw+gap:b.x,y,w:paused?bw:b.w,h:44,action:'named-saves'},'管理局内存档',gold);y+=52;
      }
      if(preview){wrap('待导入：金币 '+Math.floor(preview.coins||0)+' · '+Math.floor(preview.runs||0)+'局 · '+Math.floor(preview.won||0)+'通关\n已领取的单次奖励不重置',b.x,y+17,b.w,2,12,ink);y+=44;}
      button(rects,{x:b.x,y,w:bw,h:44,action:'export-save'},'导出备份','#85bfc5');
      button(paused?[]:rects,{x:b.x+bw+gap,y,w:bw,h:44,action:'import-save'},'导入备份',paused?muted:'#85bfc5');y+=52;
      if(preview){button(paused?[]:rects,{x:b.x,y,w:bw,h:44,action:'confirm-import'},'确认导入','#d9b879');button(rects,{x:b.x+bw+gap,y,w:bw,h:44,action:'cancel-import'},'取消导入',muted);y+=52;}
      if(paused){wrap('先结算本局，再导入备份',b.x,y+11,b.w,1,12,gold);y+=22;}
      const status=RG.storageStatus||{ok:true,message:'存档正常 · 已自动保存'};
      const statusText=status.message|| (status.ok===false?'存档不可用':'存档正常 · 已自动保存');
      const rows=textRows(statusText,b.w,12);wrap(statusText,b.x,y+11,b.w,2,12,status.ok===false?'#df9ca4':muted);y+=Math.min(2,rows.length)*17+8;
      if(RG.offlineStatus?.text)wrap(RG.offlineStatus.text,b.x,y+11,b.w,Math.max(1,Math.floor((b.y+b.h-y-11)/17)+1),12,muted);
      return;
    }
    if(category==='keys'){
      const items=[{id:'touchlayout',name:'触屏按钮布局',value:'拖动位置 · 调整大小'},{id:'resetkeys',name:'恢复默认',value:'键位与触屏布局'},...Object.keys(RG.KEY_ACTIONS).map(id=>({id:'bind:'+id,name:RG.KEY_ACTIONS[id],value:RG.bindingPending===id?'请按新键 · Esc取消':RG.keyLabel(RG.controls?.bindings[id]||RG.DEFAULT_KEYS[id])}))];
      for(const r of page(items,'settings',b,54,b.w>=360?2:1)){const on=r.item.id==='bind:'+RG.bindingPending;panel(r.x,r.y,r.w,r.h,'#85bfc5',on);if(on){c.fillStyle='#050b12';c.fillRect(r.x+4,r.y+4,r.w-8,r.h-8);}text(r.item.name,r.x+12,r.y+22,r.w-24,12,ink,true);text(r.item.value,r.x+12,r.y+43,r.w-24,11,on?'#ffd166':muted);rects.push({...r,action:r.item.id});}
      return;
    }
    if(category==='visual'){
      const rows=[{name:'帧率上限',key:'fps',selected:RG.frameRate||'60',options:[['30','30'],['60','60'],['120','120'],['auto','自动']]},
        {name:'画面清晰度',key:'resolution',selected:RG.renderQuality||'medium',options:[['low','省电'],['medium','标准'],['high','精细']]},
        {name:'特效质量',key:'fx',selected:RG.fxQuality||'medium',options:[['low','低'],['medium','中'],['high','高']]},
        {name:'自动降特效',key:'fxauto',selected:RG.fxAuto!==false,options:[[null,RG.fxAuto===false?'关闭':'开启']]}];
      for(const r of page(rows,'settings',b,80,1)){
        c.fillStyle='rgba(27,42,55,.72)';c.fillRect(r.x,r.y,r.w,r.h);c.fillStyle='#85bfc5';c.fillRect(r.x,r.y,3,r.h);
        text(r.item.name,r.x+12,r.y+23,r.w-24,12,ink,true);
        const gap=6,w=(r.w-24-gap*(r.item.options.length-1))/r.item.options.length;
        r.item.options.forEach(([value,label],i)=>button(rects,{x:r.x+12+i*(w+gap),y:r.y+32,w,h:44,action:value==null?r.item.key:r.item.key+':'+value},label,'#85bfc5',value==null?r.item.selected:r.item.selected===value));
      }
      return;
    }
    const rows=category==='audio'?[...(RG.touchMode?[['mute','游戏声音']]:[]),['master','主音量',RG.masterVol??1],['mus','音乐',RG.musicVol??.55],['sfx','音效',RG.sfxVol??1],['amb','环境音',RG.ambVol??.6]]:[['jdead','摇杆死区',((RG.joyDead||14)-2)/28],['jsens','摇杆灵敏度',((RG.joySens||1.1)-.7)/.7],['janalog','轻推轻跑']];
    for(const r of page(rows,'settings',b,b.landscape?78:60,b.landscape?(b.w>=360?2:1):b.w>800?2:1)){const [key,name,val]=r.item;
      c.fillStyle='rgba(27,42,55,.72)';c.fillRect(r.x,r.y,r.w,r.h);c.fillStyle='#85bfc5';c.fillRect(r.x,r.y,3,r.h);
      if(b.landscape){
        iconArt(category,r.x+10,r.y+8,24);text(name,r.x+42,r.y+24,r.w-52,11,ink,true);
        if(key==='mute')button(rects,{x:r.x+10,y:r.y+34,w:r.w-20,h:44,action:'mute'},RG.muted?'静音 · 点击开启':'开启 · 点击静音','#85bfc5',!RG.muted);
        else if(key==='janalog')button(rects,{x:r.x+10,y:r.y+34,w:r.w-20,h:44,action:'janalog'},RG.joyAnalog?'开启':'关闭 · 轻推全速','#85bfc5',RG.joyAnalog);
        else{const sx=r.x+14,sw=r.w-76,sy=r.y+r.h-24,value=key==='jdead'?Math.round(2+val*28)+'px':key==='jsens'?(.7+val*.7).toFixed(2)+'x':Math.round(val*100)+'%';text(value,r.x+r.w-52,sy+5,42,11,gold,false,'right');c.fillStyle='#3a4554';c.fillRect(sx,sy-3,sw,6);c.fillStyle='#85bfc5';c.fillRect(sx,sy-3,sw*RG.clamp(val,0,1),6);c.fillStyle=ink;c.fillRect(sx+sw*RG.clamp(val,0,1)-4,sy-10,8,20);rects.push({x:r.x+4,y:r.y+r.h-46,w:r.w-8,h:44,action:'vol:'+key,trackX:sx,trackW:sw});}
        continue;
      }
      iconArt(category,r.x+10,r.y+(r.h-24)/2,24);text(name,r.x+44,r.y+r.h/2+5,82,11,ink,true);
      if(key==='mute')button(rects,{x:r.x+130,y:r.y+(r.h-44)/2,w:r.w-138,h:44,action:'mute'},RG.muted?'静音 · 点击开启':'开启 · 点击静音','#85bfc5',!RG.muted);
      else if(key==='janalog')button(rects,{x:r.x+130,y:r.y+(r.h-44)/2,w:r.w-138,h:44,action:'janalog'},RG.joyAnalog?'开启 · 渐进速度':'关闭 · 轻推全速','#85bfc5',RG.joyAnalog);
      else {const sx=r.x+136,sw=r.w-194,sy=r.y+r.h/2;const value=key==='jdead'?Math.round(2+val*28)+'px':key==='jsens'?(.7+val*.7).toFixed(2)+'x':Math.round(val*100)+'%';text(value,r.x+r.w-51,sy+5,45,11,gold,false,'right');c.fillStyle='#3a4554';c.fillRect(sx,sy-3,sw,6);c.fillStyle='#85bfc5';c.fillRect(sx,sy-3,sw*RG.clamp(val,0,1),6);c.fillStyle=ink;c.fillRect(sx+sw*RG.clamp(val,0,1)-4,sy-10,8,20);rects.push({x:r.x+4,y:r.y+(r.h-44)/2,w:r.w-8,h:44,action:'vol:'+key,trackX:sx,trackW:sw});}
    }
  }
  function drawControlEditor(){
    backdrop();RG.uiNav=[];RG.uiTextBoxes=[];RG.controlRects=[];RG.setRects=[];const b=bounds(),barY=b.y;
    const actions=[['done','完成',76],['reset','重置',76],['smaller','－',44],['larger','＋',44]];let x=b.x;for(const [action,label,w] of actions){button(RG.controlRects,{x,y:barY,w,h:44,action},label,'#85bfc5');x+=w+8;}
    text('拖动按钮 · '+Math.round((RG.controls?.scale||1)*100)+'%',b.x,barY+66,b.w,12,gold);
    for(const p of RG.getControlLayout(RG.W,RG.H,RG.safe)){const r={x:p.x-p.r-5,y:p.y-p.r-5,w:p.r*2+10,h:p.r*2+10,id:p.id};panel(r.x,r.y,r.w,r.h,p.id==='dash'?'#b8a4dd':'#85bfc5',true);iconArt(p.id==='dash'?'dash':p.id==='active1'?'collapse':'aegis',p.x-16,p.y-24,32);text(p.id==='dash'?'冲刺':p.id==='active1'?'技能一':'技能二',r.x+4,p.y+23,r.w-8,11,ink,true,'center');RG.controlRects.push(r);}
  }
  RG.drawNamedSaves=function(){
    const rects=RG.saveRects=[],b=shell('局内存档','独立现场 · 读取后 3 秒准备 · 手动删除',rects),entries=RG.listNamedRuns();
    if(!entries.length){wrap('还没有命名存档。\n游玩时暂停 → 设置 → 存档 → 保存本局。',b.x,b.top+24,b.w,3,14,muted);return;}
    for(const r of page(entries,'named-saves',b,108,1)){
      panel(r.x,r.y,r.w,r.h,gold);
      const tw=Math.max(70,r.w-142);
      text(r.item.name,r.x+12,r.y+25,tw,15,gold,true);text(RG.fmtTime(r.item.time)+' · Lv'+r.item.level,r.x+12,r.y+49,tw,12,muted);
      button(rects,{x:r.x+r.w-110,y:r.y+8,w:98,h:44,action:'load-named',id:r.item.id},'读取');
      button(rects,{x:r.x+r.w-110,y:r.y+58,w:98,h:44,action:'delete-named',id:r.item.id},'删除','#df9ca4');
    }
  };
  // 详情保留原规则全文，超过可用高度时独立分页，不把截断文本当作完整效果。
  function detailPanel(item,r,key,reserve=0){
    panel(r.x,r.y,r.w,r.h,item.color||gold);drawUiIcon('inspect',r.x+12,r.y+8,24);
    iconArt(item.icon,r.x+12,r.y+40,38);textRows(item.title,r.w-72,13,true).slice(0,2).forEach((row,i)=>text(row,r.x+60,r.y+54+i*17,r.w-72,13,item.color||ink,true));
    text(item.subtitle||'',r.x+60,r.y+86,r.w-72,11,muted);
    c.fillStyle='#394250';c.fillRect(r.x+12,r.y+96,r.w-24,1);
    const rows=textRows(item.desc,r.w-24,12),available=r.h-116-reserve;
    let per=Math.max(1,Math.floor(available/17));if(rows.length>per)per=Math.max(1,Math.floor((available-47)/17));
    const pages=Math.max(1,Math.ceil(rows.length/per)),p=RG.uiPages[key]=RG.clamp(RG.uiPages[key]||0,0,pages-1);
    rows.slice(p*per,(p+1)*per).forEach((row,i)=>text(row,r.x+12,r.y+116+i*17,r.w-24,12,ink));
    if(pages>1){const yy=r.y+r.h-reserve-45;button(RG.uiNav,{x:r.x+12,y:yy,w:44,h:44,action:'page',key,delta:-1},'‹',muted);button(RG.uiNav,{x:r.x+r.w-56,y:yy,w:44,h:44,action:'page',key,delta:1},'›',muted);text((p+1)+'/'+pages,r.x+59,yy+27,r.w-118,11,muted,false,'center');}
  }
  function relicCard(r,d,selected){
    const color=d.color||gold;
    const arch=(inset)=>{const x=r.x+inset,y=r.y+inset,w=r.w-inset*2,h=r.h-inset*2;c.beginPath();c.moveTo(x,y+h);c.lineTo(x,y+h*.42);c.lineTo(x+w*.12,y+h*.19);c.lineTo(x+w/2,y);c.lineTo(x+w*.88,y+h*.19);c.lineTo(x+w,y+h*.42);c.lineTo(x+w,y+h);c.closePath();};
    c.save();c.fillStyle=selected?'#242333':'#151b28';arch(0);c.fill();c.strokeStyle=selected?gold:'#414756';c.lineWidth=selected?2:1;arch(1);c.stroke();c.strokeStyle=color;c.globalAlpha=selected?.85:.38;arch(7);c.stroke();c.restore();
    const size=Math.min(40,r.h*.26);iconArt(d.icon,r.x+(r.w-size)/2,r.y+r.h*.17,size);
    text(d.name,r.x+9,r.y+r.h-62,r.w-18,12,ink,true,'center');text(d.rangeLabel||'永久强化',r.x+9,r.y+r.h-45,r.w-18,10,color,false,'center');
    if(d.owned)drawUiIcon('owned',r.x+r.w/2-9,r.y+r.h-37,18);
    else drawCurrency(d.price,{x:r.x+5,y:r.y+r.h-39,w:r.w-10,h:22},{fontSize:12,iconSize:16,color:RG.meta.coins>=d.price?gold:'#c98e9b'});
  }
  RG.shopScroll={};
  RG.shopScrollHit=p=>{const codex=RG.state==='achievements'&&RG.uiTabs.achievements==='enemy',r=codex?RG.codexViewport:RG.shopScrollRegion;return (codex||RG.state==='shop')&&r&&p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h;};
  RG.scrollShopBy=function(dy,p){if(!RG.shopScrollHit(p))return false;if(RG.state==='achievements'){if(RG.codexSelection){RG.codexDetailScroll=RG.clamp((RG.codexDetailScroll||0)+dy,0,RG.codexDetailMax||0);return true;}const s=RG.codexScroll;s.y=RG.clamp(s.y+dy,0,s.max);return true;}const s=RG.shopScroll[RG.uiTabs.shop];if(!s||s.max<=0)return false;s.y=RG.clamp(s.y+dy,0,s.max);return true;};
  function shopItems(category){
    if(category==='weapon')return [...RG.SHOP_WEAPONS].sort((a,b)=>RG.WEAPONS[a].price-RG.WEAPONS[b].price).map(id=>{const d=RG.WEAPONS[id];return {...d,id,icon:id,rangeLabel:RG.weaponRangeLabel(id),owned:RG.weaponUnlocked(id),hint:RG.weaponRangeLabel(id)+' · '+d.shopTier,fullDesc:d.desc+'\n\n仅在强化商店购买解锁。\n解锁后加入升级卡池。'};});
    return RG.SHOP_PERKS.filter(p=>!p.runOnly&&p.group===category).map(d=>({...d,owned:RG.meta.perks.includes(d.id),fullDesc:d.desc+'\n\n永久强化，下一次开局生效。'}));
  }
  // 只滚动商品视口；分类、余额和详情保持固定，每类独立记住位置。
  function shopList(items,view,cols,height,paint){
    const category=RG.uiTabs.shop,gap=12,s=RG.shopScroll[category]||(RG.shopScroll[category]={y:0,max:0}),content=Math.ceil(items.length/cols)*(height+gap)-gap;
    s.max=Math.max(0,content-view.h);s.y=RG.clamp(s.y,0,s.max);RG.shopScrollRegion={...view};RG.shopCards=[];
    const cw=(view.w-8-gap*(cols-1))/cols,firstText=RG.uiTextBoxes.length;
    c.save();c.beginPath();c.rect(view.x,view.y,view.w,view.h);c.clip();
    items.forEach((d,i)=>{const r={x:view.x+i%cols*(cw+gap),y:view.y+Math.floor(i/cols)*(height+gap)-s.y,w:cw,h:height,item:d,id:d.id};
      if(r.y+r.h<=view.y||r.y>=view.y+view.h)return;const hit={...r,y:Math.max(r.y,view.y),h:Math.min(r.y+r.h,view.y+view.h)-Math.max(r.y,view.y)};RG.shopCards.push(r);paint(r,d,hit);
    });c.restore();
    const clippedText=RG.uiTextBoxes.splice(firstText).filter(t=>t.y>=view.y&&t.y+t.h<=view.y+view.h);RG.uiTextBoxes.push(...clippedText);
    if(s.max>0){const thumb=Math.max(24,view.h*view.h/content),ty=view.y+(view.h-thumb)*s.y/s.max;c.fillStyle='#2a3446';c.fillRect(view.x+view.w-3,view.y,3,view.h);c.fillStyle='#8c99b2';c.fillRect(view.x+view.w-3,ty,3,thumb);}
  }
  function shopOverview(){
    const rects=RG.shopRects=[],b=bounds();RG.uiNav=[];RG.uiNavState=RG.state;RG.uiTextBoxes=[];backdrop();
    const wide=b.w>=1000,side=wide?108:86,gap=12,detailW=Math.min(278,Math.max(208,b.w*.27)),bodyY=b.y+66,bodyH=b.h-74;
    button(rects,{x:b.x,y:b.y,w:76,h:44,action:'back'},'‹ 返回',ink);text('强化商店',b.x+91,b.y+29,b.w-380,23,gold,true);
    steelButton(b.x+b.w-132,b.y,132,44);drawCurrency(RG.meta.coins,{x:b.x+b.w-132,y:b.y,w:132,h:44},{align:'spread',padding:13,iconSize:24,fontSize:18,bold:true,color:gold});
    c.fillStyle='#65583f';c.fillRect(b.x,b.y+57,b.w,1);
    const groups=[['weapon','武器'],['combat','战斗'],['survival','生存'],['income','收益']];
    const category=RG.uiTabs.shop=groups.some(d=>d[0]===RG.uiTabs.shop)?RG.uiTabs.shop:'weapon';
    groups.forEach(([id,name],i)=>{const r={x:b.x,y:bodyY+i*55,w:side,h:49,action:'tab',key:'shop',id};steelButton(r.x,r.y,r.w,r.h,id===category?[119,105,160]:[110,133,167],id===category);text(name,r.x+8,r.y+r.h/2+6,r.w-16,16,id===category?gold:ink,true,'center');RG.uiNav.push(r);});
    const items=shopItems(category),gx=b.x+side+gap,gw=b.w-side-detailW-gap*2,cols=gw>=345?3:2;
    if(!items.some(d=>d.id===RG.shopSelection?.id&&RG.shopSelection.category===category)){RG.shopSelection={category,id:items[0]?.id};RG.uiPages.shopDetail=0;}
    shopList(items,{x:gx,y:bodyY,w:gw,h:bodyH},cols,Math.min(176,Math.max(140,(bodyH-gap)/2)),(r,d,hit)=>{relicCard(r,d,d.id===RG.shopSelection.id);rects.push({...hit,action:'inspect-shop'});});
    const d=items.find(d=>d.id===RG.shopSelection.id);if(!d)return;
    const dr={x:b.x+b.w-detailW,y:bodyY,w:detailW,h:bodyH};detailPanel({section:'遗物档案',title:d.name,icon:d.icon,subtitle:d.hint||'永久强化',desc:d.fullDesc,color:d.color||gold},dr,'shopDetail',58);
    const enough=RG.meta.coins>=d.price,bt={x:dr.x+12,y:dr.y+dr.h-54,w:dr.w-24,h:44,action:'buy',id:d.id};
    button(d.owned||!enough?[]:rects,bt,d.owned?'已拥有':enough?'解锁 · '+d.price+' 金':'金币不足 · '+d.price+' 金',d.owned?'#a7cda7':enough?'#fff0c5':muted,!d.owned&&enough);
  }
  function shop(){if(RG.W>=800&&RG.H>=360&&RG.W>RG.H){shopOverview();return;}const rects=RG.shopRects=[],b=shell('强化商店','余额 '+Math.floor(RG.meta.coins||0)+' 金 · 永久解锁',rects),items=[];
    const category=tabs('shop',b,[['weapon','武器'],['combat','战斗'],['survival','生存'],['income','收益']]);
    items.push(...shopItems(category));
    const view={x:b.x,y:b.top,w:b.w,h:b.y+b.h-b.top},cols=b.landscape?(b.w>=730?3:b.w>=360?2:1):b.w>850?3:b.w>480?2:1;
    shopList(items,view,cols,b.landscape?114:104,(r,d)=>{
      c.fillStyle='rgba(44,37,42,.73)';c.fillRect(r.x,r.y,r.w,r.h);c.fillStyle=gold;c.fillRect(r.x,r.y,3,r.h);
      if(b.landscape){
        iconArt(d.icon,r.x+12,r.y+10,32);text(d.name,r.x+54,r.y+24,r.w-66,12,ink,true);text(d.hint||'永久强化',r.x+54,r.y+42,r.w-66,10,gold);text(d.desc,r.x+12,r.y+58,r.w-24,10,muted);
        const bt={x:r.x+r.w-84,y:r.y+r.h-48,w:72,h:44,action:'buy',id:d.id};
        if(d.owned)drawUiIcon('owned',bt.x+24,bt.y+10,24);else button(bt.y>=view.y&&bt.y+bt.h<=view.y+view.h?rects:[],bt,d.price+' 金',RG.meta.coins>=d.price?gold:muted,RG.meta.coins>=d.price);
        return;
      }
      iconArt(d.icon,r.x+12,r.y+14,32);const tx=r.x+54,tw=r.w-148;
      text(d.name,tx,r.y+24,tw,12,ink,true);if(d.hint){text(d.hint,tx,r.y+43,tw,10,gold);wrap(d.desc,tx,r.y+59,tw,2,10,muted);}else wrap(d.desc,tx,r.y+43,tw,2,10,muted);
      const bt={x:r.x+r.w-82,y:r.y+(r.h-44)/2,w:72,h:44,action:'buy',id:d.id};
      if(d.owned)drawUiIcon('owned',bt.x+24,bt.y+10,24);else button(bt.y>=view.y&&bt.y+bt.h<=view.y+view.h?rects:[],bt,d.price+' 金',RG.meta.coins>=d.price?gold:muted,RG.meta.coins>=d.price);
    });
  }
  function oaths(){const rects=RG.oathRects=[],on=RG.meta.oaths||[],sum=RG.OATHS.reduce((v,o)=>v+(on.includes(o.id)?o.coin:0),0),b=shell('挑战契约','已选 '+on.length+' 项 · 金币加成 +'+Math.round(sum*100)+'%',rects);
    for(const r of page(RG.OATHS,'oaths',b,96,b.w>650?2:1)){const d=r.item,yes=on.includes(d.id);panel(r.x,r.y,r.w,r.h,'#cf9c81',yes);text((yes?'◆ ':'◇ ')+d.name,r.x+14,r.y+27,r.w-110,15,ink,true);text('+'+Math.round(d.coin*100)+'% 金',r.x+r.w-95,r.y+27,80,12,gold,false,'right');wrap(d.desc,r.x+14,r.y+52,r.w-28,2);rects.push({...r,action:'oath',id:d.id});}
  }
  function buildEntries(P){
    const weapons=Object.keys(P.weapons||{}).filter(id=>RG.WEAPONS[id]).map(id=>({key:'weapon:'+id,id,kind:'weapon',lv:P.weapons[id],max:P.evolved?.[id]?8:7,icon:id,color:RG.WEAPONS[id].color,...RG.weaponBuildInfo(P,id)}));
    const actives=(P.activeOrder||[]).filter(id=>RG.ACTIVES[id]).map(id=>({key:'active:'+id,id,kind:'active',lv:P.actives[id],max:RG.ACTIVES[id].maxLv,icon:id,color:RG.ACTIVES[id].color,...RG.activeBuildInfo(P,id)}));
    const passives=Object.keys(P.passives||{}).filter(id=>RG.PASSIVES[id]).map(id=>{const d=RG.PASSIVES[id];return {key:'passive:'+id,id,kind:'passive',lv:P.passives[id],max:d.maxLv,icon:d.icon||id,color:RG.RARITY[d.rarity]?.color||gold,title:d.name+' Lv'+P.passives[id],desc:RG.passiveDescription(id,P.passives[id])};});
    const sin=RG.sinBuildInfo(P);if(sin)passives.unshift({...sin,key:'sin:'+P.sinId,id:P.sinId,kind:'sin',lv:1,max:1,icon:'trophy',color:'#c7a2e0'});
    return {weapons,actives,passives};
  }
  // 构筑页只维护局部滚动，不改变其他页面的分页和输入。
  RG.buildScroll={};RG.buildScrollRegions=[];
  RG.buildScrollHit=p=>RG.state==='pause'&&(RG.buildScrollRegions||[]).find(r=>p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h);
  RG.scrollBuildBy=function(dy,p,dx=0){const r=RG.buildScrollHit(p);if(!r)return false;const s=RG.buildScroll[r.key];if(!s||s.max<=0)return false;const delta=r.axis==='x'&&Math.abs(dx)>Math.abs(dy)?dx:dy;if(!Number.isFinite(delta))return false;s.y=RG.clamp(s.y+delta,0,s.max);return true;};
  function buildClip(view,paint){
    const first=RG.uiTextBoxes.length;c.save();c.beginPath();c.rect(view.x,view.y,view.w,view.h);c.clip();paint();c.restore();
    const visible=RG.uiTextBoxes.splice(first).filter(t=>t.y>=view.y&&t.y+t.h<=view.y+view.h);RG.uiTextBoxes.push(...visible);
  }
  function buildViewport(key,r,length,axis,paint){
    const s=RG.buildScroll[key]||(RG.buildScroll[key]={y:0,max:0}),size=axis==='x'?r.w:r.h;s.max=Math.max(0,length-size);s.y=RG.clamp(s.y,0,s.max);RG.buildScrollRegions.push({...r,key,axis});
    buildClip(r,()=>paint(s.y));
    if(s.max>0){const thumb=Math.max(20,size*size/length),pos=(size-thumb)*s.y/s.max;c.fillStyle='#2a3446';if(axis==='x')c.fillRect(r.x,r.y+r.h-3,r.w,2);else c.fillRect(r.x+r.w-3,r.y,2,r.h);c.fillStyle='#8c99b2';if(axis==='x')c.fillRect(r.x+pos,r.y+r.h-3,thumb,2);else c.fillRect(r.x+r.w-3,r.y+pos,2,thumb);}
  }
  function buildHit(r,view,item){
    const x=Math.max(r.x,view.x),y=Math.max(r.y,view.y),w=Math.min(r.x+r.w,view.x+view.w)-x,h=Math.min(r.y+r.h,view.y+view.h)-y;
    if(w<=0||h<=0)return;const hit={x,y,w,h,action:'inspect-build',key:item.key};RG.offerRects.push(hit);RG.pauseCards.push({...hit,item});
  }
  function buildCard(r,item,small,view){
    if(r.y+r.h<=view.y||r.y>=view.y+view.h||r.x+r.w<=view.x||r.x>=view.x+view.w)return;
    const selected=RG.buildSelection===item.key,color=item.color||gold;
    c.fillStyle=selected?'#292937':'#141b28';pixelRect(r.x,r.y,r.w,r.h,6);c.fill();c.strokeStyle=selected?gold:color;c.lineWidth=selected?2:1;pixelRect(r.x+1,r.y+1,r.w-2,r.h-2,5);c.stroke();c.strokeStyle='#41495b';pixelRect(r.x+4,r.y+4,r.w-8,r.h-8,4);c.stroke();
    const size=small?Math.min(32,r.w-16,r.h-18):Math.min(52,r.w-16,r.h*.34),iy=r.y+(small?7:10);
    c.fillStyle='#080b12';c.fillRect(r.x+(r.w-size)/2-2,iy-2,size+4,size+4);iconArt(item.icon,r.x+(r.w-size)/2,iy,size);
    if(!small){const name=item.kind==='weapon'?RG.WEAPONS[item.id].name:RG.ACTIVES[item.id].name;const rows=textRows(name,r.w-10,Math.min(12,r.w/4.5),true).slice(0,2);rows.forEach((s,i)=>text(s,r.x+5,r.y+r.h-42+i*12,r.w-10,Math.min(12,r.w/4.5),ink,true,'center'));text('LV '+item.lv,r.x+4,r.y+r.h-7,r.w-8,11,color,false,'center');}
    const dots=Math.min(7,Math.max(1,item.max||item.lv)),step=Math.min(9,(r.w-12)/dots),x=r.x+(r.w-dots*step)/2+step/2,y=r.y+r.h-(small?7:23),sizeDot=small?2:2.4;
    for(let i=0;i<dots;i++){c.beginPath();c.moveTo(x+i*step,y-sizeDot);c.lineTo(x+i*step+sizeDot,y);c.lineTo(x+i*step,y+sizeDot);c.lineTo(x+i*step-sizeDot,y);c.closePath();c.fillStyle=i<item.lv?color:'#222b3e';c.fill();if(i>=item.lv){c.strokeStyle='#495367';c.lineWidth=1;c.stroke();}}
    buildHit(r,view,item);
  }
  function buildStats(P){
    const rows=[['生命',Math.ceil(P.hp)+' / '+P.maxhp],['护盾',(P.shield||0)+' / '+(P.shieldMax||0)],['最高伤害',Math.round(RG.run.highestDamage||0)],['暴击',Math.round(RG.effectiveCritChance(P)*100)+'%'],['暴伤',Math.round(RG.criticalDamageMultiplier(P)*100)+'%'],['减伤',Math.round(P.armor*100)+'%'],['攻速',Math.round(100/(P.cdMulEff||P.cdMul||1))+'%'],['移动',Math.round(RG.walkSpeed(P))+'像素/秒'],['经验',Math.round(P.xpMul*100)+'%'],['最高元素伤害',Math.round(RG.run.highestElementDamage||0)],['拾取',Math.round(P.pickup)+'像素'],['闪避',Math.round((P.evade||0)*100)+'%'],['远程增伤',Math.round(((P.rangedMul||1)-1)*100)+'%'],['近程增伤',Math.round(RG.passiveValue(P,'melee_power')*100)+'%'],['元素增伤',Math.round((RG.playerElementMul(P)-1)*100)+'%'],['反应增伤',Math.round(((P.reactionMul||1)*(1+(RG.resonanceBonus(P).reactionDamage||0))-1)*100)+'%'],['冲刺冷却',Math.ceil(P.dashCd||0)+'秒']];
    if(RG.touchMode){rows.push(['最佳纪录',RG.fmtTime(RG.best.time)]);if(RG.run.rushMode)rows.push(['连战难度',RG.rushDifficulty(RG.run.rushDifficulty).name]);else if(!RG.realm?.active){rows.push(['终局倒计时',RG.fmtTime(Math.max(0,RG.run.finalT-RG.run.t))]);if(RG.run.squad?.primary)rows.push(['当前攻势',RG.ETYPES[RG.run.squad.primary].name]);}}return rows;
  }
  function buildHealth(r,P){
    const ratio=RG.clamp(Math.max(0,P.hp)/Math.max(1,P.maxhp),0,1),frame=artReady('hudframe'),fill=RG.DrawKit.hudTintFill('#ef4444');
    c.save();if(frame&&fill){if(ratio>0)RG.DrawKit.drawHudTri(fill,r.x+10,r.y+4,Math.max(1,Math.round((r.w-20)*ratio)),16,6);RG.DrawKit.drawHudTri(frame,r.x,r.y,r.w,24,10);}else{c.fillStyle='#30263c';pixelRect(r.x,r.y+3,r.w,18,4);c.fill();c.fillStyle='#ef4444';c.fillRect(r.x+3,r.y+7,(r.w-6)*ratio,10);c.strokeStyle='#b7a7de';c.strokeRect(r.x+.5,r.y+3.5,r.w-1,17);}c.restore();
    if(RG.debugUiMetrics)RG.buildHealthBox={...r,ratio,image:!!(frame&&fill)};
  }
  function buildCharacter(r,P,portrait,view){
    panel(r.x,r.y,r.w,r.h,'#a3b1c7');const content=portrait?210:Math.min(96,Math.max(54,r.w*.43))+186+(r.w<140?14:0);
    const paint=offset=>{
      const y=r.y-offset,pic=portrait?82:Math.min(96,Math.max(54,r.w*.43)),cx=portrait?r.x+54:r.x+r.w/2,py=y+10,hero=artReady('launcher');
      if(hero)c.drawImage(hero,cx-pic/2,py,pic,pic);else RG.DrawKit.drawPlayerPortrait(cx,py+pic/2,pic);
      if(portrait){text('无名囚徒',r.x+110,y+36,r.w-146,18,gold,true);text('LV '+P.level,r.x+110,y+58,r.w-126,12,gold);text(RG.sinBuildInfo(P)?.title||'罪印 · 尚未选择',r.x+110,y+80,r.w-126,11,muted);}
      else{text('无名囚徒',r.x+6,y+pic+26,r.w-12,Math.min(18,r.w/6),gold,true,'center');text('LV '+P.level,r.x+6,y+pic+43,r.w-12,12,gold,false,'center');}
      const hpY=portrait?y+112:y+pic+62;text('生命',r.x+12,hpY,r.w-24,11,muted);text(Math.ceil(P.hp)+' / '+P.maxhp,r.x+12,hpY,r.w-24,12,ink,false,'right');buildHealth({x:r.x+10,y:hpY+7,w:r.w-20,h:24},P);
      const narrow=r.w<140,sy=hpY+48;text('护盾 '+(P.shield||0)+' / '+(P.shieldMax||0),r.x+12,sy,r.w-24,11,'#b7c4eb');text('经验 '+Math.floor(RG.clamp((P.xp||0)/(P.xpNext||1),0,1)*100)+'%',r.x+12,sy+(narrow?14:0),r.w-24,narrow?10:11,gold,false,'right');
      c.fillStyle='#394250';c.fillRect(r.x+12,sy+(narrow?24:10),r.w-24,1);
      for(const [i,name,value]of [[0,'暴击',Math.round(RG.effectiveCritChance(P)*100)+'%'],[1,'减伤',Math.round(P.armor*100)+'%'],[2,'攻速',Math.round(100/(P.cdMulEff||P.cdMul||1))+'%']]){const w=(r.w-24)/3,x=r.x+12+i*w;text(name,x,sy+(narrow?43:29),w,10,muted,false,'center');text(value,x,sy+(narrow?62:48),w,13,gold,true,'center');}
      if(!portrait)text(RG.sinBuildInfo(P)?.title||'罪印 · 尚未选择',r.x+10,sy+(narrow?86:72),r.w-20,10,muted,false,'center');
    };
    if(portrait)paint(0);else buildViewport('character',{x:r.x+2,y:r.y+2,w:r.w-4,h:r.h-4},content,'y',paint);
    const stats={x:r.x+r.w-48,y:r.y+6,w:44,h:44,action:'pause-stats'};if(stats.y>=view.y&&stats.y+stats.h<=view.y+view.h){drawUiIcon('stats',stats.x+10,stats.y+10,24);RG.offerRects.push(stats);}
  }
  function buildDetail(item,r,portrait,view){
    panel(r.x,r.y,r.w,r.h,item.color||gold);const color=item.color||gold,header=portrait?85:104;
    text('当前选中',r.x+12,r.y+23,r.w-24,11,gold);iconArt(item.icon,r.x+12,r.y+37,34);
    textRows(item.title,r.w-66,13,true).slice(0,2).forEach((s,i)=>text(s,r.x+55,r.y+47+i*16,r.w-66,13,color,true));text(item.subtitle||'',r.x+55,r.y+79,r.w-66,11,color);
    c.fillStyle='#394250';c.fillRect(r.x+12,r.y+header,r.w-24,1);const rows=textRows(item.desc,r.w-30,12),body={x:r.x+12,y:r.y+header+8,w:r.w-24,h:r.h-header-18};
    const paint=offset=>rows.forEach((row,i)=>text(row,body.x,body.y+14+i*18-offset,body.w-5,12,ink));
    if(portrait)paint(0);else buildViewport('detail',body,rows.length*18+4,'y',paint);
    RG.buildDetailInfo={key:item.key,desc:item.desc,rows:[...rows],view:body};
  }
  function buildOverview(){
    const P=RG.P,b=bounds(),portrait=RG.W<=RG.H,rects=RG.offerRects=[];RG.pauseCards=[];RG.uiNav=[];RG.uiNavState='pause';RG.uiTextBoxes=[];RG.buildScrollRegions=[];RG.rerollRect=null;backdrop();
    const entries=buildEntries(P),all=[...entries.weapons,...entries.actives,...entries.passives],statsItem={key:'stats',icon:'power',title:'角色数值',subtitle:'LV '+P.level,color:gold,desc:buildStats(P).map(([n,v])=>n+'  '+v).join('\n')};
    if(!all.some(d=>d.key===RG.buildSelection)&&RG.buildSelection!=='stats'){RG.buildSelection=all[0]?.key||'stats';if(RG.buildScroll.detail)RG.buildScroll.detail.y=0;}
    const selected=RG.buildSelection==='stats'?statsItem:all.find(d=>d.key===RG.buildSelection)||statsItem;
    const header=portrait?88:54,footerH=portrait?102:44,footer=b.y+b.h-footerH,view={x:b.x,y:b.y+header+8,w:b.w,h:Math.max(1,footer-b.y-header-18)};
    text('构筑总览',b.x,b.y+25,b.w,portrait?24:Math.min(30,RG.W*.029),gold,true);
    const caption=(RG.run.rushMode?'首领连战':RG.mapConfig(RG.run.mapId||'legacy').name)+' · '+RG.fmtTime(RG.run.t)+' · 击杀 '+RG.run.kills+' · 可用金币 '+RG.runShopBalance();text(caption,b.x,b.y+45,b.w,10,muted);
    const badges=Object.entries(RG.resonanceCounts(P)).filter(([,n])=>n>=RG.resonanceThreshold(P,RG.RESONANCE_RULES.first)).sort((a,b)=>b[1]-a[1]).slice(0,2);badges.forEach(([id,n],i)=>{const w=Math.min(142,(b.w-8)/2),x=portrait?b.x+i*(w+8):b.x+b.w-(w+8)*(badges.length-i),y=portrait?b.y+54:b.y-2;if(!portrait&&b.w<700)return;panel(x,y,w,28,id==='element'?'#81d3ef':gold);text('◆ '+RG.RESONANCES[id].name+' '+n+'件',x+6,y+19,w-12,10,id==='element'?'#81d3ef':gold,true,'center');});
    c.fillStyle='#65583f';c.fillRect(b.x,b.y+header,b.w,1);
    const section=(name,count,r)=>{text(name,r.x,r.y+14,r.w,13,gold,true);text(count,r.x,r.y+14,r.w,11,muted,false,'right');c.fillStyle='#494547';c.fillRect(r.x+38,r.y+8,Math.max(0,r.w-76),1);};
    const equipment=(r,cardH,clip)=>{
      const gap=6,nw=Math.max(3,entries.weapons.length),content=portrait?r.w:Math.max(r.w,(nw+2)*50+30),weaponW=(content-20)*nw/(nw+2),activeW=content-20-weaponW;
      const paint=offset=>{const x=r.x-offset;section('武器',entries.weapons.length+' / '+(P.passives.backpack?4:3),{x,y:r.y,w:weaponW});section('主动',entries.actives.length+' / 2',{x:x+weaponW+20,y:r.y,w:activeW});for(const [list,start,w,slots]of [[entries.weapons,x,weaponW,nw],[entries.actives,x+weaponW+20,activeW,2]]){const cw=(w-gap*(slots-1))/slots;for(let i=0;i<slots;i++){const rr={x:start+i*(cw+gap),y:r.y+24,w:cw,h:cardH};if(list[i])buildCard(rr,list[i],false,clip);else{c.strokeStyle='#303b4e';pixelRect(rr.x+1,rr.y+1,rr.w-2,rr.h-2,5);c.stroke();}}}};
      if(portrait)paint(0);else buildViewport('equipment',r,content,'x',paint);
    };
    const passives=(r,clip,scroll)=>{
      const gap=7,cols=Math.max(3,Math.floor((r.w+gap)/52)),cw=(r.w-6-gap*(cols-1))/cols,ch=Math.min(58,cw+2),height=Math.max(ch,Math.ceil(entries.passives.length/cols)*(ch+gap)-gap);
      const paint=offset=>{entries.passives.forEach((d,i)=>buildCard({x:r.x+i%cols*(cw+gap),y:r.y+Math.floor(i/cols)*(ch+gap)-offset,w:cw,h:ch},d,true,clip));if(!entries.passives.length)text('本局尚未获得被动或罪印',r.x+8,r.y+26,r.w-16,11,muted);};
      if(scroll)buildViewport('passives',r,height,'y',paint);else paint(0);return height;
    };
    if(portrait){
      const cols=Math.max(3,Math.floor((view.w+7)/52)),passH=Math.max(58,Math.ceil(entries.passives.length/cols)*65),detailRows=textRows(selected.desc,view.w-28,12),detailH=114+detailRows.length*18,total=446+passH+detailH;
      if(RG.buildFocusDetail){RG.buildScroll.page={y:446+passH,max:0};RG.buildFocusDetail=false;}
      buildViewport('page',view,total,'y',offset=>{let y=view.y-offset;const cr={x:view.x,y,w:view.w,h:220};buildCharacter(cr,P,true,view);y+=238;equipment({x:view.x,y,w:view.w,h:148},112,view);y+=166;section('被动',entries.passives.length+' 项',{x:view.x,y,w:view.w});y+=24;passives({x:view.x,y,w:view.w,h:passH},view,false);y+=passH+18;buildDetail({...selected,subtitle:selected.subtitle||'LV '+selected.lv+' / '+selected.max},{x:view.x,y,w:view.w,h:detailH},true,view);});
    }else{
      const gap=12,leftW=Math.min(184,Math.max(110,b.w*.205)),rightW=Math.min(278,Math.max(144,b.w*.215)),mid={x:b.x+leftW+gap,y:view.y,w:b.w-leftW-rightW-gap*2,h:view.h},eqH=Math.min(174,Math.max(92,view.h*.38));
      buildCharacter({x:b.x,y:view.y,w:leftW,h:view.h},P,false,view);equipment({...mid,h:eqH+28},eqH,{...mid,h:eqH+28});section('被动',entries.passives.length+' 项',{x:mid.x,y:mid.y+eqH+36,w:mid.w});passives({x:mid.x,y:mid.y+eqH+60,w:mid.w,h:Math.max(20,mid.h-eqH-60)}, {x:mid.x,y:mid.y+eqH+60,w:mid.w,h:Math.max(20,mid.h-eqH-60)},true);
      buildDetail({...selected,subtitle:selected.subtitle||'LV '+selected.lv+' / '+selected.max},{x:b.x+b.w-rightW,y:view.y,w:rightW,h:view.h},false,view);
    }
    if(portrait){const gap=8,w=(b.w-gap*2)/3;button(rects,{x:b.x,y:footer,w,h:44,action:'settings'},'设置',muted);button(rects,{x:b.x+w+gap,y:footer,w,h:44,action:'save-run'},'保存本局',ink);button(rects,{x:b.x+2*(w+gap),y:footer,w,h:44,action:'abandon'},'放弃本局','#df9ca4');button(rects,{x:b.x,y:footer+54,w:b.w,h:48,action:'resume'},'继续战斗','#fff0c5',true);}
    else{button(rects,{x:b.x,y:footer,w:44,h:44,action:'settings'},'设置',muted);button(rects,{x:b.x+52,y:footer,w:98,h:44,action:'save-run'},'保存本局',ink);button(rects,{x:b.x+158,y:footer,w:98,h:44,action:'abandon'},'放弃本局','#df9ca4');const w=Math.max(124,Math.min(278,b.w*.29));button(rects,{x:b.x+b.w-w,y:footer,w,h:44,action:'resume'},'继续战斗','#fff0c5',true);}
    // 竖屏裁掉正文之外的文本及触区；固定头尾不参加滚动。
    RG.uiTextBoxes=RG.uiTextBoxes.filter(t=>t.y>=b.y&&t.y+t.h<=b.y+b.h);RG.buildLayout={portrait,view,footer};
  }
  function overlay(kind){if(kind==='levelup'){drawOffers();return;}const available=bounds(),overview=RG.W>=800&&RG.W>RG.H&&available.w>=700&&available.h>=350;if(kind==='pause'){RG.uiTabs.pause='overview';buildOverview();return;}const rects=RG.offerRects=[],P=RG.P,b=shell(kind==='levelup'?'选择强化':kind==='pause'?'暂 歇':kind==='win'?'凯旋归来':'此战落幕',kind==='levelup'?'点击卡片选中，再确认生效':'存活 '+RG.fmtTime(RG.run.t)+' · '+RG.run.kills+' 击杀 · Lv '+P.level,rects,false,kind!=='pause'&&RG.W>RG.H&&RG.H>600?480:0);RG.rerollRect=null;
    {
      // 结算沿用横屏左分类、右正文；卡片限制高度，不随屏幕拉成大空框。
      b.landscape=RG.W>RG.H&&b.w>=400;if(b.landscape)b.pager={x:b.x+b.w-140,y:b.y};
      const category=tabs('result',b,[['stats','战绩总览'],['equipment','武器技能'],['passives','被动罪印'],['recap','承伤复盘']]),items=[],color=kind==='win'?gold:'#dc8890';
      if(category==='stats')for(const [title,desc,icon] of [['存活时间',RG.fmtTime(RG.run.t),'clock'],['击杀敌人',RG.run.kills,'mob:grunt'],['达到等级','Lv '+P.level,'seed'],['本局金币',Math.round((RG.run.earnedCoins||0)+(RG.run.coins||0)+(RG.run.firstClearBonus||0)+(RG.run.recordBonus||0)),'greed'],['持有金币',Math.round(RG.meta.coins||0),'greed'],['死亡来源',kind==='win'?'尚未阵亡':RG.run.deathSource||'未知来源','shell'],['本局流派',RG.buildTags(P).map(t=>t.n).join(' / ')||'初始构筑','element'],['成就',Object.keys(RG.meta.achievements||{}).length+' / '+RG.ACHIEVEMENTS.length,'trophy']])items.push({title,desc:String(desc),icon});
      if(category==='recap'){
        const taken=Object.entries(RG.run.damageTakenBySource||{}).filter(([,v])=>Number.isFinite(v)&&v>0).sort((a,b)=>b[1]-a[1]),total=taken.reduce((n,[,v])=>n+v,0);
        if(taken.length){items.push({title:'生命损失合计',desc:Math.round(total)+' 点\n仅统计实际扣血，护盾和闪避不计入。',icon:'shell'});for(const [source,damage] of taken)items.push({title:source,desc:'生命损失 '+(Math.round(damage*10)/10)+' 点 · 占比 '+Math.round(damage/total*100)+'%',icon:'shell'});}
        else items.push({title:'本局没有承伤记录',desc:'护盾、格挡与闪避不计入生命损失。\n旧版续局仅记录恢复后的承伤。',icon:'shell'});
      }
      if(category==='equipment'){
        for(const id of Object.keys(P.weapons||{}))if(RG.WEAPONS[id])items.push({...RG.weaponBuildInfo(P,id),icon:id});
        for(const id of P.activeOrder||[])if(RG.ACTIVES[id])items.push(RG.activeBuildInfo(P,id));
      }
      if(category==='passives'){
        const sin=RG.sinBuildInfo(P);if(sin)items.push({...sin,icon:'trophy'});
        for(const id of Object.keys(P.passives||{}))if(RG.PASSIVES[id])items.push({title:RG.PASSIVES[id].name+' Lv'+P.passives[id],desc:RG.passiveDescription(id,P.passives[id]),icon:RG.PASSIVES[id].icon||id});
      }
      const pb={...b,bottom:b.landscape?b.footer-8:b.bottom-52,footer:b.landscape?b.footer:b.footer-52},cols=category==='stats'?(b.w>=600?3:b.w>=310?2:1):(b.w>=900?3:b.w>=550?2:1);
      RG.resultCards=category==='stats'?page(items,'result',pb,64,cols):buildPage(items,'result',pb,cols);
      for(const r of RG.resultCards){
        if(category==='stats'){panel(r.x,r.y,r.w,r.h,color);iconArt(r.item.icon,r.x+12,r.y+14,28);text(r.item.title,r.x+50,r.y+23,r.w-62,11,muted);if(r.item.title==='本局流派')wrap(r.item.desc,r.x+50,r.y+43,r.w-62,2,11,ink);else if(r.item.title==='死亡来源')wrap(r.item.desc,r.x+12,r.y+50,r.w-24,2,12,ink);else text(r.item.desc,r.x+50,r.y+49,r.w-62,18,ink,true);}
        else buildTile(r,color);
      }
      if(!items.length)text(category==='passives'?'本局尚未获得被动或罪印':'本局尚未获得武器或技能',b.x,b.top+30,b.w,12,muted,false,'center');
    }
    const actions=kind==='pause'?[['继续游戏','resume'],['设置','settings'],['结算回主页','abandon']]:kind==='win'?[['继续无尽','continue'],['回主菜单','menu']]:[['再来一局','retry'],['回主菜单','menu']];
    const aw=(b.w-10*(actions.length-1))/actions.length;actions.forEach((a,i)=>button(rects,{x:b.x+i*(aw+10),y:b.footer,w:aw,h:44,action:a[1]},a[0],i?muted:gold,!i));
  }
  // 手机HUD保持最少常驻信息，构筑详情放入暂停页。
  RG.drawMobileStatue=function(){const b=bounds(),w=Math.min(330,b.w),x=b.x+(b.w-w)/2,y=b.y+124;panel(x,y,w,82,'#b8a4dd');text('献祭25%生命 · 5%概率损失20%金币',x+10,y+21,w-20,12,ink,false,'center');const r={x:x+10,y:y+30,w:w-20,h:44};button([],r,'献祭','#b8a4dd',true);RG.statueRect=r;};
  RG.drawRunShop=function(){
    const rects=RG.runShopRects=[],b=shell('局内商店','本局金币 '+RG.runShopBalance()+' · 第 '+((RG.run.shopVisits||0)+1)+' 次商店',rects);
    const d=RG.perkConfig('p_boltburst'),h=Math.min(132,b.bottom-b.top-44),owned=RG.P.boltDouble;
    tile({x:b.x,y:b.top,w:b.w,h},d.name+' · '+d.price+' 金',d.desc+'\n仅本局生效，下局需重新购买。',gold,'bolt');
    button(owned||RG.runShopBalance()<d.price?[]:rects,{x:b.x,y:b.top+h+8,w:b.w,h:44,action:'runbuy',id:d.id},owned?'本局已购买':RG.runShopBalance()<d.price?'金币不足':'购买 · '+d.price+' 金',owned?muted:gold);
    wrap('临时赠金剩余 '+Math.floor(RG.run.openingGold||0)+' · 第二次商店关闭后清除，仅可使用本局金币。',b.x,b.top+h+74,b.w,2,11,muted);
    button(rects,{x:b.x,y:b.footer,w:b.w,h:44,action:'runclose'},'关闭商店 · 继续战斗',gold,true);
  };
  RG.drawMaps=maps;
  RG.drawMenuBackdrop=backdrop;RG.drawMenu=drawMenu;RG.drawLoadout=()=>weapons(false);RG.drawRushWeapon=()=>weapons(true);RG.drawGrowthHub=growth;RG.drawAchievements=achievements;RG.drawGuide=guide;RG.drawRush=rush;RG.drawSettings=settings;RG.drawShop=shop;RG.drawOaths=oaths;RG.drawAdaptiveOverlay=overlay;
  RG.DRAW_MENUS_VER="v12029";
})(window.RG);
