// ============ 首领 AI:秘境典狱官 / 八首领技能状态机 ============
(function(RG){
  // 缓存只读配置对象，避免逐帧重复遍历全局表。
  const cfgBOSS_SKILLSSharedUpdateWorkshopRunes=RG.BOSS_SKILLS.shared.updateWorkshopRunes,
    cfgBOSS_SKILLSSharedUpdateWorkshopValves=RG.BOSS_SKILLS.shared.updateWorkshopValves,
    cfgBOSS_SKILLSSharedUpdateWorkshopHoles=RG.BOSS_SKILLS.shared.updateWorkshopHoles,
    cfgBOSS_SKILLSSharedSpawnWorkshopHoles=RG.BOSS_SKILLS.shared.spawnWorkshopHoles,
    cfgBOSS_SKILLSSharedBeginWorkshopWarp=RG.BOSS_SKILLS.shared.beginWorkshopWarp,
    cfgBOSS_SKILLSSharedUpdateWorkshopWarp=RG.BOSS_SKILLS.shared.updateWorkshopWarp,
    cfgBOSS_SKILLSSharedUpdateWorkshopHeat=RG.BOSS_SKILLS.shared.updateWorkshopHeat,
    cfgBOSS_SKILLSSharedUpdateBossProgress=RG.BOSS_SKILLS.shared.updateBossProgress,
    cfgBOSS_SKILLSSharedUpdateFrostBoss=RG.BOSS_SKILLS.shared.updateFrostBoss,
    cfgBOSS_SKILLSSharedUpdateRealmBoss=RG.BOSS_SKILLS.shared.updateRealmBoss,
    cfgBOSS_SKILLSSharedUpdateBoss=RG.BOSS_SKILLS.shared.updateBoss,
    cfgBOSS_SKILLSShadowUpdateBoss=RG.BOSS_SKILLS.shadow.updateBoss,
    cfgBOSS_SKILLSFurnaceUpdateBoss=RG.BOSS_SKILLS.furnace.updateBoss,
    cfgBOSS_SKILLSDomainUpdateBoss=RG.BOSS_SKILLS.domain.updateBoss,
    cfgBOSS_SKILLSVoidUpdateBoss=RG.BOSS_SKILLS.void.updateBoss,
    cfgBOSS_SKILLSGluttonyUpdateBoss=RG.BOSS_SKILLS.gluttony.updateBoss,
    cfgBOSS_SKILLSGolemUpdateBoss=RG.BOSS_SKILLS.golem.updateBoss,
    cfgBOSS_SKILLSEyeUpdateBoss=RG.BOSS_SKILLS.eye.updateBoss;

  const {rand,clamp,dist2,pick,TAU}=RG;
  // 简单连战仅一阶段，分身沿用同一场难度；常规与其他难度不受影响。
  RG.bossFirstPhaseOnly=e=>!!RG.run?.rushMode&&RG.run.rushDifficulty===1&&(e.rushBoss||e.splitChild);
  RG.bossPhaseAllows=(e,phase)=>!RG.run?.rushMode||(e.mechanicPhase||1)>=phase;
  RG.isWorkshopBoss=e=>RG.run?.mapId==='workshop'&&!RG.run.rushMode&&e.boss&&['domain','furnace','void'].includes(e.bossKind);
  // 校验整个圆形落点；预警后如果出现新墙，取消该次跃迁，不临时换点。
  RG.workshopPointFree=function(x,y,r){
    if(!Number.isFinite(x)||!Number.isFinite(y))return false;
    const probe={x,y,r};if(RG.pushOutOfWalls(probe,RG.walls))return false;
    for(let i=0;i<8;i++)if(!RG.insideArena(x+Math.cos(i*TAU/8)*r,y+Math.sin(i*TAU/8)*r))return false;
    return true;
  };
  RG.clearWorkshopBoss=function(e){
    e.workshopWarp=null;e.workshopSafe=false;e.overOrigin=null;e.overWarned=false;
    e.workshopRunes=[];
    e.workshopValves=[];e.workshopColdT=0;e.workshopRiftT=0;
    for(const item of RG.enemies)if(item.bossOwner===e&&(item.workshopHole||item.workshopWorm))item.dead=true;
    RG.removeBattleEffects('bossOwner',e,['enemies']);
    if(RG.P?.workshopRuneOwner===e){RG.P.workshopRuneT=0;RG.P.workshopRuneOwner=null;}
    if(RG.P?.workshopCoolOwner===e){RG.P.workshopCoolT=0;RG.P.workshopCoolOwner=null;}
    RG.removeBattleEffects('bossOwner',e,['domains','hbeams','ebullets','rings','hazards','wormholes']);
  };
  // 符文是可选收益：忽略它不强化首领；收益刷新时间，不累乘，不改永久属性。
  RG.updateWorkshopRunes=function(e,dt){
    if(e.dead||e.dying||e.bossKind!=='domain'||!RG.isWorkshopBoss(e))return;
    const P=RG.P,runes=e.workshopRunes||(e.workshopRunes=[]);
    for(const r of runes){
      r.t-=dt;if(r.t<=0)continue;
      if(Math.hypot(P.x-r.x,P.y-r.y)<=r.r&&RG.workshopPointFree(r.x,r.y,r.r))r.hold=Math.min(cfgBOSS_SKILLSSharedUpdateWorkshopRunes.hold_cap,r.hold+dt);
      else r.hold=0;
      if(r.hold>=cfgBOSS_SKILLSSharedUpdateWorkshopRunes.hold_threshold){r.t=0;P.workshopRuneT=cfgBOSS_SKILLSSharedUpdateWorkshopRunes.workshopRuneT;P.workshopRuneOwner=e;RG.addText(P.x,P.y-32,'符文净化 · 伤害+'+RG.configNumber((RG.BALANCE.growth.playerDamageMul.playerDamageMul_3-1)*100)+'%','#67e8f9',14);RG.addText(P.x,P.y-50,cfgBOSS_SKILLSSharedUpdateWorkshopRunes.workshopRuneT+'秒免疫本体领域','#a7f3d0',12);RG.playSfx('choose',.8);}
    }
    e.workshopRunes=runes.filter(r=>r.t>0);
    if(RG.timeStop>0)return;
    e.runeCd=(e.runeCd??cfgBOSS_SKILLSSharedUpdateWorkshopRunes.runeCd)-dt;if(e.runeCd>0)return;e.runeCd=cfgBOSS_SKILLSSharedUpdateWorkshopRunes.runeCd_2;
    const offset=rand(0,TAU);
    for(let i=0;i<48&&e.workshopRunes.length<cfgBOSS_SKILLSSharedUpdateWorkshopRunes.length_threshold;i++){
      const a=offset+i*TAU/16,d=cfgBOSS_SKILLSSharedUpdateWorkshopRunes.d_offset+Math.floor(i/cfgBOSS_SKILLSSharedUpdateWorkshopRunes.d_divisor)*100,x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;
      if(Math.hypot(x-e.x,y-e.y)<e.r+cfgBOSS_SKILLSSharedUpdateWorkshopRunes.updateWorkshopRunes_offset||!RG.workshopPointFree(x,y,cfgBOSS_SKILLSSharedUpdateWorkshopRunes.updateWorkshopRunes_workshopPointFreeArg3)||e.workshopRunes.some(r=>Math.hypot(x-r.x,y-r.y)<cfgBOSS_SKILLSSharedUpdateWorkshopRunes.range_threshold))continue;
      e.workshopRunes.push({x,y,r:cfgBOSS_SKILLSSharedUpdateWorkshopRunes.r,t:cfgBOSS_SKILLSSharedUpdateWorkshopRunes.t,hold:0});
    }
    if(e.workshopRunes.length)RG.addText(P.x,P.y-68,'净化符文 · 站印'+cfgBOSS_SKILLSSharedUpdateWorkshopRunes.hold_threshold+'秒获得增益','#67e8f9',13);
  };
  // 四个固定阀位，全场共享25秒冷却；仅最近两阀可读条，避免多阀连用累乘易伤。
  RG.updateWorkshopValves=function(e,dt){
    if(e.dead||e.dying||e.bossKind!=='furnace'||!RG.isWorkshopBoss(e))return;
    const P=RG.P;
    e.valveCooldown=Math.max(0,(e.valveCooldown||0)-dt);e.workshopColdT=Math.max(0,(e.workshopColdT||0)-dt);
    if(!e.workshopValves){
      e.workshopValves=[];const offset=rand(0,TAU);
      for(let i=0;i<64&&e.workshopValves.length<cfgBOSS_SKILLSSharedUpdateWorkshopValves.length_threshold;i++){
        const a=offset+i*TAU/16,d=cfgBOSS_SKILLSSharedUpdateWorkshopValves.d_offset+Math.floor(i/cfgBOSS_SKILLSSharedUpdateWorkshopValves.d_divisor)*100,x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;
        if(!RG.workshopPointFree(x,y,cfgBOSS_SKILLSSharedUpdateWorkshopValves.updateWorkshopValves_workshopPointFreeArg3)||Math.hypot(x-e.x,y-e.y)<e.r+cfgBOSS_SKILLSSharedUpdateWorkshopValves.updateWorkshopValves_offset||e.workshopValves.some(v=>Math.hypot(x-v.x,y-v.y)<cfgBOSS_SKILLSSharedUpdateWorkshopValves.range_threshold))continue;
        e.workshopValves.push({x,y,r:cfgBOSS_SKILLSSharedUpdateWorkshopValves.r,hold:0,active:false});
      }
    }
    const ready=e.valveCooldown<=0&&((e.heat||0)>=cfgBOSS_SKILLSSharedUpdateWorkshopValves.ready_threshold||!!e.overOrigin);
    const available=e.workshopValves.filter(v=>RG.workshopPointFree(v.x,v.y,v.r)).sort((a,b)=>dist2(P.x,P.y,a.x,a.y)-dist2(P.x,P.y,b.x,b.y)).slice(0,cfgBOSS_SKILLSSharedUpdateWorkshopValves.available_sliceArg2);
    for(const v of e.workshopValves){
      v.active=ready&&available.includes(v);
      if(v.active&&Math.hypot(P.x-v.x,P.y-v.y)<=v.r)v.hold=Math.min(cfgBOSS_SKILLSSharedUpdateWorkshopValves.hold_cap,v.hold+dt);else v.hold=0;
      if(v.hold<cfgBOSS_SKILLSSharedUpdateWorkshopValves.hold_threshold)continue;
      e.valveCooldown=cfgBOSS_SKILLSSharedUpdateWorkshopValves.valveCooldown;e.heat=0;e.overOrigin=null;e.overWarned=false;e.overT=cfgBOSS_SKILLSSharedUpdateWorkshopValves.overT;e.coolingT=cfgBOSS_SKILLSSharedUpdateWorkshopValves.coolingT;e.workshopColdT=cfgBOSS_SKILLSSharedUpdateWorkshopValves.workshopColdT;e.charging=e.chargeWind=0;
      for(const other of e.workshopValves){other.hold=0;other.active=false;}
      P.workshopCoolT=cfgBOSS_SKILLSSharedUpdateWorkshopValves.workshopCoolT;P.workshopCoolOwner=e;RG.addText(P.x,P.y-32,'急冷成功 · '+cfgBOSS_SKILLSSharedUpdateWorkshopValves.workshopCoolT+'秒免疫熔渣','#67e8f9',14);RG.addText(e.x,e.y-e.r-22,'急冷'+cfgBOSS_SKILLSSharedUpdateWorkshopValves.workshopColdT+'秒 · 受伤+'+RG.configNumber((RG.BOSS_SKILLS.furnace.receiveDamage.taken-1)*100)+'%','#a7f3d0',14);RG.playSfx('freeze');break;
    }
  };
  RG.closeWorkshopHole=function(w,reward){
    if(w.dead)return;w.dead=true;w.hp=0;RG.wormholes=RG.wormholes.filter(h=>h!==w);
    const e=w.bossOwner;
    if(e?.workshopWarp?.hole===w){e.workshopWarp=null;e.workshopSafe=false;}
    if(!reward||!e||e.dead||e.dying||!RG.isWorkshopBoss(e))return;
    e.workshopRiftT=RG.BOSS_SKILLS.shared.closeWorkshopHole.workshopRiftT;e.charging=e.chargeWind=0;
    RG.addText(w.x,w.y-w.r-12,'虫洞击破 · 母巢失稳1.2秒','#a7f3d0',13);RG.playSfx('boom',.5);
  };
  // 虫洞与武器共享目标实体，仍是无击杀/掉落的场地物件；追踪虫为定值短命召物。
  RG.updateWorkshopHoles=function(e,dt){
    if(e.dead||e.dying||e.bossKind!=='void'||!RG.isWorkshopBoss(e))return;
    e.workshopRiftT=Math.max(0,(e.workshopRiftT||0)-dt);
    if(RG.timeStop>0)return;
    for(const w of [...RG.wormholes])if(w.workshopHole&&w.bossOwner===e&&!w.dead){
      w.t-=dt;if(w.t<=0){RG.closeWorkshopHole(w,false);continue;}
      if(w.warn>0){w.warn=Math.max(0,w.warn-dt);continue;}
      w.wormCd-=dt;
      if(w.wormCd<=0){
        w.wormCd+=cfgBOSS_SKILLSSharedUpdateWorkshopHoles.wormCd;
        if(RG.enemies.filter(m=>m.workshopWorm&&!m.dead&&!m.dying).length<cfgBOSS_SKILLSSharedUpdateWorkshopHoles.length_threshold){
          const m=RG.spawnEnemy('phantasm',false);if(m)Object.assign(m,{x:w.x,y:w.y,r:cfgBOSS_SKILLSSharedUpdateWorkshopHoles.r,hp:cfgBOSS_SKILLSSharedUpdateWorkshopHoles.hp,maxhp:cfgBOSS_SKILLSSharedUpdateWorkshopHoles.maxhp,speed:cfgBOSS_SKILLSSharedUpdateWorkshopHoles.speed,dmg:e.dmg*cfgBOSS_SKILLSSharedUpdateWorkshopHoles.dmg_factor,xp:0,life:cfgBOSS_SKILLSSharedUpdateWorkshopHoles.life,homing:true,ghost:true,bossOwner:e,workshopWorm:true});
        }
      }
    }
  };
  function spawnWorkshopHoles(e){
    const P=RG.P,offset=rand(0,TAU),limit=e.enraged?cfgBOSS_SKILLSSharedSpawnWorkshopHoles.limit:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.limit_2;
    for(let i=0;i<48&&RG.wormholes.filter(w=>w.workshopHole&&!w.dead).length<limit;i++){
      const a=offset+i*TAU/16,d=cfgBOSS_SKILLSSharedSpawnWorkshopHoles.d_offset+Math.floor(i/cfgBOSS_SKILLSSharedSpawnWorkshopHoles.d_divisor)*100,x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;
      if(!RG.workshopPointFree(x,y,cfgBOSS_SKILLSSharedSpawnWorkshopHoles.workshopPointFree_workshopPointFreeArg3)||Math.hypot(P.x-x,P.y-y)<cfgBOSS_SKILLSSharedSpawnWorkshopHoles.value_threshold||RG.wormholes.some(w=>Math.hypot(x-w.x,y-w.y)<cfgBOSS_SKILLSSharedSpawnWorkshopHoles.value_threshold_2))continue;
      const w={type:'grunt',x,y,r:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.r,hp:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.hp,maxhp:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.maxhp,speed:0,dmg:0,xp:0,elite:false,boss:false,alpha:1,flash:0,frozen:0,hitCds:{},bossOwner:e,workshopHole:true,t:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.t,warn:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.warn,wormCd:cfgBOSS_SKILLSSharedSpawnWorkshopHoles.wormCd,cool:0};RG.wormholes.push(w);RG.enemies.push(w);
    }
    if(RG.wormholes.length)RG.addText(e.x,e.y-e.r-16,'虫洞'+cfgBOSS_SKILLSSharedSpawnWorkshopHoles.hp+'生命 · 击破使母巢易伤','#c084fc',13);
  }
  function beginWorkshopWarp(e,point){
    const P=RG.P,r=e.r*cfgBOSS_SKILLSSharedBeginWorkshopWarp.r_factor,offset=rand(0,TAU);let landing=point;
    if(!landing)for(let i=0;i<32;i++){
      const a=offset+i*TAU/16,d=cfgBOSS_SKILLSSharedBeginWorkshopWarp.d_offset+Math.floor(i/cfgBOSS_SKILLSSharedBeginWorkshopWarp.d_divisor)*cfgBOSS_SKILLSSharedBeginWorkshopWarp.d_factor,x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;
      if(RG.workshopPointFree(x,y,r)){landing={x,y};break;}
    }
    if(!landing||!RG.workshopPointFree(landing.x,landing.y,r)||Math.hypot(P.x-landing.x,P.y-landing.y)<r+P.r+cfgBOSS_SKILLSSharedBeginWorkshopWarp.value_offset)return false;
    e.workshopWarp={x:landing.x,y:landing.y,aim:Math.atan2(P.y-landing.y,P.x-landing.x),t:1,stage:'warn',...(landing.workshopHole?{hole:landing}:{})};
    e.workshopSafe=true;e.charging=e.chargeWind=0;
    RG.addText(landing.x,landing.y-r-18,'跃迁锁定 · 离开冲刺线','#c084fc',14);return true;
  }
  function updateWorkshopWarp(e,dt){
    const w=e.workshopWarp;if(!w)return false;
    w.t-=dt;
    if(w.t<=0){
      if(w.stage==='warn'){
        if(w.hole?.dead||!RG.workshopPointFree(w.x,w.y,e.r*cfgBOSS_SKILLSSharedUpdateWorkshopWarp.r_factor)){e.workshopWarp=null;e.workshopSafe=false;return true;}
        e.x=w.x;e.y=w.y;w.stage='recover';w.t=cfgBOSS_SKILLSSharedUpdateWorkshopWarp.t;RG.playSfx('portal',1.4);
      }else{
        e.workshopWarp=null;e.workshopSafe=false;e.charging=cfgBOSS_SKILLSSharedUpdateWorkshopWarp.charging;e.vx=Math.cos(w.aim)*cfgBOSS_SKILLSSharedUpdateWorkshopWarp.vx_factor;e.vy=Math.sin(w.aim)*cfgBOSS_SKILLSSharedUpdateWorkshopWarp.vy_factor;
      }
    }
    return true;
  }
  function updateWorkshopHeat(e,dt){
    const P=RG.P;
    if(e.overOrigin){
      e.overT-=dt;
      if(e.overT<=0){
        const o=e.overOrigin;e.overOrigin=null;e.overWarned=false;e.heat=0;e.coolingT=cfgBOSS_SKILLSSharedUpdateWorkshopHeat.coolingT;
        RG.rings.push({x:o.x,y:o.y,r:20,maxR:o.r,life:.35,maxLife:.35,color:'#fb923c'});
        RG.cam.shake=10;RG.playSfx('boom');
        if(Math.hypot(P.x-o.x,P.y-o.y)<o.r+P.r&&RG.firstWallFraction(o.x,o.y,P.x,P.y)>=1)RG.hurtPlayer(e.dmg*cfgBOSS_SKILLSSharedUpdateWorkshopHeat.dmg_factor,false,false,RG.enemyHitSource(e,'过热爆发'));
      }
      return true;
    }
    e.coolingT=Math.max(0,(e.coolingT||0)-dt);
    if(e.coolingT>0){e.heat=0;return false;}
    e.heat=Math.min(cfgBOSS_SKILLSSharedUpdateWorkshopHeat.heat_cap,(e.heat||0)+cfgBOSS_SKILLSSharedUpdateWorkshopHeat.heat_factor*dt);
    if(e.heat>=cfgBOSS_SKILLSSharedUpdateWorkshopHeat.heat_threshold){
      e.overOrigin={x:e.x,y:e.y,r:cfgBOSS_SKILLSSharedUpdateWorkshopHeat.r};e.overT=cfgBOSS_SKILLSSharedUpdateWorkshopHeat.overT;e.overWarned=true;e.charging=e.chargeWind=0;
      RG.addText(e.x,e.y-e.r-20,'过热锁定 · 撤离或躲到墙后','#ff5470',15);return true;
    }
    return false;
  }
  RG.updateBossProgress=function(e,dt){
    e.fightElapsed=(e.fightElapsed||0)+dt;
    if(!RG.run.rushMode||!e.rushBoss||e.isClone||e.splitChild)return;
    const extreme=RG.run.rushDifficulty===cfgBOSS_SKILLSSharedUpdateBossProgress.extreme,ratio=e.hp/e.maxhp,age=e.fightElapsed;
    const phase=RG.run.rushDifficulty===1?1:extreme&&age>=cfgBOSS_SKILLSSharedUpdateBossProgress.phase_threshold&&(ratio<=cfgBOSS_SKILLSSharedUpdateBossProgress.phase_threshold_2||age>=cfgBOSS_SKILLSSharedUpdateBossProgress.phase_threshold_3)?cfgBOSS_SKILLSSharedUpdateBossProgress.phase:age>=cfgBOSS_SKILLSSharedUpdateBossProgress.phase_threshold_4&&(ratio<=cfgBOSS_SKILLSSharedUpdateBossProgress.phase_threshold_5||age>=cfgBOSS_SKILLSSharedUpdateBossProgress.phase_threshold)?cfgBOSS_SKILLSSharedUpdateBossProgress.phase_2:1;
    if(phase>(e.mechanicPhase||1)){
      e.mechanicPhase=phase;
      e.spdMul=1+cfgBOSS_SKILLSSharedUpdateBossProgress.spdMul_factor*(phase-1);
      RG.addText(e.x,e.y-e.r-32,phase===3?'第三阶段 · 极限攻势':'第二阶段 · 强化招式','#fbbf24',15);
      // 新招保留自身冷却，升级当帧不会把积攒的技能一起喷出。
      e.escortT=Math.min(e.escortT??cfgBOSS_SKILLSSharedUpdateBossProgress.escortT,cfgBOSS_SKILLSSharedUpdateBossProgress.escortT_cap);
    }
  };
  RG.initFrostBoss = function(e) {
    const c=RG.FROST_BOSS;
    e.name=RG.BOSS_NAMES[4];e.speed=RG.enemyContractSpeed(c.speed);e.enrageAt=c.phaseAt;
    const pace=e.attackMul||1;
    e.frost={phase:1,shieldT:c.shieldEvery,fieldT:c.field.first*pace,breathT:c.breath.first*pace,slowT:c.slow.first*pace,wallT:c.wall.first*pace,walls:[],wallQueue:[],corpses:[]};
    e.enraged=false;e.mechanicPhase=1;delete e.mirT;delete e.mirPhase;delete e.swapI;
  };
  // 冰墙只阻挡普通移动；闪现位移复用既有穿墙权限。圆弧与画面共用同一几何参数。
  RG.resolveFrostWalls=function(P,oldX,oldY){
    if(P.dashT>0&&P.dashGhost>0)return;
    for(const e of RG.enemies)if(!e.dead&&!e.dying&&e.frost)for(const w of e.frost.walls){
      if(w.warn>0||w.t<=0)continue;
      const dx=P.x-w.x,dy=P.y-w.y,d=Math.hypot(dx,dy)||1,oldD=Math.hypot(oldX-w.x,oldY-w.y),a=Math.atan2(dy,dx);
      let da=a-w.a;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;
      if(!w.full&&Math.abs(da)>Math.PI/2+P.r/w.r)continue;
      const pad=P.r+w.width/2;
      if(Math.abs(d-w.r)<pad||(oldD-w.r)*(d-w.r)<0){
        const radius=oldD<w.r?w.r-pad-.1:w.r+pad+.1;P.x=w.x+dx/d*radius;P.y=w.y+dy/d*radius;
      }
    }
  };
  RG.clearFrostBoss=function(e){
    if(!e.frost)return;
    for(const corpse of e.frost.corpses)RG.gems.push({x:corpse.x,y:corpse.y,v:corpse.xp,tier:corpse.tier,big:corpse.tier>0,pull:false,delay:RG.BOSS_SKILLS.shared.clearFrostBoss.delay});
    e.frost.corpses=[];e.frost.walls=[];e.frost.wallQueue=[];e.frost.breath=null;
    RG.removeBattleEffects('frostOwner',e,['domains','hbeams','ebullets']);
  };
  function updateFrostBoss(e,dt,dx,dy,d,moveMul){
    if(!e.frost)RG.initFrostBoss(e);
    const c=RG.FROST_BOSS,s=e.frost;
    if(!RG.bossFirstPhaseOnly(e)&&RG.bossPhaseAllows(e,cfgBOSS_SKILLSSharedUpdateFrostBoss.bossPhaseAllows_bossPhaseAllowsArg2)&&s.phase===1&&(e.hp<=e.maxhp*c.phaseAt||RG.run.rushMode&&e.fightElapsed>=cfgBOSS_SKILLSSharedUpdateFrostBoss.fightElapsed_threshold)){s.phase=cfgBOSS_SKILLSSharedUpdateFrostBoss.phase;e.enraged=true;e.mechanicPhase=Math.max(cfgBOSS_SKILLSSharedUpdateFrostBoss.mechanicPhase_floor,e.mechanicPhase||1);RG.addText(e.x,e.y-e.r-28,'第二阶段 · 极寒封界','#67e8f9',17);}
    const phase=s.phase-1,pace=e.attackMul||1;
    e.x+=dx/d*e.speed*dt*moveMul;e.y+=dy/d*e.speed*dt*moveMul;
    s.shieldT-=dt;
    if(s.shieldT<=1e-9){s.shieldT+=c.shieldEvery;e.shieldHp=(e.shieldHp||0)+e.maxhp*c.shield[phase];RG.addText(e.x,e.y-e.r-14,'冰盾 +'+Math.round(c.shield[phase]*100)+'%','#38bdf8',14);RG.playSfx('block');}
    for(const w of s.walls){if(w.warn>0)w.warn=Math.max(0,w.warn-dt);else w.t-=dt;}s.walls=s.walls.filter(w=>w.t>0);
    // 延迟释放只存入队列，出现后才开始各自预警与十秒寿命。
    for(const w of s.wallQueue){w.delay-=dt;if(w.delay<=1e-9){w.warn=Math.max(0,w.warn+w.delay);s.walls.push(w);}}
    s.wallQueue=s.wallQueue.filter(w=>w.delay>1e-9);
    s.fieldT-=dt;
    if(s.fieldT<=0){
      s.fieldT+=c.field.cd*pace;const a=Math.atan2(dy,dx),scale=phase?c.field.grow:1;
      for(const offset of phase?[cfgBOSS_SKILLSSharedUpdateFrostBoss.value,0,cfgBOSS_SKILLSSharedUpdateFrostBoss.value_2]:[0])RG.hbeams.push({x:e.x,y:e.y,a:a+offset,len:c.field.length*scale,w:c.field.width*scale,warn:c.field.warn,fire:c.field.life,hitP:false,dmg:e.dmg*c.field.damage,frostField:true,freeze:c.field.freeze,frostOwner:e,col:'#67e8f9'});
      RG.addText(e.x,e.y-e.r-14,'寒冰场','#7dd3fc',13);
    }
    // 一轮吐息固定次数与0.2秒间隔；冷却不会覆盖未完成的吐息。
    s.breathT-=dt;
    if(s.breath){
      s.breath.next-=dt;
      while(s.breath&&s.breath.next<=1e-9){
        const cast=s.breath,n=c.breath.shots[cast.phase];
        for(let i=0;i<n;i++){const a=i/n*TAU+cast.index*.08;RG.ebullets.push({x:e.x,y:e.y,vx:Math.cos(a)*c.breath.speed,vy:Math.sin(a)*c.breath.speed,r:cfgBOSS_SKILLSSharedUpdateFrostBoss.r,dmg:e.dmg*c.breath.damage,life:cfgBOSS_SKILLSSharedUpdateFrostBoss.life,slow:true,col:'#7dd3fc',frostOwner:e,noWall:true});}
        cast.index++;cast.next+=c.breath.interval;RG.playSfx('freeze',.8);
        if(cast.index>=c.breath.count[cast.phase])s.breath=null;
      }
    }else if(s.breathT<=0){s.breathT+=c.breath.cd*pace;s.breath={next:c.breath.warn,index:0,phase};RG.addText(e.x,e.y-e.r-16,'全向寒息','#a5f3fc',13);}
    s.slowT-=dt;
    if(s.slowT<=0){s.slowT+=c.slow.cd*pace;RG.domains.push({x:RG.P.x,y:RG.P.y,r:c.slow.radius[phase],t:c.slow.life,type:'slow',frostOwner:e});}
    s.wallT-=dt;
    if(s.wallT<=0){
      s.wallT+=c.wall.cd*pace;const angle=Math.atan2(dy,dx),cx=RG.P.x,cy=RG.P.y;
      // 三面半圆错开阻路；二阶段以脚下位置为中心的一道圆墙和两道外侧圆墙。
      let delay=0;
      for(let i=0;i<c.wall.count;i++){
        const offset=i===0?0:c.wall.radius[phase]*cfgBOSS_SKILLSSharedUpdateFrostBoss.offset_factor,a=angle+(i===1?1.1:-1.1);
        if(i>0)delay+=rand(0,c.wall.gap);
        const wall={x:cx+Math.cos(a)*offset,y:cy+Math.sin(a)*offset,a:angle+(i-1)*1.05,r:c.wall.radius[phase],width:c.wall.thickness,full:!!phase,warn:c.wall.warn,t:c.wall.life,delay};
        if(delay<=1e-9)s.walls.push(wall);else s.wallQueue.push(wall);
      }
      RG.addText(e.x,e.y-e.r-18,phase?'冰牢 · 闪现穿越或等待消融':'冰墙封路','#a5f3fc',14);RG.playSfx('trap');
    }
  }
  function updateRealmBoss(e,dt,moveMul){
    const P=RG.P,ratio=e.hp/e.maxhp,next=ratio<=cfgBOSS_SKILLSSharedUpdateRealmBoss.next_threshold?cfgBOSS_SKILLSSharedUpdateRealmBoss.next:ratio<=cfgBOSS_SKILLSSharedUpdateRealmBoss.next_threshold_2?cfgBOSS_SKILLSSharedUpdateRealmBoss.next_2:1;
    if(!e.realmPhase)e.realmPhase=1;
    if(next!==e.realmPhase){e.realmPhase=next;e.enraged=next===cfgBOSS_SKILLSSharedUpdateRealmBoss.enraged;RG.ebullets.length=0;RG.hbeams.length=0;RG.addText(e.x,e.y-e.r-24,next===2?"第二钥印 · 锁界加速":"终末钥印 · 狂暴","#c084fc",17);RG.cam.shake=9;}
    e.realmCastT=Math.max(0,(e.realmCastT||0)-dt);
    // 围绕秘境中心缓慢巡游，径向弹簧把典狱官限制在约160px内，不会穿出外墙。
    const cr=Math.hypot(e.x,e.y)||1,tx=-e.y/cr,ty=e.x/cr,pull=(cfgBOSS_SKILLSSharedUpdateRealmBoss.pull_offset-cr)*cfgBOSS_SKILLSSharedUpdateRealmBoss.pull_factor;
    e.x+=(tx*e.speed*.42+e.x/cr*pull)*dt*moveMul;e.y+=(ty*e.speed*.42+e.y/cr*pull)*dt*moveMul;
    if(e.keyWarn){
      e.keyWarn.t-=dt;
      if(e.keyWarn.t<=0){
        const n=[0,cfgBOSS_SKILLSSharedUpdateRealmBoss.n,cfgBOSS_SKILLSSharedUpdateRealmBoss.n_2,cfgBOSS_SKILLSSharedUpdateRealmBoss.n_3][e.realmPhase],gap=cfgBOSS_SKILLSSharedUpdateRealmBoss.gap;
        for(let i=0;i<n;i++){const a=i/n*TAU+e.keyWarn.rot;let da=a-e.keyWarn.safe;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;if(Math.abs(da)<gap)continue;RG.ebullets.push({x:e.x,y:e.y,vx:Math.cos(a)*(cfgBOSS_SKILLSSharedUpdateRealmBoss.vx_offset+e.realmPhase*cfgBOSS_SKILLSSharedUpdateRealmBoss.vx_factor),vy:Math.sin(a)*(cfgBOSS_SKILLSSharedUpdateRealmBoss.vy_offset+e.realmPhase*cfgBOSS_SKILLSSharedUpdateRealmBoss.vy_factor),r:cfgBOSS_SKILLSSharedUpdateRealmBoss.r,dmg:e.dmg*cfgBOSS_SKILLSSharedUpdateRealmBoss.dmg_factor,life:cfgBOSS_SKILLSSharedUpdateRealmBoss.life,col:"#fbbf24"});}
        RG.playSfx("trap");e.keyWarn=null;
      }
    }else{
      e.keyT=(e.keyT===undefined?cfgBOSS_SKILLSSharedUpdateRealmBoss.keyT:e.keyT)-dt;
      if(e.keyT<=0){e.keyT=[0,cfgBOSS_SKILLSSharedUpdateRealmBoss.keyT_2,cfgBOSS_SKILLSSharedUpdateRealmBoss.keyT_3,cfgBOSS_SKILLSSharedUpdateRealmBoss.keyT_4][e.realmPhase];e.keyWarn={t:cfgBOSS_SKILLSSharedUpdateRealmBoss.t,max:cfgBOSS_SKILLSSharedUpdateRealmBoss.max,safe:rand(0,TAU),rot:rand(0,TAU)};e.realmCastT=cfgBOSS_SKILLSSharedUpdateRealmBoss.realmCastT;RG.addText(e.x,e.y-e.r-22,"缺口钥环 · 寻找青色安全区","#67e8f9",14);}
    }
    e.gridT=(e.gridT===undefined?cfgBOSS_SKILLSSharedUpdateRealmBoss.gridT:e.gridT)-dt;
    if(e.gridT<=0){
      e.gridT=[0,cfgBOSS_SKILLSSharedUpdateRealmBoss.gridT_2,cfgBOSS_SKILLSSharedUpdateRealmBoss.gridT_3,cfgBOSS_SKILLSSharedUpdateRealmBoss.gridT_4][e.realmPhase];const span=cfgBOSS_SKILLSSharedUpdateRealmBoss.span,w=cfgBOSS_SKILLSSharedUpdateRealmBoss.w_offset+e.realmPhase*cfgBOSS_SKILLSSharedUpdateRealmBoss.w_factor,dmg=e.dmg*cfgBOSS_SKILLSSharedUpdateRealmBoss.dmg_factor_2;
      RG.hbeams.push({x:P.x-span/2,y:P.y,a:0,len:span,dmg,w,warn:cfgBOSS_SKILLSSharedUpdateRealmBoss.warn,fire:cfgBOSS_SKILLSSharedUpdateRealmBoss.fire,hitP:false,realmGrid:true,col:"#c084fc"});
      RG.hbeams.push({x:P.x,y:P.y-span/2,a:Math.PI/2,len:span,dmg,w,warn:cfgBOSS_SKILLSSharedUpdateRealmBoss.warn,fire:cfgBOSS_SKILLSSharedUpdateRealmBoss.fire,hitP:false,realmGrid:true,col:"#c084fc"});
      e.realmCastT=cfgBOSS_SKILLSSharedUpdateRealmBoss.realmCastT_2;RG.addText(e.x,e.y-e.r-22,"十字锁界 · 离开交点","#f0abfc",14);RG.playSfx("nova",.75);
    }
    e.realmOrbT=(e.realmOrbT===undefined?cfgBOSS_SKILLSSharedUpdateRealmBoss.realmOrbT:e.realmOrbT)-dt;
    if(e.realmOrbT<=0){e.realmOrbT=[0,cfgBOSS_SKILLSSharedUpdateRealmBoss.realmOrbT_2,cfgBOSS_SKILLSSharedUpdateRealmBoss.realmOrbT_3,cfgBOSS_SKILLSSharedUpdateRealmBoss.realmOrbT][e.realmPhase];RG.homingShot(e,e.realmPhase+1,cfgBOSS_SKILLSSharedUpdateRealmBoss.value_125_offset+e.realmPhase*cfgBOSS_SKILLSSharedUpdateRealmBoss.realmPhase_factor,cfgBOSS_SKILLSSharedUpdateRealmBoss.homingShot_homingShotArg4,"#c084fc",cfgBOSS_SKILLSSharedUpdateRealmBoss.homingShot_homingShotArg6);RG.addText(e.x,e.y-e.r-22,"追踪钥弹","#c084fc",13);}
  }

  // 空间门状态保存在首领实例，随检查点一并恢复；不占用普通墙碰撞和地图布局。
  let spaceCache=null;
  RG.spaceGates=()=>{if(spaceCache?.run===RG.run&&spaceCache.time===RG.run?.t&&spaceCache.enemies===RG.enemies&&spaceCache.gates.every(g=>!g.owner.dead&&!g.owner.dying))return spaceCache.gates;const gates=[];for(const e of RG.enemies)if(!e.dead&&!e.dying&&e.space)gates.push(...e.space.gates);spaceCache={run:RG.run,time:RG.run?.t,enemies:RG.enemies,gates};return gates;};
  function spacePoint(x,y,r=20){const p={x,y,r};RG.constrain(p);RG.pushOutOfWalls(p,RG.walls);return p;}
  function spaceGate(e,x,y,a,kind,life,length,warn=0){
    const p=spacePoint(x,y);const g={x:p.x,y:p.y,a,kind,life,length,warn,owner:e,age:0,shotT:0};e.space.gates.push(g);return g;
  }
  function spacePair(e,kind){
    const c=RG.BOSS_SKILLS.domain.space,p=RG.P,a=Math.atan2(p.y-e.y,p.x-e.x),hole=kind==='hole',d=hole?c.hole:c.pair;
    const x=hole?e.x+Math.cos(a)*d.offset:p.x+Math.cos(a)*d.offset,y=hole?e.y+Math.sin(a)*d.offset:p.y+Math.sin(a)*d.offset;
    const b=rand(0,TAU),distance=hole?c.pair.exitMin:rand(c.pair.exitMin,c.pair.exitMax);
    const g=spaceGate(e,x,y,a+Math.PI/2,kind,d.life,d.length,hole?0:d.warn),h=spaceGate(e,p.x+Math.cos(b)*distance,p.y+Math.sin(b)*distance,b+Math.PI/2,kind,d.life,d.length,hole?0:d.warn);g.mate=h;h.mate=g;
  }
  RG.spaceCrossing=function(g,x,y,nx,ny,padding=0){
    const dx=nx-x,dy=ny-y,gx=Math.cos(g.a)*g.length,gy=Math.sin(g.a)*g.length,ax=g.x-gx/2,ay=g.y-gy/2,den=dx*gy-dy*gx;
    if(Math.abs(den)<1e-9)return null;const qx=ax-x,qy=ay-y,t=(qx*gy-qy*gx)/den,u=(qx*dy-qy*dx)/den;
    return t>=0&&t<=1&&u>=-padding/g.length&&u<=1+padding/g.length?{t,u}:null;
  };
  RG.teleportSpaceProjectile=function(b,oldX,oldY){
    if(!RG.weaponIsRanged(b.weapon)||b.spaceUntil>RG.run.t)return false;
    for(const g of RG.spaceGates()){
      if(!g.mate||g.owner.dead||g.owner.dying||g.warn>0||g.life<=0)continue;const hit=RG.spaceCrossing(g,oldX,oldY,b.x,b.y,b.r||0);if(!hit)continue;
      const a=g.mate.a-g.a+Math.PI,vx=b.vx,vy=b.vy;b.vx=vx*Math.cos(a)-vy*Math.sin(a);b.vy=vx*Math.sin(a)+vy*Math.cos(a);
      const speed=Math.hypot(b.vx,b.vy)||1,pad=RG.BOSS_SKILLS.domain.space.exitPadding;
      b.x=g.mate.x+Math.cos(g.mate.a)*(hit.u-.5)*g.mate.length+b.vx/speed*pad;b.y=g.mate.y+Math.sin(g.mate.a)*(hit.u-.5)*g.mate.length+b.vy/speed*pad;
      b.spaceUntil=RG.run.t+RG.BOSS_SKILLS.domain.space.projectileCooldown;return true;
    }return false;
  };
  RG.routeSpaceHit=function(target,dmg,id,origin){
    if(!RG.spaceGates().length&&!(id==='beam'&&target.bossKind==='domain'))return false;
    const p=origin||RG.P,d=Math.hypot(target.x-p.x,target.y-p.y),a=Math.atan2(target.y-p.y,target.x-p.x),segments=RG.traceLaser(p.x,p.y,a,d+target.r,1),width=RG.weaponStat(id,RG.P.weapons[id]||1).width||3;
    if(segments.length===1&&!segments[0].shield&&segments[0].len>=d)return false;
    const hit=new Set();
    for(const seg of segments){RG.beams.push({...seg,shield:null,w:width,life:.14,maxLife:.14});
      if(seg.hostile){RG.hbeams.push({...seg,shield:null,w:width,warn:0,fire:.14,dmg,source:'领域主宰 · 反射玩家光束'});continue;}
      for(const e of RG.enemies){if(e===seg.shield||e.dead||e.dying||e.spaceHidden||hit.has(e))continue;const t=clamp((e.x-seg.x)*Math.cos(seg.a)+(e.y-seg.y)*Math.sin(seg.a),0,seg.len);
        if(dist2(seg.x+Math.cos(seg.a)*t,seg.y+Math.sin(seg.a)*t,e.x,e.y)<(e.r+width/2)**2){hit.add(e);RG.hurtEnemy(e,dmg,0,0,true,false,true,id,{spaceRouted:true});}
      }
    }return true;
  };
  function updateSpaceUnits(e,dt){
    const c=RG.BOSS_SKILLS.domain.space,holes=e.space.gates.filter(g=>g.kind==='hole'&&g.life>0);
    if(!holes.length)return;
    for(const u of [RG.P,...RG.enemies,...(RG.allies||[]),...(RG.decoys||[])]){
      if(u.dead||u.dying||u.spaceUntil>RG.run.t)continue;
      for(const g of holes){const dx=u.x-g.x,dy=u.y-g.y,along=dx*Math.cos(g.a)+dy*Math.sin(g.a),side=-dx*Math.sin(g.a)+dy*Math.cos(g.a);
        if(Math.abs(along)>g.length/2+(u.r||0)||Math.abs(side)>(u.r||14)+8)continue;
        const out=spacePoint(g.mate.x-Math.sin(g.mate.a)*(c.exitPadding+(u.r||14)),g.mate.y+Math.cos(g.mate.a)*(c.exitPadding+(u.r||14)),u.r||14);u.x=out.x;u.y=out.y;u.spaceUntil=RG.run.t+c.teleportCooldown;break;
      }
    }
  }
  function spaceBullet(e,g,a,kind){
    const c=RG.BOSS_SKILLS.domain.space.small;
    RG.ebullets.push({x:g.x,y:g.y,vx:Math.cos(a)*c.speed,vy:Math.sin(a)*c.speed,r:kind===1?9:4,dmg:e.dmg*c.damage,life:c.life,fire:kind===1,homing:kind===2,turn:c.homingTurn,col:kind===1?'#fb923c':'#c084fc',bossOwner:e,source:'领域主宰 · 空间弹幕'});
  }
  RG.updateSpaceBoss=function(e,dt,moveMul=1){
    spaceCache=null;
    const c=RG.BOSS_SKILLS.domain.space,P=RG.P;
    const s=e.space||(e.space={gates:[],pairT:c.pair.first,smallT:c.small.first,vanishT:c.vanish.first,slowT:c.slow.first,holeT:0,phase:1,ultimateT:0,ultimateDone:false});
    for(const g of s.gates){g.life-=dt;g.age+=dt;g.warn=Math.max(0,g.warn-dt);if(g.kind==='small'||g.kind==='ultimate')g.shotT-=dt;
      if(g.life<=0||g.warn>0)continue;
      if(g.kind==='small'&&g.shotT<=0){g.shotT+=c.small.shotEvery;const a=Math.atan2(P.y-g.y,P.x-g.x),kind=g.mode;
        if(kind===0)for(let i=0;i<c.small.shots;i++)spaceBullet(e,g,a+(i/(c.small.shots-1)-.5)*c.small.spread,0);else spaceBullet(e,g,a,kind);
      }
      if(g.kind==='ultimate'&&g.shotT<=0){g.shotT=rand(...c.ultimate.interval);
        const a=Math.atan2(P.y-g.y,P.x-g.x)+rand(-.5,.5),segments=RG.traceLaser(g.x,g.y,a,c.ultimate.laserLength,c.ultimate.reflections,true),shot={lastHit:-Infinity};
        for(const seg of segments)RG.hbeams.push({...seg,w:c.ultimate.width,warn:c.ultimate.warn,fire:c.ultimate.laserLife,dmg:e.dmg*c.ultimate.damage,spaceLaser:true,bossOwner:e,spaceShot:shot,source:'领域主宰 · 反射激光'});
      }
    }
    s.gates=s.gates.filter(g=>g.life>0);s.holeT=Math.max(0,s.holeT-dt);s.slowT-=dt;s.vanishT-=dt;s.ultimateT=Math.max(0,s.ultimateT-dt);
    if(e.hp<=e.maxhp*c.phaseAt&&s.phase===1){s.phase=2;s.ultimateWait=c.ultimateDelay;e.mechanicPhase=2;}
    if(s.ultimateWait!==undefined&&!s.ultimateDone){s.ultimateWait-=dt;if(s.ultimateWait<=0){s.ultimateDone=true;s.ultimateT=c.ultimate.life;s.gates=s.gates.filter(g=>!['small','pair'].includes(g.kind));delete s.sequence;
      for(let i=0;i<c.ultimate.count;i++){const a=i/c.ultimate.count*TAU,r=rand(...c.ultimate.radius),g=spaceGate(e,P.x+Math.cos(a)*r,P.y+Math.sin(a)*r,a+Math.PI/2,'ultimate',c.ultimate.life,c.ultimate.length);g.shotT=rand(...c.ultimate.initial);}
    }}
    if(s.slowT<=0){s.slowT+=c.slow.cd;RG.domains.push({x:P.x,y:P.y,r:c.slow.radius,t:c.slow.life,type:'slow',bossOwner:e});}
    if(s.ultimateT<=0){
    s.pairT-=dt;s.smallT-=dt;
    if(s.pairT<=0){s.pairT=rand(...c.pair.cd);spacePair(e,'pair');}
    if(s.smallT<=0){s.smallT=c.small.cd;const count=RG.randi(...c.small.count);s.sequence={count,next:0,left:count,step:(c.small.sequence-c.small.life)/(count-1),center:{x:P.x,y:P.y}};}
    if(s.sequence){const q=s.sequence;q.next-=dt;if(q.next<=0){const index=q.count-q.left,a=index/q.count*TAU,r=rand(...c.small.distance),g=spaceGate(e,q.center.x+Math.cos(a)*r,q.center.y+Math.sin(a)*r,a+Math.PI/2,'small',c.small.life,c.small.length);g.mode=index%3;q.left--;q.next+=q.step;if(!q.left)delete s.sequence;}}
    }
    if(s.vanishLeft>0){s.vanishLeft=Math.max(0,s.vanishLeft-dt);e.spaceHidden=s.vanishLeft>0;e.workshopSafe=e.spaceHidden;if(e.spaceHidden)return;}
    if(s.vanishT<=0){s.vanishT=c.vanish.cd;s.vanishLeft=c.vanish.life;e.spaceHidden=true;e.workshopSafe=true;
      for(let i=0;i<c.vanish.shots;i++){const a=i/c.vanish.shots*TAU;RG.ebullets.push({x:e.x,y:e.y,vx:Math.cos(a)*c.vanish.speed,vy:Math.sin(a)*c.vanish.speed,r:5,dmg:e.dmg*c.vanish.damage,life:5,bossOwner:e,source:'领域主宰 · 消隐辐射'});}return;
    }
    const dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy)||1;e.face=Math.atan2(dy,dx);
    if(d>c.moveStop){e.x+=dx/d*e.speed*dt*moveMul;e.y+=dy/d*e.speed*dt*moveMul;RG.pushOutOfWalls(e,RG.walls);RG.constrain(e);}
    if(d>c.hole.distance&&s.holeT<=0){s.holeT=c.hole.cd;spacePair(e,'hole');}
    updateSpaceUnits(e,dt);

  };
  function updateBoss(e, dt, dx, dy, d, moveMul = 1) {
    const P = RG.P;   // v7.8 起 pat8 就裸用 P——这里不定义,虚空母巢 60% 血触发虫洞时直接 ReferenceError
    if(e.realmBoss&&!e.isClone){updateRealmBoss(e,dt,moveMul);return;}
    RG.updateBossProgress(e,dt);
    const pat = e.pattern, pace=(e.rushBoss||RG.run.rushMode&&e.splitChild)?e.attackMul||1:1, f = (e.enraged ? cfgBOSS_SKILLSSharedUpdateBoss.f : 1)*(e.attackMul||1);
    const workshop=RG.isWorkshopBoss(e);
    if(workshop&&pat===7&&e.workshopColdT>0)return;
    if(workshop&&pat===8&&e.workshopRiftT>0)return;
    if(workshop&&pat===8&&updateWorkshopWarp(e,dt))return;
    if(workshop&&pat===7&&updateWorkshopHeat(e,dt))return;
    if(RG.updateRushEscorts)RG.updateRushEscorts(e,dt);
    if(e.bossKind==='domain'){RG.updateSpaceBoss(e,dt,moveMul);return;}
    if(pat===5&&!e.realmBoss){updateFrostBoss(e,dt,dx,dy,d,moveMul);return;}
    if(!RG.run.rushMode&&e.mechanicsTier>=cfgBOSS_SKILLSSharedUpdateBoss.mechanicsTier_threshold&&!e.isClone&&!e.splitChild){
      const ratio=e.hp/e.maxhp,phase=e.mechanicsTier>=cfgBOSS_SKILLSSharedUpdateBoss.phase_threshold&&ratio<=cfgBOSS_SKILLSSharedUpdateBoss.phase_threshold_2?cfgBOSS_SKILLSSharedUpdateBoss.phase:ratio<=cfgBOSS_SKILLSSharedUpdateBoss.phase_threshold_3?cfgBOSS_SKILLSSharedUpdateBoss.phase_2:1;
      if(phase>(e.mechanicPhase||1)){e.mechanicPhase=phase;RG.addText(e.x,e.y-e.r-32,phase===3?"第三阶段 · 极限攻势":"第二阶段 · 强化招式","#fbbf24",15);}
    }
    if (!RG.bossFirstPhaseOnly(e) && RG.bossPhaseAllows(e,RG.run.rushDifficulty===cfgBOSS_SKILLSSharedUpdateBoss.rushDifficulty?cfgBOSS_SKILLSSharedUpdateBoss.value:cfgBOSS_SKILLSSharedUpdateBoss.value_2) && !e.enraged && e.hp < e.maxhp * (e.enrageAt || cfgBOSS_SKILLSSharedUpdateBoss.enrageAt)) {
      e.enraged = true; e.speed *= cfgBOSS_SKILLSSharedUpdateBoss.speed;
      RG.addText(e.x, e.y - e.r - 20, "! 狂暴!", "#ff5470", 17);
      RG.cam.shake = 8;
    }
    if (e.chargeWind > 0) {
      e.chargeWind -= dt;
      if (e.chargeWind <= 0) {
        e.charging = cfgBOSS_SKILLSSharedUpdateBoss.charging;
        e.vx = Math.cos(e.chargeAim) * cfgBOSS_SKILLSSharedUpdateBoss.vx_factor; e.vy = Math.sin(e.chargeAim) * cfgBOSS_SKILLSSharedUpdateBoss.vy_factor;
        RG.playSfx("trap");
      }
    } else if (e.charging > 0) {
      e.charging -= dt;
      let nx = e.x + e.vx * dt * moveMul, ny = e.y + e.vy * dt * moveMul;
      if (pat === 4 && !e.isEcho && !e.noCharge) {   // v8.20:终焉之影冲撞改 Z 字形(垂直于冲向的两段横移)
        const prog = 1 - e.charging / cfgBOSS_SKILLSShadowUpdateBoss.prog_divisor;
        const lat = (prog < 1 / cfgBOSS_SKILLSShadowUpdateBoss.lat_divisor ? 1 : prog < cfgBOSS_SKILLSShadowUpdateBoss.lat_divisor_2 / cfgBOSS_SKILLSShadowUpdateBoss.lat_divisor ? -1 : 1) * cfgBOSS_SKILLSShadowUpdateBoss.lat_factor;
        nx += Math.cos(e.chargeAim + Math.PI / 2) * lat * dt * moveMul;
        ny += Math.sin(e.chargeAim + Math.PI / 2) * lat * dt * moveMul;
      }
      const probe = { x: nx, y: ny, r: e.r };
      if (!RG.pushOutOfWalls(probe, workshop?RG.walls:RG._tempWalls)) { e.x = nx; e.y = ny; }
      else { e.charging = 0; RG.cam.shake = 6; }
    } else {
      e.x += dx / d * e.speed * dt * moveMul; e.y += dy / d * e.speed * dt * moveMul;
      if ((pat === 1 || pat === 4 || pat === 7) && !e.noCharge) {
        e.chargeT -= dt;
        if (e.chargeT <= 0) {
          e.chargeT = (pat === 7 ? rand(cfgBOSS_SKILLSFurnaceUpdateBoss.chargeT_min, cfgBOSS_SKILLSFurnaceUpdateBoss.chargeT_max) : rand(cfgBOSS_SKILLSSharedUpdateBoss.chargeT_min_2, cfgBOSS_SKILLSSharedUpdateBoss.chargeT_max_2)) * f;
          e.chargeWind = cfgBOSS_SKILLSSharedUpdateBoss.chargeWind; e.chargeAim = Math.atan2(dy, dx);
          RG.addText(e.x, e.y - e.r - 14, "! 冲锋预警", "#ffd166", 14);
        }
      }
    }
    // 秘境守卫:周期性分裂幻象分身(持续 10 秒,间隔 30 秒),只有真身可被伤害
    if (e.realmBoss && !e.isClone) {
      e.cloneT -= dt;
      if (e.cloneT <= 0) { e.cloneT = cfgBOSS_SKILLSSharedUpdateBoss.cloneT; RG.bossSplit(e); }
      if (e.splitFlash > 0) e.splitFlash -= dt;
    }
    const dens = (e.realmBoss ? cfgBOSS_SKILLSSharedUpdateBoss.dens : 1) * (e.densMul || 1), densN = e.realmBoss ? cfgBOSS_SKILLSSharedUpdateBoss.densN : 0;
    // ---- pattern 6:领域主宰(8向弹幕→禁疗领域/减速领域交替,狂暴半径+30%周期缩短) ----
    if (pat === 6) {
      e.domT = (e.domT === undefined ? cfgBOSS_SKILLSDomainUpdateBoss.domT : e.domT) - dt;
      e.burstT -= dt;
      if (e.burstT <= 0) {
        e.burstT = (workshop?cfgBOSS_SKILLSDomainUpdateBoss.burstT:cfgBOSS_SKILLSDomainUpdateBoss.burstT_2)*pace;
        const speed=workshop?cfgBOSS_SKILLSDomainUpdateBoss.speed_2:cfgBOSS_SKILLSDomainUpdateBoss.speed_3,damage=workshop?cfgBOSS_SKILLSDomainUpdateBoss.damage:cfgBOSS_SKILLSDomainUpdateBoss.damage_2;
        for (let i = 0; i < RG.SPAWN_COUNTS.domainRadial; i++) { const a = i / RG.SPAWN_COUNTS.domainRadial * TAU + (e.spiralA || 0); RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, r: cfgBOSS_SKILLSDomainUpdateBoss.r, dmg: e.dmg * damage, life: cfgBOSS_SKILLSDomainUpdateBoss.life }); }
        e.spiralA = (e.spiralA || 0) + cfgBOSS_SKILLSDomainUpdateBoss.spiralA_offset;
      }
      if (e.domT <= 0) {
        const domStart=(RG.domains||[]).length;
        e.domPhase = ((e.domPhase || 0) + 1) % cfgBOSS_SKILLSDomainUpdateBoss.domPhase;
        if (e.domPhase === 0) { e.domT = cfgBOSS_SKILLSDomainUpdateBoss.domT_factor*pace; (RG.domains = RG.domains || []).push({ x: e.x, y: e.y, r: cfgBOSS_SKILLSDomainUpdateBoss.r_factor * (e.enraged ? cfgBOSS_SKILLSDomainUpdateBoss.r_2 : 1), t: cfgBOSS_SKILLSDomainUpdateBoss.t, type: "healnull" }); RG.addText(e.x, e.y - e.r - 16, "禁疗领域 展开!", "#ff5470", 15); if ((RG.run.rushMode?e.mechanicPhase:e.cycle||1) >= cfgBOSS_SKILLSDomainUpdateBoss.value_threshold) { (RG.domains = RG.domains || []).push({ x: e.x, y: e.y, r: cfgBOSS_SKILLSDomainUpdateBoss.r_3, t: cfgBOSS_SKILLSDomainUpdateBoss.t, type: "slow" }); RG.addText(e.x, e.y - e.r - 34, "双领域同开!", "#7dd3fc", 14); } }
        else { e.domT = cfgBOSS_SKILLSDomainUpdateBoss.domT_factor_2*pace; (RG.domains = RG.domains || []).push({ x: RG.P.x, y: RG.P.y, r: cfgBOSS_SKILLSDomainUpdateBoss.r_factor_2 * (e.enraged ? cfgBOSS_SKILLSDomainUpdateBoss.r_2 : 1), t: cfgBOSS_SKILLSDomainUpdateBoss.t_2, type: "slow" }); RG.addText(e.x, e.y - e.r - 16, "减速领域 展开!", "#7dd3fc", 15); }
        RG.playSfx("portal", 0.8);
        if(workshop)for(let i=domStart;i<RG.domains.length;i++){const dm=RG.domains[i];dm.warn=1;dm.t+=1;dm.bossOwner=e;}
      }
    }
    // ---- pattern 7:巨械·熔炉核心(过热槽 DPS check:输出越猛过热越快;70% 起灼烧地带;40% 常驻爆发) ----
    if (pat === 7) {
      const phaseB = !RG.bossFirstPhaseOnly(e)&&RG.bossPhaseAllows(e,cfgBOSS_SKILLSFurnaceUpdateBoss.phaseB_bossPhaseAllowsArg2)&&e.hp < e.maxhp * cfgBOSS_SKILLSFurnaceUpdateBoss.phaseB_factor, phaseC = !RG.bossFirstPhaseOnly(e)&&RG.bossPhaseAllows(e,cfgBOSS_SKILLSFurnaceUpdateBoss.phaseC_bossPhaseAllowsArg2)&&e.hp < e.maxhp * cfgBOSS_SKILLSFurnaceUpdateBoss.phaseC_factor;
      if(!workshop)e.heat = phaseC ? cfgBOSS_SKILLSFurnaceUpdateBoss.heat : Math.min(cfgBOSS_SKILLSFurnaceUpdateBoss.heat_cap, (e.heat || 0) + cfgBOSS_SKILLSFurnaceUpdateBoss.heat_factor * dt + (e.heatDmgAcc || 0));
      e.heatDmgAcc = 0;
      if (phaseB || phaseC) {
        e.fireT = (e.fireT || 0) - dt;
        if (e.fireT <= 0) {
          e.fireT=workshop?cfgBOSS_SKILLSFurnaceUpdateBoss.fireT:cfgBOSS_SKILLSFurnaceUpdateBoss.fireT_2;const x=e.x+rand(-20,20),y=e.y+rand(-20,20);
          if(!workshop)RG.spawnTrap(x,y);
          else if(RG.hazards.filter(h=>h.bossOwner===e&&!h.dead).length<cfgBOSS_SKILLSFurnaceUpdateBoss.length_threshold&&RG.workshopPointFree(x,y,cfgBOSS_SKILLSFurnaceUpdateBoss.workshopPointFree_workshopPointFreeArg3)&&!(e.workshopValves||[]).some(v=>Math.hypot(x-v.x,y-v.y)<v.r+cfgBOSS_SKILLSFurnaceUpdateBoss.r_offset))RG.hazards.push({x,y,r:cfgBOSS_SKILLSFurnaceUpdateBoss.r_4,phase:'warn',t:cfgBOSS_SKILLSFurnaceUpdateBoss.t_3,hitCd:0,dur:cfgBOSS_SKILLSFurnaceUpdateBoss.dur,dmg:e.dmg*cfgBOSS_SKILLSFurnaceUpdateBoss.dmg_factor,bossOwner:e,workshopSlag:true});
        }   // 工坊熔渣保留预警且避开阀位，旧图/连战沿用原频率。
      }
      if (!workshop&&e.heat >= cfgBOSS_SKILLSFurnaceUpdateBoss.heat_threshold) {
        e.overT = (e.overT === undefined ? cfgBOSS_SKILLSFurnaceUpdateBoss.overT : e.overT) - dt;
        if (!e.overWarned) {
          e.overWarned = true;
          RG.rings.push({ x: e.x, y: e.y, r: 20, maxR: 300, life: 0.8, maxLife: 0.8, color: "#ff5470" });
          RG.addText(e.x, e.y - e.r - 20, "! 过热爆发!", "#ff5470", 16);
        }
        if (e.overT <= 0) {
          e.overWarned = false; e.overT = cfgBOSS_SKILLSFurnaceUpdateBoss.overT; if (!phaseC) e.heat = 0;
          RG.rings.push({ x: e.x, y: e.y, r: 20, maxR: 300, life: 0.35, maxLife: 0.35, color: "#fb923c" });
          RG.cam.shake = 10; RG.playSfx("boom");
          if (dist2(e.x, e.y, P.x, P.y) < cfgBOSS_SKILLSFurnaceUpdateBoss.value_300_factor * cfgBOSS_SKILLSFurnaceUpdateBoss.value_300_factor) RG.hurtPlayer(cfgBOSS_SKILLSFurnaceUpdateBoss.hurtPlayer_hurtPlayerArg1, false, false, RG.enemyHitSource(e,"近身领域"));
          if ((RG.run.rushMode?e.mechanicPhase:e.cycle||1) >= cfgBOSS_SKILLSFurnaceUpdateBoss.value_threshold_2 && !e.furSplit && !e.isClone && !e.splitChild) { e.furSplit = true; RG.bossRealSplit(e, cfgBOSS_SKILLSFurnaceUpdateBoss.bossRealSplit_bossRealSplitArg2, cfgBOSS_SKILLSFurnaceUpdateBoss.bossRealSplit_bossRealSplitArg3, { ringOnly: true }); }   // W2:首次过热分裂小熔炉
        }
      } else if(!workshop) { e.overWarned = false; e.overT = cfgBOSS_SKILLSFurnaceUpdateBoss.overT; }
    }
    // ---- pattern 8:虚空母巢(扇形弹幕+闪现追击;60% 后虫洞空间控制,玩家踏入即传送) ----
    if (pat === 8) {
      e.burstT -= dt;
      if (e.burstT <= 0) {
        e.burstT = cfgBOSS_SKILLSVoidUpdateBoss.burstT_factor*pace;
        const a0 = Math.atan2(dy, dx);
        for (let i = 0; i < RG.SPAWN_COUNTS.voidFan; i++) { const a = a0 + (i / (RG.SPAWN_COUNTS.voidFan-1) - 0.5) * 1.1; RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSVoidUpdateBoss.vx_factor_2, vy: Math.sin(a) * cfgBOSS_SKILLSVoidUpdateBoss.vy_factor_2, r: cfgBOSS_SKILLSVoidUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSVoidUpdateBoss.dmg_factor_2, life: cfgBOSS_SKILLSVoidUpdateBoss.life }); }
      }
      e.warpT = (e.warpT === undefined ? cfgBOSS_SKILLSVoidUpdateBoss.warpT : e.warpT) - dt;
      if (e.warpT <= 0) {
        e.warpT = cfgBOSS_SKILLSVoidUpdateBoss.warpT_factor*pace;
        if(workshop){beginWorkshopWarp(e);return;}
        const wa = rand(0, TAU);
        RG.rings.push({ x: e.x, y: e.y, r: e.r, maxR: 4, life: 0.2, maxLife: 0.2, color: "#c084fc" });
        e.x = RG.P.x + Math.cos(wa) * 180; e.y = RG.P.y + Math.sin(wa) * 180;
        e.charging = cfgBOSS_SKILLSVoidUpdateBoss.charging_2; const a2 = Math.atan2(RG.P.y - e.y, RG.P.x - e.x); e.vx = Math.cos(a2) * cfgBOSS_SKILLSVoidUpdateBoss.vx_factor_3; e.vy = Math.sin(a2) * cfgBOSS_SKILLSVoidUpdateBoss.vy_factor_3;
        RG.playSfx("portal", 1.4);
      }
      if (!RG.bossFirstPhaseOnly(e)&&RG.bossPhaseAllows(e,cfgBOSS_SKILLSVoidUpdateBoss.bossPhaseAllows_bossPhaseAllowsArg2)&&e.hp < e.maxhp * cfgBOSS_SKILLSVoidUpdateBoss.maxhp_factor) {
        e.whT = (e.whT === undefined ? cfgBOSS_SKILLSVoidUpdateBoss.whT : e.whT) - dt;
        if (e.whT <= 0) {
          e.whT = (workshop?cfgBOSS_SKILLSVoidUpdateBoss.whT_2:cfgBOSS_SKILLSVoidUpdateBoss.whT_3)*pace;
          if(workshop)spawnWorkshopHoles(e);
          else {
          const n2 = e.enraged ? cfgBOSS_SKILLSVoidUpdateBoss.n2 : cfgBOSS_SKILLSVoidUpdateBoss.n2_2;
          RG.wormholes = [];
          for (let i = 0; i < n2; i++) {
            const wx = P.x + Math.cos(i / n2 * TAU + RG.run.t) * rand(cfgBOSS_SKILLSVoidUpdateBoss.wx_min, cfgBOSS_SKILLSVoidUpdateBoss.wx_max), wy = P.y + Math.sin(i / n2 * TAU + RG.run.t) * rand(cfgBOSS_SKILLSVoidUpdateBoss.wy_min, cfgBOSS_SKILLSVoidUpdateBoss.wy_max);
            if(workshop&&(!RG.workshopPointFree(wx,wy,cfgBOSS_SKILLSVoidUpdateBoss.workshopPointFree_workshopPointFreeArg3_2)||Math.hypot(P.x-wx,P.y-wy)<cfgBOSS_SKILLSVoidUpdateBoss.value_threshold_3))continue;
            RG.wormholes.push({ x: wx, y: wy, r: cfgBOSS_SKILLSVoidUpdateBoss.r_5, cool: 0,...(workshop?{bossOwner:e}:{}) });
            if ((RG.run.rushMode?e.mechanicPhase:e.cycle||1) >= cfgBOSS_SKILLSVoidUpdateBoss.value_threshold_2) RG.poisonZone(wx, wy, cfgBOSS_SKILLSVoidUpdateBoss.poisonZone_poisonZoneArg3, cfgBOSS_SKILLSVoidUpdateBoss.poisonZone_poisonZoneArg4, e.dmg * cfgBOSS_SKILLSVoidUpdateBoss.dmg_factor_3);   // W2:虫洞毒化
          }
          RG.addText(e.x, e.y - e.r - 16, "维度撕裂!", "#c084fc", 14);
          }
        }
        e.whRead = (e.whRead === undefined ? cfgBOSS_SKILLSVoidUpdateBoss.whRead : e.whRead) - dt;
        if (e.whRead <= 0 && (RG.wormholes || []).length >= cfgBOSS_SKILLSVoidUpdateBoss.length_threshold_2) {
          e.whRead = cfgBOSS_SKILLSVoidUpdateBoss.whRead_factor*pace;
          const wh = pick(RG.wormholes.filter(w=>!w.dead&&!(w.warn>0)));
          if(!wh)return;
          if(workshop){beginWorkshopWarp(e,wh);return;}
          RG.rings.push({ x: wh.x, y: wh.y, r: wh.r, maxR: wh.r + 26, life: 0.4, maxLife: 0.4, color: "#c084fc" });
          e.x = wh.x; e.y = wh.y;
          if ((RG.run.rushMode?e.mechanicPhase:e.cycle||1) >= cfgBOSS_SKILLSVoidUpdateBoss.value_threshold) { const fa = Math.atan2(P.y - e.y, P.x - e.x); for (let i = 0; i < RG.SPAWN_COUNTS.voidFission; i++) { const a = fa + (i / (RG.SPAWN_COUNTS.voidFission-1) - 0.5) * 0.9; RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSVoidUpdateBoss.vx_factor_4 * (e.spdMul || 1), vy: Math.sin(a) * cfgBOSS_SKILLSVoidUpdateBoss.vy_factor_4 * (e.spdMul || 1), r: cfgBOSS_SKILLSVoidUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSVoidUpdateBoss.dmg_factor_2, life: cfgBOSS_SKILLSVoidUpdateBoss.life }); } }   // W3:突袭接扇形弹
          e.charging = cfgBOSS_SKILLSVoidUpdateBoss.charging_3; const aa = Math.atan2(P.y - e.y, P.x - e.x); e.vx = Math.cos(aa) * cfgBOSS_SKILLSVoidUpdateBoss.vx_factor_5; e.vy = Math.sin(aa) * cfgBOSS_SKILLSVoidUpdateBoss.vy_factor_5;
          RG.addText(e.x, e.y - e.r - 14, "虚空突袭!", "#c084fc", 13);
        }
      }
    }
    // ---- v8.5 BOSS 技能组:按 bossKind + 周目解锁(W2=二周目,W3=三周目;狂暴再解锁隐藏招) ----
    if (!e.isClone && !e.splitChild) {
      const cyc = RG.run.rushMode?(e.mechanicPhase||1):e.cycle||1;
      const W2 = cyc >= cfgBOSS_SKILLSSharedUpdateBoss.W2_threshold || e.mechanicPhase>=cfgBOSS_SKILLSSharedUpdateBoss.W2_threshold, W3 = cyc >= cfgBOSS_SKILLSSharedUpdateBoss.W3_threshold || e.mechanicPhase>=cfgBOSS_SKILLSSharedUpdateBoss.W3_threshold;
      if (e.bossKind === "gluttony") {
        // 饥饿引力:收缩环预警 1s → 380px 内吸拉玩家 1.4s;固定 10s 冷却(v8.20:范围 280→380,冷却不受狂暴加速)
        e.hunT -= dt;
        if (e.hunT <= 1 && e.hunT + dt > 1) RG.rings.push({ x: e.x, y: e.y, r: 380, maxR: 380, life: 1, maxLife: 1, color: "#c084fc", shrink: 250 });   // v8.21 退修:原比较方向写反(要求时间倒流),预警环自 v8.5 起从未生成;hunT+dt=递减前值
        if (e.hunT <= 0) { e.hunT = cfgBOSS_SKILLSGluttonyUpdateBoss.hunT_factor*(e.rushBoss?pace:1); e.hunActive = cfgBOSS_SKILLSGluttonyUpdateBoss.hunActive; }
        if (e.hunActive > 0) {
          e.hunActive -= dt;
          const hd = Math.hypot(P.x - e.x, P.y - e.y) || 1;
          if (hd < cfgBOSS_SKILLSGluttonyUpdateBoss.hd_threshold && hd > cfgBOSS_SKILLSGluttonyUpdateBoss.hd_threshold_2) { P.x -= (P.x - e.x) / hd * 150 * dt; P.y -= (P.y - e.y) / hd * 150 * dt; }
        }
        // 饱食阶段:60% 血召食饵;BOSS 靠近吞食回 4% 血(W3 吞食处留毒雾)
        if (!RG.bossFirstPhaseOnly(e) && RG.bossPhaseAllows(e,cfgBOSS_SKILLSGluttonyUpdateBoss.bossPhaseAllows_bossPhaseAllowsArg2) && !e.baitA && e.hp < e.maxhp * cfgBOSS_SKILLSGluttonyUpdateBoss.maxhp_factor) {
          e.baitA = true;
          for (let i = 0; i < RG.SPAWN_COUNTS.gluttonyBait; i++) {
            const m = RG.spawnEnemy("swarm", false);
            m.isBait = true; m.x = e.x + rand(-130, 130); m.y = e.y + rand(-130, 130);
            m.hp = m.maxhp = cfgBOSS_SKILLSGluttonyUpdateBoss.maxhp_factor_2 * (1 + RG.run.t / 60 * cfgBOSS_SKILLSGluttonyUpdateBoss.maxhp_factor_3);
            RG.burst(m.x, m.y, "#ff9ecd", 8, 90);
          }
          RG.addText(e.x, e.y - e.r - 26, "暴食召唤食饵!抢在它吃掉前杀掉!", "#ff9ecd", 15);
        }
        for (const m of RG.enemies) {
          if (!m.isBait || m.dead) continue;
          if (dist2(m.x, m.y, e.x, e.y) < cfgBOSS_SKILLSGluttonyUpdateBoss.value_70_factor * cfgBOSS_SKILLSGluttonyUpdateBoss.value_70_factor) {
            m.dead = true;
            RG.burst(m.x, m.y, "#ff9ecd", 12, 130);
            e.hp = Math.min(e.maxhp, e.hp + e.maxhp * cfgBOSS_SKILLSGluttonyUpdateBoss.hp_factor);
            RG.addText(e.x, e.y - e.r - 18, "吞噬 +4% 生命", "#ff9ecd", 13);
            if (W3) RG.poisonZone(m.x, m.y, cfgBOSS_SKILLSGluttonyUpdateBoss.poisonZone_poisonZoneArg3, cfgBOSS_SKILLSGluttonyUpdateBoss.poisonZone_poisonZoneArg4, e.dmg * cfgBOSS_SKILLSGluttonyUpdateBoss.dmg_factor);
          }
        }
        if (W2) {
          e.waveT -= dt;
          if (e.waveT <= 0) { e.waveT = cfgBOSS_SKILLSGluttonyUpdateBoss.waveT_factor * f; RG.radialWaves(e, cfgBOSS_SKILLSGluttonyUpdateBoss.radialWaves_radialWavesArg2, e.dmg * cfgBOSS_SKILLSGluttonyUpdateBoss.dmg_factor_2); }
        }
        // 狂暴解锁:冲锋结束接超大弹 3 连封路
        if (e._chPrev > 0 && e.charging <= 0 && e.enraged) { RG.bigShots(e, cfgBOSS_SKILLSGluttonyUpdateBoss.bigShots_bigShotsArg2, cfgBOSS_SKILLSGluttonyUpdateBoss.bigShots_bigShotsArg3, cfgBOSS_SKILLSGluttonyUpdateBoss.bigShots_bigShotsArg4, cfgBOSS_SKILLSGluttonyUpdateBoss.bigShots_bigShotsArg5); RG.addText(e.x, e.y - e.r - 20, "饱食冲撞!", "#ff8c42", 15); }
        e._chPrev = e.charging;
      }
      if (e.bossKind === "golem") {
        // 石肤:每掉 25% 血 → 2s 减伤 80% + 脚下大地刺
        if (!RG.bossFirstPhaseOnly(e) && RG.bossPhaseAllows(e,cfgBOSS_SKILLSGolemUpdateBoss.bossPhaseAllows_bossPhaseAllowsArg2) && !e.s1 && e.hp < e.maxhp * cfgBOSS_SKILLSGolemUpdateBoss.maxhp_factor) { e.s1 = true; e.stoneT = cfgBOSS_SKILLSGolemUpdateBoss.stoneT; RG.spawnTrap(e.x + rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), e.y + rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), true); RG.addText(e.x, e.y - e.r - 20, "岩石护肤!", "#9ca3af", 15); RG.playSfx("block"); }
        if (!RG.bossFirstPhaseOnly(e) && RG.bossPhaseAllows(e,cfgBOSS_SKILLSGolemUpdateBoss.bossPhaseAllows_bossPhaseAllowsArg2) && !e.s2 && e.hp < e.maxhp * cfgBOSS_SKILLSGolemUpdateBoss.maxhp_factor_2) { e.s2 = true; e.stoneT = cfgBOSS_SKILLSGolemUpdateBoss.stoneT; RG.spawnTrap(e.x + rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), e.y + rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), true); RG.addText(e.x, e.y - e.r - 20, "岩石护肤!", "#9ca3af", 15); RG.playSfx("block"); }
        if (!RG.bossFirstPhaseOnly(e) && RG.bossPhaseAllows(e,cfgBOSS_SKILLSGolemUpdateBoss.bossPhaseAllows_bossPhaseAllowsArg2_2) && !e.s3 && e.hp < e.maxhp * cfgBOSS_SKILLSGolemUpdateBoss.maxhp_factor_3) { e.s3 = true; e.stoneT = cfgBOSS_SKILLSGolemUpdateBoss.stoneT; RG.spawnTrap(e.x + rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), e.y + rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), true); RG.addText(e.x, e.y - e.r - 20, "岩石护肤!", "#9ca3af", 15); RG.playSfx("block"); }
        if (e.stoneT > 0) e.stoneT -= dt;
        // 地脉隆起:玩家↔BOSS 连线 3 连超大地刺(v8.20:间距 90→170 更远、big=2 更大、间隔 7→10s)+ 接十字震爆弹幕
        e.veinT -= dt;
        if (e.veinT <= 0) {
          e.veinT = cfgBOSS_SKILLSGolemUpdateBoss.veinT_factor * f;
          const va = Math.atan2(P.y - e.y, P.x - e.x);
          for (let i = 1; i <= 3; i++) RG.spawnTrap(e.x + Math.cos(va) * cfgBOSS_SKILLSGolemUpdateBoss.value_factor * i, e.y + Math.sin(va) * cfgBOSS_SKILLSGolemUpdateBoss.value_factor * i, cfgBOSS_SKILLSGolemUpdateBoss.spawnTrap_spawnTrapArg3);
          const sm = e.spdMul || 1;
          for (let k = 0; k < RG.SPAWN_COUNTS.golemCross; k++) {   // v8.20 新增:十字弹幕(沿地震轴四向各 3 连,近中远三速)
            const ca = va + k * Math.PI / (RG.SPAWN_COUNTS.golemCross/2);
            for (let s = 0; s < cfgBOSS_SKILLSGolemUpdateBoss.s_threshold; s++) {
              const sp = (cfgBOSS_SKILLSGolemUpdateBoss.sp_offset + s * cfgBOSS_SKILLSGolemUpdateBoss.sp_factor) * sm;
              RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(ca) * sp, vy: Math.sin(ca) * sp, r: cfgBOSS_SKILLSGolemUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSGolemUpdateBoss.dmg_factor, life: cfgBOSS_SKILLSGolemUpdateBoss.life });
            }
          }
          RG.addText(e.x, e.y - e.r - 20, "地脉隆起·十字震爆!", "#fb923c", 15);
        }
        // 双震地环:第二圈延迟 0.5s
        if (e.slamEcho > 0) {
          e.slamEcho -= dt;
          if (e.slamEcho <= 0) { RG.rings.push({ x: e.x, y: e.y, r: e.r + 10, maxR: 420, life: 2.2, color: "#fb923c", hazard: true, dmg: e.dmg * 0.7, hitP: false }); RG.cam.shake = 6; }
        }
        if (W2) {
          e.starT -= dt;
          if (e.starT <= 0) {
            e.starT = cfgBOSS_SKILLSGolemUpdateBoss.starT_factor * f;
            for (let i = 0; i < 6; i++) { const sa = i / cfgBOSS_SKILLSGolemUpdateBoss.sa_divisor * TAU + rand(0, TAU); RG.spawnTrap(P.x + Math.cos(sa) * cfgBOSS_SKILLSGolemUpdateBoss.value_factor_2, P.y + Math.sin(sa) * cfgBOSS_SKILLSGolemUpdateBoss.value_factor_2, true); }
            RG.addText(P.x, P.y - 70, "星阵地刺!", "#fb923c", 15);
          }
        }
        if (W3) {
          e.rockT -= dt;
          if (e.rockT <= 0) { e.rockT = cfgBOSS_SKILLSGolemUpdateBoss.rockT_factor * f; RG.bigShots(e, cfgBOSS_SKILLSGolemUpdateBoss.bigShots_bigShotsArg2, cfgBOSS_SKILLSGolemUpdateBoss.bigShots_bigShotsArg3, cfgBOSS_SKILLSGolemUpdateBoss.bigShots_bigShotsArg4, cfgBOSS_SKILLSGolemUpdateBoss.bigShots_bigShotsArg5); RG.addText(e.x, e.y - e.r - 20, "落石!", "#9ca3af", 15); }
        }
      }
      if (e.bossKind === "eye") {
        // 凝视射线(W3 三重扇形;v8.20:残血狂暴升格为米字凝视——8 向预警激光)
        e.gazeT -= dt;
        if (e.gazeT <= 0) {
          e.gazeT = (e.enraged ? cfgBOSS_SKILLSEyeUpdateBoss.gazeT : (W3 ? cfgBOSS_SKILLSEyeUpdateBoss.gazeT_2 : cfgBOSS_SKILLSEyeUpdateBoss.gazeT_3)) * f;
          const ga = Math.atan2(P.y - e.y, P.x - e.x);
          if (e.enraged) {
            for (let i = 0; i < RG.SPAWN_COUNTS.eyeRays; i++) RG.hbeams.push({ x: e.x, y: e.y, a: ga + i * Math.PI / (RG.SPAWN_COUNTS.eyeRays/2), len: cfgBOSS_SKILLSEyeUpdateBoss.len, dmg: e.dmg * cfgBOSS_SKILLSEyeUpdateBoss.dmg_factor, w: cfgBOSS_SKILLSEyeUpdateBoss.w, warn: cfgBOSS_SKILLSEyeUpdateBoss.warn, fire: cfgBOSS_SKILLSEyeUpdateBoss.fire, hitP: false });
            RG.playSfx("nova", 0.6);
            RG.addText(e.x, e.y - e.r - 22, "米字凝视!", "#ff5470", 16);
          } else if (W3) { for (let i = -1; i <= 1; i++) RG.fireHBeam(e.x, e.y, ga + i * cfgBOSS_SKILLSEyeUpdateBoss.i_factor, cfgBOSS_SKILLSEyeUpdateBoss.fireHBeam_fireHBeamArg4, e.dmg * cfgBOSS_SKILLSEyeUpdateBoss.dmg_factor_2, cfgBOSS_SKILLSEyeUpdateBoss.fireHBeam_fireHBeamArg6, cfgBOSS_SKILLSEyeUpdateBoss.fireHBeam_fireHBeamArg7); RG.addText(e.x, e.y - e.r - 22, "三重凝视!", "#ff5470", 15); }
          else { RG.fireHBeam(e.x, e.y, ga, cfgBOSS_SKILLSEyeUpdateBoss.fireHBeam_fireHBeamArg4, e.dmg * cfgBOSS_SKILLSEyeUpdateBoss.dmg_factor_2, cfgBOSS_SKILLSEyeUpdateBoss.fireHBeam_fireHBeamArg6, cfgBOSS_SKILLSEyeUpdateBoss.fireHBeam_fireHBeamArg7); RG.addText(e.x, e.y - e.r - 22, "凝视!", "#ff5470", 14); }
        }
        if (W2) {
          // 瞬移重现接 6 向弹
          e.tpT -= dt;
          if (e.tpT <= 0) {
            e.tpT = cfgBOSS_SKILLSEyeUpdateBoss.tpT_factor * f;
            RG.bossTeleport(e);
            for (let i = 0; i < RG.SPAWN_COUNTS.eyeRadial; i++) { const a = i / RG.SPAWN_COUNTS.eyeRadial * TAU; RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSEyeUpdateBoss.vx_factor * (e.spdMul || 1), vy: Math.sin(a) * cfgBOSS_SKILLSEyeUpdateBoss.vy_factor * (e.spdMul || 1), r: cfgBOSS_SKILLSEyeUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSEyeUpdateBoss.dmg_factor_3, life: cfgBOSS_SKILLSEyeUpdateBoss.life }); }
          }
          // v8.20:删除"瞳孔分裂"原地小眼(玩家反馈的"立墙",站桩环形弹封路);追踪眼珠承担该定位
        }
        // 狂暴解锁:追踪眼珠弹(v8.20:存活更久 4.5→7s)
        if (e.enraged) {
          e.orbT = (e.orbT === undefined ? cfgBOSS_SKILLSEyeUpdateBoss.orbT_factor*pace : e.orbT) - dt;
          if (e.orbT <= 0) { e.orbT = cfgBOSS_SKILLSEyeUpdateBoss.orbT_factor_2*pace; RG.homingShot(e, cfgBOSS_SKILLSEyeUpdateBoss.homingShot_homingShotArg2, cfgBOSS_SKILLSEyeUpdateBoss.homingShot_homingShotArg3, cfgBOSS_SKILLSEyeUpdateBoss.homingShot_homingShotArg4, null, cfgBOSS_SKILLSEyeUpdateBoss.homingShot_homingShotArg6); RG.addText(e.x, e.y - e.r - 20, "追踪眼珠!", "#fbbf24", 14); }
        }
      }
      if (e.bossKind === "shadow") {
        // 影分身:可受伤真分身;v8.20:场上至多 1 个(玩家反馈"两个太多"),W3 周期缩短
        if(!RG.run.rushMode || W2)e.echoT -= dt;
        if (e.echoT <= 0 && (!RG.run.rushMode || W2)) {
          e.echoT = (W3 ? cfgBOSS_SKILLSShadowUpdateBoss.echoT : cfgBOSS_SKILLSShadowUpdateBoss.echoT_2) * f;
          if (!RG.enemies.some(m => m.isEcho && m.bossKind === "shadow" && !m.dead)) RG.bossRealSplit(e, 1, cfgBOSS_SKILLSShadowUpdateBoss.bossRealSplit_bossRealSplitArg3, {});
        }
        // v8.20 新增:米字影弹(8 向双速圈,冷却长,与旋转弹幕/瞬移并列)
        e.miT = (e.miT === undefined ? RG.SHADOW_BOSS.miFirst*pace : e.miT) - (!RG.run.rushMode || W2 || RG.bossFirstPhaseOnly(e) ? dt : 0);
        if (e.miT <= 0 && (!RG.run.rushMode || W2 || RG.bossFirstPhaseOnly(e))) {
          e.miT = RG.SHADOW_BOSS.miCd * f;
          const ma = rand(0, TAU), sm = e.spdMul || 1;
          for (let i = 0; i < RG.SPAWN_COUNTS.shadowRadial; i++) {
            const a = ma + i / RG.SPAWN_COUNTS.shadowRadial * TAU;
            RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSShadowUpdateBoss.vx_factor * sm, vy: Math.sin(a) * cfgBOSS_SKILLSShadowUpdateBoss.vy_factor * sm, r: cfgBOSS_SKILLSShadowUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSShadowUpdateBoss.dmg_factor, life: cfgBOSS_SKILLSShadowUpdateBoss.life });
            RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a + cfgBOSS_SKILLSShadowUpdateBoss.vx_offset) * cfgBOSS_SKILLSShadowUpdateBoss.vx_factor_2 * sm, vy: Math.sin(a + cfgBOSS_SKILLSShadowUpdateBoss.vy_offset) * cfgBOSS_SKILLSShadowUpdateBoss.vy_factor_2 * sm, r: cfgBOSS_SKILLSShadowUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSShadowUpdateBoss.dmg_factor, life: cfgBOSS_SKILLSShadowUpdateBoss.life_2 });
          }
          RG.addText(e.x, e.y - e.r - 20, "米字影弹!", "#7c3aed", 14);
        }
        if (W2) {
          e.shwaveT -= dt;
          if (e.shwaveT <= 0) { e.shwaveT = RG.SHADOW_BOSS.waveCd * f; RG.radialWaves(e, cfgBOSS_SKILLSShadowUpdateBoss.radialWaves_radialWavesArg2, e.dmg * cfgBOSS_SKILLSShadowUpdateBoss.dmg_factor_2); }
        }
        if (W3) {
          // 影潮:分身也会瞬移
          for (const m of RG.enemies) {
            if (m.isEcho && !m.dead && m.bossKind === "shadow") {
              m.eTpT = (m.eTpT === undefined ? cfgBOSS_SKILLSShadowUpdateBoss.eTpT_factor*pace : m.eTpT) - dt;
              if (m.eTpT <= 0) { m.eTpT = cfgBOSS_SKILLSShadowUpdateBoss.eTpT_factor*pace; RG.bossTeleport(m); }
            }
          }
        }
      }
      if (e.bossKind === "domain" && cyc >= cfgBOSS_SKILLSDomainUpdateBoss.cyc_threshold) {
        // 领域内刷追踪弹
        e.domShotT -= dt;
        if (e.domShotT <= 0) {
          e.domShotT = cfgBOSS_SKILLSDomainUpdateBoss.domShotT_factor*pace;
          if ((RG.domains || []).length) RG.homingShot(e, 1, cfgBOSS_SKILLSDomainUpdateBoss.homingShot_homingShotArg3, cfgBOSS_SKILLSDomainUpdateBoss.homingShot_homingShotArg4, "#7dd3fc");
        }
      }
      if (e.bossKind === "furnace" && cyc >= cfgBOSS_SKILLSFurnaceUpdateBoss.cyc_threshold) {
        // 超大灼热弹
        e.fbigT -= dt;
        if (e.fbigT <= 0) { e.fbigT = cfgBOSS_SKILLSFurnaceUpdateBoss.fbigT_factor * f; RG.bigShots(e, cfgBOSS_SKILLSFurnaceUpdateBoss.bigShots_bigShotsArg2, cfgBOSS_SKILLSFurnaceUpdateBoss.bigShots_bigShotsArg3, cfgBOSS_SKILLSFurnaceUpdateBoss.bigShots_bigShotsArg4, cfgBOSS_SKILLSFurnaceUpdateBoss.bigShots_bigShotsArg5); }
      }
    }
    if (pat === 1 || pat === 4) {
      e.burstT -= dt;
      if (e.burstT <= 0) {
        e.burstT = (pat===4?rand(...RG.SHADOW_BOSS.burst):rand(cfgBOSS_SKILLSSharedUpdateBoss.burstT_min,cfgBOSS_SKILLSSharedUpdateBoss.burstT_max)) * f * dens;
        const n = cfgBOSS_SKILLSSharedUpdateBoss.n_offset + RG.run.bossNum * cfgBOSS_SKILLSSharedUpdateBoss.n_factor + densN;
        for (let i = 0; i < n; i++) { const a = i / n * TAU + rand(-0.05, 0.05); RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSSharedUpdateBoss.vx_factor_6, vy: Math.sin(a) * cfgBOSS_SKILLSSharedUpdateBoss.vy_factor_6, r: cfgBOSS_SKILLSSharedUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSSharedUpdateBoss.dmg_factor_4, life: cfgBOSS_SKILLSSharedUpdateBoss.life_2 }); }
        RG.tone(180, 0.15, "square", 0.03, -60);
      }
    }
    if (pat === 2) {
      e.slamT -= dt;
      if (e.slamT <= 0) {
        e.slamT = rand(cfgBOSS_SKILLSGolemUpdateBoss.slamT_min, cfgBOSS_SKILLSGolemUpdateBoss.slamT_max) * f;
        RG.rings.push({ x: e.x, y: e.y, r: e.r + 10, maxR: 420, life: 2.2, color: "#fb923c", hazard: true, dmg: e.dmg * 0.7, hitP: false });
        e.slamEcho = cfgBOSS_SKILLSGolemUpdateBoss.slamEcho;   // v8.5 双震地:第二圈延迟 0.5s
        RG.cam.shake = 7; RG.playSfx("trap");
        if (e.enraged && (e.cycle || 1) >= cfgBOSS_SKILLSGolemUpdateBoss.value_threshold) RG.poisonZone(e.x, e.y, cfgBOSS_SKILLSGolemUpdateBoss.poisonZone_poisonZoneArg3_2, cfgBOSS_SKILLSGolemUpdateBoss.poisonZone_poisonZoneArg4_2, e.dmg * cfgBOSS_SKILLSGolemUpdateBoss.dmg_factor_5);   // 狂暴解锁:震地处岩浆毒圈
        for (let i = 0; i < (e.realmBoss ? cfgBOSS_SKILLSGolemUpdateBoss.value : cfgBOSS_SKILLSGolemUpdateBoss.value_2); i++) { const a = rand(0, TAU); RG.spawnTrap(RG.P.x + Math.cos(a) * rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), RG.P.y + Math.sin(a) * rand(cfgBOSS_SKILLSGolemUpdateBoss.rand_min, cfgBOSS_SKILLSGolemUpdateBoss.rand_max), e.realmBoss); }
      }
      e.burstT -= dt;
      if (e.burstT <= 0) { e.burstT = cfgBOSS_SKILLSGolemUpdateBoss.burstT_factor_2 * f * dens; for (let i = 0; i < cfgBOSS_SKILLSGolemUpdateBoss.value_8_offset + densN; i++) { const a = i / (8 + densN) * TAU; RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSGolemUpdateBoss.vx_factor_7, vy: Math.sin(a) * cfgBOSS_SKILLSGolemUpdateBoss.vy_factor_7, r: cfgBOSS_SKILLSGolemUpdateBoss.r, dmg: e.dmg * cfgBOSS_SKILLSGolemUpdateBoss.dmg_factor_2, life: cfgBOSS_SKILLSGolemUpdateBoss.life }); } }
    }
    if (pat === 3 || pat === 4) {
      e.spiralT -= dt;
      e.spiralA += dt * cfgBOSS_SKILLSSharedUpdateBoss.spiralA_factor;
      if (e.spiralT <= 0) {
        e.spiralT = (pat===4?RG.SHADOW_BOSS.spiral:cfgBOSS_SKILLSSharedUpdateBoss.spiralT) * (e.enraged ? cfgBOSS_SKILLSSharedUpdateBoss.spiralT_2 : 1) * dens * pace;
        const arms = e.realmBoss ? cfgBOSS_SKILLSSharedUpdateBoss.arms : cfgBOSS_SKILLSSharedUpdateBoss.arms_2;
        for (let k = 0; k < arms; k++) {
          const a = e.spiralA + k * TAU / arms;
          RG.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * cfgBOSS_SKILLSSharedUpdateBoss.vx_factor_2, vy: Math.sin(a) * cfgBOSS_SKILLSSharedUpdateBoss.vy_factor_2, r: cfgBOSS_SKILLSSharedUpdateBoss.r_6, dmg: e.dmg * cfgBOSS_SKILLSSharedUpdateBoss.dmg_factor_6, life: cfgBOSS_SKILLSSharedUpdateBoss.life });
        }
      }
      e.summonT -= dt;
      if (e.summonT <= 0) { e.summonT = cfgBOSS_SKILLSSharedUpdateBoss.summonT_factor * f; if(!RG.run.rushMode)for (let i = 0; i < RG.SPAWN_COUNTS.voidBrood; i++) { const m = RG.spawnEnemy("swarm", false); m.x = e.x + rand(-50, 50); m.y = e.y + rand(-50, 50); } }
    }
  }

  // 冲击波单次脉冲(v8.24 连冲共用):knockMul 击退倍率、radiusMul 范围倍率——连冲首脉冲减击退、后续脉冲扩圈无击退,保证贴脸怪吃满次数
  RG.updateBoss=updateBoss;
  RG.SYSTEM_BOSSES_VER="v12029";
})(window.RG);
