(function(RG){
 'use strict';
 const cfg=RG.sceneWeather={fog:'auto'},chunks=new Map(),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const depthQueue=[];let depthActive=false,depthOrder=0;
 function beginDepth(){depthQueue.length=0;depthOrder=0;depthActive=RG.run?.mapId==='workshop'&&!RG.realm?.active;}
 function queue(depth,paint,kind){if(depthActive)depthQueue.push({depth,paint,kind,order:depthOrder++});else paint();}
 function flushDepth(){
  depthQueue.sort((a,b)=>a.depth-b.depth||a.order-b.order);
  if(RG.debugTreeDepth)RG.worldDepthTrace=depthQueue.map(({depth,kind})=>({depth,kind}));
  for(const item of depthQueue)item.paint();depthQueue.length=0;depthActive=false;
 }
 const hash=(x,y)=>{let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263);n=Math.imul(n^(n>>>13),1274126177);return(n^(n>>>16))>>>0;};
 const ready=id=>{const im=RG.ART?.['meadow_'+id];return im?.complete&&im.naturalWidth?im:null;};
 const creek=y=>160+Math.sin(y/240)*130+Math.sin(y/90)*25,width=y=>29+Math.sin(y/145)*9;
 function cell(ctx,img,id,x,y,size){const n=img.naturalWidth/2;RG.drawWorldImage(ctx,img,id%2*n,Math.floor(id/2)*n,n,n,x,y,size,size);}
 function ground(ctx,W,H){
  const grass=ready('grass');if(!grass)return false;
  const size=512,{x:ox,y:oy}=RG.w2s(0,0);
  ctx.save();ctx.imageSmoothingEnabled=false;
  for(let cy=Math.floor(-oy/size);cy<=Math.floor((H-oy)/size);cy++)for(let cx=Math.floor(-ox/size);cx<=Math.floor((W-ox)/size);cx++){
   const key=(RG.renderDpr||1)+':'+cx+':'+cy;let cv=chunks.get(key);
   if(!cv){
    cv=document.createElement('canvas');cv.width=cv.height=size;const c=cv.getContext('2d');c.imageSmoothingEnabled=false;
    c.fillStyle='#39472a';c.fillRect(0,0,size,size);c.globalAlpha=.82;
    for(let sy=0;sy<2;sy++)for(let sx=0;sx<2;sx++)c.drawImage(grass,sx*256,sy*256,256,256);c.globalAlpha=1;
    // 溪岸按世界坐标连续构造，4像素采样与分档色面保留像素边缘。
    const bed=document.createElement('canvas');bed.width=bed.height=128;const b=bed.getContext('2d'),im=b.createImageData(128,128);
    if(!im?.data){ctx.restore();return false;}
    for(let y=0;y<128;y++)for(let x=0;x<128;x++){
     const wx=cx*size+x*4,wy=cy*size+y*4,d=Math.abs(wx-creek(wy)),w=width(wy),edge=Math.sin(wy*.13)*2+(hash(wx>>3,wy>>3)%5-2),p=(y*128+x)*4;
     if(d>w+10+edge)continue;
     const n=hash(wx>>3,wy>>3)%9,col=d>w+3+edge?[66+n,76+n,44+n]:d>w-3+edge?[66+n,80+n,49+n]:d>w-11?[54+n,87+n,70+n]:[36+n,76+n,72+n];
     im.data[p]=col[0];im.data[p+1]=col[1];im.data[p+2]=col[2];im.data[p+3]=d>w+6+edge?64+(hash(wx>>4,wy>>4)%5)*25:255;
    }
    b.putImageData(im,0,0);c.drawImage(bed,0,0,size,size);c.fillStyle='rgba(10,22,15,.16)';c.fillRect(0,0,size,size);
    chunks.set(key,cv);if(chunks.size>24)chunks.delete(chunks.keys().next().value);
   }
   RG.drawWorldImage(ctx,cv,ox+cx*size,oy+cy*size);
  }
  const t=RG.run?.t||0;
  // 水线有相位差，只在浅溪内部移动，不移动河岸或碰撞体。
  ctx.globalAlpha=.37;
  for(let i=Math.floor((RG.cam.y-H/2)/30)-1;i<=Math.ceil((RG.cam.y+H/2)/30)+1;i++){
   const n=hash(i,71),y=i*30+(Math.floor(t*5+n%30)%30),x=creek(y)+(n%41-20),p=RG.w2s(x,y);
   ctx.fillStyle=n%2?'#87afa0':'#416d68';RG.fillWorldRect(ctx,p.x,p.y,7+n%14,2);
  }
  ctx.globalAlpha=1;
  const bank=ready('banks');if(bank){
   for(let i=Math.floor((RG.cam.y-H/2)/180)-1;i<=Math.ceil((RG.cam.y+H/2)/180)+1;i++){
    const y=i*180+hash(i,9)%25,side=i%2?1:-1,p=RG.w2s(creek(y)+side*(width(y)+14),y),sz=96+hash(i,3)%10;
    ctx.globalAlpha=.86;cell(ctx,bank,Math.abs(i)%3===0?3:Math.abs(i)%2,p.x-sz/2,p.y-sz*.6,sz);
   }
   ctx.globalAlpha=.95;
   for(let i=Math.floor((RG.cam.y-H/2)/480)-1;i<=Math.ceil((RG.cam.y+H/2)/480)+1;i++){const y=i*480+120,p=RG.w2s(creek(y),y);cell(ctx,bank,2,p.x-53,p.y-45,106);}
  }
  ctx.restore();return true;
 }
 function trees(ctx){
  const img=ready('trees');
  for(const w of RG.walls||[]){if(!w.meadowTree)continue;const wx=w.x+w.w/2,wy=w.y+w.h/2,p=RG.w2s(wx,wy),sz=w.treeSize;
   if(p.x < -sz||p.x>RG.W+sz||p.y < -30||p.y>RG.H+sz)continue;
   queue(wy,()=>{const pos=RG.w2s(wx,wy),x=RG.snapRenderPixel(pos.x-sz/2),y=RG.snapRenderPixel(pos.y-sz*88/96);
    ctx.save();ctx.imageSmoothingEnabled=false;ctx.globalAlpha=1;
    if(img)cell(ctx,img,w.treeCell,x,y,sz);
    else{ctx.fillStyle='#354429';ctx.fillRect(pos.x-14,pos.y-45,28,44);ctx.fillStyle='#222e22';ctx.fillRect(pos.x-4,pos.y-25,8,25);}
    ctx.restore();
   },'tree');
  }
 }
 const noise=[];let veil=null;
 function noiseTile(layer){
  if(noise[layer])return noise[layer];
  const cv=document.createElement('canvas');cv.width=256;cv.height=128;const c=cv.getContext('2d'),im=c.createImageData(256,128);
  const smooth=t=>t*t*(3-2*t),grid=(x,y)=>hash((x%8+8)%8,(y%8+8)%8+layer*31)/4294967295;
  const value=(x,y)=>{const ix=Math.floor(x),iy=Math.floor(y),a=smooth(x-ix),b=smooth(y-iy);return(grid(ix,iy)*(1-a)+grid(ix+1,iy)*a)*(1-b)+(grid(ix,iy+1)*(1-a)+grid(ix+1,iy+1)*a)*b;};
  if(!im?.data)return null;
  for(let y=0;y<128;y++)for(let x=0;x<256;x++){
   const n=value(x/32,y/16)*.73+value(x/16,y/8)*.27,a=Math.floor(clamp((n-.26)*1.9,0,1)*5)/5,p=(y*256+x)*4;
   im.data[p]=180+layer*8;im.data[p+1]=196+layer*7;im.data[p+2]=184+layer*10;im.data[p+3]=Math.round(a*150);
  }
  c.putImageData(im,0,0);noise[layer]=cv;return cv;
 }
 function weather(){
  const phase=((RG.run?.t||0)+22)%72,s=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
  const strength=cfg.fog==='off'?0:cfg.fog==='on'?1:phase<10||phase>=50?0:phase<22?s((phase-10)/12):phase<38?1:1-s((phase-38)/12);
  return {phase,strength,cycle:72,clearSeconds:32,mode:cfg.fog};
 }
 function fog(ctx,W,H){
  if(RG.realm?.active||RG.run?.rushMode||!['valley','workshop'].includes(RG.run?.mapId))return;const state=weather();if(state.strength<=0)return;
  const scale=3,w=Math.ceil(W/scale),h=Math.ceil(H/scale),low=RG.fxQuality==='low'||RG.fxAutoReduced;
  if(!veil){veil=document.createElement('canvas');}if(veil.width!==w||veil.height!==h){veil.width=w;veil.height=h;}
  const c=veil.getContext('2d');c.clearRect(0,0,w,h);c.imageSmoothingEnabled=false;const t=Math.floor((RG.run?.t||0)*8)/8;
  for(let layer=0;layer<(low?1:2);layer++){
   const im=noiseTile(layer);if(!im)return;const tw=layer?360:296,th=layer?114:100,ox=((-RG.cam.x*.23+t*(layer?-.7:1.7))/scale%tw+tw)%tw,oy=((-RG.cam.y*.18+t*(layer?.12:.2))/scale%th+th)%th;
   c.globalAlpha=layer?.34:.55;for(let y=oy-th;y<h;y+=th)for(let x=ox-tw;x<w;x+=tw)c.drawImage(im,Math.floor(x),Math.floor(y),tw,th);
  }
  c.globalAlpha=1;c.globalCompositeOperation='destination-in';const p=RG.w2s(RG.P.x,RG.P.y),cx=p.x/scale,cy=p.y/scale,inner=Math.min(205,Math.min(W,H)*.34)/scale,outer=Math.min(440,Math.min(W,H)*.83)/scale;
  const mask=c.createRadialGradient(cx,cy,inner,cx,cy,outer);mask.addColorStop(0,'rgba(0,0,0,0)');mask.addColorStop(.45,'rgba(0,0,0,.24)');mask.addColorStop(1,'#000');c.fillStyle=mask;c.fillRect(0,0,w,h);c.globalCompositeOperation='source-over';
  ctx.save();ctx.imageSmoothingEnabled=false;ctx.globalAlpha=state.strength*.68;ctx.drawImage(veil,0,0,W,H);ctx.restore();
 }
 RG.scenery={ground,trees,fog,weather,creek,width,beginDepth,queue,flushDepth,cache:()=>({chunks:chunks.size,maxChunks:24,bytes:chunks.size*512*512*4})};
})(window.RG);

// ============ 渲染层 v6:宝石分层/光环/BOSS 演出/自适应卡牌 ============
(function (RG) {
  const { clamp, TAU } = RG;
  const cv = document.getElementById("cv");
  RG.ctx = cv.getContext("2d");
  // 帧时间戳:RG.draw 每帧刷新一次,实体循环里反复取系统时间不值
  let NOW = 0;
  function crossfireMark(x,y){
    ctx2.save();ctx2.globalAlpha=1;ctx2.fillStyle='rgba(25,31,34,.85)';ctx2.fillRect(Math.round(x)-9,Math.round(y)-9,18,18);
    ctx2.strokeStyle='#f5d7a1';ctx2.lineWidth=1;ctx2.strokeRect(Math.round(x)-9,Math.round(y)-9,18,18);
    ctx2.fillStyle='#f5d7a1';ctx2.font=F(12,true);ctx2.textAlign='center';ctx2.fillText('互',Math.round(x),Math.round(y)+4);ctx2.restore();
  }
  // 卡牌图标(GPT 像素切图,assets/icons/):按需加载,缺文件自动回退纯文字
  RG.CARD_ICON = {};
  ["magnet","frost","berserk","barrier","heal","power","crit","split","seed","regen","shell","shieldcore","evade","stance","pact","healbig","frenzy","critd","bigshot","explosive","boots","ricochet","ember","harmony","crystal","ash","echo","debt","combostorm","heart","phantom","allin"].forEach(id => {
    try { const img = new Image(); img.src = "assets/icons/" + id + ".png"; RG.CARD_ICON[id] = img; } catch (err) {}
  });
  // v8.6 像素美术:以现有卡牌图标为色板与像素密度基准；缺图仍回退几何图形。
  RG.ART = {};
  [
    ["floor", "assets/art/arena-floor-pixel-v3.png"],
    ["env_valley", "assets/art/environment-valley-atlas-pixel-v1.png"],
    ["env_workshop", "assets/art/environment-workshop-atlas-pixel-v1.png"],
    ["ground_earth", "assets/art/ground-earth-moss-pixel-v1.png"],
    ["ground_valley", "assets/art/ground-valley-stone-pixel-v1.png"],
    ["ground_workshop", "assets/art/ground-workshop-stone-pixel-v1.png"],
    ["env_detail", "assets/art/environment-detail-atlas-pixel-v1.png"],
    ["meadow_grass", "assets/art/meadow-ground-pixel-v1.png"],
    ["meadow_trees", "assets/art/meadow-trees-atlas-pixel-v1.png"],
    ["meadow_banks", "assets/art/meadow-banks-atlas-pixel-v1.png"],
    ["meadow_wall_h", "assets/art/meadow-wall-horizontal-pixel-v1.png"],
    ["meadow_wall_v", "assets/art/meadow-wall-vertical-pixel-v1.png"],
    ["stele_base", "assets/art/stele-base-pixel-v1.png"],
    ["stele_idle", "assets/art/stele-idle-atlas-pixel-v1.png"],
    ["element_marks", "assets/art/element-marks-atlas-pixel-v1.png"],
    ["realmfloor", "assets/art/arena-floor-pixel-v1.png"],
    ["menu", "assets/art/menu-arena-pixel-v1.png"],
    ["menuvalley", "assets/art/menu-valley-pixel-v2.png"],
    ["menusettings", "assets/art/menu-settings-v1.png"],
    ["menubook", "assets/art/menu-book-v1.png"],
    ["menuframe", "assets/art/menu-primary-frame-v1.png"],
    ["uicoin", "assets/art/ui-coin-pixel-v1.png"],
    ["uiaux", "assets/art/ui-aux-atlas-pixel-v1.png"],
    ["launcher", "assets/launcher-mage-v1-192.png"],
    ["atlas", "assets/art/character-atlas-pixel-v2.png"],
    ["boss", "assets/art/boss-atlas-pixel-v1.png"],
    ["wall_h", "assets/art/ruin-wall-horizontal-pixel-v1.png"],
    ["wall_v", "assets/art/ruin-wall-vertical-pixel-v1.png"],
    ["wall_temp_h", "assets/art/ruin-barrier-horizontal-pixel-v1.png"],
    ["wall_temp_v", "assets/art/ruin-barrier-vertical-pixel-v1.png"],
    ["card", "assets/art/card-atlas-pixel-v1.png"],
    ["player", "assets/art/player-atlas-pixel-v1.png"],
    ["mobanim", "assets/art/mob-anim-pixel-v1.png"],
    ["mobanim2", "assets/art/mob-anim-pixel-v2.png"],
    ["bossanim", "assets/art/boss-anim-pixel-v1.png"],
    ["hudframe", "assets/art/hud-bar-frame.png"],
    ["hudfill", "assets/art/hud-bar-fill.png"],
    ["dashbtn", "assets/art/hud-dash-btn.png"],
    ["mob_stalker", "assets/art/mob-stalker-pixel-v1-cut.png"],
    ["mob_crystal", "assets/art/mob-crystal-pixel-v1-cut.png"],
    ["mob_howler", "assets/art/mob-howler-pixel-v1-cut.png"],
    ["mob_stalker_anim", "assets/art/mob-stalker-anim-v2.png"],
    ["mob_crystal_anim", "assets/art/mob-crystal-anim-v3.png"],
    ["mob_scavenger_anim", "assets/art/mob-scavenger-move-v2.png"],
    ["mob_sporepod_anim", "assets/art/mob-sporepod-move-v2.png"],
    ["mob_warder_anim", "assets/art/mob-warder-move-v2.png"],
    ["mob_tether_anim", "assets/art/mob-tether-move-v2.png"],
    ["mob_mortar_anim", "assets/art/mob-mortar-move-v2.png"],
    ["mob_crucible_anim", "assets/art/mob-crucible-move-v2.png"],
    ["mob_phantasm_anim", "assets/art/mob-phantasm-move-v2.png"],
    ["mob_howler_anim", "assets/art/mob-howler-anim-v2.png"],
  ].forEach(([id, src]) => {
    try { const img = new Image(); img.src = src; RG.ART[id] = img; } catch (err) {}
  });

  // 世界→屏幕坐标:复用单点对象,避免每帧为上千个实体各分配一个临时对象(GC 压力)
  // 调用方约定:取回后立即读 x/y,不要同时持有两次调用的结果
  const SP = { x: 0, y: 0 };
  let shakeX=0,shakeY=0;
  // 静态世界共享设备像素网格，镜头小数位不能让地面、墙体和装饰各自跳格。
  RG.snapRenderPixel = value => {const d=RG.renderDpr||1;return Math.floor(value*d+.5000001)/d;};
  // 直接在设备像素上落图，避免非整数DPR反复重采样时浮点误差让同一纹理跳色。
  RG.drawWorldImage = (ctx,image,...args) => {
    const d=RG.renderDpr||1,p=v=>Math.floor(v*d+.5000001);
    if(args.length===2)args.push(image.naturalWidth||image.width,image.naturalHeight||image.height);
    const i=args.length-4,x=p(args[i]),y=p(args[i+1]),w=p(args[i]+args[i+2])-x,h=p(args[i+1]+args[i+3])-y;
    args.splice(i,4,x,y,w,h);ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(image,...args);ctx.restore();
  };
  RG.fillWorldRect = (ctx,x,y,w,h) => {const d=RG.renderDpr||1,p=v=>Math.floor(v*d+.5000001),px=p(x),py=p(y);ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillRect(px,py,p(x+w)-px,p(y+h)-py);ctx.restore();};
  RG.w2s = (x, y) => {
    SP.x = x + RG.snapRenderPixel(-RG.cam.x + RG.W / 2 + shakeX);
    SP.y = y + RG.snapRenderPixel(-RG.cam.y + RG.H / 2 + shakeY);
    return SP;
  };

  // 多边形填充
  function poly(x, y, r, n, rot, color) {
    ctx2.fillStyle = color; ctx2.beginPath();
    for (let i = 0; i < n; i++) {
      const a = rot + i / n * TAU;
      i === 0 ? ctx2.moveTo(x + Math.cos(a) * r, y + Math.sin(a) * r) : ctx2.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
    }
    ctx2.closePath(); ctx2.fill();
  }
  // 怪物几何组合:每类 2~3 个几何体叠出形态
  function drawEnemyShape(e, s, col, faceA) {
    const r = e.r;
    if(e.type==='prism'||e.type==='amplifier'){
      // 原生像素图案：透明空格、独立棱镜核心与炉体散热片，无外部图片依赖。
      const rows=e.type==='prism'?['      11        ','     1221       ','    122221      ','   12333221     ','  1234443321    ',' 123444443321   ','12344454433221  ','12344444433221  ',' 123444443321   ','  1233333321    ','   12222221     ','    111111      ','   21 11 12     ','  21  11  12    ',' 111  11  111   ','                ']:[' 11 11    11 11 ',' 12 12    12 12 ',' 12212222212221 ','1122222222222211','1233333333333321','1231444444413321','1231455555413321','1231454445413321','1231455555413321','1231444444413321','1233333333333321','1122222222222211',' 1112222222111  ','  1121111211    ',' 1111    1111   ','                '];
      const palette=e.type==='prism'?['','#132b42','#405d77','#22a2bd','#67e8f9','#ecfeff']:['','#251b19','#61534a','#ad681f','#f59e0b','#fff0a5'];
      const step=Math.max(1,r*3.2/16),x=Math.round(s.x-step*8),y=Math.round(s.y-step*8);
      rows.forEach((row,iy)=>{for(let ix=0;ix<row.length;ix++)if(row[ix]!==' '){ctx2.fillStyle=e.flash>0?'#ffffff':palette[+row[ix]];ctx2.fillRect(x+ix*step,y+iy*step,Math.ceil(step),Math.ceil(step));}});return;
    }
    switch (e.type) {
      case "grunt":
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
        poly(s.x - r * 0.62, s.y - r * 0.7, r * 0.3, 3, -0.5, col);
        poly(s.x + r * 0.62, s.y - r * 0.7, r * 0.3, 3, 0.5, col);
        break;
      case "swarm":
        poly(s.x, s.y, r * 1.15, 3, faceA, col);
        poly(s.x, s.y, r * 0.6, 3, faceA + Math.PI, col);
        break;
      case "shooter":
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.85, 0, TAU); ctx2.fill();
        ctx2.save(); ctx2.translate(s.x, s.y); ctx2.rotate(faceA);
        ctx2.fillRect(r * 0.5, -3.5, r * 0.95, 7); ctx2.restore();
        break;
      case "ice":
        poly(s.x, s.y, r * 1.15, 6, 0.3, col);
        ctx2.strokeStyle = "rgba(255,255,255,0.55)"; ctx2.lineWidth = 1.5;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.5, 0, TAU); ctx2.stroke();
        break;
      case "brute":
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
        ctx2.beginPath(); ctx2.arc(s.x - r * 0.75, s.y - r * 0.55, r * 0.32, 0, TAU); ctx2.fill();
        ctx2.beginPath(); ctx2.arc(s.x + r * 0.75, s.y - r * 0.55, r * 0.32, 0, TAU); ctx2.fill();
        break;
      case "colossus":
        ctx2.fillStyle = col;
        ctx2.fillRect(s.x - r * 0.85, s.y - r * 0.6, r * 1.7, r * 1.5);
        ctx2.beginPath(); ctx2.arc(s.x, s.y - r * 0.55, r * 0.55, 0, TAU); ctx2.fill();
        ctx2.strokeStyle = "rgba(0,0,0,0.35)"; ctx2.lineWidth = 2;
        ctx2.strokeRect(s.x - r * 0.85, s.y - r * 0.6, r * 1.7, r * 1.5);
        break;
      case "healer":
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
        ctx2.strokeStyle = "#fff"; ctx2.lineWidth = 2;
        ctx2.beginPath(); ctx2.moveTo(s.x - r * 0.5, s.y); ctx2.lineTo(s.x + r * 0.5, s.y);
        ctx2.moveTo(s.x, s.y - r * 0.5); ctx2.lineTo(s.x, s.y + r * 0.5); ctx2.stroke();
        break;
      case "bomber":
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.9, 0, TAU); ctx2.fill();
        ctx2.strokeStyle = "#fca5a5"; ctx2.lineWidth = 2;
        ctx2.beginPath(); ctx2.moveTo(s.x, s.y - r * 0.9); ctx2.quadraticCurveTo(s.x + r * 0.5, s.y - r * 1.5, s.x + r * 0.2, s.y - r * 1.9); ctx2.stroke();
        break;
      case "summoner":
        poly(s.x, s.y, r * 1.2, 3, -Math.PI / 2, col);
        ctx2.fillStyle = "rgba(255,255,255,0.6)"; ctx2.beginPath(); ctx2.arc(s.x, s.y - r * 0.15, r * 0.28, 0, TAU); ctx2.fill();
        break;
      case "splitter":
        ctx2.fillStyle = col;
        ctx2.beginPath(); ctx2.arc(s.x - r * 0.4, s.y, r * 0.75, 0, TAU); ctx2.fill();
        ctx2.beginPath(); ctx2.arc(s.x + r * 0.4, s.y, r * 0.75, 0, TAU); ctx2.fill();
        break;
      case "homing":
        poly(s.x, s.y, r * 1.25, 4, faceA, col);
        poly(s.x, s.y, r * 0.5, 4, faceA + Math.PI / 4, "rgba(255,255,255,0.5)");
        break;
      case "boss": {
        // BOSS 专属外形:按 bossKind 区分
        const k = e.bossKind || "gluttony";
        // 新 BOSS 专属外形(v7.8)
        if (k === "furnace") {
          const hv = Math.min(1, (e.heat || 0) / 100);
          ctx2.fillStyle = "#3d2a12"; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
          ctx2.strokeStyle = "#f97316"; ctx2.lineWidth = 3; ctx2.beginPath(); ctx2.arc(s.x, s.y, r + 2, 0, TAU); ctx2.stroke();
          ctx2.fillStyle = "rgba(255," + Math.round(120 + 100 * hv) + ",60," + (0.55 + hv * 0.45).toFixed(2) + ")";
          ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.36 + hv * 7, 0, TAU); ctx2.fill();
          break;
        }
        if (k === "mirror") {
          poly(s.x, s.y, r * 1.1, 4, NOW / 500, col);
          const b2 = 0.5 + 0.5 * Math.sin(NOW / 250);
          ctx2.strokeStyle = "rgba(192,132,252," + (0.4 + b2 * 0.5).toFixed(2) + ")"; ctx2.lineWidth = 3;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, r + 6 + b2 * 4, 0, TAU); ctx2.stroke();
          break;
        }
        if (k === "domain") {
          poly(s.x, s.y, r * 1.15, 6, NOW / 800, col);
          ctx2.strokeStyle = "rgba(125,211,252,0.6)"; ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.5, 0, TAU); ctx2.stroke();
          break;
        }
        if (k === "void") {
          poly(s.x, s.y, r * 1.2, 3, faceA, col);
          ctx2.fillStyle = "rgba(192,132,252,0.8)"; ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.4, 0, TAU); ctx2.fill();
          break;
        }
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
        if (k === "gluttony") {
          // 暴食之主:巨口獠牙
          ctx2.fillStyle = "#3d0d0d";
          ctx2.beginPath(); ctx2.moveTo(s.x - r * 0.7, s.y - r * 0.1);
          ctx2.quadraticCurveTo(s.x, s.y + r * 0.75, s.x + r * 0.7, s.y - r * 0.1);
          ctx2.quadraticCurveTo(s.x, s.y + r * 0.25, s.x - r * 0.7, s.y - r * 0.1);
          ctx2.fill();
          ctx2.fillStyle = "#f5f3ff";
          for (let i = 0; i < 4; i++) {
            const tx = s.x - r * 0.5 + i * r * 0.33;
            ctx2.beginPath(); ctx2.moveTo(tx, s.y - r * 0.05); ctx2.lineTo(tx + r * 0.1, s.y + r * 0.22); ctx2.lineTo(tx + r * 0.2, s.y - r * 0.05); ctx2.closePath(); ctx2.fill();
          }
          ctx2.fillStyle = "#ffd166";
          ctx2.beginPath(); ctx2.arc(s.x - r * 0.38, s.y - r * 0.42, r * 0.1, 0, TAU); ctx2.fill();
          ctx2.beginPath(); ctx2.arc(s.x + r * 0.38, s.y - r * 0.42, r * 0.1, 0, TAU); ctx2.fill();
        } else if (k === "golem") {
          // 裂地魔像:岩石方块 + 裂纹
          ctx2.fillStyle = col;
          ctx2.fillRect(s.x - r * 0.85, s.y - r * 0.85, r * 1.7, r * 1.7);
          ctx2.strokeStyle = "rgba(0,0,0,0.45)"; ctx2.lineWidth = 2.5;
          ctx2.beginPath();
          ctx2.moveTo(s.x - r * 0.4, s.y - r * 0.85); ctx2.lineTo(s.x - r * 0.15, s.y - r * 0.2); ctx2.lineTo(s.x - r * 0.5, s.y + r * 0.3);
          ctx2.moveTo(s.x + r * 0.5, s.y - r * 0.5); ctx2.lineTo(s.x + r * 0.2, s.y + r * 0.05); ctx2.lineTo(s.x + r * 0.55, s.y + r * 0.6);
          ctx2.stroke();
          ctx2.fillStyle = "#fbbf24";
          ctx2.fillRect(s.x - r * 0.5, s.y - r * 0.35, r * 0.3, r * 0.16);
          ctx2.fillRect(s.x + r * 0.2, s.y - r * 0.35, r * 0.3, r * 0.16);
        } else if (k === "eye") {
          // 深渊之眼:跟踪瞳孔
          ctx2.fillStyle = "#e8e2f0"; ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.92, 0, TAU); ctx2.fill();
          ctx2.strokeStyle = "rgba(124,58,237,0.5)"; ctx2.lineWidth = 1.5;
          for (let i = 0; i < 5; i++) {
            const va = i / 5 * TAU + 0.4;
            ctx2.beginPath(); ctx2.moveTo(s.x, s.y);
            ctx2.quadraticCurveTo(s.x + Math.cos(va) * r * 0.7, s.y + Math.sin(va) * r * 0.7, s.x + Math.cos(va + 0.5) * r * 0.88, s.y + Math.sin(va + 0.5) * r * 0.88);
            ctx2.stroke();
          }
          const ix2 = s.x + Math.cos(faceA) * r * 0.3, iy2 = s.y + Math.sin(faceA) * r * 0.3;
          ctx2.fillStyle = "#7c3aed"; ctx2.beginPath(); ctx2.arc(ix2, iy2, r * 0.38, 0, TAU); ctx2.fill();
          ctx2.fillStyle = "#12101e"; ctx2.beginPath(); ctx2.arc(ix2, iy2, r * 0.16, 0, TAU); ctx2.fill();
        } else if (k === "shadow") {
          // 终焉之影:波状暗影体 + 发光斜眼
          ctx2.fillStyle = "#171129";
          ctx2.beginPath();
          for (let i = 0; i <= 16; i++) {
            const wa = i / 16 * TAU;
            const wr = r * (1.02 + 0.1 * Math.sin(wa * 3 + NOW / 260));
            const px2 = s.x + Math.cos(wa) * wr, py2 = s.y + Math.sin(wa) * wr;
            if (i === 0) ctx2.moveTo(px2, py2); else ctx2.lineTo(px2, py2);
          }
          ctx2.closePath(); ctx2.fill();
          ctx2.strokeStyle = "rgba(124,58,237,0.55)"; ctx2.lineWidth = 2; ctx2.stroke();
          ctx2.fillStyle = "#e9d5ff";
          ctx2.beginPath(); ctx2.moveTo(s.x - r * 0.45, s.y - r * 0.18); ctx2.lineTo(s.x - r * 0.1, s.y - r * 0.02); ctx2.lineTo(s.x - r * 0.45, s.y + r * 0.1); ctx2.closePath(); ctx2.fill();
          ctx2.beginPath(); ctx2.moveTo(s.x + r * 0.45, s.y - r * 0.18); ctx2.lineTo(s.x + r * 0.1, s.y - r * 0.02); ctx2.lineTo(s.x + r * 0.45, s.y + r * 0.1); ctx2.closePath(); ctx2.fill();
        } else if (k === "guard") {
          // 秘境守卫:六角装甲 + 金边 + 核心晶石
          poly(s.x, s.y, r * 1.05, 6, 0, col);
          ctx2.strokeStyle = "#ffd166"; ctx2.lineWidth = 2.5;
          ctx2.beginPath();
          for (let i = 0; i <= 6; i++) {
            const ga = i / 6 * TAU;
            const gx = s.x + Math.cos(ga) * r * 1.05, gy = s.y + Math.sin(ga) * r * 1.05;
            if (i === 0) ctx2.moveTo(gx, gy); else ctx2.lineTo(gx, gy);
          }
          ctx2.stroke();
          ctx2.fillStyle = "#ffd166";
          ctx2.save(); ctx2.translate(s.x, s.y); ctx2.rotate(Math.PI / 4);
          ctx2.fillRect(-r * 0.18, -r * 0.18, r * 0.36, r * 0.36);
          ctx2.restore();
        } else {
          // 终焉·吞噬者:旋转利齿环 + 红核
          ctx2.fillStyle = "#2a0f1e";
          ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
          const rot = NOW / 300;
          ctx2.fillStyle = "#e8e2f0";
          for (let i = 0; i < 8; i++) {
            const ta = rot + i / 8 * TAU;
            const tx = s.x + Math.cos(ta) * r * 0.8, ty = s.y + Math.sin(ta) * r * 0.8;
            ctx2.save(); ctx2.translate(tx, ty); ctx2.rotate(ta + Math.PI / 2);
            ctx2.beginPath(); ctx2.moveTo(0, -r * 0.16); ctx2.lineTo(r * 0.13, r * 0.12); ctx2.lineTo(-r * 0.13, r * 0.12); ctx2.closePath(); ctx2.fill();
            ctx2.restore();
          }
          ctx2.fillStyle = "#ff4d6d";
          ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.3 + Math.sin(NOW / 180) * r * 0.04, 0, TAU); ctx2.fill();
          ctx2.fillStyle = "#12101e";
          ctx2.beginPath(); ctx2.arc(s.x, s.y, r * 0.12, 0, TAU); ctx2.fill();
        }
        break;
      }
      default:
        ctx2.fillStyle = col; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
    }
  }

  function roundRect(x, y, w, h, r) {
    // P1 视觉统一:全局 UI 弃用圆角弧线,统一走正交阶梯角(与 pixelRect 同轮廓,弧线是"网页感"的主要来源)
    pixelRect(x, y, w, h, r);
  }
  // 正交阶梯角：卡牌采用真正的像素轮廓，不用圆角/斜线抗锯齿。
  function pixelRect(x, y, w, h, c) {
    c = Math.max(4, Math.min(c || 8, w / 5, h / 5)); const s = Math.max(2, Math.floor(c / 2));
    ctx2.beginPath();
    ctx2.moveTo(x + c, y); ctx2.lineTo(x + w - c, y); ctx2.lineTo(x + w - c, y + s); ctx2.lineTo(x + w - s, y + s);
    ctx2.lineTo(x + w - s, y + c); ctx2.lineTo(x + w, y + c); ctx2.lineTo(x + w, y + h - c);
    ctx2.lineTo(x + w - s, y + h - c); ctx2.lineTo(x + w - s, y + h - s); ctx2.lineTo(x + w - c, y + h - s);
    ctx2.lineTo(x + w - c, y + h); ctx2.lineTo(x + c, y + h); ctx2.lineTo(x + c, y + h - s); ctx2.lineTo(x + s, y + h - s);
    ctx2.lineTo(x + s, y + h - c); ctx2.lineTo(x, y + h - c); ctx2.lineTo(x, y + c); ctx2.lineTo(x + s, y + c);
    ctx2.lineTo(x + s, y + s); ctx2.lineTo(x + c, y + s); ctx2.closePath();
  }
  function wrapText(text, cx, y, maxW, lh, maxLines) {
    const chars = String(text || "").split(""), lines = []; let line = "";
    for (const ch of chars) {
      if (ctx2.measureText(line + ch).width > maxW && line) { lines.push(line); line = ch; }
      else line += ch;
    }
    if (line) lines.push(line);
    if (maxLines && lines.length > maxLines) {
      lines.length = maxLines;
      let tail = lines[maxLines - 1];
      while (tail && ctx2.measureText(tail + "…").width > maxW) tail = tail.slice(0, -1);
      lines[maxLines - 1] = tail + "…";
    }
    lines.forEach((l, i) => ctx2.fillText(l, cx, y + i * lh));
    return y + Math.max(0, lines.length - 1) * lh;
  }
  function drawEdgeMarker(wx, wy, color, label) {
    const W = RG.W, H = RG.H, sx = wx - RG.cam.x + W / 2, sy = wy - RG.cam.y + H / 2, margin = 44;
    if (sx >= margin && sx <= W - margin && sy >= margin && sy <= H - margin) return false;
    const dx = sx - W / 2, dy = sy - H / 2, d = Math.hypot(dx, dy) || 1;
    const scale = Math.min((W / 2 - margin) / Math.max(1, Math.abs(dx)), (H / 2 - margin) / Math.max(1, Math.abs(dy)));
    const x = W / 2 + dx * scale, y = H / 2 + dy * scale, a = Math.atan2(dy, dx);
    ctx2.save(); ctx2.translate(x, y); ctx2.rotate(a);
    ctx2.fillStyle = color; ctx2.beginPath(); ctx2.moveTo(12, 0); ctx2.lineTo(-8, -8); ctx2.lineTo(-5, 0); ctx2.lineTo(-8, 8); ctx2.closePath(); ctx2.fill();
    ctx2.restore();
    ctx2.fillStyle = color; ctx2.textAlign = "center"; ctx2.font = F(10, true);
    ctx2.fillText(label + " " + Math.round(d / 10) + "m", x, y + (dy < 0 ? 20 : -14));
    return true;
  }
  function artReady(id) {
    const img = RG.ART && RG.ART[id];
    return img && img.complete && img.naturalWidth > 0 ? img : null;
  }
  // 小型像素符号直接缓存成透明画布；轮廓清楚、低饱和底、少量亮点，不依赖旧印记素材。
  const elementGlyphs=new Map(),elementPixels={
    fire:['000100000','001110000','001210100','011221100','012222110','012332210','012332210','001222100','000111000'],
    ice:['000100000','010101000','001110000','111211100','001210000','011211000','010101000','000100000','000000000'],
    elec:['000111000','001210000','001210000','012111000','011221000','000121000','000110000','001100000','001000000'],
    poison:['000111000','001221100','012122110','012222210','001112100','000121000','001222100','001111100','000000000'],
    earth:['000110000','001221000','012332100','012222100','011111100','001221000','011111100','000000000','000000000']};
  function elementGlyph(id,phase){const key=id+phase;if(elementGlyphs.has(key))return elementGlyphs.get(key);const cv=document.createElement('canvas');cv.width=11;cv.height=11;const g=cv.getContext('2d'),rows=elementPixels[id],colors=['','#1c1828',RG.ELEMENTS[id].color,'#fff0ce'];for(let y=0;y<rows.length;y++)for(let x=0;x<rows[y].length;x++){const n=+rows[y][x];if(!n)continue;g.fillStyle=colors[n];g.fillRect(x+1,y+1+(id==='fire'&&y<3&&phase%2?1:0),1,1);}elementGlyphs.set(key,cv);return cv;}
  function drawElementMarks(e,s,size,player=false){
    if(e.dead||e.dying)return true;const active=[],add=id=>{if(!active.includes(id)&&active.length<2)active.push(id);};
    if(player){if(e.slowT>0||e.freezeT>0)add('ice');if(e.poisonContactT>0)add('poison');}
    else{if(e.frozen>0)add('ice');if(e.petrifyT>0)add('earth');for(const id of RG.ELEMENT_ORDER)if(e.el?.[id]>0||id==='fire'&&e.burnDps>0)add(id);}
    const phase=Math.floor((RG.run?.t||0)*6)%4,scale=2,foot=s.y+e.r;
    ctx2.save();ctx2.imageSmoothingEnabled=false;
    active.forEach((id,i)=>{const x=s.x+(i===0?-1:1)*(e.r+3)-11,y=foot-19+(phase===1||phase===2?-1:0);ctx2.drawImage(elementGlyph(id,phase),Math.round(x),Math.round(y),11*scale,11*scale);});ctx2.restore();return true;
  }
  function drawAtlasCell(col, row, x, y, size, rot) {
    const img = artReady("atlas"); if (!img) return false;
    const sw = img.naturalWidth / 4, sh = img.naturalHeight / 3;
    size = Math.round(size); x = Math.round(x); y = Math.round(y);
    ctx2.save(); ctx2.imageSmoothingEnabled = false; ctx2.translate(x, y); ctx2.rotate(rot || 0);
    ctx2.drawImage(img, col * sw, row * sh, sw, sh, -size / 2, -size / 2, size, size);
    ctx2.restore(); return true;
  }
  function drawBossCell(col, row, x, y, size, rot) {
    const img = artReady("boss"); if (!img) return false;
    const sw = img.naturalWidth / 3, sh = img.naturalHeight / 3;
    size = Math.round(size); x = Math.round(x); y = Math.round(y);
    ctx2.save(); ctx2.imageSmoothingEnabled = false; ctx2.translate(x, y); ctx2.rotate(rot || 0);
    ctx2.drawImage(img, col * sw, row * sh, sw, sh, -size / 2, -size / 2, size, size);
    ctx2.restore(); return true;
  }
  // 玩家四方向行走图(player-atlas-pixel-vN.png,4列×3行):
  // 列 = 朝向 0下/1上/2左/3右;行 = 0待机 / 1~2 行走两帧(150ms 轮换);
  // 缺图回退 character-atlas [0,0],再缺回退几何圆(C-05 代码侧,ZCode)
  let playerEdgeSource=null,playerEdge=null;
  function drawPlayerArt(s) {
    const P = RG.P;
    if (artReady("player")) {
      const img = RG.ART.player;
      const cw = img.naturalWidth / 4, ch = img.naturalHeight / 3;
      const a = P.face, abs = Math.abs;
      // 朝向四象限:±45° 边界归水平帧——WASD 对角线恰好等于 ±45°,旧写法(严格小于)会把右下/右上误判成朝左
      const col = (a >= -Math.PI / 4 && a <= Math.PI / 4) ? 3
        : (a > Math.PI / 4 && a < 3 * Math.PI / 4) ? 0
        : (a >= -3 * Math.PI / 4 && a < -Math.PI / 4) ? 1
        : 2;
      const row = P.moving ? 1 + (Math.floor(NOW / 150) % 2) : 0;
      const size = Math.round(P.r * 4.15);
      ctx2.save();
      ctx2.imageSmoothingEnabled = false;
      // 用原图透明轮廓缓存硬边描线，保持角色尺寸与像素，不盖住场地预警。
      if(playerEdgeSource!==img){const off=document.createElement('canvas');off.width=img.naturalWidth;off.height=img.naturalHeight;const g=off.getContext('2d');g.drawImage(img,0,0);g.globalCompositeOperation='source-in';g.fillStyle='#b9dce6';g.fillRect(0,0,off.width,off.height);playerEdgeSource=img;playerEdge=off;}
      const px=Math.round(s.x-size/2),py=Math.round(s.y-size/2);
      ctx2.globalAlpha=.65;
      for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]])ctx2.drawImage(playerEdge,col*cw,row*ch,cw,ch,px+dx,py+dy,size,size);
      ctx2.globalAlpha=1;
      ctx2.drawImage(img, col * cw, row * ch, cw, ch, Math.round(s.x - size / 2), Math.round(s.y - size / 2), size, size);
      ctx2.restore();
      return true;
    }
    return drawAtlasCell(0, 0, s.x, s.y, P.r * 4.15, 0);
  }
  function drawPlayerPortrait(x,y,size){
    const img=artReady("player");
    if(img){const cw=img.naturalWidth/4,ch=img.naturalHeight/3;ctx2.save();ctx2.imageSmoothingEnabled=false;ctx2.drawImage(img,0,0,cw,ch,Math.round(x-size/2),Math.round(y-size/2),Math.round(size),Math.round(size));ctx2.restore();return true;}
    return drawAtlasCell(0,0,x,y,size,0);
  }
  // ---------- Z-P1 帧动画驱动(P1,缺图自动回退静态格/几何)----------
  // 小怪动画 mob-anim-pixel-vN.png:4列×11行,行=ETYPES 声明顺序;列=移动循环帧(~7fps;只画2帧时把第2/3列复制第0/1列即可)
  // BOSS 动画 boss-anim-pixel-vN.png:5列×8行,行=BOSS_NAMES 顺序;列=0待机/1蓄力/2受击/3狂暴/4死亡(预留)
  const MOB_ANIM_ROWS = { colossus:0, brute:1, ice:2, shooter:3, grunt:4, swarm:5, healer:6, bomber:7, summoner:8, splitter:9, homing:10 };
  const BOSS_ANIM_ROWS = { gluttony:0, golem:1, eye:2, shadow:3, mirror:4, domain:5, furnace:6, void:7 };
  // C-10 v2 图集(4×16):行 0~10 与 v1 逐像素一致;行 11~15 = 冲锋犬/盾兽/喷火兽/捶地兽/电击兽(typeKey 已预留,批次 G 登场)
  const MOB_ANIM2_ROWS = { colossus:0, brute:1, ice:2, shooter:3, grunt:4, swarm:5, healer:6, bomber:7, summoner:8, splitter:9, homing:10, hound:11, bulwark:12, flamer:13, smasher:14, volt:15 };
  // v11.8 朝向:0下/1左/2右/3上 —— 与 anim 图集行序一致
  function mobFacing(e) {
    if (e.faceA != null) {
      // 有瞄准角时按角度分四向
      const a = e.faceA;
      const c = Math.cos(a), sn = Math.sin(a);
      if (Math.abs(c) > Math.abs(sn)) return c < 0 ? 1 : 2;
      return sn < 0 ? 3 : 0;
    }
    const ax = e.vx || 0, ay = e.vy || 0;
    if (Math.abs(ax) + Math.abs(ay) < 1) {
      // 静止:朝向玩家粗略方向由调用方写入 faceDir,否则朝下
      return e.faceDir || 0;
    }
    if (Math.abs(ax) > Math.abs(ay)) return ax < 0 ? 1 : 2;
    return ay < 0 ? 3 : 0;
  }
  const MOB_ANIM_SHEET = { scavenger: "mob_scavenger_anim", sporepod: "mob_sporepod_anim", warder: "mob_warder_anim", tether: "mob_tether_anim", mortar: "mob_mortar_anim", crucible: "mob_crucible_anim", phantasm: "mob_phantasm_anim", stalker: "mob_stalker_anim", crystal: "mob_crystal_anim", howler: "mob_howler_anim" };
  const MOB_SOLO = { stalker: "mob_stalker", crystal: "mob_crystal", howler: "mob_howler" };
  const cleanMobSheets={};
  function drawMobAnim(e, s, size) {
    // v11.8 四向帧图集:4列行走 × 4行朝向
    const sheetId = MOB_ANIM_SHEET[e.type];
    if (sheetId) {
      const simg = artReady(sheetId);
      if (simg) {
        const cw = simg.naturalWidth / 4, ch = simg.naturalHeight / 4;
        let cleaned=cleanMobSheets[sheetId];
        if(!cleaned||cleaned.source!==simg){const cv=document.createElement('canvas');cv.width=simg.naturalWidth;cv.height=simg.naturalHeight;const cc=cv.getContext('2d');cc.drawImage(simg,0,0);for(let r=0;r<4;r++)for(let q=0;q<4;q++)cc.clearRect(q*cw+cw*52/64,r*ch+ch*58/64,cw*12/64,ch*6/64);cleaned=cleanMobSheets[sheetId]={source:simg,canvas:cv};}
        const col = RG.mobFrame(e,RG.run?.t||0);
        const row = (e.type==='crystal'||RG.ETYPES[e.type]?.meadow)&&Math.hypot(e.motionX||0,e.motionY||0)>1 ? mobFacing({vx:e.motionX,vy:e.motionY}) : mobFacing(e);
        const bob=(e.type==='crystal'||RG.ETYPES[e.type]?.meadow)?0:[0,-1,0,1][col]*Math.min(2,size/80);
        ctx2.save(); ctx2.imageSmoothingEnabled = false;
        ctx2.drawImage(cleaned.canvas, col * cw, row * ch, cw, ch, Math.round(s.x - size / 2), Math.round(s.y - size / 2+bob), Math.round(size), Math.round(size));
        ctx2.restore(); return true;
      }
    }
    // v11.7 单体立绘(无四向时左右翻转模拟朝向)
    const soloId = MOB_SOLO[e.type];
    if (soloId) {
      const simg = artReady(soloId);
      if (simg) {
        const face = mobFacing(e);
        ctx2.save(); ctx2.imageSmoothingEnabled = false;
        if (face === 1) {
          ctx2.translate(Math.round(s.x), 0); ctx2.scale(-1, 1);
          ctx2.drawImage(simg, Math.round(-size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
        } else if (face === 3) {
          // 朝上略缩小高光背影:直接画并压暗
          ctx2.globalAlpha = 0.92;
          ctx2.drawImage(simg, Math.round(s.x - size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
        } else {
          ctx2.drawImage(simg, Math.round(s.x - size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
        }
        ctx2.restore(); return true;
      }
    }
    const img2 = artReady("mobanim2");
    const img = img2 || artReady("mobanim");   // v2 缺图回退 v1(行 0~10 两版逐像素一致)
    if (!img) return false;
    const map = img2 ? MOB_ANIM2_ROWS : MOB_ANIM_ROWS;
    const row = map[e.type];
    if (row === undefined) return false;
    const rowsN = img2 ? 16 : 11;
    const cw = img.naturalWidth / 4, ch = img.naturalHeight / rowsN;
    const col = RG.mobFrame(e,RG.run?.t||0);
    const face = mobFacing(e);
    ctx2.save(); ctx2.imageSmoothingEnabled = false;
    if (face === 1) {
      // 朝左:水平翻转(原图默认朝右/正面)
      ctx2.translate(Math.round(s.x), 0); ctx2.scale(-1, 1);
      ctx2.drawImage(img, col * cw, row * ch, cw, ch, Math.round(-size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
    } else if (face === 3) {
      ctx2.globalAlpha = 0.94;
      ctx2.drawImage(img, col * cw, row * ch, cw, ch, Math.round(s.x - size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
      // 朝上:头顶略暗提示背向
      ctx2.globalAlpha = 0.12; ctx2.fillStyle = "#090A12";
      ctx2.fillRect(Math.round(s.x - size * 0.28), Math.round(s.y - size * 0.42), Math.round(size * 0.56), Math.round(size * 0.18));
    } else {
      ctx2.drawImage(img, col * cw, row * ch, cw, ch, Math.round(s.x - size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
    }
    ctx2.restore(); return true;
  }
  // 活体与冻结遗体共用同一素材选择，缺图时才回退几何。
  function drawMobSprite(e,s,size){
    const cell=MOB_ATLAS_CELLS[e.type];
    return drawMobAnim(e,s,size)||(cell?drawAtlasCell(cell[0],cell[1],s.x,s.y,size,0):false);
  }
  function icePolygon(points,fill,stroke,c=ctx2){
    c.beginPath();points.forEach(([x,y],i)=>{if(i)c.lineTo(Math.round(x),Math.round(y));else c.moveTo(Math.round(x),Math.round(y));});c.closePath();
    c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}
  }
  const frostIceTiles=[];
  function frostIceTile(i){
    const id=i%4;if(frostIceTiles[id])return frostIceTiles[id];
    // 四种小像素冰块只生成一次；近邻放大保持像素棱角，也减少满墙逐帧路径绘制。
    const tile=document.createElement('canvas');tile.width=18;tile.height=28;const c=tile.getContext('2d');c.scale(.5,.5);
    const x=18,y=44,h=24+id*5,half=15,peak=(id%3-1)*4;
    icePolygon([[x-half,y+7],[x-half,y-h*.55],[x-6+peak,y-h],[x+8,y-h*.82],[x+half,y-h*.38],[x+half,y+5],[x+3,y+10]],'#71bdd8','#285a79',c);
    icePolygon([[x-half,y-h*.55],[x-6+peak,y-h],[x+8,y-h*.82],[x+2,y-h*.38],[x-5,y+5]],'#c9effa',null,c);
    icePolygon([[x+8,y-h*.82],[x+half,y-h*.38],[x+half,y+5],[x+3,y+10],[x+2,y-h*.38]],'#398dad',null,c);
    c.strokeStyle='#e3f8ff';c.lineWidth=2;c.beginPath();c.moveTo(x-6+peak,y-h+3);c.lineTo(x-3,y-h*.45);c.lineTo(x+3,y-h*.3);c.lineTo(x,y+1);c.stroke();return frostIceTiles[id]=tile;
  }
  function drawFrozenCorpse(e,s){
    const size=e.r*(e.type==='colossus'?4.15:4),r=Math.max(13,e.r*1.45);
    ctx2.save();
    if(!drawMobSprite(e,s,size))drawEnemyShape(e,s,'#7dd3fc',e.faceA||0);
    // 透明冰棱包住原怪物，颜色与轮廓仍可辨认；静止帧由frozen锁定。
    const x=s.x,y=s.y;
    icePolygon([[x-r,y-r*.5],[x-r*.55,y-r*1.2],[x+r*.45,y-r*1.1],[x+r,y-r*.4],[x+r*.9,y+r*.8],[x-r*.65,y+r]],'rgba(125,211,252,.24)','#b6eaff');
    icePolygon([[x-r,y-r*.5],[x-r*.55,y-r*1.2],[x-r*.25,y+r*.85],[x-r*.65,y+r]],'rgba(224,242,254,.24)');
    ctx2.strokeStyle='rgba(224,242,254,.8)';ctx2.lineWidth=1;ctx2.beginPath();ctx2.moveTo(x+r*.45,y-r*1.1);ctx2.lineTo(x+r*.15,y-r*.35);ctx2.lineTo(x+r*.55,y);ctx2.lineTo(x+r*.2,y+r*.65);ctx2.stroke();ctx2.restore();
  }
  function drawFrostWall(w,s){
    const start=w.full?0:w.a-Math.PI/2,end=w.full?TAU:w.a+Math.PI/2;
    ctx2.save();ctx2.globalAlpha=w.warn>0?.7:clamp(w.t/1.2,0,1);
    if(w.warn>0){ctx2.strokeStyle='#ff5470';ctx2.lineWidth=2;ctx2.setLineDash([14,10]);ctx2.beginPath();ctx2.arc(s.x,s.y,w.r,start,end);ctx2.stroke();}
    else{
      // 脚下暗面覆盖碰撞弧，分块冰柱向上生长，避免亮色管道/霓虹圆环感。
      ctx2.strokeStyle='rgba(15,52,79,.7)';ctx2.lineWidth=w.width+5;ctx2.beginPath();ctx2.arc(s.x,s.y,w.r,start,end);ctx2.stroke();
      const count=Math.ceil((end-start)*w.r/24),step=(end-start)/count;ctx2.imageSmoothingEnabled=false;
      for(let i=0;i<count;i++){
        const a=start+(i+.5)*step,x=s.x+Math.cos(a)*w.r,y=s.y+Math.sin(a)*w.r;
        ctx2.drawImage(frostIceTile(i),Math.round(x)-18,Math.round(y)-44,36,56);
      }
    }
    ctx2.restore();
  }
  function drawFrostField(hb,s){
    ctx2.save();ctx2.translate(s.x,s.y);ctx2.rotate(hb.a);
    if(hb.warn>0){ctx2.fillStyle='rgba(255,84,112,.07)';ctx2.strokeStyle='#ff5470';ctx2.lineWidth=2;ctx2.setLineDash([14,10]);ctx2.fillRect(0,-hb.w/2,hb.len,hb.w);ctx2.strokeRect(0,-hb.w/2,hb.len,hb.w);}
    else{
      ctx2.globalAlpha=clamp(hb.fire/.15,0,1);ctx2.fillStyle='rgba(117,197,220,.22)';ctx2.fillRect(0,-hb.w/2,hb.len,hb.w);
      // 零散棱面与冰裂地表铺满实际矩形，不再画箭头图标。
      ctx2.strokeStyle='rgba(210,246,255,.7)';ctx2.lineWidth=1;ctx2.strokeRect(0,-hb.w/2,hb.len,hb.w);
      for(let i=0,x=18;x<hb.len-10;x+=42,i++)for(let j=0,y=-hb.w/2+17;y<hb.w/2-10;y+=36,j++){
        const px=x+(j%2)*8,py=y+(i%2)*5;
        icePolygon([[px-9,py],[px-3,py-8],[px+8,py-5],[px+12,py+3],[px+2,py+10]],'rgba(190,237,250,.35)');
        ctx2.strokeStyle='rgba(232,251,255,.55)';ctx2.beginPath();ctx2.moveTo(px-9,py);ctx2.lineTo(px+1,py+2);ctx2.lineTo(px+8,py-5);ctx2.moveTo(px+1,py+2);ctx2.lineTo(px+2,py+10);ctx2.stroke();
      }
    }
    ctx2.restore();
  }
  const furnaceToneCache=new WeakMap();
  function furnaceToneRow(img,row,cold){
    let tones=furnaceToneCache.get(img);if(!tones){tones={};furnaceToneCache.set(img,tones);}const key=cold?'cold':'settling';if(tones[key])return tones[key];
    try{
      const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight/8;const g=c.getContext('2d');g.drawImage(img,0,row*c.height,c.width,c.height,0,0,c.width,c.height);
      const pixels=g.getImageData(0,0,c.width,c.height),d=pixels.data;
      for(let i=0;i<d.length;i+=4)if(d[i+3]&&d[i]>d[i+1]*1.04&&d[i+1]>d[i+2]*1.1){
        if(cold){const v=(d[i]+d[i+1])/2;d[i]=35+v*.24;d[i+1]=55+v*.53;d[i+2]=70+v*.57;}
        else{d[i]*=.48;d[i+1]*=.48;d[i+2]*=.48;}
      }
      g.putImageData(pixels,0,0);tones[key]=c;return c;
    }catch(_){return null;} // 媒体或旧浏览器无法读取像素时保留原图，状态散热片继续生效。
  }
  function drawBossAnim(e, s, size) {
    const img = artReady("bossanim");
    const row = e.bossKind==="guard" ? (e.guardSkin||0) : BOSS_ANIM_ROWS[e.bossKind || "gluttony"];
    if (!img || row === undefined) return false;
    const cw = img.naturalWidth / 5, ch = img.naturalHeight / 8;
    const col = e.dying ? 4 : (e.chargeWind > 0 || e.charging > 0 || e.realmCastT>0) ? 1 : e.flash > 0 ? 2 : e.enraged ? 3 : 0;   // C-08:死亡列接入濒死演出
    const cooled=!RG.debugLegacyEnvironment&&e.bossKind==='furnace'&&RG.run?.mapId==='workshop'&&!RG.run.rushMode&&!e.dead&&!e.dying&&(e.workshopColdT>0||e.coolingT>0);
    const toned=cooled?furnaceToneRow(img,row,e.workshopColdT>0):null;
    ctx2.save(); ctx2.imageSmoothingEnabled = false;
    ctx2.drawImage(toned||img, col * cw, toned?0:row * ch, cw, ch, Math.round(s.x - size / 2), Math.round(s.y - size / 2), Math.round(size), Math.round(size));
    ctx2.restore(); return true;
  }
  const CARD_ATLAS_CELLS = {
    beam:[0,0], bolt:[1,0], seeker:[2,0], orbit:[3,0], nova:[4,0],
    boomer:[0,1], hammer:[1,1], vial:[2,1], laser:[3,1], chain:[4,1],
    scatter:[0,2], collapse:[2,2], overdrive:[3,2], aegis:[4,2],
  };
  // BOSS 图集格子(3×3):敌人渲染与连战选关头像共用(C-01 接口,ZCode 提升到模块级)
  const BOSS_ATLAS_CELLS = { gluttony:[0,0], golem:[1,0], eye:[2,0], shadow:[0,1], mirror:[1,1], domain:[2,1], furnace:[0,2], void:[1,2], devourer:[2,2] };
  const MOB_ATLAS_CELLS={grunt:[1,0],swarm:[2,0],shooter:[3,0],ice:[0,1],brute:[1,1],healer:[2,1],bomber:[3,1],summoner:[0,2],splitter:[1,2],homing:[2,2],colossus:[3,2]};
  function drawEnemyIcon(type,x,y,size){const e={type,r:size/4,faceDir:0},s={x:x+size/2,y:y+size/2};if(drawMobAnim(e,s,size))return;const cell=MOB_ATLAS_CELLS[type];if(cell&&drawAtlasCell(cell[0],cell[1],s.x,s.y,size,0))return;drawEnemyShape(e,s,RG.ETYPES[type].color,0);}
  function drawCardAtlasIcon(id, x, y, size) {
    const img = artReady("card"), cell = CARD_ATLAS_CELLS[id]; if (!img || !cell) return drawSmallWeaponIcon(id,x,y,size);
    const sw = img.naturalWidth / 5, sh = img.naturalHeight / 3;
    ctx2.save(); ctx2.imageSmoothingEnabled = false;
    ctx2.drawImage(img, cell[0] * sw, cell[1] * sh, sw, sh, Math.round(x), Math.round(y), Math.round(size), Math.round(size));
    ctx2.restore(); return true;
  }
  function drawSmallWeaponIcon(id,x,y,size){
    if(!['scythe','spinner','kiwave','thunder','chrono'].includes(id))return false;
    // 仅补齐原图集缺的四个图案：沿用32像素、少色块、硬边和灰框。
    ctx2.save();ctx2.translate(Math.round(x),Math.round(y));ctx2.scale(size/32,size/32);ctx2.fillStyle='#10151d';ctx2.fillRect(1,1,30,30);ctx2.strokeStyle='#343e48';ctx2.lineWidth=1;ctx2.strokeRect(2,2,28,28);
    const block=(color,rects)=>{ctx2.fillStyle=color;for(const a of rects)ctx2.fillRect(...a);};
    if(id==='thunder'){block('#aa8133',[[17,5,7,3],[14,8,8,3],[11,11,8,5],[16,16,6,3],[13,19,6,3],[10,22,6,3]]);block('#fde047',[[18,6,4,2],[15,9,4,3],[13,12,4,3],[17,16,3,3],[14,19,3,3],[11,22,3,3]]);}
    if(id==='chrono'){block('#318092',[[9,5,14,3],[6,8,3,16],[23,8,3,16],[9,24,14,3]]);block('#67e8f9',[[10,6,12,2],[7,9,2,14],[23,9,2,14],[10,24,12,2],[15,10,2,8],[17,16,5,2]]);}
    if(id==='scythe'){block('#98446a',[[7,5,17,3],[4,8,11,3],[3,11,5,7],[21,8,3,19]]);block('#f28ab7',[[9,5,12,2],[5,8,7,2],[4,11,3,4],[21,9,2,15]]);block('#ffd5e8',[[11,5,8,1],[21,10,1,11]]);}
    if(id==='spinner'){block('#6b4f33',[[7,10,5,17],[21,5,5,17],[11,6,11,2]]);block('#e9a348',[[7,11,4,12],[21,6,4,12]]);block('#ffe3a0',[[7,12,1,9],[21,7,1,9]]);block('#99a6b1',[[11,8,3,2],[14,6,3,2],[17,8,4,2]]);}
    if(id==='kiwave'){for(const [a,b] of [[9,10],[21,12],[15,23]]){block('#286887',[[a-4,b-2,8,4],[a-2,b-4,4,8]]);block('#5bccdf',[[a-3,b-2,6,4],[a-2,b-3,4,6]]);block('#d5f9ff',[[a-1,b-1,2,2]]);}}
    ctx2.restore();return true;
  }
  const wallShadows=new WeakMap();
  function drawWallArt(w, s, sw, sh) {
    const id=(w.temp?'wall_temp_':'wall_')+(sw>=sh?'h':'v'),img=(!w.temp&&RG.run?.mapId==='workshop'&&!RG.realm?.active?artReady('meadow_'+id):null)||artReady(id);if(!img)return false;
    // 横纵墙分别绘制：短边等比缩放，保留两端，中段重复/裁切；不拉长纹理也不旋转立面。
    if(!w._ruin||w._ruinSource!==img||w._ruinW!==sw||w._ruinH!==sh){
      const cv=document.createElement('canvas');cv.width=Math.ceil(sw);cv.height=Math.ceil(sh);const c=cv.getContext('2d');c.imageSmoothingEnabled=false;
      for(const a of RG.wallArtSlices(sw,sh,img.naturalWidth,img.naturalHeight))c.drawImage(img,a.sx,a.sy,a.sw,a.sh,a.x,a.y,a.w,a.h);
      w._ruin=cv;w._ruinSource=img;w._ruinW=sw;w._ruinH=sh;
    }
    let shadow=wallShadows.get(w._ruin);
    if(!shadow){shadow=document.createElement('canvas');shadow.width=w._ruin.width;shadow.height=w._ruin.height;const c=shadow.getContext('2d');c.drawImage(w._ruin,0,0);c.globalCompositeOperation='source-in';c.fillStyle='rgba(5,8,7,.55)';c.fillRect(0,0,shadow.width,shadow.height);wallShadows.set(w._ruin,shadow);}
    const x=RG.snapRenderPixel(s.x-sw/2),y=RG.snapRenderPixel(s.y-sh/2);
    ctx2.save();ctx2.imageSmoothingEnabled=false;RG.drawWorldImage(ctx2,shadow,x+3,y+6);RG.drawWorldImage(ctx2,w._ruin,x,y);ctx2.restore();return true;
  }
  RG.wallArtSlices=function(w,h,iw,ih){
    const horizontal=w>=h,long=horizontal?w:h,short=horizontal?h:w,sourceLong=horizontal?iw:ih,sourceShort=horizontal?ih:iw,scale=short/sourceShort;
    const cap=Math.min(sourceShort*.65,sourceLong*.24,long/(2*scale)),edge=cap*scale,mid=sourceLong-cap*2,result=[];
    const add=(src,len,dst)=>{if(len<=0)return;result.push(horizontal?{sx:src,sy:0,sw:len,sh:ih,x:dst,y:0,w:len*scale,h:short}:{sx:0,sy:src,sw:iw,sh:len,x:0,y:dst,w:short,h:len*scale});};
    add(0,cap,0);for(let x=edge;x<long-edge-.0001;){const len=Math.min(mid,(long-edge-x)/scale);add(cap,len,x);x+=len*scale;}add(sourceLong-cap,cap,long-edge);return result;
  };
  function drawCover(img, W, H) {
    if (!img) return false;
    const sc = Math.max(W / img.naturalWidth, H / img.naturalHeight);
    const dw = img.naturalWidth * sc, dh = img.naturalHeight * sc;
    ctx2.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh); return true;
  }
  const ctx2 = RG.ctx;
  const F = RG.fnt;

  const UI_ICON_CELLS={back:[0,0],previous:[1,0],next:[2,0],owned:[0,1],locked:[1,1],save:[2,1],reroll:[0,2],inspect:[1,2],stats:[2,2]};
  // 统一读取透明图标；旧缓存或缺图时保留同义几何图案。
  function drawUiIcon(id,x,y,size){
    const cell=UI_ICON_CELLS[id],img=artReady(id==='coin'?'uicoin':'uiaux');
    if(id!=='coin'&&!cell)return false;
    ctx2.save();ctx2.imageSmoothingEnabled=false;
    if(img){
      if(id==='coin')ctx2.drawImage(img,Math.round(x),Math.round(y),Math.round(size),Math.round(size));
      else{const sw=img.naturalWidth/3,sh=img.naturalHeight/3;ctx2.drawImage(img,cell[0]*sw,cell[1]*sh,sw,sh,Math.round(x),Math.round(y),Math.round(size),Math.round(size));}
    }else{
      ctx2.translate(Math.round(x),Math.round(y));ctx2.scale(size/32,size/32);ctx2.strokeStyle='#d1dce8';ctx2.fillStyle='#d1dce8';ctx2.lineWidth=3;ctx2.lineCap='square';
      if(id==='coin'){ctx2.fillStyle='#896025';ctx2.fillRect(8,3,16,26);ctx2.fillRect(3,8,26,16);ctx2.fillStyle='#dfb85e';ctx2.fillRect(9,5,14,22);ctx2.fillRect(5,9,22,14);ctx2.strokeStyle='#fff0ad';ctx2.lineWidth=2;ctx2.beginPath();ctx2.moveTo(16,10);ctx2.lineTo(22,16);ctx2.lineTo(16,22);ctx2.lineTo(10,16);ctx2.closePath();ctx2.stroke();}
      else if(['previous','next','back','owned'].includes(id)){ctx2.beginPath();if(id==='owned'){ctx2.strokeStyle='#82d4c6';ctx2.moveTo(5,16);ctx2.lineTo(12,23);ctx2.lineTo(27,8);}else if(id==='next'){ctx2.moveTo(11,6);ctx2.lineTo(22,16);ctx2.lineTo(11,26);}else{ctx2.moveTo(21,6);ctx2.lineTo(10,16);ctx2.lineTo(21,26);if(id==='back'){ctx2.moveTo(10,16);ctx2.lineTo(27,16);ctx2.lineTo(27,25);}}ctx2.stroke();}
      else if(id==='locked'){ctx2.strokeRect(10,4,12,15);ctx2.fillStyle='#859aae';ctx2.fillRect(7,14,18,14);ctx2.fillStyle='#d8bb7a';ctx2.fillRect(15,18,3,7);}
      else if(id==='save'){ctx2.strokeRect(4,5,24,23);ctx2.fillRect(8,8,16,5);ctx2.beginPath();ctx2.moveTo(16,14);ctx2.lineTo(16,24);ctx2.moveTo(11,19);ctx2.lineTo(16,24);ctx2.lineTo(21,19);ctx2.stroke();}
      else if(id==='reroll'){ctx2.strokeRect(5,5,22,22);for(const [px,py]of [[9,9],[15,15],[21,21]])ctx2.fillRect(px,py,3,3);}
      else if(id==='inspect'){ctx2.beginPath();ctx2.arc(13,13,9,0,Math.PI*2);ctx2.moveTo(20,20);ctx2.lineTo(29,29);ctx2.stroke();}
      else if(id==='stats'){for(let i=0;i<3;i++){ctx2.fillRect(4,7+i*9,24,2);ctx2.fillStyle='#d8bb7a';ctx2.fillRect(8+(i%2)*12,4+i*9,4,8);ctx2.fillStyle='#d1dce8';}}
    }ctx2.restore();if(RG.debugUiMetrics)(RG.uiIconBoxes||(RG.uiIconBoxes=[])).push({id,x,y,size,image:!!img});return true;
  }
  // 图标占固定列，数字独立排版；用真实字体墨迹计算垂直中线。
  function drawCurrency(value,r,options={}){
    ctx2.save();
    const label=typeof value==='string'?value:String(Math.max(0,Math.floor(value||0))),pad=options.padding??8,iconSize=options.iconSize||Math.min(22,r.h-4),gap=options.gap??6;
    let n=options.fontSize||14,metrics,limit=Math.max(1,r.w-pad*2-iconSize-gap);
    do{ctx2.font=(options.bold?'bold ':'')+n+'px "PixelCN", "Microsoft YaHei", sans-serif';metrics=ctx2.measureText(label);if(metrics.width<=limit||n<=8)break;n--;}while(true);
    const total=iconSize+gap+metrics.width,align=options.align||'center',ix=align==='spread'||align==='left'?r.x+pad:align==='right'?r.x+r.w-pad-total:r.x+(r.w-total)/2,tx=align==='spread'?r.x+r.w-pad-metrics.width:ix+iconSize+gap,cy=r.y+r.h/2;
    const ascent=metrics.actualBoundingBoxAscent??n*.8,descent=metrics.actualBoundingBoxDescent??n*.2,baseline=cy+(ascent-descent)/2;
    ctx2.save();drawUiIcon('coin',ix,cy-iconSize/2,iconSize);ctx2.font=(options.bold?'bold ':'')+n+'px "PixelCN", "Microsoft YaHei", sans-serif';ctx2.textAlign='left';ctx2.textBaseline='alphabetic';ctx2.fillStyle=options.color||'#d9b879';ctx2.fillText(label,tx,baseline);ctx2.restore();
    const box={...r,value:label,icon:{x:ix,y:cy-iconSize/2,w:iconSize,h:iconSize},number:{x:tx,y:baseline-ascent,w:metrics.width,h:ascent+descent},fontSize:n};if(RG.debugUiMetrics)(RG.currencyBoxes||(RG.currencyBoxes=[])).push(box);ctx2.restore();return box;
  }

  // 墙体预渲染:渐变/斜纹/描边是静态外观,每帧重建 gradient+clip+save/restore 很浪费;
  // 每面墙只画一次缓存成离屏画布,主循环只做一次 drawImage(按 DPR 渲染避免拉伸发虚)
  function wallSprite(w) {
    const ss = RG.renderDpr || Math.min(window.devicePixelRatio || 1, 2);
    if (w._spr && w._sprDpr === ss) return w._spr;
    w._sprDpr = ss;
    const off = document.createElement("canvas");
    off.width = Math.max(2, Math.ceil(w.w * ss));
    off.height = Math.max(2, Math.ceil(w.h * ss));
    const c = off.getContext("2d");
    c.scale(off.width / w.w, off.height / w.h);
    const temp = !!w.temp;
    const g = c.createLinearGradient(0, 0, 0, w.h);
    g.addColorStop(0, temp ? "#514687" : "#4a4080");
    g.addColorStop(1, temp ? "#37305f" : "#332c5c");
    c.fillStyle = g;
    c.fillRect(0, 0, w.w, w.h);
    c.strokeStyle = "rgba(163,150,255,0.14)"; c.lineWidth = 1;
    c.beginPath();
    for (let o = -w.h; o < w.w; o += 13) { c.moveTo(o, w.h); c.lineTo(o + w.h, 0); }
    c.stroke();
    c.strokeStyle = temp ? "rgba(129,140,248,0.95)" : "rgba(150,135,245,0.7)";
    c.lineWidth = 2;
    c.strokeRect(1, 1, w.w - 2, w.h - 2);
    c.strokeStyle = "rgba(200,190,255,0.5)"; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(2, 1.5); c.lineTo(w.w - 2, 1.5); c.stroke();
    w._spr = off;
    return off;
  }

  const MENU_DRAWERS = {
    menu: "drawMenu", maps:"drawMaps",loadout: "drawLoadout", growth: "drawGrowthHub", guide: "drawGuide", achievements: "drawAchievements",
    runshop:"drawRunShop",shop: "drawShop", settings: "drawSettings", saves:"drawNamedSaves", oaths: "drawOaths", rush: "drawRush", rushweapon: "drawRushWeapon"
  };
  const MENU_RECTS = {
    menu:"menuRects",loadout:"loadoutRects",growth:"growthRects",guide:"guideRects",shop:"shopRects",
    settings:"setRects",saves:"saveRects",oaths:"oathRects",rush:"rushRects",rushweapon:"rushWeaponRects",achievements:"achRects"
  };

  function drawScrollBar(state) {
    const s=RG.pageScroll&&RG.pageScroll[state];if(!s||s.max<=0)return;
    const safe=RG.safe||{top:0,bottom:0},vh=RG.H-safe.top-safe.bottom,thumb=Math.max(28,vh*vh/(vh+s.max));
    const y=safe.top+(vh-thumb)*(s.y/s.max);
    ctx2.fillStyle="rgba(255,255,255,.2)";ctx2.fillRect(RG.W-safe.right-5,y,3,thumb);
  }

  // 场景表现只读取现场；不推进玩法时钟、不消耗随机数、不写回首领或存档。
  RG.readEnvironment = function () {
    const theme=RG.realm?.active?'vault':RG.run?.mapId==='workshop'?'workshop':RG.run?.mapId==='legacy'?'legacy':'valley';
    let furnace=null;
    if(theme==='workshop'&&!RG.run?.rushMode)for(const e of RG.enemies||[])if(e.bossKind==='furnace'&&!e.dead&&!e.dying){furnace=e;break;}
    const heat=clamp((furnace?.heat||0)/100,0,1);
    const stage=!furnace?'none':furnace.workshopColdT>0?'cold':furnace.overOrigin?'locked':furnace.coolingT>0?'settling':heat>=.5?'heating':'idle';
    return {theme,furnace,heat,stage};
  };
  const groundChunks=new Map();
  const envHash=(x,y)=>{let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263);n=Math.imul(n^(n>>>13),1274126177);return(n^(n>>>16))>>>0;};
  function envCell(c,img,id,x,y,size){RG.drawWorldImage(c,img,(id%4)*128,Math.floor(id/4)*128,128,128,x,y,size,size);}
  function envAtlas(theme){return artReady(theme==='workshop'?'env_workshop':'env_valley');}
  function drawModularGround(W,H,env){
    if(env.theme==='workshop')return RG.scenery.ground(ctx2,W,H);
    if(RG.debugLegacyEnvironment||env.theme==='legacy')return false;
    const theme=env.theme==='workshop'?'workshop':'valley',stone=artReady('ground_'+theme),earth=artReady('ground_earth');if(!stone||!earth)return false;
    const size=512,{x:ox,y:oy}=RG.w2s(0,0);
    const minX=Math.floor(-ox/size),maxX=Math.floor((W-ox)/size),minY=Math.floor(-oy/size),maxY=Math.floor((H-oy)/size);
    ctx2.save();ctx2.imageSmoothingEnabled=false;
    for(let cy=minY;cy<=maxY;cy++)for(let cx=minX;cx<=maxX;cx++){
      const key=theme+':'+cx+':'+cy;let chunk=groundChunks.get(key);
      if(!chunk){
        chunk=document.createElement('canvas');chunk.width=chunk.height=size;const g=chunk.getContext('2d');g.imageSmoothingEnabled=false;
        const surface=(c,img)=>{c.save();c.translate((cx&1)?size:0,(cy&1)?size:0);c.scale((cx&1)?-1:1,(cy&1)?-1:1);c.drawImage(img,0,0,size,size);c.restore();};
        surface(g,earth);
        const paving=document.createElement('canvas');paving.width=paving.height=size;const p=paving.getContext('2d');p.imageSmoothingEnabled=false;surface(p,stone);
        const mask=document.createElement('canvas');mask.width=mask.height=128;const m=mask.getContext('2d'),pixels=m.createImageData(128,128);
        for(let y=0;y<128;y++)for(let x=0;x<128;x++){
          const wx=cx*size+x*4,wy=cy*size+y*4;
          const weave=Math.sin(wx*.018+Math.sin(wy*.013)*2)*19+Math.sin(wy*.025)*12;
          const d=Math.min(Math.abs(wx-Math.sin(wy/530)*190)-(theme==='workshop'?165:105),Math.abs(wy-Math.sin(wx/610)*135)-(theme==='workshop'?125:85));
          const alpha=Math.round(clamp(.5-(d+weave)/65,0,1)*10)/10;pixels.data[(y*128+x)*4+3]=Math.round(alpha*255);
        }
        m.putImageData(pixels,0,0);p.globalCompositeOperation='destination-in';p.drawImage(mask,0,0,size,size);g.drawImage(paving,0,0);
        g.fillStyle=theme==='workshop'?'rgba(9,12,10,.20)':'rgba(9,16,12,.24)';g.fillRect(0,0,size,size);
        groundChunks.set(key,chunk);if(groundChunks.size>24)groundChunks.delete(groundChunks.keys().next().value);
      }
      RG.drawWorldImage(ctx2,chunk,ox+cx*size,oy+cy*size);
    }
    if(env.theme==='vault'){ctx2.fillStyle='rgba(13,10,27,.28)';ctx2.fillRect(0,0,W,H);}
    const detail=artReady('env_detail');
    if(detail){ctx2.globalAlpha=theme==='workshop'?.62:.48;const step=384;
      for(let gy=Math.floor((RG.cam.y-H/2)/step)-1;gy<=Math.ceil((RG.cam.y+H/2)/step);gy++)for(let gx=Math.floor((RG.cam.x-W/2)/step)-1;gx<=Math.ceil((RG.cam.x+W/2)/step);gx++){
        const n=envHash(gx,gy);if(n%3===0)continue;const p=RG.w2s(gx*step+80+(n>>>6)%160,gy*step+80+(n>>>14)%160);if(p.x<-128||p.x>W+128||p.y<-128||p.y>H+128)continue;
        envCell(ctx2,detail,theme==='workshop'?12+n%3:4+n%3,p.x-64,p.y-64,128);
      }
    }
    ctx2.restore();return true;
  }
  function drawStele(st){
    const s=RG.w2s(st.x,st.y),x=RG.snapRenderPixel(s.x),y=RG.snapRenderPixel(s.y);
    if(x < -80||x > RG.W+80||y < -40||y > RG.H+140)return;
    const base=artReady('stele_base'),idle=artReady('stele_idle');
    ctx2.save();ctx2.imageSmoothingEnabled=false;
    if(base)RG.drawWorldImage(ctx2,base,x-40,y-23,80,52);
    else{ctx2.fillStyle='#4a4661';ctx2.fillRect(x-24,y-5,48,16);}
    if(idle){
      // bob由战斗更新推进；暂停不动。各格足点固定，3.2秒一轮只呼吸符文光。
      const phase=((st.bob||0)*.625%4+4)%4,frame=Math.floor(phase),mix=phase-frame,cell=idle.naturalWidth/2;
      const paint=f=>RG.drawWorldImage(ctx2,idle,(f%2)*cell,Math.floor(f/2)*cell,cell,cell,x-56,y-107,112,112);
      paint(frame);ctx2.globalAlpha=mix;paint((frame+1)%4);
    }else{
      // 底座和碑身分别回退，任意一张缺失仍能认出交互对象。
      ctx2.fillStyle='#4a4661';ctx2.fillRect(x-12,y-54,24,52);
      ctx2.beginPath();ctx2.arc(x,y-54,12,0,TAU);ctx2.fill();
      ctx2.globalAlpha=.5+.3*Math.sin((st.bob||0)*3);ctx2.fillStyle='#a78bfa';
      ctx2.fillRect(x-3,y-49,6,25);
    }
    ctx2.restore();
  }
  function drawWallFootDecor(env,front=false){
    if(env.theme==='workshop')return;
    if(RG.debugLegacyEnvironment||env.theme==='legacy')return;
    const img=artReady('env_detail');if(!img)return;
    const low=RG.fxQuality==='low'||RG.fxAutoReduced,budget=low?20:48;let count=0;
    ctx2.save();ctx2.imageSmoothingEnabled=false;ctx2.globalAlpha=front?.88:.72;
    for(const w of RG.walls||[]){
      if(w.temp)continue;const horizontal=w.w>=w.h,seed=envHash(w.x,w.y),length=horizontal?w.w:w.h,n=Math.max(1,Math.min(6,Math.ceil(length/90)));
      for(let j=0;j<n;j++){
        const t=(j+.4+(seed%3)*.07)/n,side=(seed+j)%2?1:-1;
        const x=horizontal?w.x+w.w*t:w.x+(side>0?w.w+6:-6),y=horizontal?w.y+(side>0?w.h+5:-5):w.y+w.h*t;
        if((RG.keyItems||[]).some(k=>Math.hypot(k.x-x,k.y-y)<95)||RG.portal&&Math.hypot(RG.portal.x-x,RG.portal.y-y)<120)continue;
        const p=RG.w2s(x,y);if(p.x<-150||p.x>RG.W+150||p.y<-150||p.y>RG.H+150)continue;
        const workshop=env.theme==='workshop',id=front?(workshop?12+(seed+j)%4:(seed+j)%4):(workshop?14:4+(seed+j)%4),size=front?96:128;
        envCell(ctx2,img,id,p.x-size/2,p.y-size/2-(front?14:0),size);
        if(++count>=budget){ctx2.restore();return;}
      }
    }
    ctx2.restore();
  }
  function drawFurnaceMaterial(e,s,env){
    if(env.furnace!==e||RG.debugLegacyEnvironment)return;
    const cold=env.stage==='cold',settling=env.stage==='settling',locked=env.stage==='locked',r=Math.round(e.r*1.5);
    ctx2.save();ctx2.imageSmoothingEnabled=false;
    // 离散炉体散热片，只占本体两侧；升温不用危险范围轮廓，锁点仍用原240半径预警。
    const col=cold?'#6fbbc7':settling?'#46616b':locked?'#f49c54':env.stage==='heating'?'#9b7449':'#5c5146';
    for(const sign of [-1,1])for(let i=0;i<4;i++){
      const x=Math.round(s.x+sign*(r+5)-(sign<0?10:0)),y=Math.round(s.y-15+i*10);
      ctx2.fillStyle='#131c24';ctx2.fillRect(x-2,y-2,14,8);ctx2.fillStyle=col;ctx2.fillRect(x,y,10,3);
    }
    if(cold){
      const img=envAtlas('workshop');if(img&&RG.fxQuality!=='low'&&!RG.fxAutoReduced){
        ctx2.globalAlpha=.22;const frame=Math.floor((2.5-e.workshopColdT)*6)%3;
        for(let i=0;i<2;i++)envCell(ctx2,img,15,s.x+(i?1:-1)*(r+16)-32,s.y-44-frame*4,64);
      }
    }
    ctx2.restore();
  }
  RG.environmentCacheInfo=()=>({chunks:groundChunks.size,maxChunks:24,bytes:groundChunks.size*512*512*4});

  RG.draw = function () {
    if(RG.debugUiMetrics){RG.currencyBoxes=[];RG.uiIconBoxes=[];}
    // 结算新增分类后，离开页面立即清理导航与测量数据，避免带入战斗HUD。
    if(RG.uiNavState!==RG.state){RG.uiNav=[];RG.uiTextBoxes=[];RG.resultCards=[];}
    NOW = performance.now();
    const shakeMul=(RG.fxQuality==='low'||RG.fxAutoReduced) ? .45 : RG.fxQuality==='medium' ? .75 : 1;
    const shake=(RG.cam?.shake||0)*shakeMul;
    if(!((RG.hurtFx?.freeze||0)>0||(RG.deathFx?.freeze||0)>0)){shakeX=shake?(Math.random()-.5)*shake:0;shakeY=shake?(Math.random()-.5)*shake:0;}
    const W = RG.W, H = RG.H;
    ctx2.clearRect(0, 0, W, H);
    ctx2.fillStyle = "#0b0d14"; ctx2.fillRect(0, 0, W, H);
    const environment=RG.readEnvironment(),modularGround=drawModularGround(W,H,environment);
    // 独立地表组件未加载时保留旧地板，再缺图走原几何底色。
    const mainFloorArt = artReady("floor"), realmFloorArt = artReady("realmfloor");
    const floorArt = RG.realm && RG.realm.active
      ? (realmFloorArt || mainFloorArt)
      : (mainFloorArt || realmFloorArt);
    if (floorArt&&!modularGround) {
      const tile = RG.mobile ? 768 : 896;
      const origin=RG.w2s(0,0),fx = ((origin.x % tile) + tile) % tile - tile;
      const fy = ((origin.y % tile) + tile) % tile - tile;
      ctx2.save(); ctx2.imageSmoothingEnabled=false; ctx2.globalAlpha = RG.realm && RG.realm.active ? 0.34 : 0.58;
      for (let x = fx; x < W + tile; x += tile) for (let y = fy; y < H + tile; y += tile) RG.drawWorldImage(ctx2,floorArt, x, y, tile, tile);
      ctx2.restore();
      ctx2.fillStyle = RG.realm && RG.realm.active ? "rgba(5,7,14,0.30)" : "rgba(5,7,14,0.18)"; ctx2.fillRect(0, 0, W, H);
    }
    if (!modularGround&&RG.realm && RG.realm.active) { ctx2.fillStyle = "rgba(90,40,180,0.10)"; ctx2.fillRect(0, 0, W, H); }
    const gs = 64, ox = (-RG.cam.x + W / 2+shakeX) % gs, oy = (-RG.cam.y + H / 2+shakeY) % gs;
    ctx2.strokeStyle = modularGround?"rgba(120,110,200,0)":floorArt ? "rgba(120,110,200,0.018)" : "rgba(120,110,200,0.07)"; ctx2.lineWidth = 1;
    ctx2.beginPath();
    for (let x = ox; x < W; x += gs) { ctx2.moveTo(x, 0); ctx2.lineTo(x, H); }
    for (let y = oy; y < H; y += gs) { ctx2.moveTo(0, y); ctx2.lineTo(W, y); }
    ctx2.stroke();
    // 地表装饰先画完；草丛不能盖住墙面、石碑与战斗实体。
    drawWallFootDecor(environment);
    drawWallFootDecor(environment,true);
    // 竞技场边界(不规则多边形)
    if (RG.boundary && RG.boundary.pts) {
      ctx2.strokeStyle = "rgba(124,108,240,0.3)"; ctx2.lineWidth = 3;
      ctx2.setLineDash([14, 10]);
      ctx2.beginPath();
      RG.boundary.pts.forEach((p, i) => {
        const s = RG.w2s(p.x, p.y);
        if (i === 0) ctx2.moveTo(s.x, s.y); else ctx2.lineTo(s.x, s.y);
      });
      ctx2.closePath(); ctx2.stroke();
      ctx2.setLineDash([]);
    }
    // 钥匙
    for (const k of RG.keyItems) {
      const s = RG.w2s(k.x, k.y + Math.sin(k.bob) * 5);
      ctx2.save(); ctx2.translate(s.x, s.y); ctx2.rotate(Math.sin(k.bob * 0.7) * 0.3);
      ctx2.fillStyle = "#ffd166";
      ctx2.beginPath(); ctx2.arc(0, -8, 7, 0, TAU); ctx2.fill();
      ctx2.fillStyle = "#0b0d14"; ctx2.beginPath(); ctx2.arc(0, -8, 3, 0, TAU); ctx2.fill();
      ctx2.fillStyle = "#ffd166"; ctx2.fillRect(-2.5, -4, 5, 18);
      ctx2.fillRect(2, 8, 7, 4); ctx2.fillRect(2, 14, 5, 4);
      ctx2.restore();
      ctx2.strokeStyle = "rgba(255,209,102,0.4)"; ctx2.lineWidth = 1.5;
      ctx2.beginPath(); ctx2.arc(s.x, s.y, 20 + Math.sin(k.bob * 2) * 3, 0, TAU); ctx2.stroke();
    }
    // 秘境传送门
    if (RG.portal) {
      const s = RG.w2s(RG.portal.x, RG.portal.y), sp = RG.portal.swirl;
      const sealed=!RG.portal.exit&&!!RG.realmEntrySeal();
      for (let i = 0; i < 3; i++) {
        ctx2.strokeStyle = (sealed?["#d97706", "#b45309", "#ffd166"]:["#c084fc", "#8b5cf6", "#e9d5ff"])[i];
        ctx2.lineWidth = 3.5;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, RG.portal.r - i * 6, sp + i * 2.1, sp + i * 2.1 + 4.2); ctx2.stroke();
      }
      ctx2.fillStyle = sealed?"rgba(217,119,6,0.2)":"rgba(192,132,252,0.25)";
      ctx2.beginPath(); ctx2.arc(s.x, s.y, RG.portal.r + 10, 0, TAU); ctx2.fill();
      ctx2.fillStyle = sealed?"#ffd166":"#e9d5ff"; ctx2.font = F(12, true); ctx2.textAlign = "center";
      ctx2.fillText(RG.realmPortalLabel(), s.x, s.y - RG.portal.r - 12);
    }

    const menuDrawer = MENU_DRAWERS[RG.state];
    if (menuDrawer) {
      RG.pageScroll[RG.state]={y:0,max:0};
      RG[menuDrawer]();
      return;
    }
    const P = RG.P;
    if (!P) {   // 状态异常时安全回主菜单，绝不让空玩家对象拖垮整个渲染循环
      RG.state = "menu";
      RG.drawMenu();
      return;
    }

    // 废墟墙体；临时壁垒沿用琥珀色提示，碰撞体不变。
    for (const w of RG.walls) {
      if(w.meadowTree)continue;
      const s = RG.w2s(w.x + w.w / 2, w.y + w.h / 2);
      const sw = w.w, sh = w.h;
      if (s.x + sw / 2 < -40 || s.x - sw / 2 > W + 40 || s.y + sh / 2 < -40 || s.y - sh / 2 > H + 40) continue;
      const blink = w.temp && w.ttl < 2.5 && Math.floor(w.ttl * 6) % 2 === 0;
      ctx2.globalAlpha = blink ? 0.35 : 1;
      // 独立横纵遗址素材优先；缺图时使用原预渲染几何墙体。
      if (!drawWallArt(w, s, sw, sh)) RG.drawWorldImage(ctx2,wallSprite(w),s.x - sw / 2,s.y - sh / 2,sw,sh);
      ctx2.globalAlpha = 1;
    }
    RG.scenery.beginDepth();
    if(environment.theme==='workshop')RG.scenery.trees(ctx2);
    for(const st of RG.statues||[])RG.scenery.queue(st.y+20,()=>drawStele(st),'stele');
    const drawGroundHazards=()=>{
    // 陷阱与玩家熔岩区
    for (const h of RG.hazards) {
      const s = RG.w2s(h.x, h.y);
      if(h.friendlyLava){
        ctx2.fillStyle="rgba(249,115,22,.30)";ctx2.beginPath();ctx2.arc(s.x,s.y,h.r,0,TAU);ctx2.fill();
        ctx2.strokeStyle="#fb923c";ctx2.lineWidth=3;ctx2.beginPath();ctx2.arc(s.x,s.y,h.r*(.88+.06*Math.sin(NOW/100)),0,TAU);ctx2.stroke();
      } else if (h.phase === "warn") {
        const pulse = 0.5 + 0.5 * Math.sin(NOW / 90);
        ctx2.save();ctx2.globalAlpha=.5+.4*pulse;ctx2.strokeStyle='#ff5470';ctx2.lineWidth=2;ctx2.setLineDash([14,10]);
        ctx2.beginPath();ctx2.arc(s.x,s.y,h.r,0,TAU);ctx2.stroke();ctx2.restore();
        ctx2.fillStyle = "rgba(255,84,112,0.08)";
        ctx2.beginPath(); ctx2.arc(s.x, s.y, h.r, 0, TAU); ctx2.fill();
      } else {
        ctx2.fillStyle = "rgba(251,146,60,0.25)";
        ctx2.beginPath(); ctx2.arc(s.x, s.y, h.r, 0, TAU); ctx2.fill();
        ctx2.strokeStyle = "#fb923c"; ctx2.lineWidth = 2;
        for (let i = 0; i < 8; i++) {
          const a = i / 8 * TAU + 0.4;
          ctx2.beginPath();
          ctx2.moveTo(s.x + Math.cos(a) * h.r * 0.35, s.y + Math.sin(a) * h.r * 0.35);
          ctx2.lineTo(s.x + Math.cos(a) * h.r * 0.85, s.y + Math.sin(a) * h.r * 0.85);
          ctx2.stroke();
        }
      }
    }
    };
    if(environment.theme!=='workshop')drawGroundHazards();
    // 经验宝石(0 普通/1 精英·巨像紫/2 BOSS 红)
    for (const g of RG.gems) {
      RG.scenery.queue(g.y,()=>{
      if((g.delay||0)>0)return;
      const s = RG.w2s(g.x, g.y);
      if (s.x < -20 || s.x > W + 20 || s.y < -20 || s.y > H + 20) return;
      const gc = g.tier === 2 ? "#ff4d6d" : g.tier === 1 ? "#a78bfa" : "#2dd4bf";
      const sz = g.tier === 2 ? 9 : g.tier === 1 ? 6 : 4;
      ctx2.globalAlpha = 0.85;
      ctx2.fillStyle = gc;
      ctx2.beginPath();
      ctx2.moveTo(s.x, s.y - sz); ctx2.lineTo(s.x + sz * 0.9, s.y + sz * 0.7); ctx2.lineTo(s.x - sz * 0.9, s.y + sz * 0.7);
      ctx2.closePath(); ctx2.fill();
      if (g.tier === 2) {
        ctx2.strokeStyle = "rgba(255,77,109,0.5)"; ctx2.lineWidth = 1.5;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, sz + 3 + Math.sin(NOW / 150 + g.x) * 1.5, 0, TAU); ctx2.stroke();
      }
      ctx2.globalAlpha = 1;

      },'gem');
    }
    // 治疗球
    for (const o of RG.orbs) {
      RG.scenery.queue(o.y,()=>{
      const s = RG.w2s(o.x, o.y);
      ctx2.fillStyle = "#4ade80";
      ctx2.beginPath(); ctx2.arc(s.x, s.y, o.r, 0, TAU); ctx2.fill();
      ctx2.fillStyle = "#0b0d14"; ctx2.fillRect(s.x - 5, s.y - 1.5, 10, 3); ctx2.fillRect(s.x - 1.5, s.y - 5, 3, 10);

      },'orb');
    }
    // 玩家
    RG.scenery.queue(P.y+P.r,()=>{
      const s = RG.w2s(P.x, P.y);
      const blink = P.iTimer > 0 && Math.floor(P.iTimer * 14) % 2 === 0;
      if (!blink) {
        ctx2.fillStyle = "rgba(0,0,0,0.30)"; ctx2.beginPath(); ctx2.ellipse(s.x, s.y + P.r * 0.8, P.r * 1.28, P.r * 0.48, 0, 0, TAU); ctx2.fill();
        const painted = drawPlayerArt(s);
        if (!painted) {
          ctx2.fillStyle = "#f5f3ff";
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r, 0, TAU); ctx2.fill();
          ctx2.strokeStyle = P.slowT > 0 ? "#7dd3fc" : "#7c6cf0"; ctx2.lineWidth = 2.5;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r, 0, TAU); ctx2.stroke();
          ctx2.fillStyle = P.slowT > 0 ? "#7dd3fc" : "#7c6cf0";
          ctx2.beginPath(); ctx2.arc(s.x + Math.cos(P.face) * P.r * 0.55, s.y + Math.sin(P.face) * P.r * 0.55, 4.5, 0, TAU); ctx2.fill();
        }
        const pixelMarks=drawElementMarks(P,s,Math.round(P.r*4.15),true);
        if (P.slowT > 0 && !pixelMarks) {
          ctx2.strokeStyle = "rgba(125,211,252,0.75)"; ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 3, 0, TAU); ctx2.stroke();
        }
        if (P.iTimer > 0 && !blink) {
          // P2 受伤无敌表现:稳定虚线圈,闪烁帧也看得出保护还在
          ctx2.strokeStyle = "rgba(245,243,255,0.5)"; ctx2.lineWidth = 1.5;
          ctx2.setLineDash([6, 5]);
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 7, NOW / 300, NOW / 300 + TAU); ctx2.stroke();
          ctx2.setLineDash([]);
        }
        if (P.shield > 0) {
          ctx2.strokeStyle = "rgba(56,189,248,0.7)"; ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 6, 0, TAU); ctx2.stroke();
        }
        if (P.activeGuard > 0) {
          ctx2.strokeStyle = "rgba(56,189,248,0.9)"; ctx2.lineWidth = 3;
          for (let i = 0; i < P.activeGuard; i++) {
            const a = NOW / 650 + i / P.activeGuard * TAU;
            ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 10 + i * 1.5, a, a + 0.85); ctx2.stroke();
          }
        }
        if (P.overdriveT > 0) {
          const pulse = 2 + Math.sin(NOW / 70) * 2;
          ctx2.strokeStyle = "rgba(251,191,36,0.85)"; ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 8 + pulse, 0, TAU); ctx2.stroke();
        }
        if (RG.passiveValue(P,"stance") && P.stillT > 1) {
          ctx2.strokeStyle = "rgba(250,204,21,0.5)"; ctx2.lineWidth = 1.5;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 10, 0, TAU); ctx2.stroke();
        }
        if (RG.auraT > 0) {
          ctx2.strokeStyle = "rgba(255,209,102," + (0.22 + 0.12 * Math.sin(NOW / 110)).toFixed(3) + ")";
          ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, 280, 0, TAU); ctx2.stroke();
          const ag = ctx2.createRadialGradient(s.x, s.y, 120, s.x, s.y, 280);
          ag.addColorStop(0, "rgba(255,209,102,0.02)");
          ag.addColorStop(1, "rgba(255,209,102,0.08)");
          ctx2.fillStyle = ag;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, 280, 0, TAU); ctx2.fill();
        }
        if (P.pdBuff > 0) {
          // 完美闪避增伤光环
          ctx2.strokeStyle = "rgba(196,181,253,0.85)"; ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, P.r + 8 + Math.sin(NOW / 90) * 2, 0, TAU); ctx2.stroke();
        }

      }
      if (P.weapons.orbit) {
        const st = RG.weaponStat("orbit",P.weapons.orbit,P.evolved.orbit);
        const osz = st.size || 1;   // v8.23:刃体体积随级
        for (let i = 0; i < st.blades; i++) {
          const a = P.orbitAngle + i / st.blades * TAU;
          const bx = s.x + Math.cos(a) * st.radius, by = s.y + Math.sin(a) * st.radius;
          ctx2.save(); ctx2.translate(bx, by); ctx2.rotate(a + Math.PI / 2); ctx2.scale(osz, osz);
          ctx2.fillStyle = "#ffd166";
          ctx2.beginPath(); ctx2.moveTo(0, -9); ctx2.lineTo(5, 7); ctx2.lineTo(-5, 7); ctx2.closePath(); ctx2.fill();
          ctx2.restore();
        }
      }
    },'player');
    // 敌人
    // 友军渲染:幻影分身(紫) / 忠诚残兵(绿)
    for (const al of RG.phantoms || []) {
      RG.scenery.queue(al.y+13,()=>{
      const ps = RG.w2s(al.x, al.y);
      if (ps.x < -40 || ps.x > W + 40 || ps.y < -40 || ps.y > H + 40) return;
      ctx2.globalAlpha = Math.min(1, al.t / 8) * 0.7 + 0.25;
      ctx2.fillStyle = "#7c6cf0"; ctx2.beginPath(); ctx2.arc(ps.x, ps.y, 13, 0, TAU); ctx2.fill();
      ctx2.strokeStyle = "#fff"; ctx2.lineWidth = 1.5; ctx2.beginPath(); ctx2.arc(ps.x, ps.y, 13, 0, TAU); ctx2.stroke();
      ctx2.globalAlpha = 1;

      },'phantom');
    }
    for (const al of RG.allies || []) {
      RG.scenery.queue(al.y+al.r,()=>{
      const as = RG.w2s(al.x, al.y);
      if (as.x < -40 || as.x > W + 40 || as.y < -40 || as.y > H + 40) return;
      if(al.converted){
        ctx2.globalAlpha=.28;ctx2.fillStyle="#22c55e";ctx2.beginPath();ctx2.arc(as.x,as.y,al.r+8,0,TAU);ctx2.fill();ctx2.globalAlpha=1;
        const painted=al.boss?drawBossAnim(al,as,al.r*3.2):drawMobAnim(al,as,al.r*4);
        if(!painted)drawEnemyShape(al,as,"#4ade80",al.face||0);
        ctx2.fillStyle="#16a34a";ctx2.fillRect(as.x-9,as.y-al.r-21,18,14);ctx2.fillStyle="#f0fdf4";ctx2.textAlign="center";ctx2.font=F(10,true);ctx2.fillText("友",as.x,as.y-al.r-10);
      }
      else {ctx2.fillStyle = "rgba(34,197,94,0.85)"; ctx2.beginPath(); ctx2.arc(as.x, as.y, al.r, 0, TAU); ctx2.fill();}
      ctx2.strokeStyle = "#bbf7d0"; ctx2.lineWidth = 2; ctx2.beginPath(); ctx2.arc(as.x, as.y, al.r, 0, TAU); ctx2.stroke();
      if(al.hp!=null){ctx2.fillStyle="rgba(0,0,0,.6)";ctx2.fillRect(as.x-al.r,as.y-al.r-8,al.r*2,4);ctx2.fillStyle="#4ade80";ctx2.fillRect(as.x-al.r,as.y-al.r-8,al.r*2*clamp(al.hp/al.maxhp,0,1),4);}

      },'ally');
    }
    for(const d of RG.decoys||[]){
      RG.scenery.queue(d.y+d.r,()=>{
      const ds=RG.w2s(d.x,d.y),pulse=.75+.2*Math.sin(NOW/90);ctx2.globalAlpha=clamp(d.t,0,1);
      ctx2.fillStyle="#fbbf24";ctx2.fillRect(ds.x-12,ds.y-16,24,32);ctx2.fillStyle="#3f2a16";ctx2.fillRect(ds.x-6,ds.y-10,4,4);ctx2.fillRect(ds.x+2,ds.y-10,4,4);
      ctx2.strokeStyle=`rgba(251,191,36,${pulse})`;ctx2.lineWidth=2;ctx2.beginPath();ctx2.arc(ds.x,ds.y,d.r+6,0,TAU);ctx2.stroke();
      ctx2.fillStyle="rgba(0,0,0,.6)";ctx2.fillRect(ds.x-20,ds.y-28,40,5);ctx2.fillStyle="#fbbf24";ctx2.fillRect(ds.x-20,ds.y-28,40*clamp(d.hp/d.maxhp,0,1),5);ctx2.globalAlpha=1;

      },'decoy');
    }
    // 腐蚀瓶酸液地面
    for (const v of RG.vials || []) {
      const vs = RG.w2s(v.x, v.y);
      ctx2.globalAlpha = v.arm > 0 ? 0.3 : Math.min(0.45, v.t / 4 + 0.15);
      ctx2.fillStyle = v.poisonTrail ? "#65a30d" : "#a3e635"; ctx2.beginPath(); ctx2.arc(vs.x, vs.y, v.r, 0, TAU); ctx2.fill();
      ctx2.strokeStyle = "rgba(255,255,255,0.4)"; ctx2.lineWidth = 1.5; ctx2.stroke();
      ctx2.globalAlpha = 1;
    }
    for (const f of RG.healFields || []) {
      const fs = RG.w2s(f.x,f.y), pulse=0.12+0.05*Math.sin(NOW/180);
      ctx2.globalAlpha=clamp(f.t/1.2,0,1);
      ctx2.fillStyle=`rgba(74,222,128,${pulse})`;ctx2.beginPath();ctx2.arc(fs.x,fs.y,f.r,0,TAU);ctx2.fill();
      ctx2.strokeStyle="#86efac";ctx2.lineWidth=2;ctx2.setLineDash([8,6]);ctx2.stroke();ctx2.setLineDash([]);ctx2.globalAlpha=1;
    }
    for (const f of RG.autoFx || []) if (f.type === "thunder") {
      const s=RG.w2s(f.x,f.y);ctx2.globalAlpha=clamp(f.t/f.max,0,1);ctx2.strokeStyle='#fde047';ctx2.lineWidth=3;
      ctx2.beginPath();ctx2.moveTo(s.x+10,s.y-100);ctx2.lineTo(s.x-7,s.y-62);ctx2.lineTo(s.x+6,s.y-62);ctx2.lineTo(s.x-4,s.y-24);ctx2.lineTo(s.x+4,s.y-24);ctx2.lineTo(s.x,s.y);ctx2.stroke();ctx2.globalAlpha=1;
    } else if(f.active==='collapse'){
      const s=RG.w2s(f.x,f.y),well=f.type==='collapseWell',fade=clamp(f.t/f.max,0,1);ctx2.globalAlpha=well?.14:.08;ctx2.fillStyle=well?'#a78bfa':'#fde047';ctx2.beginPath();ctx2.arc(s.x,s.y,f.r,0,TAU);ctx2.fill();
      ctx2.globalAlpha=.7;ctx2.strokeStyle=well?'#c4b5fd':'#fde047';ctx2.lineWidth=2;ctx2.setLineDash(well?[]:[8,6]);ctx2.beginPath();ctx2.arc(s.x,s.y,f.r,0,TAU);ctx2.stroke();ctx2.setLineDash([]);
      ctx2.globalAlpha=.8;ctx2.beginPath();ctx2.arc(s.x,s.y,well?24+Math.sin(NOW/170)*6:f.r*(1-fade),0,TAU);ctx2.stroke();ctx2.globalAlpha=1;
    } else if (f.type === "meteor") {
      const ms=RG.w2s(f.x,f.y), q=clamp(f.t/f.max,0,1);
      ctx2.globalAlpha=0.45+0.35*Math.sin(NOW/55);ctx2.strokeStyle="#fb923c";ctx2.lineWidth=3;ctx2.setLineDash([8,6]);
      ctx2.beginPath();ctx2.arc(ms.x,ms.y,f.r*(1-q*0.35),0,TAU);ctx2.stroke();ctx2.setLineDash([]);
      ctx2.globalAlpha=1;ctx2.fillStyle="#fde68a";ctx2.fillRect(ms.x-6,ms.y-70*q-6,12,12);
    }
    // 领域(v8.5 补上历史缺失的地面渲染):禁疗红 / 减速蓝 / 毒气绿(带气泡)
    if(P.aegisEvoT>0&&P.activeGuard>0&&RG.aegisCast(P)?.id==='void'){
      const s=RG.w2s(P.x,P.y),r=RG.aegisCast(P).radius;ctx2.fillStyle='#38bdf8';ctx2.globalAlpha=.07;ctx2.beginPath();ctx2.arc(s.x,s.y,r,0,TAU);ctx2.fill();ctx2.globalAlpha=.7;ctx2.strokeStyle='#67e8f9';ctx2.lineWidth=2;ctx2.beginPath();ctx2.arc(s.x,s.y,r,0,TAU);ctx2.stroke();ctx2.globalAlpha=1;
    }
    for (const dm of RG.domains || []) {
      const ds = RG.w2s(dm.x, dm.y);
      const col = dm.type === "healnull" ? "255,84,112" : dm.type === "poison" ? "163,230,53" : "125,211,252";
      const fade = clamp(dm.t / 1.2, 0, 1);
      ctx2.globalAlpha = dm.warn>0?.035:(0.10 + 0.06 * Math.sin(NOW / 300)) * fade;
      ctx2.fillStyle = "rgb(" + col + ")";
      ctx2.beginPath(); ctx2.arc(ds.x, ds.y, dm.r, 0, TAU); ctx2.fill();
      ctx2.globalAlpha = 0.75 * fade;
      ctx2.strokeStyle = "rgba(" + col + ",0.8)"; ctx2.lineWidth = 2;
      ctx2.setLineDash(dm.warn>0?[6,6]:[12,9]);
      ctx2.beginPath(); ctx2.arc(ds.x, ds.y, dm.r, NOW / 900, NOW / 900 + TAU); ctx2.stroke();
      ctx2.setLineDash([]);
      if (dm.type === "poison" && !(dm.warn>0)) {
        ctx2.fillStyle = "rgba(163,230,53,0.7)";
        for (let i = 0; i < 5; i++) {
          const ba = NOW / 400 + i * 1.26, br = (dm.r * 0.75) * (0.4 + 0.5 * ((NOW / 700 + i * 0.37) % 1));
          ctx2.beginPath(); ctx2.arc(ds.x + Math.cos(ba) * br, ds.y + Math.sin(ba * 1.7) * br, 3, 0, TAU); ctx2.fill();
        }
      }
      ctx2.globalAlpha = 1;
    }
    // 工坊危险范围直接画完整几何，低特效也保留，不用扩张动画冒充有效半径。
    for(const e of RG.enemies)if(!e.dead&&!e.dying){
      for(const r of e.workshopRunes||[]){
        const s=RG.w2s(r.x,r.y);ctx2.save();ctx2.strokeStyle='#67e8f9';ctx2.fillStyle='rgba(103,232,249,.08)';ctx2.lineWidth=2;ctx2.beginPath();ctx2.arc(s.x,s.y,r.r,0,TAU);ctx2.fill();ctx2.stroke();
        ctx2.fillStyle='rgba(103,232,249,.25)';ctx2.beginPath();ctx2.moveTo(s.x,s.y-20);ctx2.lineTo(s.x+20,s.y);ctx2.lineTo(s.x,s.y+20);ctx2.lineTo(s.x-20,s.y);ctx2.closePath();ctx2.fill();ctx2.stroke();
        if(r.hold>0){ctx2.strokeStyle='#fef3c7';ctx2.lineWidth=4;ctx2.beginPath();ctx2.arc(s.x,s.y,r.r+5,-Math.PI/2,-Math.PI/2+TAU*r.hold/1.2);ctx2.stroke();}
        ctx2.font='12px ui-monospace';ctx2.textAlign='center';ctx2.fillStyle='#a7f3d0';ctx2.fillText('净化',s.x,s.y+r.r+18);ctx2.restore();
      }
      for(const v of e.workshopValves||[]){
        const s=RG.w2s(v.x,v.y);ctx2.save();ctx2.strokeStyle=v.active?'#67e8f9':'#64748b';ctx2.fillStyle=v.active?'rgba(103,232,249,.08)':'rgba(100,116,139,.04)';ctx2.lineWidth=2;ctx2.beginPath();ctx2.arc(s.x,s.y,v.r,0,TAU);ctx2.fill();ctx2.stroke();
        ctx2.fillStyle=v.active?'#a7f3d0':'#64748b';ctx2.strokeRect(s.x-14,s.y-14,28,28);ctx2.fillRect(s.x-24,s.y-4,10,8);ctx2.fillRect(s.x+14,s.y-4,10,8);ctx2.fillRect(s.x-4,s.y-24,8,10);ctx2.fillRect(s.x-4,s.y+14,8,10);
        if(v.hold>0){ctx2.strokeStyle='#fef3c7';ctx2.lineWidth=4;ctx2.beginPath();ctx2.arc(s.x,s.y,v.r+5,-Math.PI/2,-Math.PI/2+TAU*v.hold/1.2);ctx2.stroke();}
        ctx2.font='12px ui-monospace';ctx2.textAlign='center';ctx2.fillStyle=v.active?'#a7f3d0':'#94a3b8';ctx2.fillText(v.active?'急冷 · 站圈1.2秒':e.valveCooldown>0?'冷却 '+Math.ceil(e.valveCooldown)+'秒':'热量50后可用',s.x,s.y+v.r+18);ctx2.restore();
      }
      if(e.workshopColdT>0){const s=RG.w2s(e.x,e.y);ctx2.save();ctx2.strokeStyle='#67e8f9';ctx2.lineWidth=3;ctx2.beginPath();ctx2.arc(s.x,s.y,e.r+10,0,TAU);ctx2.stroke();ctx2.restore();}
      if(e.overOrigin){
        const o=e.overOrigin,s=RG.w2s(o.x,o.y);ctx2.save();ctx2.fillStyle='rgba(255,84,112,.045)';ctx2.strokeStyle='rgba(255,84,112,.75)';ctx2.lineWidth=2;ctx2.setLineDash([10,7]);
        ctx2.beginPath();ctx2.arc(s.x,s.y,o.r,0,TAU);ctx2.fill();ctx2.stroke();ctx2.setLineDash([]);ctx2.strokeStyle='#ffd166';ctx2.beginPath();ctx2.arc(s.x,s.y,e.r+10,-Math.PI/2,-Math.PI/2+TAU*clamp(e.overT/1.8,0,1));ctx2.stroke();ctx2.restore();
      }
      if(e.workshopWarp){
        const w=e.workshopWarp,s=RG.w2s(w.x,w.y),r=e.r+P.r;
        ctx2.save();ctx2.strokeStyle=w.stage==='warn'?'rgba(192,132,252,.8)':'rgba(103,232,249,.7)';ctx2.lineWidth=2;ctx2.setLineDash([8,6]);ctx2.beginPath();ctx2.arc(s.x,s.y,r,0,TAU);ctx2.stroke();
        ctx2.lineWidth=e.r*2;ctx2.globalAlpha=.16;ctx2.beginPath();ctx2.moveTo(s.x,s.y);ctx2.lineTo(s.x+Math.cos(w.aim)*210,s.y+Math.sin(w.aim)*210);ctx2.stroke();ctx2.restore();
      }
    }
    // 冰墙和冻结尸体属于首领现场，图像缺失时同样能画出轮廓。
    for(const boss of RG.enemies)if(boss.frost&&!boss.dead){
      for(const w of boss.frost.walls){
        drawFrostWall(w,RG.w2s(w.x,w.y));
      }
      for(const corpse of boss.frost.corpses){const cs=RG.w2s(corpse.x,corpse.y);if(cs.x<-100||cs.y<-100||cs.x>RG.W+100||cs.y>RG.H+100)continue;drawFrozenCorpse(corpse,cs);}
    }
    // 敌用激光:预警=红色虚线闪烁 / 点火=亮束
    for (const hb of RG.hbeams || []) {
      const hs = RG.w2s(hb.x, hb.y);
      if(hb.frostField){
        drawFrostField(hb,hs);continue;
      }
      const ex = hs.x + Math.cos(hb.a) * hb.len, ey = hs.y + Math.sin(hb.a) * hb.len;
      if(hb.crossfireKind&&RG.crossfireTrial())crossfireMark(hs.x+Math.cos(hb.a)*48,hs.y+Math.sin(hb.a)*48-16);
      if (hb.warn > 0) {
        ctx2.globalAlpha = hb.prism?.65:0.35 + 0.4 * Math.sin(NOW / 60);
        ctx2.strokeStyle = hb.prism?'#67e8f9':"#ff5470"; ctx2.lineWidth = hb.prism?hb.w:2;
        ctx2.setLineDash([14, 10]);
        ctx2.beginPath(); ctx2.moveTo(hs.x, hs.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        ctx2.setLineDash([]);
        ctx2.globalAlpha = 1;
      } else {
        ctx2.globalAlpha = clamp(hb.fire / 0.28, 0, 1);
        ctx2.strokeStyle = hb.col || "#ff5470"; ctx2.lineWidth = hb.w + (hb.spaceLaser?2:10);
        ctx2.beginPath(); ctx2.moveTo(hs.x, hs.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        ctx2.strokeStyle = "#ffe0e6"; ctx2.lineWidth = Math.max(hb.spaceLaser?1:3, hb.w * 0.4);
        ctx2.beginPath(); ctx2.moveTo(hs.x, hs.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        ctx2.globalAlpha = 1;
      }
    }
    for(const vb of RG.voltBeams||[]){
      ctx2.save();ctx2.globalAlpha=vb.warn>0?.35+.3*Math.sin(NOW/55):1;ctx2.strokeStyle=vb.warn>0?"#ff5470":"#ffffff";ctx2.lineWidth=vb.warn>0?2:5;ctx2.setLineDash(vb.warn>0?[14,10]:[]);ctx2.beginPath();
      vb.points.forEach((p,i)=>{const s2=RG.w2s(p[0],p[1]);if(i)ctx2.lineTo(s2.x,s2.y);else ctx2.moveTo(s2.x,s2.y);});ctx2.stroke();ctx2.restore();
    }
    // 落点预警独立于怪物本体裁剪：本体在屏外也必须看得到屏内危险位置。
    for(const e of RG.enemies)if(e.type==='stalker'&&!e.dead&&!e.dying&&(e.stalkWind>0||e.stalkRecover>0)&&Number.isFinite(e.stalkX)&&Number.isFinite(e.stalkY)){
      const landing=RG.w2s(e.stalkX,e.stalkY),r=e.stalkRadius||e.r+P.r,wind=e.stalkWind>0;
      ctx2.save();ctx2.strokeStyle=wind?'rgba(255,84,112,.45)':'rgba(192,132,252,.35)';ctx2.fillStyle=wind?'rgba(255,84,112,.045)':'rgba(192,132,252,.04)';ctx2.lineWidth=1.5;ctx2.setLineDash([]);
      ctx2.beginPath();ctx2.arc(landing.x,landing.y,r,0,TAU);ctx2.fill();ctx2.stroke();ctx2.setLineDash([]);
      ctx2.restore();
    }
    for(const e of RG.enemies)if(e.type==='amplifier'&&!e.dead&&!e.dying){
      const s=RG.w2s(e.x,e.y);ctx2.save();ctx2.globalAlpha=.23;ctx2.strokeStyle='#fbbf24';ctx2.lineWidth=1.5;ctx2.setLineDash([8,12]);ctx2.beginPath();ctx2.arc(s.x,s.y,RG.WORKSHOP_MOBS.amplifier.radius,0,TAU);ctx2.stroke();ctx2.restore();
    }
    for(const w of RG.wormholes||[])if(!w.dead){
      const s=RG.w2s(w.x,w.y);ctx2.save();ctx2.strokeStyle=w.warn>0?'#c084fc':'#e9d5ff';ctx2.fillStyle='rgba(168,85,247,.10)';ctx2.lineWidth=3;ctx2.setLineDash(w.warn>0?[8,6]:[]);ctx2.beginPath();ctx2.arc(s.x,s.y,w.r,0,TAU);ctx2.fill();ctx2.stroke();ctx2.setLineDash([]);
      ctx2.strokeStyle='#c084fc';ctx2.lineWidth=2;ctx2.beginPath();ctx2.arc(s.x,s.y,w.r*.55,NOW/700,NOW/700+Math.PI*1.6);ctx2.stroke();
      if(w.workshopHole){ctx2.fillStyle='#312e81';ctx2.fillRect(s.x-30,s.y-w.r-13,60,5);ctx2.fillStyle='#e9d5ff';ctx2.fillRect(s.x-30,s.y-w.r-13,60*clamp(w.hp/w.maxhp,0,1),5);ctx2.font='12px ui-monospace';ctx2.textAlign='center';ctx2.fillStyle='#e9d5ff';ctx2.fillText(w.warn>0?'虫洞预警 · 可击破':'虫洞 · 可击破',s.x,s.y+w.r+17);}ctx2.restore();
    }
    for (const e of RG.enemies) {
      RG.scenery.queue(e.y+e.r,()=>{
      if(e.workshopHole||e.dead||e.spaceHidden)return;
      const s = RG.w2s(e.x, e.y);
      if (s.x < -60 || s.x > W + 60 || s.y < -60 || s.y > H + 60) return;
      const base = e.boss ? "#a855f7" : RG.ETYPES[e.type].color;
      const col = e.flash > 0 ? "#ffffff" : e.isMirror ? "#c084fc" : e.isEcho ? "#7c3aed" : base;
      const faceA = Math.atan2(P.y - e.y, P.x - e.x);
      const dk = e.dying ? clamp(e.dyingT / e.dyingMax, 0, 1) : 1;   // P2 死亡演出:淡出+收缩,白闪复用 flash
      const esz = e.dying ? 0.55 + 0.45 * dk : 1;
      ctx2.globalAlpha = e.alpha * dk;
      const ringed = e.elite && !e.isClone;   // 金环 = 精英标记(v8.15:BOSS 周身黄圈按玩家反馈删除;真身/分身靠配色与镜像紫环区分)
      if (ringed) { ctx2.strokeStyle = "#ffd166"; ctx2.lineWidth = 2; }
      const cell = !e.boss && MOB_ATLAS_CELLS[e.type];
      const bossCell = e.boss && BOSS_ATLAS_CELLS[e.bossKind || "gluttony"];
      const canPaint = (!!cell && !!artReady("atlas")) || (!!bossCell && !!artReady("boss"));
      if (canPaint) {
        ctx2.fillStyle = "rgba(0,0,0,0.28)"; ctx2.beginPath(); ctx2.ellipse(s.x, s.y + e.r * 0.78, e.r * 1.32, e.r * 0.46, 0, 0, TAU); ctx2.fill();
      }
      const painted = e.boss
        ? (drawBossAnim(e, s, e.r * 3.2 * esz) || (bossCell ? drawBossCell(bossCell[0], bossCell[1], s.x, s.y, e.r * 3.2 * esz, e.bossKind === "devourer" ? NOW / 7000 : 0) : false))
        : drawMobSprite(e,s,e.r*(e.type==='colossus'?4.15:4)*esz);
      if (!painted) drawEnemyShape(e, s, col, faceA);
      else if (e.flash > 0) {
        // 受击角标比白色大圆更清晰，不盖住新怪物动画。
        ctx2.fillStyle='#f5e8cf';const d=Math.round(e.r*1.25);for(const [a,b] of [[-1,-1],[1,-1],[-1,1],[1,1]]){ctx2.fillRect(Math.round(s.x+a*d)-2,Math.round(s.y+b*d)-1,5,2);ctx2.fillRect(Math.round(s.x+a*d)-1,Math.round(s.y+b*d)-2,2,5);}
      }
      const pixelMarks=drawElementMarks(e,s,e.r*(e.boss?3.2:e.type==='colossus'?4.15:4)*esz);
      drawFurnaceMaterial(e,s,environment);
      if (ringed) {
        ctx2.strokeStyle = "#ffd166"; ctx2.lineWidth = 2;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r * (painted ? 1.48 : 1) + 3, 0, TAU); ctx2.stroke();
      }
      if(e.frost){
        ctx2.save();ctx2.lineWidth=2;const rr=e.r*1.25;
        if(e.shieldHp>0){ctx2.strokeStyle='rgba(174,230,250,.65)';ctx2.beginPath();for(let i=0;i<=8;i++){const a=i*TAU/8,x=s.x+Math.cos(a)*(rr+8),y=s.y+Math.sin(a)*(rr+8);if(i)ctx2.lineTo(x,y);else ctx2.moveTo(x,y);}ctx2.stroke();}
        if(e.frost.breath&&e.frost.breath.index===0){ctx2.strokeStyle='#ff5470';ctx2.setLineDash([14,10]);ctx2.beginPath();ctx2.arc(s.x,s.y,rr+24,0,TAU);ctx2.stroke();}ctx2.restore();
      }
      if (e.isMirror) {
        // 镜像:高频闪烁紫环(与本体呼吸灯区分,靠肉眼分辨真假)
        ctx2.globalAlpha = (Math.floor(NOW / 75) % 2) ? 0.85 : 0.3;
        ctx2.strokeStyle = "#c084fc"; ctx2.lineWidth = 2;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r + 5, 0, TAU); ctx2.stroke();
        ctx2.globalAlpha = 1;
      }
      if (e.isBait) {
        // 暴食食饵:粉色脉冲环,提醒抢杀
        ctx2.globalAlpha = 0.5 + 0.4 * Math.sin(NOW / 120);
        ctx2.strokeStyle = "#ff9ecd"; ctx2.lineWidth = 2.5;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r + 6 + Math.sin(NOW / 150) * 2, 0, TAU); ctx2.stroke();
        ctx2.globalAlpha = 1;
      }
      if (e.stoneT > 0) {
        // 石肤:灰色裂纹护体(减伤 80% 提示)
        ctx2.strokeStyle = "rgba(156,163,175,0.95)"; ctx2.lineWidth = 3;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r + 4, 0, TAU); ctx2.stroke();
        ctx2.beginPath();
        ctx2.moveTo(s.x - e.r * 0.5, s.y - e.r * 0.5); ctx2.lineTo(s.x + e.r * 0.1, s.y);
        ctx2.moveTo(s.x + e.r * 0.3, s.y - e.r * 0.6); ctx2.lineTo(s.x - e.r * 0.1, s.y + e.r * 0.3);
        ctx2.stroke();
      }
      if(e.type==="bulwark"){
        const fa=e.face==null?faceA:e.face;ctx2.strokeStyle="#e2e8f0";ctx2.lineWidth=5;ctx2.beginPath();ctx2.arc(s.x,s.y,e.r+7,fa-.85,fa+.85);ctx2.stroke();
      }
      if(e.ampSource&&e.ampT>0){ctx2.fillStyle='#fbbf24';for(const off of [-5,5]){ctx2.fillRect(s.x+off-1,s.y-e.r*1.7,3,6);ctx2.fillRect(s.x+off-3,s.y-e.r*1.7,7,2);}}
      if(e.type==="flamer"&&(e.flameWind||0)>0){ctx2.save();ctx2.strokeStyle="#ff5470";ctx2.lineWidth=2;ctx2.setLineDash([14,10]);ctx2.beginPath();ctx2.arc(s.x,s.y,e.r+8,-Math.PI/2,-Math.PI/2+TAU*(1-e.flameWind/1.2));ctx2.stroke();ctx2.restore();}
      if(e.realmBoss&&e.keyWarn){
        ctx2.save();ctx2.globalAlpha=.55+.25*Math.sin(NOW/70);ctx2.fillStyle="#67e8f9";
        for(const off of [-.36,.36])for(let d2=e.r+16;d2<300;d2+=18){const a=e.keyWarn.safe+off;ctx2.fillRect(Math.round(s.x+Math.cos(a)*d2-4),Math.round(s.y+Math.sin(a)*d2-2),8,4);}
        const tx=s.x+Math.cos(e.keyWarn.safe)*245,ty=s.y+Math.sin(e.keyWarn.safe)*245;ctx2.fillStyle="#cffafe";ctx2.font=F(11,true);ctx2.textAlign="center";ctx2.fillText("安全缺口",tx,ty);ctx2.restore();
      }
      if (e.type === "bomber" && e.fuseLit) {
        if(RG.crossfireTrial())crossfireMark(s.x+e.r+18,s.y-e.r-12);
        ctx2.save();ctx2.strokeStyle="#ff5470";ctx2.fillStyle="rgba(255,84,112,.08)";ctx2.lineWidth=2;ctx2.setLineDash([14,10]);ctx2.beginPath();ctx2.arc(s.x,s.y,(e.elite?RG.MOB_SKILLS.bomber.eliteRadius:RG.MOB_SKILLS.bomber.radius),0,TAU);ctx2.fill();ctx2.stroke();ctx2.restore();
        const remain = clamp((e.fuseT || 0) / RG.MOB_SKILLS.bomber.fuse, 0, 1), pulse = 1 + Math.sin(NOW / 55) * 0.08;
        ctx2.strokeStyle = remain < 0.38 ? "#ff3b3b" : "#fb923c"; ctx2.lineWidth = 3;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, (e.r + 9) * pulse, -Math.PI / 2, -Math.PI / 2 + TAU * remain); ctx2.stroke();
        ctx2.fillStyle = "#fff"; ctx2.textAlign = "center"; ctx2.font = F(12, true); ctx2.fillText("!", s.x, s.y - e.r - 12);
      }
      if (e.chargeWind > 0) {
        const ca = e.chargeAim || 0, len = e.type==="hound"?RG.MOB_SKILLS.hound.distance:Math.max(W, H) * 0.48;
        ctx2.save(); ctx2.setLineDash([10, 8]); ctx2.strokeStyle = "rgba(255,84,112," + (0.45 + 0.35 * Math.sin(NOW / 55)).toFixed(2) + ")"; ctx2.lineWidth = 3;
        if (e.pattern === 4 && !e.isEcho && !e.noCharge) {
          // v8.21 退修:终焉之影 Z 字冲撞预警改三段折线,与实际轨迹一致(每段前 138px/横移 90px,两次换向)
          const fx = Math.cos(ca), fy = Math.sin(ca), px2 = Math.cos(ca + Math.PI / 2), py2 = Math.sin(ca + Math.PI / 2);
          const zx1 = s.x + fx * 138 + px2 * 90, zy1 = s.y + fy * 138 + py2 * 90;
          const zx2 = s.x + fx * 276, zy2 = s.y + fy * 276;
          const zx3 = s.x + fx * 414, zy3 = s.y + fy * 414;
          ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(zx1, zy1); ctx2.lineTo(zx2, zy2); ctx2.lineTo(zx3, zy3); ctx2.stroke();
        } else {
          ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(s.x + Math.cos(ca) * len, s.y + Math.sin(ca) * len); ctx2.stroke();
        }
        ctx2.restore();
      }
      if (e.chest) {
        ctx2.font = F(14); ctx2.textAlign = "center";
        ctx2.fillText("箱", s.x, s.y - e.r - 8);
      }
      if (e.affix) {
        // 词缀标签:爆/迅/分/盾
        const AF = { boom: ["爆", "#fb923c"], swift: ["迅", "#6ee7b7"], split: ["分", "#c4b5fd"], shield: ["盾", "#38bdf8"] };
        const af = AF[e.affix];
        ctx2.fillStyle = af[1]; ctx2.font = F(11, true); ctx2.textAlign = "center";
        ctx2.fillText(af[0], s.x, s.y - e.r - (e.chest ? 24 : 8));
      if (e.affix === "shield" && e.shieldHp > 0) {
          ctx2.strokeStyle = "rgba(56,189,248,0.75)"; ctx2.lineWidth = 2;
          ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r + 7, 0, TAU); ctx2.stroke();
      }
      if (e.el && !pixelMarks) {
        // 元素状态角标(脚下):火橙/冰青/电黄/毒绿/地棕
        let ppx = s.x - 10;
        if (e.el.fire > 0) { ctx2.fillStyle = "#fb923c"; ctx2.beginPath(); ctx2.arc(ppx, s.y + e.r + 8, 3.5, 0, TAU); ctx2.fill(); ppx += 10; }
        if (e.el.ice > 0) { ctx2.fillStyle = "#7dd3fc"; ctx2.beginPath(); ctx2.arc(ppx, s.y + e.r + 8, 3.5, 0, TAU); ctx2.fill(); ppx += 10; }
        if (e.el.elec > 0) { ctx2.fillStyle = "#fde047"; ctx2.beginPath(); ctx2.arc(ppx, s.y + e.r + 8, 3.5, 0, TAU); ctx2.fill(); ppx += 10; }
        if (e.el.poison > 0) { ctx2.fillStyle = "#84cc16"; ctx2.beginPath(); ctx2.arc(ppx, s.y + e.r + 8, 3.5, 0, TAU); ctx2.fill(); ppx += 10; }
        if (e.el.earth > 0) { ctx2.fillStyle = "#d6a85f"; ctx2.beginPath(); ctx2.arc(ppx, s.y + e.r + 8, 3.5, 0, TAU); ctx2.fill(); }
      }
      }
      // 元素状态光环:脚下呼吸光环,一眼扫出"谁带着元素"
      if (!pixelMarks && e.el && (e.el.fire > 0 || e.el.ice > 0 || e.el.elec > 0 || e.el.poison > 0 || e.el.earth > 0)) {
        const pulse = 0.26 + 0.13 * Math.sin(NOW / 300 + e.x * 0.05);
        const mix = e.el.fire > 0 ? "#fb923c" : e.el.ice > 0 ? "#7dd3fc" : e.el.elec > 0 ? "#fde047" : e.el.poison > 0 ? "#84cc16" : "#d6a85f";
        ctx2.globalAlpha = pulse;
        ctx2.strokeStyle = mix; ctx2.lineWidth = 3;
        ctx2.beginPath(); ctx2.ellipse(s.x, s.y + e.r * 0.75, e.r * 0.95, e.r * 0.32, 0, 0, TAU); ctx2.stroke();
        ctx2.globalAlpha = 1;
      }
      if (e.splitFlash > 0) {
        ctx2.strokeStyle = "rgba(192,132,252," + clamp(e.splitFlash * 1.6, 0, 1).toFixed(3) + ")"; ctx2.lineWidth = 3;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r + 10 + (0.6 - e.splitFlash) * 60, 0, TAU); ctx2.stroke();
      }
      if (e.chronoT > 0) {
        ctx2.strokeStyle='#67e8f9';ctx2.lineWidth=2;ctx2.beginPath();ctx2.arc(s.x,s.y,e.r+5,0,TAU);ctx2.stroke();
        ctx2.beginPath();ctx2.moveTo(s.x,s.y-e.r*.6);ctx2.lineTo(s.x,s.y);ctx2.lineTo(s.x+e.r*.5,s.y);ctx2.stroke();
      } else if (e.petrifyT > 0) {
        if(!pixelMarks){
        ctx2.fillStyle="rgba(120,113,108,0.62)";ctx2.beginPath();ctx2.arc(s.x,s.y,e.r,0,TAU);ctx2.fill();
        ctx2.strokeStyle="#d6d3d1";ctx2.lineWidth=2;ctx2.stroke();
        }
      } else if (e.frozen > 0) {
        if(!pixelMarks){
        ctx2.fillStyle = "rgba(155,216,255,0.55)";
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r, 0, TAU); ctx2.fill();
        ctx2.strokeStyle = "#e0f2fe"; ctx2.lineWidth = 1.5;
        ctx2.beginPath();
        ctx2.moveTo(s.x, s.y - e.r * 0.7); ctx2.lineTo(s.x, s.y + e.r * 0.7);
        ctx2.moveTo(s.x - e.r * 0.6, s.y - e.r * 0.35); ctx2.lineTo(s.x + e.r * 0.6, s.y + e.r * 0.35);
        ctx2.moveTo(s.x + e.r * 0.6, s.y - e.r * 0.35); ctx2.lineTo(s.x - e.r * 0.6, s.y + e.r * 0.35);
        ctx2.stroke();
        }
      } else if (!e.boss&&e.type!=='prism'&&e.type!=='amplifier') {
        // v8.15:BOSS 不再画朝向注视黑点(玩家反馈干扰识别);小怪保留"注视感"
        const dx = P.x - e.x, dy = P.y - e.y, dd = Math.hypot(dx, dy) || 1;
        ctx2.fillStyle = "#0b0d14";
        ctx2.beginPath(); ctx2.arc(s.x + dx / dd * e.r * 0.4, s.y + dy / dd * e.r * 0.4, Math.max(2, e.r * 0.22), 0, TAU); ctx2.fill();
      }
      // 燃烧状态:闪烁火焰环(呼应用火元素主题,让"着火了"看得见)
      if (!pixelMarks && (e.burnDps || 0) > 0 && e.frozen <= 0) {
        const fl = 0.5 + 0.5 * Math.sin(NOW / 70 + e.x * 0.13);
        ctx2.strokeStyle = "rgba(251,146,60," + (0.4 + fl * 0.45).toFixed(2) + ")";
        ctx2.lineWidth = 2.5;
        ctx2.beginPath(); ctx2.arc(s.x, s.y, e.r + 3 + fl * 2.5, 0, TAU); ctx2.stroke();
      }
      if (!e.dying && (e.elite || (e.hp < e.maxhp && !e.boss))) {
        const w = e.r * 2;
        ctx2.fillStyle = "rgba(0,0,0,0.5)"; ctx2.fillRect(s.x - w / 2, s.y - e.r - 9, w, 4);
        ctx2.fillStyle = "#ef4444"; ctx2.fillRect(s.x - w / 2, s.y - e.r - 9, w * clamp(e.hp / e.maxhp, 0, 1), 4);
      }
      ctx2.globalAlpha = 1;

      },'enemy');
    }
    RG.scenery.flushDepth();
    RG.scenery.fog(ctx2,W,H);
    if(environment.theme==='workshop')drawGroundHazards();
    // 关键目标超出视野时给方向提示，避免玩家在大地图里盲走。
    if (P) {
      const boss = RG.run && RG.run.boss && !RG.run.boss.dead ? RG.run.boss : null;
      if (boss) drawEdgeMarker(boss.x, boss.y, "#ff5470", "首领");
      for (const k of (RG.keyItems || []).slice(0, 2)) drawEdgeMarker(k.x, k.y, "#ffd166", "钥匙");
      if (RG.portal) drawEdgeMarker(RG.portal.x, RG.portal.y, "#c084fc", RG.portal.exit ? "出口" : "秘境");
      if (!boss && !(RG.keyItems || []).length && !RG.portal) {
        let elite = null, bd = Infinity;
        for (const e of RG.enemies) if (e.elite && !e.dead) { const d = (e.x - P.x) ** 2 + (e.y - P.y) ** 2; if (d < bd) { bd = d; elite = e; } }
        if (elite) drawEdgeMarker(elite.x, elite.y, "#ffd166", "精英");
      }
    }
    // v9.0 新武器:像素分段镰弧 / 驻场旋棍 / 环绕气珠 / 聚能预警线。
    for(const sl of RG.slashes||[]){
      const s=RG.w2s(sl.x,sl.y),fade=clamp(sl.life/sl.maxLife,0,1);ctx2.save();ctx2.globalAlpha=fade;ctx2.fillStyle=sl.col;
      if(sl.rect){ctx2.translate(Math.round(s.x),Math.round(s.y));ctx2.rotate(sl.a);ctx2.globalAlpha=fade*.22;ctx2.fillRect(0,-sl.width/2,sl.length,sl.width);ctx2.globalAlpha=fade;ctx2.strokeStyle=sl.col;ctx2.lineWidth=2;ctx2.strokeRect(0,-sl.width/2,sl.length,sl.width);ctx2.fillStyle="#fde68a";ctx2.fillRect(sl.length-10,-sl.width/2,10,sl.width);ctx2.restore();continue;}
      for(let i=0;i<9;i++){const a=sl.a-sl.arc/2+sl.arc*i/8,r=sl.r*(.72+.22*i/8),x=s.x+Math.cos(a)*r,y=s.y+Math.sin(a)*r;ctx2.save();ctx2.translate(Math.round(x),Math.round(y));ctx2.rotate(a+Math.PI/2);ctx2.fillRect(-8,-3,16,6);ctx2.restore();}
      ctx2.restore();
    }
    for(const sp of RG.spinners||[]){
      const s=RG.w2s(sp.x,sp.y),ax=Math.cos(sp.spin),ay=Math.sin(sp.spin);ctx2.save();ctx2.translate(Math.round(s.x),Math.round(s.y));ctx2.rotate(sp.spin);ctx2.fillStyle="#3f2a16";ctx2.fillRect(-sp.r-3,-6,sp.r*2+6,12);ctx2.fillStyle="#fb923c";ctx2.fillRect(-sp.r,-4,sp.r*2,8);ctx2.fillStyle="#fde68a";ctx2.fillRect(-5,-5,10,10);ctx2.restore();
    }
    for(const q of RG.qiOrbs||[]){
      const s=RG.w2s(q.x,q.y);ctx2.fillStyle="rgba(103,232,249,.28)";ctx2.fillRect(Math.round(s.x-8),Math.round(s.y-8),16,16);ctx2.fillStyle="#cffafe";ctx2.fillRect(Math.round(s.x-4),Math.round(s.y-4),8,8);ctx2.fillStyle="#22d3ee";ctx2.fillRect(Math.round(s.x-2),Math.round(s.y-7),4,14);ctx2.fillRect(Math.round(s.x-7),Math.round(s.y-2),14,4);
    }
    // 回旋镖
    for (const bm of RG.booms) {
      const s = RG.w2s(bm.x, bm.y);
      ctx2.save(); ctx2.translate(s.x, s.y); ctx2.rotate(bm.spin); ctx2.scale(bm.size || 1, bm.size || 1);   // v8.24:刃体体积随级
      ctx2.fillStyle = bm.evo ? "#ffd166" : "#a3e635";
      ctx2.fillRect(-10, -3, 20, 6); ctx2.fillRect(-3, -10, 6, 20);
      ctx2.restore();
    }
    // 子弹(友方:圆/方 + 近黑硬描边,与敌弹形状分层)
    let detailedBullets=0;
    for (const b of RG.bullets) {
      const s = RG.w2s(b.x, b.y);
      if (s.x < -20 || s.x > W + 20 || s.y < -20 || s.y > H + 20) continue;
      const r = Math.max(2, b.r || 4);
      if(RG.fxQuality!=='low'&&!RG.fxAutoReduced){
        const v=Math.hypot(b.vx||0,b.vy||0)||1,high=RG.fxQuality==='high'&&detailedBullets++<96,n=high?4:2;
        ctx2.fillStyle=b.col||'#7ecbff';for(let i=n;i>0;i--){ctx2.globalAlpha=.10+(n-i)*.07;const pr=Math.max(2,Math.round(r*(1-i*.15)));ctx2.fillRect(Math.round(s.x-(b.vx||0)/v*(i*(r+3))-pr/2),Math.round(s.y-(b.vy||0)/v*(i*(r+3))-pr/2),pr,pr);}
        if(high&&b.weapon==='seeker'){ctx2.globalAlpha=.65;ctx2.fillStyle='#edf9ff';ctx2.fillRect(Math.round(s.x-b.vx/v*(r+4))-1,Math.round(s.y-b.vy/v*(r+4))-1,3,3);}ctx2.globalAlpha=1;
      }
      if (b.ki) {
        const rr = Math.max(3, Math.round(b.r));
        ctx2.fillStyle = "#090A12"; ctx2.fillRect(Math.round(s.x - rr - 1), Math.round(s.y - rr - 1), rr * 2 + 2, rr * 2 + 2);
        ctx2.fillStyle = b.col || "#67e8f9"; ctx2.fillRect(Math.round(s.x - rr), Math.round(s.y - rr), rr * 2, rr * 2);
        ctx2.fillStyle = "#ecfeff"; ctx2.fillRect(Math.round(s.x - 1), Math.round(s.y - 1), 3, 3);
      } else {
        ctx2.fillStyle = "#090A12"; ctx2.beginPath(); ctx2.arc(s.x, s.y, r + 1.5, 0, TAU); ctx2.fill();
        ctx2.fillStyle = b.col || "#7ecbff"; ctx2.beginPath(); ctx2.arc(s.x, s.y, r, 0, TAU); ctx2.fill();
        ctx2.fillStyle = "#ffffff"; ctx2.beginPath(); ctx2.arc(s.x - r * 0.2, s.y - r * 0.2, r * 0.35, 0, TAU); ctx2.fill();
      }
    }
    // 激光束 / 闪电链：高档用短脉冲与折线增加层次，不使用大面积模糊。
    for (const bm of RG.beams) {
      const s = RG.w2s(bm.x, bm.y);
      const ex = s.x + Math.cos(bm.a) * bm.len, ey = s.y + Math.sin(bm.a) * bm.len;
      ctx2.globalAlpha = clamp(bm.life / bm.maxLife, 0, 1);
      if (bm.chainCol) {
        ctx2.strokeStyle = "#7dd3fc"; ctx2.lineWidth = bm.w + 3;
        ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        if(RG.fxQuality==='high'&&!RG.fxAutoReduced){
          const nx=-Math.sin(bm.a),ny=Math.cos(bm.a),phase=(RG.run?.t||0)*24;
          ctx2.strokeStyle=bm.chainCol;ctx2.lineWidth=2;ctx2.beginPath();ctx2.moveTo(s.x,s.y);
          for(let i=1;i<6;i++){const k=i/6,z=Math.sin(i*2.7+phase)*7;ctx2.lineTo(s.x+(ex-s.x)*k+nx*z,s.y+(ey-s.y)*k+ny*z);}ctx2.lineTo(ex,ey);ctx2.stroke();
          ctx2.fillStyle='#effaff';ctx2.fillRect(Math.round(ex)-2,Math.round(ey)-2,4,4);
        }
        ctx2.strokeStyle = "#ffffff"; ctx2.lineWidth = 1.5;
        ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        if(RG.fxQuality==='high'&&!RG.fxAutoReduced){
          const k=.25+((RG.run?.t||0)*2% .5),x=s.x+(ex-s.x)*k,y=s.y+(ey-s.y)*k;
          ctx2.fillStyle='#fff6de';ctx2.fillRect(Math.round(x)-3,Math.round(y)-3,6,6);
        }
      } else {
        const bc = bm.col || "#ff8fa3";
        if (RG.fxQuality !== "low" && !RG.fxAutoReduced) {
          ctx2.globalAlpha = clamp(bm.life / bm.maxLife, 0, 1) * 0.35;
          ctx2.strokeStyle = bc; ctx2.lineWidth = bm.w + 8;
          ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        }
        ctx2.globalAlpha = clamp(bm.life / bm.maxLife, 0, 1);
        ctx2.strokeStyle = bm.evo ? "#ffd166" : bc; ctx2.lineWidth = bm.w;
        ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(ex, ey); ctx2.stroke();
        ctx2.strokeStyle = "#ffffff"; ctx2.lineWidth = Math.max(1.5, bm.w * 0.3);
        ctx2.beginPath(); ctx2.moveTo(s.x, s.y); ctx2.lineTo(ex, ey); ctx2.stroke();
      }
      ctx2.globalAlpha = 1;
    }
    // 敌弹(硬边菱刺,与友方圆弹一眼可分)
    for (const b of RG.ebullets) {
      const s = RG.w2s(b.x, b.y);
      if (s.x < -12 || s.x > W + 12 || s.y < -12 || s.y > H + 12) continue;
      const ebc = b.col || (b.slow ? "#7dd3fc" : b.fire ? "#fb923c" : "#ff4d6d");
      const rr = Math.max(3, b.r || 6);
      if(b.turn){ctx2.globalAlpha=1;ctx2.fillStyle="#090A12";ctx2.fillRect(s.x-rr-2,s.y-rr-2,rr*2+4,rr*2+4);ctx2.fillStyle="#facc15";ctx2.fillRect(s.x-rr,s.y-rr,rr*2,rr*2);ctx2.fillStyle="#fff5a0";ctx2.fillRect(s.x-2,s.y-2,4,4);continue;}
      if (RG.fxQuality !== "low" && !RG.fxAutoReduced) {
        ctx2.globalAlpha = 0.28;
        ctx2.fillStyle = ebc;
        ctx2.beginPath();
        ctx2.moveTo(s.x, s.y - rr - 4); ctx2.lineTo(s.x + rr + 4, s.y);
        ctx2.lineTo(s.x, s.y + rr + 4); ctx2.lineTo(s.x - rr - 4, s.y);
        ctx2.closePath(); ctx2.fill();
      }
      ctx2.globalAlpha = 1;
      ctx2.fillStyle = "#090A12";
      ctx2.beginPath();
      ctx2.moveTo(s.x, s.y - rr - 2); ctx2.lineTo(s.x + rr + 2, s.y);
      ctx2.lineTo(s.x, s.y + rr + 2); ctx2.lineTo(s.x - rr - 2, s.y);
      ctx2.closePath(); ctx2.fill();
      ctx2.fillStyle = ebc;
      ctx2.beginPath();
      ctx2.moveTo(s.x, s.y - rr); ctx2.lineTo(s.x + rr, s.y);
      ctx2.lineTo(s.x, s.y + rr); ctx2.lineTo(s.x - rr, s.y);
      ctx2.closePath(); ctx2.fill();
      ctx2.fillStyle = "#ffffff";
      ctx2.fillRect(Math.round(s.x - 2), Math.round(s.y - 2), 4, 4);
    }
    // 冲击环
    let detailedRings=0;
    for (const r of RG.rings) {
      if(r.delay>0)continue;
      const s = RG.w2s(r.x, r.y);
      ctx2.strokeStyle = r.warning?'#ff5470':r.color;
      ctx2.globalAlpha = r.fan ? .7 : r.hazard ? .65 : (r.static ? .4 : clamp(r.life / r.maxLife, 0, 1));
      ctx2.lineWidth = r.fan ? 2 : r.hazard ? 3 : r.static ? 1.5 : 3;
      if(r.warning)ctx2.setLineDash([14,10]);
      ctx2.beginPath(); ctx2.arc(s.x, s.y, r.r, r.fan?r.a-r.half:0, r.fan?r.a+r.half:TAU); ctx2.stroke();
      if(RG.fxQuality==='high'&&!RG.fxAutoReduced&&!r.warning&&!r.hazard&&!r.static&&!r.fan&&r.r>12&&detailedRings++<12){
        ctx2.globalAlpha*=.45;ctx2.lineWidth=1;ctx2.beginPath();ctx2.arc(s.x,s.y,r.r*.87,0,TAU);ctx2.stroke();
        ctx2.fillStyle=r.color;for(let i=0;i<8;i++){const a=i*TAU/8;ctx2.fillRect(Math.round(s.x+Math.cos(a)*r.r)-2,Math.round(s.y+Math.sin(a)*r.r)-2,4,4);}
      }
      if(r.warning)ctx2.setLineDash([]);
      ctx2.globalAlpha = 1;
      if(r.crossfireKind&&RG.crossfireTrial())crossfireMark(s.x+Math.cos(r.a||0)*r.r,s.y+Math.sin(r.a||0)*r.r-12);
    }
    // 粒子(P1 像素化:透明度四档阶梯 + 整数像素对齐,去掉矢量渐隐的"网页感")
    for (const p of RG.parts) {
      const s = RG.w2s(p.x, p.y);
      if (s.x < -4 || s.x > W + 4 || s.y < -4 || s.y > H + 4) continue;
      ctx2.globalAlpha = Math.ceil(clamp(p.life / p.max, 0, 1) * 4) / 4;
      ctx2.fillStyle = p.color;
      const pr = Math.max(1, Math.round(p.r*(.45+.55*clamp(p.life/p.max,0,1))));
      ctx2.fillRect(Math.round(s.x - pr / 2), Math.round(s.y - pr / 2), pr, pr);
      if(RG.fxQuality==='high'&&p.life>p.max*.6){ctx2.fillStyle='#f6efe3';ctx2.fillRect(Math.round(s.x),Math.round(s.y),1,1);}
      ctx2.globalAlpha = 1;
    }
    // 碎片风暴
    for (const s of RG.storms || []) {
      const sc = RG.w2s(s.x, s.y);
      ctx2.globalAlpha = clamp(s.t / 2, 0, 1) * 0.8;
      ctx2.strokeStyle = "#e9d5ff"; ctx2.lineWidth = 2;
      ctx2.beginPath(); ctx2.arc(sc.x, sc.y, s.r, 0, TAU); ctx2.stroke();
      ctx2.fillStyle = "#c4b5fd";
      for (let i = 0; i < 6; i++) {
        const sa = s.rot + i / 6 * TAU;
        ctx2.fillRect(sc.x + Math.cos(sa) * s.r * 0.6 - 3, sc.y + Math.sin(sa) * s.r * 0.6 - 3, 6, 6);
      }
      ctx2.globalAlpha = 1;
    }
    // 命中火花(硬边像素:十字/星爆/斜火花/放射)
    if (RG.sparks && RG.sparks.length) {
      for (const sp of RG.sparks) {
        const s = RG.w2s(sp.x, sp.y);
        const k = clamp(sp.life / sp.maxLife, 0, 1);
        ctx2.globalAlpha = Math.ceil(k * 4) / 4;
        const sz = (sp.tier === "big" ? 14 : sp.tier === "crit" ? 11 : sp.tier === "heavy" ? 9 : sp.tier === "melee" ? 8 : 6)*(1+(1-k)*.65);
        ctx2.fillStyle = sp.color;
        ctx2.save();
        ctx2.translate(Math.round(s.x), Math.round(s.y));
        ctx2.rotate((sp.rot | 0) * Math.PI / 2);
        if(sp.tier === "critical") {
          const reach=24+(1-k)*26;
          ctx2.fillStyle='#f6b74e';
          // 金色尖锐斩光 + 白芯，形状和普通星点火花明显区分。
          for(let j=0;j<4;j++){ctx2.save();ctx2.rotate(j*Math.PI/2+.38);ctx2.beginPath();ctx2.moveTo(0,-5);ctx2.lineTo(reach,0);ctx2.lineTo(0,5);ctx2.lineTo(-6,0);ctx2.closePath();ctx2.fill();ctx2.restore();}
          ctx2.fillStyle='#fffbe8';ctx2.fillRect(-4,-4,8,8);
          for(let j=0;j<8;j++){const a=j*Math.PI/4+.38;const d=reach*.8;ctx2.fillRect(Math.round(Math.cos(a)*d)-2,Math.round(Math.sin(a)*d)-2,4,4);}
        } else if (sp.tier === "light") {
          ctx2.fillRect(-sz, -1, sz * 2, 2); ctx2.fillRect(-1, -sz, 2, sz * 2);
        } else if (sp.tier === "melee") {
          ctx2.fillRect(-sz, -2, sz + 2, 2); ctx2.fillRect(-2, -sz, 2, sz + 2);
          ctx2.fillRect(2, 0, sz, 2);
        } else if (sp.tier === "heavy" || sp.tier === "crit") {
          for (let i = 0; i < 6; i++) {
            const a = i * Math.PI / 3;
            ctx2.fillRect(Math.round(Math.cos(a) * 2) - 1, Math.round(Math.sin(a) * 2) - 1, 3, 3);
            ctx2.fillRect(Math.round(Math.cos(a) * sz) - 1, Math.round(Math.sin(a) * sz) - 1, 3, 3);
          }
          ctx2.fillRect(-2, -2, 4, 4);
        } else {
          for (let i = 0; i < 8; i++) {
            const a = i * Math.PI / 4;
            for (let r = 3; r <= sz; r += 3) {
              ctx2.fillRect(Math.round(Math.cos(a) * r) - 1, Math.round(Math.sin(a) * r) - 1, 2, 2);
            }
          }
          ctx2.fillStyle = "#FFD166"; ctx2.fillRect(-3, -3, 6, 6);
        }
        ctx2.restore();
        ctx2.globalAlpha = 1;
      }
    }
    // 进化/罪印全屏高光
    if (RG.flashes && RG.flashes.length) {
      for (const fl of RG.flashes) {
        const k = clamp(fl.t / fl.max, 0, 1);
        ctx2.globalAlpha = 0.22 * k;
        ctx2.fillStyle = fl.color;
        ctx2.fillRect(0, 0, W, H);
        ctx2.globalAlpha = 0.55 * k;
        ctx2.strokeStyle = fl.color; ctx2.lineWidth = 4;
        const inset = 18 + (1 - k) * 40;
        ctx2.strokeRect(inset, inset, W - inset * 2, H - inset * 2);
        if (fl.title) {
          ctx2.globalAlpha = k;
          ctx2.textAlign = "center";
          ctx2.font = F(28, true);
          ctx2.fillStyle = "#F1F0FA";
          ctx2.strokeStyle = "#090A12"; ctx2.lineWidth = 4;
          ctx2.strokeText(fl.title, W / 2, H * 0.28);
          ctx2.fillText(fl.title, W / 2, H * 0.28);
        }
        ctx2.globalAlpha = 1;
      }
    }
    const labels=RG.playerStatusLabels(P);
    if(labels.length){const p=RG.w2s(P.x,P.y);ctx2.save();ctx2.font=F(12,true);ctx2.textAlign='center';ctx2.lineWidth=3;ctx2.strokeStyle='#080c14';ctx2.fillStyle='#ffe1ba';labels.forEach((label,i)=>{const row=Math.floor(i/3),group=labels.slice(row*3,row*3+3),x=p.x+(i%3-(group.length-1)/2)*46,y=p.y-P.r-23-row*17;ctx2.strokeText(label,x,y);ctx2.fillText(label,x,y);});ctx2.restore();}
    // 空间门不阻挡身体，黑洞门才转移单位；红线对应双门的真实预警时间。
    for(const g of RG.spaceGates()){const p=RG.w2s(g.x,g.y);ctx2.save();ctx2.translate(p.x,p.y);ctx2.rotate(g.a);ctx2.fillStyle=g.warn>0?'#ff5470':'#060712';ctx2.fillRect(-g.length/2,-6,g.length,12);ctx2.strokeStyle=g.warn>0?'#ff5470':g.kind==='hole'?'#e0b2ff':'#9a72cd';ctx2.lineWidth=g.warn>0?1:2;ctx2.strokeRect(-g.length/2,-6,g.length,12);if(g.warn<=0){ctx2.fillStyle='#46315e';ctx2.fillRect(-g.length/2+6,-1,g.length-12,2);}ctx2.restore();}
    // 飘字(描边 + 弹跳缩放)
    ctx2.textAlign = "center";
    for (const t of RG.texts) {
      const s = RG.w2s(t.x, t.y);
      const lifeK = clamp(t.life / (t.maxLife || 0.8), 0, 1);
      const sc = t.scale && t.scale > 1 ? t.scale : 1;
      ctx2.globalAlpha = lifeK;
      ctx2.font = F(Math.round(t.size * sc), true);
      if (t.outline !== false) {
        ctx2.strokeStyle = "#090A12";
        ctx2.lineWidth = t.critical ? 5 : 3;
        ctx2.lineJoin = "miter";
        ctx2.strokeText(t.str, s.x, s.y);
      }
      ctx2.fillStyle = t.color;
      ctx2.fillText(t.str, s.x, s.y);
      ctx2.globalAlpha = 1;
    }
    // 待机摇杆保留轻淡圆环，说明沿用开局引导。
    if (RG.touchMode && (!RG.joy || !RG.joy.active) && RG.state === "play") {
      const safe = RG.safe || { left: 0, bottom: 0 }, hx = safe.left + 84, hy = H - safe.bottom - 96;
      ctx2.strokeStyle = "rgba(255,255,255,0.10)"; ctx2.lineWidth = 1.5;
      ctx2.beginPath(); ctx2.arc(hx, hy, 34, 0, TAU); ctx2.stroke();
    }
    // 虚拟摇杆
    if (RG.joy && RG.joy.active) {
      ctx2.strokeStyle = "rgba(255,255,255,0.18)"; ctx2.lineWidth = 2;
      ctx2.beginPath(); ctx2.arc(RG.joy.sx, RG.joy.sy, 56, 0, TAU); ctx2.stroke();
      ctx2.fillStyle = "rgba(255,255,255,0.22)";
      ctx2.beginPath(); ctx2.arc(RG.joy.sx + RG.joy.vx * 44, RG.joy.sy + RG.joy.vy * 44, 24, 0, TAU); ctx2.fill();
    }
    // BOSS 出场演出:红屏渐隐 + 名字横幅弹入
    if (RG.bossIntro > 0 && RG.bossIntroName && RG.P) {
      const k = clamp(RG.bossIntro / 0.4, 0, 1);
      const g = ctx2.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.72);
      g.addColorStop(0, "rgba(255,60,90,0)");
      g.addColorStop(1, "rgba(255,60,90," + (0.3 * k).toFixed(3) + ")");
      ctx2.fillStyle = g; ctx2.fillRect(0, 0, W, H);
      const pop = 1 + Math.max(0, RG.bossIntro - 1.9) * 2.5;
      ctx2.save(); ctx2.translate(W / 2, H * 0.3); ctx2.scale(pop, pop);
      ctx2.globalAlpha = clamp(RG.bossIntro / 0.5, 0, 1);
      ctx2.font = F(34, true); ctx2.textAlign = "center";
      ctx2.strokeStyle = "rgba(0,0,0,0.65)"; ctx2.lineWidth = 7;
      ctx2.strokeText("! " + RG.bossIntroName + " 降临", 0, 0);
      ctx2.fillStyle = "#ff5470";
      ctx2.fillText("! " + RG.bossIntroName + " 降临", 0, 0);
      ctx2.restore(); ctx2.globalAlpha = 1;
    }
    if (P.hp / P.maxhp < 0.35 && RG.state === "play") {
      const danger = clamp(1 - P.hp / (P.maxhp * 0.35), 0, 1), pulse = 0.75 + 0.25 * Math.sin(NOW / 140);
      const dg = ctx2.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.22, W / 2, H / 2, Math.max(W, H) * 0.7);
      dg.addColorStop(0, "rgba(255,35,55,0)"); dg.addColorStop(1, "rgba(255,25,45," + (0.12 + danger * 0.20 * pulse).toFixed(3) + ")");
      ctx2.fillStyle = dg; ctx2.fillRect(0, 0, W, H);
    }
    // 连杀光只落在屏幕四边，中心战场与HUD保持清晰。
    if(RG.comboGlow&&RG.state==='play'){
      const glow=RG.comboGlow,k=RG.comboGlowEnvelope(glow),band=Math.min(W,H)*(.06+.035*glow.strength);
      ctx2.save();ctx2.globalCompositeOperation='screen';ctx2.globalAlpha=glow.opacity*k;
      for(const [x,y,w,h,ex,ey] of [[0,0,W,band,0,band],[0,H,W,-band,0,H-band],[0,0,band,H,band,0],[W,0,-band,H,W-band,0]]){
        const g=ctx2.createLinearGradient(x,y,ex,ey);g.addColorStop(0,"#fff2c2");g.addColorStop(.18,glow.color);g.addColorStop(1,'rgba(0,0,0,0)');ctx2.fillStyle=g;ctx2.fillRect(x,y,w,h);
      }
      ctx2.restore();
    }
    drawHUD();
    // 雕像献祭提示(靠近时)
    RG.statueRect = null;
    if (P.statueNear && RG.state === "play" && (RG.touchMode || W<960 || H<500)) { RG.drawMobileStatue(); }
    else if (P.statueNear && RG.state === "play") {
      const pw = Math.min(520, W - 40), px3 = W / 2 - pw / 2, py3 = H - 112;
      ctx2.fillStyle = "rgba(20,18,36,0.94)"; roundRect(px3, py3, pw, 92, 12); ctx2.fill();
      ctx2.strokeStyle = "rgba(139,92,246,0.6)"; ctx2.lineWidth = 1.5; roundRect(px3, py3, pw, 92, 12); ctx2.stroke();
      ctx2.textAlign = "center";
      ctx2.fillStyle = "#c084fc"; ctx2.font = F(15, true);
      ctx2.fillText("像 神秘雕像", W / 2, py3 + 26);
      ctx2.fillStyle = "#c9c7d8"; ctx2.font = F(12);
      ctx2.fillText("献祭25%生命 · 70%强化 / 20%金币 / 5%落空 / 5%损失20%金币", W / 2, py3 + 48);
      const abw = 150, abx = W / 2 - abw / 2, aby = py3 + 58;
      ctx2.fillStyle = "#7c6cf0"; roundRect(abx, aby, abw, 26, 8); ctx2.fill();
      ctx2.fillStyle = "#fff"; ctx2.font = F(13, true);
      ctx2.fillText("点击献祭", W / 2, aby + 18);
      RG.statueRect = { x: abx, y: aby, w: abw, h: 26 };
    }
    if (RG.state === "levelup") drawLevelUp();
    if (RG.state === "pause") drawPause();
    if(RG.state==="countdown"&&RG.runCountdown){
      RG.offerRects=[];RG.btnRects=[];RG.activeRects=[];RG.uiNav=[];
      ctx2.fillStyle="rgba(11,13,20,.42)";ctx2.fillRect(0,0,W,H);
      ctx2.font=F(76,true);ctx2.textAlign="center";ctx2.fillStyle="#f4f0ff";ctx2.fillText(String(Math.max(1,Math.ceil(RG.runCountdown.remaining))),W/2,H/2+24);
      ctx2.font=F(15,true);ctx2.fillStyle="#d9b879";ctx2.fillText("准备继续",W/2,H/2+60);
    }
    const dying=RG.state==="over"&&RG.deathFx;
    const red=dying?.24*(.5+.5*RG.deathFx.remaining/RG.deathFx.duration):Math.min(.1,(RG.hurtFx?.red||0)*.4);
    if(red>0){
      ctx2.save();ctx2.fillStyle="#a5102c";ctx2.globalAlpha=red*.35;ctx2.fillRect(0,0,W,H);
      const shade=ctx2.createRadialGradient(W/2,H/2,Math.min(W,H)*.25,W/2,H/2,Math.hypot(W,H)*.6);
      shade.addColorStop(0,"rgba(125,8,30,0)");shade.addColorStop(1,"rgba(180,15,44,1)");
      ctx2.fillStyle=shade;ctx2.globalAlpha=red*2.3;ctx2.fillRect(0,0,W,H);ctx2.restore();
    }
    if(dying){RG.overRects=[];RG.uiNav=[];}else if (RG.state === "over") drawOver();
    if (RG.state === "win") drawWin();
  };

  // ---- C-11 HUD 像素条辅助(v8.18)----
  const _hudTint = {};
  function hudTintFill(color) {   // 填充图叠色缓存:平铺目标色保可读,再 30% 叠回原纹理留层次(纯 multiply 会把暗紫底压成近黑)
    const img = artReady("hudfill");
    if (!img) return null;
    if (!_hudTint[color]) {
      try {
        const c = document.createElement("canvas");
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        const cc = c.getContext("2d");
        cc.drawImage(img, 0, 0);
        cc.globalCompositeOperation = "source-in";
        cc.fillStyle = color; cc.fillRect(0, 0, c.width, c.height);
        cc.globalCompositeOperation = "source-atop";
        cc.globalAlpha = 0.3;
        cc.drawImage(img, 0, 0);
        cc.globalAlpha = 1;
        _hudTint[color] = c;
      } catch (err) { return null; }
    }
    return _hudTint[color];
  }
  function drawHudTri(img, x, y, w, h, cap) {   // 三段拉伸:端帽原尺寸不缩放,中段逐列一致可任意拉伸
    const sw = img.naturalWidth || img.width, sh = img.naturalHeight || img.height;   // v8.19:Canvas 源无 naturalWidth(曾致填充静默不绘制)
    ctx2.imageSmoothingEnabled = false;
    if (w < cap * 2) {   // 过窄:按比例只画左帽一段
      ctx2.drawImage(img, 0, 0, Math.max(2, sw * w / (cap * 2)), sh, x, y, w, h);
      ctx2.imageSmoothingEnabled = true; return;
    }
    ctx2.drawImage(img, 0, 0, cap, sh, x, y, cap, h);
    if (w > cap * 2) ctx2.drawImage(img, cap, 0, sw - cap * 2, sh, x + cap, y, w - cap * 2, h);
    ctx2.drawImage(img, sw - cap, 0, cap, sh, x + w - cap, y, cap, h);
    ctx2.imageSmoothingEnabled = true;
  }
  function drawHudBarsGeo(hw, ox, oy) {   // 缺图回退:原几何血条/经验条
    const P = RG.P;
    ctx2.fillStyle = "rgba(255,255,255,0.12)"; ctx2.fillRect(ox, oy + 6, hw, 16);
    ctx2.fillStyle = "#ef4444"; ctx2.fillRect(ox, oy + 6, hw * clamp(Math.max(0, P.hp) / P.maxhp, 0, 1), 16);
    ctx2.strokeStyle = "rgba(255,255,255,0.35)"; ctx2.lineWidth = 1; ctx2.strokeRect(ox, oy + 6, hw, 16);
    ctx2.fillStyle = "rgba(255,255,255,0.12)"; ctx2.fillRect(ox, oy + 30, hw, 10);
    ctx2.fillStyle = "#22d3ee"; ctx2.fillRect(ox, oy + 30, hw * clamp(P.xp / P.xpNext, 0, 1), 10);
  }
  // 手机小面板沿用像素条的双层紫边、阶梯切角和亮角钉。
  function mobileHudPanel(x, y, w, h) {
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    ctx2.fillStyle = "#302646"; pixelRect(x, y, w, h, 5); ctx2.fill();
    ctx2.fillStyle = "#776d9e"; pixelRect(x + 1, y + 1, w - 2, h - 2, 4); ctx2.fill();
    ctx2.fillStyle = "rgba(9,14,26,.96)"; pixelRect(x + 3, y + 3, w - 6, h - 6, 4); ctx2.fill();
    ctx2.fillStyle = "#b8a8e5"; ctx2.fillRect(x + 7, y + 1, w - 14, 1);
    ctx2.fillStyle = "#4a3b6e"; ctx2.fillRect(x + 7, y + h - 3, w - 14, 1);
    ctx2.fillStyle = "#e2dcff";
    for (const [px, py] of [[x + 3, y + 4], [x + w - 5, y + 4], [x + 3, y + h - 6], [x + w - 5, y + h - 6]]) ctx2.fillRect(px, py, 2, 2);
  }
  function mobileHudCoin(x, y, size) {
    drawUiIcon('coin',x,y,size);
  }
  function mobileHudNumber(value) {
    const n = Math.max(0, Math.floor(value || 0));
    if (n >= 1e8) return (Math.floor(n / 1e7) / 10) + "亿";
    if (n >= 1e4) return (Math.floor(n / 1e3) / 10) + "万";
    if (n >= 1000) return (Math.floor(n / 100) / 10) + "千";
    return String(n);
  }
  function drawHUD() {
    const W = RG.W, H = RG.H, P = RG.P;
    const safe = RG.safe || { top: 0, right: 0, bottom: 0, left: 0 }, hx0 = (RG.touchMode?10:18) + safe.left, hy0 = (RG.touchMode?6:12) + safe.top;
    const hud = (W < 760 ? 0.7 : 1) * (RG.touchMode?.9:1);   // 小屏整体缩小 HUD,给游戏画面留视野
    const hw = Math.min(210, W * 0.4) * hud;
    const FH = (s, b) => F(s * hud, b);
    // C-11 像素条(v8.18):三段拉伸(端帽原尺寸不缩放,中段逐列一致可拉伸),填充按比例裁宽;
    // 血/经验共用填充图,初始化时 multiply+destination-in 叠色(保留明暗层次);缺图回退几何绘制
    const hudFrame = artReady("hudframe"), hudFill = artReady("hudfill");
    ctx2.save();if(RG.touchMode){ctx2.translate(hx0,hy0);ctx2.scale(1,.9);ctx2.translate(-hx0,-hy0);}
    if (hudFrame && hudFill) {
      const hpFill = hudTintFill("#ef4444"), xpFill = hudTintFill("#22d3ee");
      if (hpFill && xpFill) {
        const hpRatio = clamp(Math.max(0, P.hp) / P.maxhp, 0, 1), xpRatio = clamp(P.xp / P.xpNext, 0, 1);
        drawHudTri(hpFill, hx0 + 10, hy0 + 4, Math.round((hw - 20) * hpRatio), 16, 6);      // 血填充(腔内)
        drawHudTri(hudFrame, hx0, hy0, hw, 24, 10);                                        // 血框盖在上层
        drawHudTri(xpFill, hx0 + 10, hy0 + 30, Math.round((hw - 20) * xpRatio), 16, 6);
        drawHudTri(hudFrame, hx0, hy0 + 26, hw, 24, 10);
      } else drawHudBarsGeo(hw, hx0, hy0);
    } else drawHudBarsGeo(hw, hx0, hy0);
    ctx2.restore();
    ctx2.fillStyle = "#fff"; ctx2.textAlign = "left"; ctx2.font = FH(11);
    ctx2.fillText(Math.max(0, Math.ceil(P.hp)) + " / " + Math.round(P.maxhp), hx0 + hw + 6, hy0 + 16);
    ctx2.fillText("Lv " + P.level, hx0, hy0 + 54 * hud + 12);
    if (P.shieldMax > 0) {
      ctx2.fillStyle = "#38bdf8"; ctx2.font = FH(12);
      ctx2.fillText("◈".repeat(P.shield) + "◇".repeat(P.shieldMax - P.shield), hx0, hy0 + 72 * hud + 10);
    }
    // 构筑一览(窄屏只显示数量,宽屏全列)
    let ix = hx0, iy = hy0 + (P.shieldMax > 0 ? 90 : 76) * hud + 6;
    ctx2.font = FH(12);
    const buildCount = Object.keys(P.weapons).length + Object.keys(P.passives).length;
    if (W < 760) {
      ctx2.fillStyle = "#8b8fa8";
      ctx2.fillText("构筑 " + buildCount, hx0, iy);
    } else {
      // 宽屏:武器全列(彩色),被动只显汇总,构筑详情看死亡结算
      for (const id in P.weapons) {
        const t = RG.WEAPONS[id].name + (P.evolved[id] ? "★" : " " + P.weapons[id]);
        ctx2.fillStyle = RG.WEAPONS[id].color; ctx2.fillText(t, ix, iy); ix += ctx2.measureText(t).width + 14;
        if (ix > W - safe.right - 200) { ix = hx0; iy += 16; }
      }
      const pc = Object.keys(P.passives).length;
      ctx2.fillStyle = "#8b8fa8";
      ctx2.fillText("被动 x" + pc + (P.evoCount ? " · ★进化 x" + P.evoCount : ""), hx0, iy + 20);
      // 进化条件提示(满级未进化武器)
      const hints = RG.evoHints();
      if (hints.length) {
        ctx2.font = FH(11);
        ctx2.fillStyle = hints.some(h => h.includes("★")) ? "#ffd166" : "#8b8fa8";
        ctx2.fillText("★ " + hints.join(" · "), hx0, iy + 36);
      }
    }
    // 手机布局只依赖屏幕和安全区，当前血量、击杀和金币不会推动顶部位置。
    const mobile = !!RG.touchMode, portrait = H > W;
    const pauseBox = { x: W - safe.right - 48, y: safe.top + 4, w: 44, h: 44, action: "pause" };
    const scoreW = W < 760 ? 108 : 120, scoreX = pauseBox.x - 6 - scoreW;
    const badgeW = W < 760 ? 100 : 112, badgeH = W < 760 ? 22 : 28;
    const centerX = mobile && !portrait ? clamp(W / 2, hx0 + hw + 6 + (W < 760 ? 70 : 90) + 30 * hud, scoreX - badgeW / 2 - 6) : W / 2;
    const timeY = safe.top + (mobile ? portrait?98:30*hud+5 : 42*hud+8);
    const badgeY = timeY + 8;
    let mobileLabel = "";
    if (mobile) {
      ctx2.textAlign = "center"; ctx2.font = FH(30, true); ctx2.fillStyle = "#e8e6f0";
      ctx2.fillText(RG.fmtTime(RG.run.t), centerX, timeY);
      if (RG.portal?.exit) mobileLabel = "寻找秘境出口";
      else if (RG.run.boss && !RG.run.boss.dead) mobileLabel = "";
      else if (RG.run.rushMode) mobileLabel = "连战 " + RG.run.rushLv + " · " + Math.ceil(RG.run.cardT) + "s";
      else if (RG.realm?.active) mobileLabel = "秘境探索中";
      else if (RG.run.bossNum < RG.mapConfig().bosses.length) mobileLabel = "首领 " + RG.fmtTime(Math.max(0, RG.run.bossT || 0));
      if (mobileLabel) {
        const x = centerX - badgeW / 2;
        mobileHudPanel(x, badgeY, badgeW, badgeH);
        const icon = W < 760 ? 18 : 22;
        drawEnemyIcon("grunt", x + 7, badgeY + (badgeH - icon) / 2, icon);
        ctx2.font = FH(12, true); ctx2.fillStyle = "#e8e6f0";
        ctx2.fillText(mobileLabel, x + (badgeW + icon + 8) / 2, badgeY + badgeH / 2 + 4 * hud, badgeW - icon - 21);
      }
    } else {
    ctx2.textAlign = "center"; ctx2.font = FH(30, true);
    ctx2.fillStyle = "#e8e6f0"; ctx2.fillText(RG.fmtTime(RG.run.t), W / 2, safe.top + 42 * hud + 8);
    // 击杀连击(10 连以上才显示)
    if ((RG.combo || 0) >= 10) {
      const pulse = 1 + Math.max(0, (RG.comboT || 0) - 2.3) * 1.2;
      ctx2.save(); ctx2.translate(W / 2, 42 * hud + 32); ctx2.scale(pulse, pulse);
      ctx2.fillStyle = RG.combo >= 25 ? "#ffd166" : "#c9c7d8"; ctx2.font = FH(14, true);
      ctx2.fillText("⚡ " + RG.combo + " 连击", 0, 0);
      ctx2.restore();
    }
    // 钥匙计数
    const keysHeld = RG.keysHeld || 0;
    if (RG.keyItems.length || keysHeld) {
      let kx = W / 2 - ((RG.keyItems.length + keysHeld) * 20) / 2;
      ctx2.font = FH(13);
      for (let i = 0; i < keysHeld; i++) { ctx2.fillStyle = "#ffd166"; ctx2.fillText("钥", kx + 10, 66 * hud + 14); kx += 20; }
      for (let i = 0; i < RG.keyItems.length; i++) { ctx2.fillStyle = "#565a70"; ctx2.fillText("钥", kx + 10, 66 * hud + 14); kx += 20; }
    }
    }
    // 手机只让短时状态进入战场，长期目标移入暂停详情。
    let stackY = mobile ? (mobileLabel ? badgeY + badgeH + 17 * hud : timeY + 30 * hud) : safe.top + 88 * hud + 10;
    if (mobile && (RG.combo || 0) >= 10) {
      ctx2.font = FH(14, true); ctx2.fillStyle = RG.combo >= 25 ? "#ffd166" : "#c9c7d8";
      ctx2.fillText("⚡ " + RG.combo + " 连击", centerX, stackY); stackY += 20 * hud;
    }
    if (mobile && (RG.keyItems.length || RG.keysHeld)) {
      ctx2.font = FH(11); ctx2.fillStyle = "#ffd166";
      ctx2.fillText("钥匙 " + (RG.keysHeld || 0) + " / 3", centerX, stackY); stackY += 20 * hud;
    }
    let objective = "";
    if (!mobile && RG.run.rushMode) {
      objective = "† 连战 第" + RG.run.rushLv + "关 · "+RG.rushDifficulty(RG.run.rushDifficulty).name+" · 补给 " + Math.ceil(RG.run.cardT) + "s";
    }
    else if (!mobile && RG.realm && RG.realm.active) objective = (RG.keysHeld || 0) >= 3 ? "目标 · 寻找出口返回主战场" : "目标 · 收集秘境钥匙 " + (RG.keysHeld || 0) + " / 3";
    else if (!mobile && RG.run.boss && !RG.run.boss.dead) objective = "目标 · 击败 " + RG.run.boss.name;
    else if (!mobile && !RG.run.finalBoss) objective = (RG.run.bossNum<RG.mapConfig().bosses.length?"下一首领 " + RG.fmtTime(Math.max(0, RG.run.bossT || 0)) + " · ":"")+"终局 " + RG.fmtTime(Math.max(0, RG.run.finalT - RG.run.t));
    if(RG.crossfireTrial())objective=(mobile?'互 · 借敌杀敌':'互 · 借敌杀敌 · ')+(mobile?'':objective);
    if (objective) {
      ctx2.font = FH(11, true);const width=Math.min(W-24,ctx2.measureText(objective).width+20);
      ctx2.fillStyle="rgba(13,18,29,.82)";ctx2.fillRect((W-width)/2,stackY-14*hud,width,20*hud);
      ctx2.fillStyle = "#d3d5df";ctx2.fillText(objective, W / 2, stackY);
      stackY += 20 * hud;
    }
    if(!mobile&&!RG.run.rushMode&&!RG.realm.active&&!RG.run.boss&&RG.run.squad?.primary){
      const label="当前攻势 · "+RG.ETYPES[RG.run.squad.primary].name;ctx2.font=FH(10);const width=ctx2.measureText(label).width+20;
      ctx2.fillStyle="rgba(13,18,29,.82)";ctx2.fillRect((W-width)/2,stackY-12*hud,width,18*hud);
      ctx2.fillStyle="#d3d5df";ctx2.fillText(label,W/2,stackY);stackY+=18*hud;
    }
    if (RG.timeStop > 0) {
      ctx2.fillStyle = "#7dd3fc"; ctx2.font = FH(15, true);
      ctx2.fillText("⏱ 时间静止 " + RG.timeStop.toFixed(1) + "s", W / 2, stackY);
      stackY += 22 * hud;
    }
    if (RG.auraT > 0) {
      ctx2.fillStyle = "#ffd166"; ctx2.font = FH(15, true);
      ctx2.fillText("✦ 惩戒光环 " + RG.auraT.toFixed(1) + "s", W / 2, stackY);
      stackY += 22 * hud;
    }
    if(P.howlDebuffT>0){ctx2.fillStyle="#f0abfc";ctx2.font=F(12,true);ctx2.fillText("哀嚎 · 攻击↓ 减伤↓ "+P.howlDebuffT.toFixed(1)+"s",W/2,stackY);stackY+=22;}
    if (P.overdriveT > 0) {
      ctx2.fillStyle = "#fbbf24"; ctx2.font = FH(15, true);
      ctx2.fillText('⚡ '+(RG.overdriveCast(P)?.name||'超频')+' '+P.overdriveT.toFixed(1)+'s',W/2,stackY);
      stackY += 22 * hud;
    }else if(P.overdriveWeakT>0){
      ctx2.fillStyle='#fb923c';ctx2.font=FH(15,true);ctx2.fillText('虚弱 '+P.overdriveWeakT.toFixed(1)+'s',W/2,stackY);stackY+=22*hud;
    }
    if (P.activeGuard > 0) {
      ctx2.fillStyle = "#38bdf8"; ctx2.font = FH(14, true);
      const aegis=RG.aegisCast(P),extra=P.aegisEvoT>0?(aegis?.id==='void'?' · 消弹'+(P.aegisCleared||0)+(P.aegisCleared>=999?'+':''):aegis?.id==='mirror'?' · 反射'+(P.aegisReflected||0):''):'';
      ctx2.fillText('◈ '+(P.aegisEvoT>0?aegis?.name||'相位格挡':'相位格挡')+' ×'+P.activeGuard+extra,W/2,stackY);
      stackY += 22 * hud;
    }
    if (RG.realm && RG.realm.active) {
      ctx2.fillStyle = "#c084fc"; ctx2.font = FH(14, true);
      ctx2.fillText("秘境 Lv" + RG.realm.lv, W / 2, stackY);
    }
    if (mobile) {
      const sy = safe.top + 8, sh = 32, icon = W < 760 ? 14 : 16, coinX = scoreX + scoreW - 48;
      mobileHudPanel(scoreX, sy, scoreW, sh);
      ctx2.textAlign = "left"; ctx2.font = FH(12, true); ctx2.fillStyle = "#e8e6f0";
      ctx2.fillText("击杀 " + mobileHudNumber(RG.run.kills), scoreX + 10, sy + 23, scoreW - 66);
      mobileHudCoin(coinX, sy + (sh - icon) / 2, icon);
      ctx2.fillStyle = "#fff0ba"; ctx2.fillText(mobileHudNumber(RG.runShopBalance()), coinX + icon + 5, sy + 23, scoreW - (coinX - scoreX) - icon - 13);
    } else {
    ctx2.textAlign = "right"; ctx2.font = FH(13); ctx2.fillStyle = "#8b8fa8";
    ctx2.fillText("击杀 " + RG.run.kills, W - safe.right - 18, safe.top + 26);
    ctx2.fillStyle = "#ffd166";
    drawCurrency(RG.runShopBalance(),{x:W-safe.right-148,y:safe.top+29,w:138,h:24},{align:'right',fontSize:12,iconSize:18,color:'#fff0ba'});
    if (W >= 760) { ctx2.fillStyle = "#8b8fa8"; ctx2.fillText("最佳 " + RG.fmtTime(RG.best.time), W - safe.right - 18, safe.top + 66); }
    }
    ctx2.textAlign = "right"; ctx2.fillStyle = "#3c405c"; ctx2.font = FH(10);
    ctx2.fillText(RG.VERSION || "", W - safe.right - 18, H - safe.bottom - 10);
    if (RG.run.boss && !RG.run.boss.dead) {
      const bw = Math.min(460, W - 80);
      ctx2.fillStyle = "rgba(255,255,255,0.12)"; ctx2.fillRect(W / 2 - bw / 2, H - safe.bottom - 40, bw, 12);
      ctx2.fillStyle = RG.run.boss.enraged ? "#ff5470" : "#a855f7";
      ctx2.fillRect(W / 2 - bw / 2, H - safe.bottom - 40, bw * clamp(RG.run.boss.hp / RG.run.boss.maxhp, 0, 1), 12);
      if(RG.run.boss.frost&&RG.run.boss.shieldHp>0){ctx2.fillStyle='#38bdf8';ctx2.fillRect(W/2-bw/2,H-safe.bottom-40,bw*clamp(RG.run.boss.shieldHp/RG.run.boss.maxhp,0,1),3);}
      ctx2.fillStyle = "#fff"; ctx2.textAlign = "center"; ctx2.font = FH(13, true);
      ctx2.fillText(RG.run.boss.name + (RG.run.boss.frost ? (RG.run.boss.enraged?" · 二阶段":"")+(RG.run.boss.shieldHp>0?" · 盾 "+Math.ceil(RG.run.boss.shieldHp):"") : RG.run.boss.enraged ? " !狂暴" : ""), W / 2, H - safe.bottom - 46);
    }
    // 触屏按钮:暂停 / 静音(右上角小圆钮)
    RG.btnRects = [];
    if(P.hurtFlash>0){ctx2.save();ctx2.globalAlpha=Math.min(.25,P.hurtFlash*1.2);ctx2.fillStyle='#ff5470';ctx2.fillRect(0,0,W,7);ctx2.fillRect(0,H-7,W,7);ctx2.fillRect(0,7,7,H-14);ctx2.fillRect(W-7,7,7,H-14);ctx2.restore();}
    const touch = !!RG.touchMode;
    const br = touch ? 25 : 21, bx = W - safe.right - (touch ? 44 : 40);
    if (mobile) {
      mobileHudPanel(pauseBox.x + 6, pauseBox.y + 6, 32, 32);
      ctx2.fillStyle = "#f4f0ff"; ctx2.fillRect(pauseBox.x + 15, pauseBox.y + 14, 4, 16); ctx2.fillRect(pauseBox.x + 25, pauseBox.y + 14, 4, 16);
      RG.btnRects.push(pauseBox);
    }
    const defs = mobile ? [] : [
      { action: "pause", x: bx - 70, y: safe.top + 96, glyph: "❚❚" },
      { action: "mute", x: bx, y: safe.top + 96, glyph: RG.muted ? "🔇" : "🔊" },
    ];
    for (const d of defs) {
      ctx2.fillStyle = "rgba(255,255,255,0.10)";
      ctx2.beginPath(); ctx2.arc(d.x, d.y, br, 0, TAU); ctx2.fill();
      ctx2.strokeStyle = "rgba(255,255,255,0.3)"; ctx2.lineWidth = 1.5;
      ctx2.beginPath(); ctx2.arc(d.x, d.y, br, 0, TAU); ctx2.stroke();
      ctx2.fillStyle = "#e8e6f0"; ctx2.textAlign = "center"; ctx2.font = FH(13, d.action === "pause");
      ctx2.fillText(d.glyph, d.x, d.y + 5);
      const mrg = d.action === "mute" ? 4 : 6;
      RG.btnRects.push({ x: d.x - br - mrg, y: d.y - br - mrg, w: br * 2 + mrg * 2, h: br * 2 + mrg * 2, action: d.action });
    }
    // 冲刺大按钮(右侧拇指区,面积加大,矢量双箭头图标)
    const layout=RG.getControlLayout(W,H,safe),hitDr=layout[0].r,dr=touch?hitDr*.86:hitDr,dxb=layout[0].x,dyb=layout[0].y;
    const cd = P.dashCd || 0, ready = cd <= 0;
    const dashImg = artReady("dashbtn");
    if (dashImg) {   // C-11 像素按钮底(中央 52×52 留白给矢量图标);冷却整钮压暗
      ctx2.imageSmoothingEnabled = false;
      ctx2.globalAlpha = ready ? 1 : 0.5;
      ctx2.drawImage(dashImg, dxb - dr, dyb - dr, dr * 2, dr * 2);
      ctx2.globalAlpha = 1;
      ctx2.imageSmoothingEnabled = true;
    } else {
      ctx2.fillStyle = ready ? "rgba(124,108,240,0.30)" : "rgba(255,255,255,0.08)";
      ctx2.beginPath(); ctx2.arc(dxb, dyb, dr, 0, TAU); ctx2.fill();
      ctx2.strokeStyle = ready ? "rgba(154,140,255,0.95)" : "rgba(255,255,255,0.25)";
      ctx2.lineWidth = 2.5;
      ctx2.beginPath(); ctx2.arc(dxb, dyb, dr, 0, TAU); ctx2.stroke();
      if (ready) {
        // 就绪光晕
        ctx2.strokeStyle = "rgba(154,140,255,0.35)"; ctx2.lineWidth = 6;
        ctx2.beginPath(); ctx2.arc(dxb, dyb, dr + 5, 0, TAU); ctx2.stroke();
      }
    }
    if (!ready) {
      // 冷却扇形遮罩 + 秒数(贴图/几何共用)
      ctx2.fillStyle = "rgba(11,13,20,0.65)";
      ctx2.beginPath(); ctx2.moveTo(dxb, dyb);
      ctx2.arc(dxb, dyb, dr + 0.5, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(cd / (P.dashCdMax || 3 * (P.dashCdMul || 1) * (P.globalCdMul || 1)), 0, 1));
      ctx2.closePath(); ctx2.fill();
    }
    // 矢量双箭头(贴图时略收进中央留白)
    const u = dr / (dashImg ? 24 : 21);
    ctx2.strokeStyle = ready ? "#f5f3ff" : "rgba(232,230,240,0.12)";
    ctx2.lineWidth = 3.5 * u; ctx2.lineCap = "round"; ctx2.lineJoin = "round";
    ctx2.beginPath();
    ctx2.moveTo(dxb - 11 * u, dyb - 12 * u); ctx2.lineTo(dxb - 1 * u, dyb); ctx2.lineTo(dxb - 11 * u, dyb + 12 * u);
    ctx2.moveTo(dxb + 2 * u, dyb - 12 * u); ctx2.lineTo(dxb + 12 * u, dyb); ctx2.lineTo(dxb + 2 * u, dyb + 12 * u);
    ctx2.stroke();
    if (!ready) {
      ctx2.fillStyle = "#e8e6f0"; ctx2.textAlign = "center"; ctx2.font = FH(Math.max(16, dr * 0.5), true);
      ctx2.fillText((cd < 1 ? cd.toFixed(1) : Math.ceil(cd)), dxb, dyb + dr * 0.18);
    }
    RG.btnRects.push({ x: dxb - hitDr - 4, y: dyb - hitDr - 4, w: (hitDr + 4) * 2, h: (hitDr + 4) * 2, action: "dash" });
    // 主动技能按钮:触屏纵向排在冲刺上方，桌面横向排在冲刺左侧。
    RG.activeRects = [];
    const activeIds = (P.activeOrder || []).slice(0, 2);
    for (let i = 0; i < activeIds.length; i++) {
      const id = activeIds[i], def = RG.ACTIVES[id], acd = RG.activeWait(P,id);
      const ar=layout[i+1].r,ax=layout[i+1].x,ay=layout[i+1].y;
      ctx2.fillStyle='rgba(12,16,25,.88)';pixelRect(ax-ar,ay-ar,ar*2,ar*2,5);ctx2.fill();
      ctx2.strokeStyle = acd <= 0 ? def.color : "rgba(255,255,255,0.24)"; ctx2.lineWidth = 2;
      pixelRect(ax-ar,ay-ar,ar*2,ar*2,5);ctx2.stroke();if(!drawCardAtlasIcon(id,ax-ar*.78,ay-ar*.78,ar*1.56)){ctx2.fillStyle=def.color;ctx2.font=FH(18,true);ctx2.textAlign='center';ctx2.fillText(def.glyph,ax,ay+6);}
      if (acd > 0) {
        const full = Math.max(1, def.cooldown(P.actives[id])*(P.globalCdMul||1));
        ctx2.fillStyle = "rgba(11,13,20,0.68)"; ctx2.beginPath(); ctx2.moveTo(ax, ay);
        ctx2.arc(ax, ay, ar + 0.5, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(acd / full, 0, 1)); ctx2.closePath(); ctx2.fill();
      }
      ctx2.fillStyle = acd <= 0 ? "#fff" : "#c9c7d8"; ctx2.textAlign = "center"; ctx2.font = FH(touch ? 18 : 15, true);
      if(acd>0){ctx2.fillStyle='#10151d';ctx2.fillRect(ax-16,ay-10,32,24);ctx2.fillStyle='#fff';ctx2.fillText(Math.ceil(acd),ax,ay+7);}
      ctx2.fillStyle = '#e9e4d9'; ctx2.font = FH(9, true);ctx2.fillText(touch?(RG.activeEvolution(P,id)?.name||def.name):RG.keyLabel(RG.controls?.bindings[i===0?'active1':'active2']||RG.DEFAULT_KEYS[i===0?'active1':'active2']),ax,ay+ar-3,ar*2-6);
      RG.activeRects.push({ x: ax - ar - 5, y: ay - ar - 5, w: (ar + 5) * 2, h: (ar + 5) * 2, slot: i });
    }
    // 首局前 22 秒的分段引导:只讲当前最需要知道的一件事。
    if (RG.run.t < 22 && !RG.run.boss && (!RG.meta || (RG.meta.runs || 0) < 1)) {
      const msg = RG.run.t < 7
        ? (touch ? "左侧拖动移动 · 右侧按钮冲刺" : [RG.controls?.bindings.up||'w',RG.controls?.bindings.left||'a',RG.controls?.bindings.down||'s',RG.controls?.bindings.right||'d'].map(RG.keyLabel).join('')+' 移动 · '+RG.keyLabel(RG.controls?.bindings.dash||' ')+'冲刺')
        : RG.run.t < 14 ? "攻击会自动锁定敌人，专心走位"
        : "升级时选择卡牌，逐步形成自己的构筑";
      const tw = Math.min(W - safe.left - safe.right - 36, 420), ty = H - safe.bottom - (touch ? 26 : 20);
      ctx2.fillStyle = "rgba(11,13,20,0.58)"; roundRect(W / 2 - tw / 2, ty - 23, tw, 30, 10); ctx2.fill();
      ctx2.fillStyle = "#c9c7d8"; ctx2.textAlign = "center"; ctx2.font = FH(12, true); ctx2.fillText(msg, W / 2, ty - 3);
    }
    if (H > W) {
      ctx2.textAlign = "center"; ctx2.fillStyle = "#565a70"; ctx2.font = F(12);
      ctx2.fillText("建议横屏体验", W / 2, H - safe.bottom - 60);
    }
  }

  function card(x, y, w, h, info, tag, compact, s) {
    s = s || 1;
    const hover = !RG.touchMode && RG.mouse && RG.mouse.x >= x && RG.mouse.x <= x + w && RG.mouse.y >= y && RG.mouse.y <= y + h;
    ctx2.save();
    if (hover) { ctx2.fillStyle = "rgba(0,0,0,0.42)"; pixelRect(x + 5, y + 6, w, h, 8); ctx2.fill(); }
    ctx2.fillStyle = hover ? "rgba(27,32,43,0.99)" : "rgba(12,16,24,0.97)";
    pixelRect(x, y, w, h, 8); ctx2.fill();
    ctx2.strokeStyle = info.color; ctx2.lineWidth = hover ? 4 : 3;
    pixelRect(x, y, w, h, 8); ctx2.stroke();
    ctx2.strokeStyle = "rgba(255,255,255,0.08)"; ctx2.lineWidth = 1;
    pixelRect(x + 5, y + 5, w - 10, h - 10, 5); ctx2.stroke();
    // 罪纹角标:传说/诅咒档加暗红缺口点缀
    if (info && (info.q || 0) >= 5) {
      ctx2.fillStyle = "#F04A66";
      ctx2.fillRect(x + 2, y + 2, 5, 5); ctx2.fillRect(x + w - 7, y + 2, 5, 5);
      ctx2.fillRect(x + 2, y + h - 7, 5, 5); ctx2.fillRect(x + w - 7, y + h - 7, 5, 5);
    }
    ctx2.restore();
    ctx2.textAlign = "center";
    const iconImg = info.icon && RG.CARD_ICON[info.icon] && RG.CARD_ICON[info.icon].complete && RG.CARD_ICON[info.icon].naturalWidth > 0 ? RG.CARD_ICON[info.icon] : null;
    const iconSize = clamp(h * (compact ? 0.31 : 0.34), 34, compact ? 56 : 68);
    const iconY = y + 10 * s, iconX = x + (w - iconSize) / 2;
    if (iconImg) {
      ctx2.save(); ctx2.imageSmoothingEnabled = false;
      ctx2.drawImage(iconImg, iconX, iconY, iconSize, iconSize);
      ctx2.restore();
    } else if (!drawCardAtlasIcon(info.icon, iconX, iconY, iconSize)) {
      ctx2.fillStyle = "rgba(255,255,255,0.055)"; pixelRect(iconX, iconY, iconSize, iconSize, 6); ctx2.fill();
      ctx2.strokeStyle = info.color; ctx2.lineWidth = 2; pixelRect(iconX, iconY, iconSize, iconSize, 6); ctx2.stroke();
      ctx2.fillStyle = info.color; ctx2.font = F(iconSize * 0.46, true);
      ctx2.fillText(info.glyph || (info.title || "?").replace(/^.*·\s*/, "").trim().charAt(0), x + w / 2, iconY + iconSize * 0.67);
    }
    const titleY = iconY + iconSize + 19 * s;
    ctx2.fillStyle = info.color; ctx2.font = F((compact ? 13.5 : 15.5) * s, true);
    ctx2.fillText((info.title || "") + (info.lv ? "  " + info.lv : ""), x + w / 2, titleY, w - 18 * s);
    const descY = titleY + 18 * s;
    if (descY < y + h - 24 * s) {
      ctx2.fillStyle = "#c9c7d8"; ctx2.font = F((compact ? 10.5 : 11.5) * s);
      const maxLines = Math.max(1, Math.floor((y + h - 28 * s - descY) / (14 * s)) + 1);
      wrapText(info.desc, x + w / 2, descY, w - 22 * s, 14 * s, Math.min(compact ? 2 : 3, maxLines));
    }
    ctx2.fillStyle = "#565a70"; ctx2.font = F(11 * s);
    ctx2.fillText(tag, x + w / 2, y + h - 9 * s);
  }

  function drawLevelUp() { RG.pageScroll["levelup"]={y:0,max:0}; RG.drawAdaptiveOverlay("levelup"); }

  function drawPause() { RG.pageScroll["pause"]={y:0,max:0}; RG.drawAdaptiveOverlay("pause"); }

  function drawOver() { RG.pageScroll["over"]={y:0,max:0}; RG.drawAdaptiveOverlay("over"); }

  function drawWin() { RG.drawAdaptiveOverlay("win"); }
  // 旧版单页武器墙已由 H4 分层主页替代。
  // H5 菜单模块只通过这一组稳定绘制原语接触世界渲染，避免反向依赖私有实现。
  RG.DrawKit={drawUiIcon,drawCurrency,drawPlayerPortrait,drawEnemyIcon,ctx2,F,roundRect,pixelRect,artReady,drawCover,drawCardAtlasIcon,drawBossCell,card,BOSS_ATLAS_CELLS,hudTintFill,drawHudTri};

  RG.DRAW_WORLD_VER="v12032";
})(window.RG);
